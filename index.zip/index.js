
window.FbRelease = true
window.screenOrientation="sensor_landscape",loadLib("libs/laya.core.js"),loadLib("libs/laya.ui.js"),loadLib("libs/laya.physics3D.js"),loadLib("libs/laya.d3.js"),loadLib("js/main.js");