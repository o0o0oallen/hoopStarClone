var _0x516f = ['authenticLogin', 'btnRevival', 'formatNum', 'BallSpeed', '间隔秒数', 'visible', 'ranking/rank_2nd.png', 'func', 'regClass', 'bottom', 'timeout', 'loading/process.png', 'onMouseDownHandle', 'moveGameClickHandle', 'ChangeSkin', 'cacheData', 'sendLoadingLog', 'box/chesLight.png', 'countdown', 'MoreGameUIUI', 'startChallenges', 'recordstartHandle', 'game/icon_shareVideo.png', 'finalLose', '38,43,46,38', 'gameobject', '显示banner', '_curPage', 'EventDispatcher', 'UIMgr', 'createBannerAd', 'https://jg.yunsugames.com:8001/', '_trigger1', 'Directional\x20Light', 'onDisable', '当前时间', 'reward/result_key_2.png', 'log', '点击获取奖品', 'quadEquationGetX', '../enum/EventEnum', 'Less', 'playGame/ColorText_EXCELLENT.png', 'txtState2', '#031871', 'meshRenderer', 'screenMode', '_plane', '_preSelectId', 'res/jpg/3.jpg', 'LucktBoxUIUI', 'FreeGemTxt', 'setItem', 'trace', './script/view/OpenRewardUI', '../entity/Ball', 'AddScore', '#be22c5', 'version.json', 'ATLAS', '_headUrl', 'CupUIUI', '1111111', 'binaryEquationGetKB', 'space', 'create', 'basePath', 'stringKeyList', '__proto__', '进度条开始加载', 'matchBg', 'imgGem8', 'res/jpg/4.jpg', 'imgKey1', 'isHasBox', 'image', 'CheckReward', 'skinBg', 'HoopGravity', 'linearNone', 'txtScore', '_rankbg', 'anchorY', 'ResMgr', 'lixin-shi-shuai-ge', 'web', 'loadBannerAdAsync', 'MOUSE_MOVE', 'getComponent', 'adIcon', 'game/MainBg.jpg', '_boxClose', 'imgBG', './enum/GameConst', 'AddScoreHandle', 'getMilliseconds', '../../enum/EventEnum', 'SoundMgr', 'disabled', 'moveArrowAni', 'game/BTN_challenge.png', 'localRotation', '_referee', 'onPC', 'LoadingUIUI', 'doubleClickHandle', '看完视频后即可领取奖励！', '../../../utils/Tools', 'ForceX', 'centerY', 'imgLose', 'signDate', '_target', 'revival', 'light', 'openUI', 'onTriggerExit', 'Arabic', 'ranking/rank_di_5.png', 'Opponent', 'constructor', 'ui.view.MoreGameUIUI', 'signClickHandle', '_sleep', 'true', '_flag_renderer_right', 'startIndex', 'imageurl', 'getTimBoxTime', 'script/view/SignUI.ts', 'banner', 'HBox', 'addTimeBoxIndex', 'laya.display.Text', 'text01', '1454137928122196', 'luckyTxt', 'setItemCentorByIndex', 'LoadingUI', 'loseAd', 'BaseView', 'Time', 'getVideoRecorderManager', 'setFeedbackButtonVisible', 'prototype', '_obj', 'basestage', 'Language', 'txtGem8', '_shareCnt', 'txtGem1', 'initUnlockHoop', 'initUnlockBall', 'createInnerAudioContext', 'Animation', 'Clamp', 'shareVedioBack', './script/view/DareLoseUI', 'ui.view.OpenBoxUIUI', '_bIsNewer,_bVibration,_bSound', 'stopBGM', './manager/SceneManager', '_currentY', '_skinArr', 'cupbg', 'rankbtn', 'DareLoseUI', '_initX', '../../ui/layaMaxUI', './XGame', '_robotList', 'ranking/textdown.png', 'game/main_menu_vibroon_1.png', 'onMiniGame', 'score', 'frameRate', 'list', 'ui.view.ToppingUIUI', 'getAdCfg', 'now', 'playGame/TextGO.png', 'parse', 'signObj', 'game/mainShareVedio.png', 'InitBall', 'Dapatkan\x20permata', '_hoopArr', 'receiveobj', 'Clamp01', 'createItems', 'DataMgr', '_light', 'owner', 'creativeId', 'alignH', '_videoCount', 'imgRandom', 'prefab/SkinItem.json', 'shareCallback', 'runWith', 'tipsInfo', 'playFlagDownAnim', 'stopRandomTimer', '../../enum/ResEnum', 'initCrown', 'game/record_start.png', 'ranking/Rank_title.png', 'skin/skin_mask.png', 'loadIcon', 'getchanceHandle', '1454137928122196_', '_collider', 'debug', 'Event', 'imgLevel03', 'VivoAd', 'enable', 'ranking/textup.png', './script/view/MoreGameView', 'SetRigibody', 'addLine', '_timeBoxCointCount', '双倍奖励', 'Multiply', './manager/ResourceManager', 'RandomRange', '../../enum/UIEnum', 'Crown', 'Stage', 'initializeAsync', 'updateView', '3d/prefabs/Conventional/Particles.lh', 'changeAdIcon', 'onUpdata', 'button_daily\x20get', 'ballbtn', 'Special', 'game/main_menu_sound_2.png', '_rotation', 'imgLevel02', 'getchance', 'Portuguese', 'button_ring\x20unlock\x20', 'startGame', 'Box', 'cos', '32,16,16,28', 'Hoops', 'sharecard_config', 'ui.view.CupUIUI', 'challengeModeTxt', 'hooArr', 'rewardArr', 'level/btn_green.png', 'sign/sign_Greensigned.png', 'Desk', 'splice', 's_setSound', 'isOpenVibration', 'switchTabView', 'imgVS', 'color', 'linearVelocity', 'addChild', 'vibrateLong', 'nextpageClickHandle', 'setLoadingProgress', '45,0,44,0', 'friction', 'doSmall', 'LoadingViewUI', 'getMonth', '_gold', 'coinCount', 'overrideGravity', 'getRewardCfg', 'luckyBox', 'position', '../../../enum/ResEnum', '_dragScript', 'sqrMagnitude', '_bannerFlag', 'btnMoreGame', 'Global', 'Battle_AddScore', '../Platform', 'EAtlas', '0,78,0,75', 'game/guideLeft.png', '_currentOrder', '../../../enum/GameConst', 'addSkinList', 'RewardItem', 'Distance', 'postMessage', 'zhengckais', 'remain', 'txtGem3', '1088,85,108,58', 'Prefabs', 'defX', '7,11,8,8', 'box/btn_orange.png', './script/view/SignUI', 'rotationEuler', 'clone', '_Up', 'box', 'imgFinals', 'sort', 'spend', 'AddBall', 'Ball_light', '_coinCount', '_hoopInfoArr', 'game/rank.png', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/Number_2.lmat', '__className', 'instantiate', 'txtAddGem', '代码:', 'Jump', 'txtState1', 'login', 'close', 'box/text_claim.png', 'ui.view.OpenRewardUIUI', 'addCoinCount', '../../enum/GameConst', '../../Platform', 'rewardClickHandle', 'loopLoadIcon', 'BoxColliderShape', '1454160188119970', './item/SkinItem', '_knifeIcon', 'lang', 'game/CaptureVideo.png', 'tweenSize', 'EffMgr', 'ownrank', 'PlayGameUIUI', 'launchInfo', 'frameLoop', 'game/share_icon.png', 'txtGem7', 'key3', 'key1', 'skin/Hoop_vertical_pink_icon.png', 'alertGlobalError', 'Script3D', '0,49,0,50', 'loader', 'onConfigLoaded', 'curRound', 'clampMagnitude', 'view', '....', 'Game4399', './script/view/LucktBoxUI', 'json', 'SkinItem', 'vibration', '67,30,24,27', 'freeTxt', 'https://ssdzz-1256732840.cos.ap-guangzhou.myqcloud.com/share/tao_share3.jpg', '_offX', '_canGetTimeBox', 'dragBox', 'level/result_key_fx.png', 'dragSkinBox', 'start', 'showBannerMoveBtn', 'align', 'key', 'game/moregame.png', '_child', 'script/view/LoadingUI.ts', 'Rigidbody3D', 'end_next\x20level', 'RankOpen', '随机：', 'onLoopLeft', '45,20,43,81', 'startTimeBox', '_ZERO', 'floor', 'updateGoldHandle', 'test', 'Main\x20Camera', 'skinbtn', 'progress', 'btnStart', 'closeClickHandle', 'rankClickHandle', '3d/scenes/Conventional/Game.ls', 'gravity', './script/view/SkinUI', 'name', 'scaleMode', 'txtTimer', 'res/jpg/2.jpg', 'res/atlas/reward.atlas', '该广告位是否开启:', 'ui.view.DareLoseUIUI', 'headicon', 'human', 'script/view/SetUI.ts', 'dare/vs.png', 'sound', 'camera', '.png', 'BallTxt', 'ShowCrown', 'reward/luckTitle.png', 'GemUnlock', 'onWatchTvCallback', 'Skin', '_flag_right', 'restitution', 'signTxt', 'Microsoft\x20YaHei', 'updateItem', 'PhysicsCollider', 'ForceY', 'h5api', '19,20,25', 'game/backBTN.png', '_checkedTxt', 'stopRecord', '_getGold', 'initConfigs', '兼容错误，找不到', 'timeLabel', 'nextTxt', 'game/PlayerMark.png', '_bg', 'Robot', 'rePlaceGetNumber', 'openUI\x20error', 'transform', 'arrow', '__esModule', '/////', 'SceneMgr', 'magnitude', 'minY', 'videoClickHandle', 'imgSkin', 'setUserCloudStorage', 'button_free\x20use_ad', 'ShareSwitch', 'level/fail-xxx.png', 'createRewardedVideoAd', 'DebugPanel', '#898585', 'abs', '加载资源失败:', 'laya.d3.math.Point', 'fontSize', 'shareVedioBtn', 'getRes', 'toString', 'COLLISIONFILTERGROUP_CUSTOMFILTER2', '../../XGame', 'WebPlatform', '../enum/UIEnum', 'TouTAd', '_startX', 'getRecordState', 'CheckRewardTwo', 'res/jsons/Robot.json', 'Ball_GEM', 'removeItemObj', '_aniList', 'skin/skin_Tap_Select.png', 'winBG', 'Cannot\x20find\x20module\x20\x27', 'getChildAt', 'clearData', 'game/iocn_diamondBG.png', 'isTurnRight', 'Openid', 'btnBack', '分享录制！！', 'onMouseMoveHandle', 'res/jsons/Badge.json', 'luckyBox/LuckPan_2.png', 'bestRewardTxt', 'getInsertPointBetweenCircleAndLine', 'btnVideo', '...', 'res/atlas/box.atlas', 'getGlobalCfg', 'GetPrefab', 'catch', 'day7Gold', 'btnSharekVedio', '_hoopSkinId', '挑战结束！！', 'view/SignUI.scene', 'canPlayAd', 'Wall', 'platform', 'GemLevel', 'txtGem5', '_pool', '_isOpen', 'skin/Hoop_Duck_icon.png', 'res/jpg/1.jpg', 'mass', 'showEff', 'Res_Load_Progress', 'push', '_maxIndex', '_flag_renderer_left', 'initConfig', 'game/BTN_skin.png', 'level/level_bar1.png', 'PlayGameGemUIUI', 'logo', '30,30,30,30', 'gem', 'thisObj', '_signTotalCount', 'creId', 'clipVideo', 'top', 'script/view/LucktBoxUI.ts', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage_plane3.lmat', '_signCount', '#FFFFFF', 'initAdData', 'game/friendPlaying_small.png', 'PixelLineSprite3D', 'Reward_ClickItem', 'LocalStorage', 'Skin_ClickItem', 'send', '_crown', './script/view/LevelResultUI', './item/SignItem', '_gembg', 'https://ssdzz-1256732840.cos.ap-guangzhou.myqcloud.com/share/tao_share1.jpg', '_rewardInfo', 'res/jsons/Reward.json', 'OpenBoxUIUI', '本地加载！', 'TablePlaqueAD', 'adunit', 'FBInstant', 'needSaveMap', 'AdItem', 'onClickVedio', './script/view/LoadingUI', '../base/GameObjcet3D', 'onPreLoadResProgress', 'GetReward', 'setBg', 'OnHoppTriggerEnter', 'Utils', 'prefab/signItem.prefab', 'shareHandle', 'English', '观看完视频，立即使用皮肤！', 'game/otherADBG.png', 'sign/sign_mask.png', 'luckyBoxClickHandle', 'guideLeftHandle', 'exports', 'MaskEnum', 'random', './script/view/DareUI', 'ProgressBar', 'onUIClose', '_tipsInfoArr', '_hoopPageArr', '+9999', 'scheduleTxt', 'Text', './item/RewardItem', 'showSelected', 'maxLevel', '_trigger2', 'SkinList', 'initDebug', 'sortHandle', '_hoopUnlockList', 'reward/rewarded_video_button.png', 'watch4399Callback', 'level/level_finalDi0.png', '_getChanceCount', 'reward/LuckBG.jpg', '7,11,6,8', 'stage', 'animUpdate', 'message', '保存数据到服务器失败', 'substring', 'createInsertAd', 'elasticInOut', 'script/view/LevelResultUI.ts', 'button_daily\x20double_ad', 'isPoint', 'http', 'Phần\x20thưởng\x20mỗi\x20ngày', 'updateFeeling', 'data:', 'displayHeight', 'VideoGold', 'getSignReward', 'wxcode', '_ball', 'Angle', 'jumpFlag', '_dragFlag', 'imgGem1', '../XGame', '_curHoopId', '授权成功!', 'onTriggerStay', 'isVector2', 'play4399Ad', 'adPanel', 'RandomAISkin', 'luckyBox/text_claim.png', 'State', 'Reward_UpdateInfo', 'ui.view.LevelResultUIUI', 'distance', 'boxWin', 'onMouseDown', 'skin/skin_Tap_UnSelect.png', '自动刷新列表：', 'game/record_startText.png', 'url', 'Game', 'posId', 'prefab/signItem.json', 'content:', 'doubGetTxt', 'hago系统信息：', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage_plane4.lmat', 'resultTxt', 'Restitution', 'res/atlas/robot.atlas', 'OpenTimeBoxUIUI', 'button_chest', 'caller', 'imgSkinBG', 'videoIcon', 'localStorage', '该广告位当前配置', 'game/record_RecordingText.png', 'substr', 'OpenRewardUI', 'Vietnamese', 'imgGem2', 'fx_01', 'getKeysTxt', 'day7Knife', 'getItem', 'playGame/ColorText_SPLENDID.png', 'onShare', '_openCount', 'detail', 'skinTxt', 'txtJewel', '进度条结束加载', 'angularDamping', 'Res_Load_Complete', '_rigibody', 'show_config', 'progressStart', './script/view/LoadingView', 'Battle_UpdateFeeling', 'shareCount', 'startLoading', 'tween', 'ui.view.OpenTimeBoxUIUI', 'sendCloud', 'authorizeHandle', 'defZ', 'info', 'ranking/backBTN.png', 'TimeMgr', 'imgState1', 'ballObj', 'txtCoin', 'CLICK', '_itemArr', '../enum/GameEnum', '../enum/ResEnum', 'Skip', 'imgLine2', 'Right', '_arrow', 'elasticOut', 'GetRes', 'scale', 'feeling', 'dare/vs_di.png', 'ShowBannerTime', '_node', 'level/level_uidi_fail.png', 'pos', 'debu', 'res/jsons/ScreenFont.json', 'imgTimer', '观看完视频，获得奖励！', 'sign/sign_di.png', 'day7Txt', 'PhysicsDebugDraw', './script/view/GameUI', 'collectKeysTxt', 'game/settingDI2.png', 'adArr', '+88', 'signBg', 'currentFarm', '../enum/MaskEnum', 'reward/result_key_1.png', './manager/EffectManager', 'GameConst', 'width', 'addRedPoint', 'guideLeftHandleBig', 'initEvent', 'score_right', 'AIContral', 'redPoint', 'imgTurntable', 'imgGem', 'game/topUI.png', './Hoop', 'indexOf', 'imgLine02', 'onClickStart', 'FacebookAd', 'ToppingUIUI', 'playGame/ColorText_GREAT.png', 'Res_Load_NetFail', '剩余次数', 'onClickWatchTV', 'once', 'SignItem', 'formatTime', '分享失败!', 'gold', '_time', 'cupBg', 'initHaGoDebug', 'post', 'script/view/DareUI.ts', 'imgKey2', 'clearItems', 'game_lose', '../utils/Utils', 'DareUI', 'game/setting1.png', 'Physics', '_randomArr', 'split', 'https://ssdzz-1256732840.cos.ap-guangzhou.myqcloud.com/', './item/AdItem', 'clearAll', 'fx_06', 'isAuthorize', 'positionId', '../../../XGame', '_numberMaterial', 'min', 'getUnlockBall', 'button_free\x20draw_ad', 'openCustomerServiceConversation', 'langCfg', 'HoopForceY', '#fffdfd', '_skinList', 'COLLISIONFILTERGROUP_CUSTOMFILTER4', './manager/DataManager', 'getSeconds', '../../utils/Tools', 'game/icon_diamond.png', 'complete', 'getOpenDataContext', 'then', 'skinId', 'game/guideRight.png', 'level/gem_completeTitle.png', 'guideRightHandle', 'levelBg', 'skinnedMeshRenderer', '宝石挑战结束', 'initView', '看完视频后获得奖励', 'prefab/rewardItem.json', 'ShowSkin', '999999', 'watchTvCallback', 'parseInt', 'setTimeBoxTime', 'playGame/ColorText_WOW.png', 'collisionGroup', 'maxY', '_zOrder', 'PsClick.wav', 'game/btn_luckypan.png', 'loading/Logo.png', 'onMessage', '_itemsList', 'script/view/PlayGameGemUI.ts', 'Level\x20Berikutnya', 'lookAtPlayer', 'script/view/OpenBoxUI.ts', '_secondEnterIndex', 'WebGL', 'fx_03', 'setSelectIconPos', '_isOpenVoice', './HoopTrigger', 'plane', 'parent', 'getLangById', '_trySkinId', 'MOUSE_DOWN', 'uiconfig', 'level/result_key_small2.png', 'winIcon', 'Rút\x20thăm\x20may\x20mắn', '_curIndex', 'skin/skin_dot2.png', 'txtGem4', 'Script', 'unlockbtn', '3d/prefabs/Conventional/Balls.lh', 'shadowPCFType', 'hoopUnlockMap', 'time', 'COMPLETE', '_maxScore', 'ShowLastPointEff', 'qqq', 'sendUrl', '_bSound', '_received', 'labName', '_eff', 'netFailHandle', 'showVideobtn', 'game_win', 'showHoopTurnHandle', 'script/view/LoadingView.ts', 'res/jsons/Ai.json', 'game/emoji1.png', 'PlayGameUI', 'boolKeyList', 'getRobotCfg', 'number', 'JSON', 'skin/SkinBG.jpg', 'randomIndex', 'scaleX', 'linearFactor', 'localRotationEuler', 'grade', 'roundLose', 'skin/btn_green.png', 'prepageClickHandle', 'Map', 'onloopRight', '_bIsNewer', '获取服务器玩家数据成功：', 'sharebtn', 'HIERARCHY', 'SignUIUI', 'addEvent', '../../../enum/EventEnum', 'removeChild', '0123456789', 'fx_02', 'skinbtnClickHandle', 'CupUI', 'level/level_bar2.png', 'AddForce', '_addCoin', '_ballPool', 'query', '_startIndex', 'button_lucky\x20draw', 'COLLISIONFILTERGROUP_CUSTOMFILTER3', 'setUIVisible', 'recordstartBtn', 'onTriggerEnter', '#ff0400', 'error=', 'timeBox', 'reward/result_rays.png', 'toUI', 'GameEnum', 'imgLine3', 'getSystemInfoSync', 'shift', 'openStage', './script/view/RankingGlobalUI', 'createBannercallbackHandle', '_lastPosition', 'closeBannerAd', 'Desbloqueio\x20aleatório', 'updateBar', 'level/level_bg3.png', 'socre_left', 'guideLeft', 'PlayGameGemUI', 'getUnlockHoop', '../utils/Tools', 'createChildren', 'playGame/ColorText_AWESOME.png', 'getFullYear', 'AppID', '_isAI', 'load', 'openid', '_endTime', 'closeUI', '_nickName,_hoopUnlockList,_ballUnlockList,_signDate,_headUrl', 'setMusicVolume', 'ResName', 'roundWin', 'Laya3D', 'regEvent', 'selectIcon', 'goldCount', 'Ease', './script/view/OpenTimeBoxUI', 'imgTitle', 'adCfg', 'success', '_foceFlag', 'switchPageHandle', 'quadInOut', '\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'startScene', 'cup', 'imgLight', 'btnVedio', '_effName', '跳转失败', '#0b41ee', 'headUrl', 'fx_07', '1059841', 'boxBg', 'fixedTimeStep', 'ani1', 'LuckBox', '111111', 'Browser', 'SignUI', 'onSDown', 'getMapCfg', 'bSound', 'receiveClickHandle', 'Despawn', 'setClickHandle', '_guideStep', '_bVibration', 'getRewardedVideoAsync', 'level/title_Victory.png', 'imgAddIcon', 'appid', 'startRecorderVedio', 'ShowGemRoundEnd', '_order', 'initMaterials', 'hoopicon', '../enum/GameConst', 'finalsTxt', 'guideLeftHandleSmall', 'Interstitial\x20ad\x20finished\x20successfully', 'rewardObj', '_angles', 'showShareBtn', 'progressEnd', 'COLLISIONFILTERGROUP_CUSTOMFILTER5', 'quartOut', 'onVersionLoaded', 'game/main_menu_sound_1.png', 'HttpServer', 'useClickHandle', '获得宝石\x20+60', 'left', 'recordingBtn', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/Number_1.lmat', './Platform', 'PREFAB', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage_plane2.lmat', 'loading/LoadingBg.jpg', 'initData', 'signCount', '{}.constructor(\x22return\x20this\x22)(\x20)', '0,11,0,14', 'loop', 'authorCallback', 'downFlag', 'findUI', '_ballDrag', '资源未加载/已释放:', 'getCurrentTime', 'skin/Skinitem_BG1.png', 'localRotationEulerY', '3d/prefabs/Conventional/Hoops.lh', 'Battle_DelPlayer', 'script/view/OpenRewardUI.ts', 'centerX', 'imgKey', ',消息:', 'rankNum', '_hoop', 'onClickBack', 'City', 'pow', 'Normalized', 'stateObject', '什么是套？来选一款吧！', 'fixedwidth', 'ERROR', '看完视频才能获得奖励！', 'prepage', 'setData', 'moveRightAni', 'logEvent', 'nextJump', 'onMouseUpHandle', 'setSoundVolume', 'openUniqueUI', 'Balls', 'view/LuckBoxLight.ani', '--------------ShowBanner', 'OnHoppTriggerStay', 'OnHoppTriggerExit', 'vertical', 'imgState3', 'game/ADbtn.png', 'sharecard_id', 'imgSchedule', 'level/level_bg1.png', 'getTxt', 'LevelResultUIUI', 'imgGem4', 'adRemainTimes', 'badgeLevel', 'SoundManager', '152,47,58,43', '1059942', 'button_draw\x20skip', 'uiView', 'turnToMini', 'adBox', 'end_challenge\x20skip', '../../core/ServerAgency', '_ownItem', 'call', '#fbf9f9', 'recordingHandle', 'Left', 'setIcon', 'game/btn_orange.png', 'counter', 'HagoAd', 'swan', 'Initialization', 'remainTime', 'box/chest02.png', 'hoopObj', 'Hoop', '176,49,90,38', '_rewardArr', '_score_right', 'ranking/rank_di_4.png', 'backClickHandle', 'Items', 'text', 'UIEnum', 'tmSDK', 'GameMgr', 'height', 'eff', 'countDownHandle', 'hoopSkinId', 'endTime', 'fx_04', 'pt-br', 'URL', 'level/result_key.png', 'stat', 'knifeIcon', 'dareClickHandle', 'createUI', 'btnClose', 'Ball', 'randomReward', 'itemObj', 'Tween', '_index', '../../enum/GameEnum', '_badgeLevel', 'defineProperty', 'colliderShape', 'state', 'skin/skin_dot1.png', '_lerp', 'closeHandle', 'getUnlockIndex', './script/view/ToppingUI', 'imgGem7', '_hoopDrag', 'setRecordState', 'showItem', 'localRotationEulerX', 'level/result_key_small.png', 'res/atlas/level.atlas', 'reqTmAd', 'button_skins', '666,666', '_skinScene', 'autoPlay', '_uiArray', 'getCurrentDate', 'game/textShare.png', 'transferSecondToHMS', 'BaiduAd', '_itemObj', 'MOUSE_UP', 'Ranking', 'GetEffect', 'imgGem6', '#f9f8f8', 'EventMgr', 'SkinUI', '当前回合数:', 'timeBoxClickHandle', 'apply', 'unlockCoin', '_ballPageArr', 'moveUp', 'imgState2', 'End', 'imgLine01', 'skin/skin_Tap_closeBTN.png', 'randomItem', 'icon', 'ranking/rank_3rd.png', 'TransferStringToNumberArr', '#######\x20时间宝箱\x20', 'hScrollBar', 'OpenScene', 'createFeedbackButton', 'Trigger', 'playSound', 'succes', 'player02', 'gembtn', 'zOrder', '_mask', 'Player', '_1454159051453417', 'signTotalCount', '__extends', 'button_chest\x20get_ad', 'Lerp', 'showGoldBtn', 'destroy', 'event', 'LucktBoxUI', 'key2', 'title', '#fbf6f6', 'particleSystem', '_score_left', '5,5,5,5', 'addunlockBall', 'receivebtn', 'removeEvent', 'createView', 'res/jsons/Global.json', 'setValue', 'HoopMass', 'instance', 'exportSceneToJson', 'scene', 'videobtn', 'script/view/CupUI.ts', 'skin/', 'online', '#f9f4f4', 'getChildByName', 'globalCfg', 'showAsync', 'len', 'initPlayer', 'startClickHandle', '_ballSkinId', 'en-us', '_info', 'dare', 'box/rewarded_video.png', 'DisableCrown', 'default', 'navigateToMiniProgram', 'mouseEnabled', 'btnStop', '_icon', 'Reward', 'castShadow', 'button_ring\x20', 'fb初始化成功！', 'Interstitial\x20failed\x20to\x20preload:\x20', 'res/atlas/dare.atlas', 'Start', 'resAdHandle', 'backOut', 'skin', 'txtState3', 'Hoàn\x20thành\x20thử\x20thách', 'script/view/RankingGlobalUI.ts', 'box/BG_Black.png', 'game/ADclose.png', 'addscore', '_currentTime', 'onUpdataRotate', 'enabled', 'angularFactor', '../../utils/Utils', 'ResourceVersion', 'canCollideWith', 'createTestInfo', 'hideAuthenticLoginBtn', '_stage', 'RotatePos', 'Loader', 'level/reward_cup.png', 'stop', 'ResIcon', 'initPrefab', 'hoopbtn', '看完视频后即可获得随机奖励哦！', '看完视频后即可获得翻倍宝石哦！', 'banner\x20load\x20catch>>>', 'boxClose', '#f9f6f6', '_signDate', 'game/loading3.png', 'quadOut', 'itemArr', 'getInterstitialAdAsync', '_prefabMap', 'vibrationClickHandle', 'onClickHandle', 'roundIdel', 'updateData', 'level/level_failed.png', 'shareClickHandle', 'Panel', 'Physics3DUtils', 'getItemCfg', 'numChildren', 'SourceOpenid', 'PreloadRes', 'luckyBox/LuckPan_1.png', 'script/view/OpenTimeBoxUI.ts', '_skinId', '22222', 'replace', 'back', 'H5平台初始化111！！', 'from', '_speed', 'ui.view.LoadingViewUI', '#d549db', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/Number_0.lmat', '有没录屏!！!', 'Platform', '未上榜', '_randomSkinIdArr', 'box/text_freeVhest.png', 'DareLoseUIUI', '_timeBoxEndTime', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/Number_3.lmat', './script/view/CupUI', 'ShowBackbtnTime', 'callShowMask', 'script/view/PlayGameUI.ts', '_randomId', 'mouseX', '>>>>>>>>>>>>>>>>>>>>>>>没有完全加载！！！', 'init', 'localPositionY', 'imgTitleLose', 'gameLoadResult', 'imgAI', 'level/num0-9.png', 'eff_normal', 'doublebtn', 'looping', '1059639', 'addItemInfo', 'bouceBack', '_shareCount', 'loseBG', 'stringify', 'ChallengeGold', 'backIn', 'Battle_AlertInfo', 'backbtn', 'rewardCfg', '开始播放', 'game/messageBG.png', 'Double\x20Gem', 'sqrt', 'skinMask', '_goldCount', 'onClickNext', 'onPreLoadResComplete', 'guideRight', 'imgOver', '24:59', 'boxLose', 'usebtn', 'res', 'getItemListByType', 'btnRightAdView', 'ShareId', 'checkBanner', 'playGame/ColorText_AMAZING.png', 'freeGemHandle', 'isTmAdOpen', 'skinUI.....', 'doLager', '_videobtn', '_timeBoxTime', 'scrollTo', 'bestReward', 'max', 'round', 'onShow', '_score', 'COLLISIONFILTERGROUP_CUSTOMFILTER6', '_maxRank', 'res/jsons/language.json', 'playGame/fightTime_bg.png', 'class', 'ui.view.GameUIUI', 'Particles', 'eff_special', 'playGame/ColorText_WONDERFUL.png', '_recordstate', 'signbtn', '玩套是需要技术的，一起来挑战你的手法吧！', 'hideBannerAdAsync', './script/view/OpenBoxUI', 'Battle_AddPlayer', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/Number_5.lmat', 'RecordingInit', '_rankNum', '加载成功！', './script/view/PlayGameGemUI', 'isOpenVoice', 'ScoreToString', 'end_lose\x20skip', 'SetupEngine', 'isUnlock', '_curRound', 'localPosition', 'addunlockHoop', 'initLight', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage_plane5.lmat', 'ballUnlockMap', 'useTxt', 'vibrateShort', 'isSharing', '_ownRank', 'isVector3', '_player', 'clear', '_loginCount', '_opponent', 'SetCollider', 'texture', 'middle', 'keyNone', 'ScreenFont', 'showTips', 'GameEnd', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage_plane1.lmat', '100', 'txtRevival', 'Challenge', '两个触发器中有一个没触发，失败', 'startgame', 'RoundType', 'HoopRestitution', 'autoStopMusic', 'delta', '../core/Http', 'level/reward_key.png', 'Type', 'string', 'freezSide', 'gameObject', '_stageMaterial', 'shadowResolution', '_firstX', 'game/main_UiNotice.png', 'bind', '4399游戏初始化444！！！', 'ballSkinId', 'IntRange', 'onEnable', 'onUpdate', 'level/level_bg2.png', './manager/UIManager', 'game/btn_chest.png', 'drawline', 'button_start', 'DistanceSquared', 'OpenTimeBoxUI', 'show', 'lingbg', 'button_daily\x20reward', 'onSUp', 'pageObj', 'Divide', '1059740', 'initAdX', 'var', 'Checked\x20in', '_oldPage', 'count', 'getRemainTime', 'Materials', 'Handler', 'Sprite', 'removeChildren', 'loadingComplete', 'startX', 'setPlayerName', 'timeBoxTime', 'script/view/SkinUI.ts', 'onHide', 'ESound', '_rewardMap', './enum/UIEnum', 'res/atlas/ranking.atlas', '1109893028', 'TimeBox', 'CtrlSide', 'AddToStage', 'gray', 'rotation', 'updateTimeBox', 'OpenRewardUIUI', 'initGlobalData', '_ballUnlockList', 'GameType', '_selectHoopFlag', 'Quaternion', 'Use\x20and\x20Revenge', 'active', '3d/scenes/Conventional/ShowSkin.ls', 'onClikShareVedio', 'box/chest01.png', 'getSupportedAPIs', 'Update_Items', 'Permata\x20Gratis', 'game/addi.png', 'HoopForceX', 'EventEnum', 'game/btn_green.png', 'skin/Hoop_Minecraft_icon.png', '_space', 'ranCol', 'itemCfg', 'SplitToStr', 'Stat', 'ItemType', 'length', '是否可播放广告', 'CfgMgr', 'warn', 'game/game_redPoint.png', 'soundClickHandle', 'isEmpty', 'physicsDebug', 'right', 'game/main_menu_vibroon_2.png', 'shareCard', 'TryRingList', 'screenCfg', 'ToppingUI', 'imgWxAd', 'imgTitleWin', 'imgPlayer', '../../core/Http', 'txtStop', '01:00', 'Chìa\x20Khóa\x20+3', 'hasOwnProperty', 'StartGame', 'game/top_close.png', './manager/EventManager', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage2.lmat', 'windowHeight', 'Switch_Page', 'keyClickHandle', 'dare/skin_di.png', 'openId', '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage4.lmat', '10,10,10,10', 'LivingRoom', 'MapDistanceSquared', 'RandomPosition', 'sin', 'error_code', 'game/btn_red.png', 'playGame/colorbg.png', 'GameUIUI', 'received', 'ChangeScore', '600', 'saveData', '_ballMap', 'Garden', 'DisableEff', 'onAwake', '_recordTime', 'windowWidth', 'moveDown', 'closebtn', 'SkinUIUI', 'ui.view.PlayGameGemUIUI', 'TestHandle', 'console', '../entity/Crown', 'robotCfg', 'uitween', 'BallMass', 'game/friendPlaying.png', '_roundTime', 'Vector2', 'keybtn', 'h5Platform', 'skin/freeDiamond.png', 'script/view/GameUI.ts', 'script/view/MoreGameView.ts', 'imgLevel01', 'level/levelTitle_fail.png', '_nickName', 'btnNext', 'GameStart', 'Scenes', '_newIndex', 'playBGM', 'creatives', 'regClick', 'undefined', 'imgGem5', './manager/SoundManager', 'dragFlag', 'reqTmIcons', '_camera', '_hoopicon', 'localScale', 'imgLine1', 'GameTop', 'play', '_flags', 'script/view/ToppingUI.ts', 'exception', 'gger', 'RingTxt', 'PlatformType', 'value', '_name', 'onClickVideo', 'ranking/rank_1st.png', 'pivotX', 'getTimBoxIndex', '_headicon', 'hoopClickHandle', 'end_key_ad', 'destroyButton', 'Range', '_title', 'getRegClass', 'flags', 'updateInfo', 'Button', 'callHandler', 'drag', 'BackTime', './core/ServerAgency', 'QQAd', '当前顺序重复触发enter:', 'showItemOnStage', '播放结束', 'tips', 'rankbg', 'videoShow', 'script/view/DareLoseUI.ts', 'showReward', 'finalWin', 'nextpage', 'skinClickHandle', 'friendPlay', 'shareid', 'lightTurnHandle', 'randomUnlockTxt', './Player', 'function', 'anchorX', 'imgKey3', '#ffffff', 'data', 'localPositionX', 'shadowPSSMCount', 'language', 'code', 'Sprite3D', 'label', 'Image', 'AtlasInfoManager', 'game/btn_blue.png', 'includes', 'error', 'transferSecondToMS', 'testBtn', 'destroyUI', 'game/mask.png', 'onClickRevival', 'skin/Ball_goal_04_icon.png', 'SetTarget', 'interstitialShow', 'sign/sign_bg.png', 'addForce', 'onPlay4399Ad', 'winTxt', 'gameBg', '_pageArr', 'randomSkin', 'Jsons', 'stopRecorderVedio', 'skin/Hoop_Donut_01_icon.png', 'update', 'setBannerVisible', '_arrTips', 'WXAd', 'game/emoji', 'nickName', 'Normal', '_ballInfoArr', 'keyShow', '_hoopMap', 'ballClickHandle', 'defaultValMap', 'getHours', '第7天', '_timeBoxLastTime', '0,30,0,26', '_flag_left', '_videoFlag', 'off', 'loginCount', 'subcode', 'GuideProgressEnum', 'RankingGlobalUIUI', 'level', 'imgGem3', '_succes', 'luckyDrawTxt', 'game/btn_Purpledi.png', 'challgeTxt', 'flowNavigate', 'getQueryString', 'Vector3', 'vScrollBarSkin', 'removeSelf', 'authorize', 'forEach', 'onClickStop', 'material', 'loseIcon', '#217ea3', '_mapName', '_timeBoxIndex', 'ClassUtils', 'game/di1.png', 'center', 'getRankInfo', 'reward/LuckItemBG.png', 'OPPOAd', 'addComponent', 'level/level_uidi_victory.png', 'game/btn_sign.png', '_randomTotalNum', 'GemAddScore', '_selected', 'freeuse', 'ranking/rank_bgDI.png', 'token', 'timer', 'level/level_complete.png', 'HttpRequest', 'clearLoadUI', 'new\x20arr>>>>>>', 'ui.view.LoadingUIUI', 'res/atlas/game.atlas', 'setPos', 'GameUI', 'bVibration', 'open\x20the\x20moregameview', 'winAd', 'level/BG_Black.png', 'getFlowConfig'];
(function (_0x11293d, _0x516fab) {
    var _0x59858f = function (_0x9816d3) {
        while (--_0x9816d3) {
            _0x11293d['push'](_0x11293d['shift']());
        }
    };
    _0x59858f(++_0x516fab);
}(_0x516f, 0x102));
var _0x5985 = function (_0x11293d, _0x516fab) {
    _0x11293d = _0x11293d - 0x0;
    var _0x59858f = _0x516f[_0x11293d];
    return _0x59858f;
};
var _0x4b7fcf = _0x5985;
function logEvent(_0x30848d) {
    var _0x1cffc4 = _0x5985;
    FBInstant[_0x1cffc4('0x305')](_0x30848d),
        console['log'](_0x30848d);
}
var minute = 0x0
    , logMinute = [];
setInterval(() => {
    minute++;
}
    , 0x3e8 * 0x3c);
const aaaa = _0x4b7fcf('0x641') + _0x4b7fcf('0x38c')
    , bbbb = _0x4b7fcf('0x68c') + _0x4b7fcf('0x4b')
    , cccc = _0x4b7fcf('0x68c') + '1560627327473255';
var preloadedRewardedVideo, preloadedInterstitial;
function LoadInter() {
    var _0x470f46 = _0x4b7fcf
        , _0x2e8665 = FBInstant[_0x470f46('0x4be')]();
    if (_0x2e8665['includes'](_0x470f46('0x3e5')))
        preloadedInterstitial = null,
            FBInstant[_0x470f46('0x3e5')](aaaa)['then'](function (_0x3bdc62) {
                return preloadedInterstitial = _0x3bdc62,
                    preloadedInterstitial['loadAsync']();
            })[_0x470f46('0x210')](function () {
                console['log']('Interstitial\x20preloaded');
            })[_0x470f46('0xed')](function (_0x2a0e54) {
                var _0x4809ba = _0x470f46;
                console[_0x4809ba('0x560')](_0x4809ba('0x3bf') + _0x2a0e54[_0x4809ba('0x152')]);
            });
    else { }
}
function ShowInter() {
    var _0x2b8a66 = _0x4b7fcf;
    if (preloadedInterstitial == null || preloadedInterstitial == undefined)
        return;
    preloadedInterstitial[_0x2b8a66('0x3ac')]()[_0x2b8a66('0x210')](function () {
        var _0x4444fa = _0x2b8a66;
        console[_0x4444fa('0x5df')](_0x4444fa('0x2d1')),
            LoadInter();
    })[_0x2b8a66('0xed')](function (_0x932955) {
        var _0x1713d1 = _0x2b8a66;
        console[_0x1713d1('0x560')](_0x932955[_0x1713d1('0x152')]),
            LoadInter();
    });
}
function LoadRewarded() { }
function ShowRewarded(_0x2ef765, _0x55cbdb) {    
    var _0x4915ea = _0x4b7fcf
        , _0x26c78a = null;    
    _0x2ef765();
    /*FBInstant[_0x4915ea('0x2c5')](bbbb)[_0x4915ea('0x210')](function (_0x4014b1) {
        return _0x26c78a = _0x4014b1,
            _0x26c78a['loadAsync']();
    })[_0x4915ea('0x210')](function () {
        var _0x11205e = _0x4915ea;
        return _0x26c78a[_0x11205e('0x3ac')]();
    })[_0x4915ea('0x210')](function () {
        _0x2ef765();
    })[_0x4915ea('0xed')](function (_0x50a3de) {
        var _0x58d620 = _0x4915ea;
        console[_0x58d620('0x560')](_0x50a3de[_0x58d620('0x152')]);
        if (_0x55cbdb)
            _0x55cbdb();
    });*/
}
function ShowBanner() {
    var _0xc63a14 = _0x4b7fcf;
    console[_0xc63a14('0x5df')](_0xc63a14('0x30c'));
    var _0x5811fb = FBInstant[_0xc63a14('0x4be')]();
    if (!_0x5811fb[_0xc63a14('0x55f')](_0xc63a14('0x610')))
        return;
    FBInstant[_0xc63a14('0x610')](cccc)[_0xc63a14('0x210')](() => {
        var _0x1e6186 = _0xc63a14;
        console[_0x1e6186('0x5df')](_0x1e6186('0x2a7'));
    }
    )[_0xc63a14('0xed')](function (_0x496c25) {
        var _0x5bf75f = _0xc63a14
            , _0x45c877 = JSON[_0x5bf75f('0x41c')](_0x496c25);
        console[_0x5bf75f('0x560')](_0x5bf75f('0x3de') + _0x45c877);
    });
}
function HideBanner() {
    var _0x49209b = _0x4b7fcf;
    console[_0x49209b('0x5df')]('--------------HideBanner');
    var _0x542c43 = FBInstant['getSupportedAPIs']();
    if (!_0x542c43[_0x49209b('0x55f')](_0x49209b('0x44d')))
        return;
    FBInstant[_0x49209b('0x44d')]();
}
function H5Platform() {
    var _0x43e168 = _0x4b7fcf;
    console[_0x43e168('0x5df')](_0x43e168('0x3f9'));
}
var preloadedRewarded = null
    , preloadedInter = null;
H5Platform[_0x4b7fcf('0x64a')] = {
    'constructor': H5Platform,
    'createBannerAd'() {
        ShowBanner();
    },
    'closeBannerAd'() {
        HideBanner();
    },
    'setBannerVisible'(_0x191e62) {
        _0x191e62 ? ShowBanner() : HideBanner();
    },
    'interstitialShow'() {
        ShowInter();
    },
    'videoShow'(_0x1e6f4c) {
        ShowRewarded(function () {
            _0x1e6f4c && _0x1e6f4c(!![]);
        }, function () {
            _0x1e6f4c && _0x1e6f4c(![], 'You\x20can\x20only\x20get\x20reward\x20once\x20within\x2030\x27S');
        });
    }
},
    window[_0x4b7fcf('0x50d')] = new H5Platform();
var __extends = this && this[_0x4b7fcf('0x38e')] || function () {
    var _0x1f33e0 = function () {
        var _0x977b74 = !![];
        return function (_0x1d7432, _0x55b34b) {
            var _0x1e5f26 = _0x977b74 ? function () {
                var _0x165138 = _0x5985;
                if (_0x55b34b) {
                    var _0x2b195b = _0x55b34b[_0x165138('0x374')](_0x1d7432, arguments);
                    return _0x55b34b = null,
                        _0x2b195b;
                }
            }
                : function () { }
                ;
            return _0x977b74 = ![],
                _0x1e5f26;
        }
            ;
    }()
        , _0x1bf256 = _0x1f33e0(this, function () {
            var _0x2b0d25 = _0x5985
                , _0x247e4f = function () {
                    var _0x2c2571 = _0x5985, _0x25cf36;
                    try {
                        _0x25cf36 = Function('return\x20(function()\x20' + _0x2c2571('0x2e6') + ');')();
                    } catch (_0x35810d) {
                        _0x25cf36 = window;
                    }
                    return _0x25cf36;
                }
                , _0x1cac37 = _0x247e4f()
                , _0x44552c = _0x1cac37[_0x2b0d25('0x504')] = _0x1cac37[_0x2b0d25('0x504')] || {}
                , _0x3488f1 = ['log', _0x2b0d25('0x4cf'), _0x2b0d25('0x1a9'), _0x2b0d25('0x560'), _0x2b0d25('0x528'), 'table', _0x2b0d25('0x5ef')];
            for (var _0x1ba063 = 0x0; _0x1ba063 < _0x3488f1['length']; _0x1ba063++) {
                var _0xdcf01a = _0x1f33e0['constructor']['prototype'][_0x2b0d25('0x484')](_0x1f33e0)
                    , _0x42199f = _0x3488f1[_0x1ba063]
                    , _0x1e7161 = _0x44552c[_0x42199f] || _0xdcf01a;
                _0xdcf01a[_0x2b0d25('0x5fe')] = _0x1f33e0[_0x2b0d25('0x484')](_0x1f33e0),
                    _0xdcf01a[_0x2b0d25('0xcc')] = _0x1e7161[_0x2b0d25('0xcc')][_0x2b0d25('0x484')](_0x1e7161),
                    _0x44552c[_0x42199f] = _0xdcf01a;
            }
        });
    _0x1bf256();
    var _0x53e6a0 = Object['setPrototypeOf'] || {
        '__proto__': []
    } instanceof Array && function (_0x32dcdc, _0x11d3ec) {
        var _0x506252 = _0x5985;
        _0x32dcdc[_0x506252('0x5fe')] = _0x11d3ec;
    }
        || function (_0x5936eb, _0x51ab89) {
            for (var _0x2c6b12 in _0x51ab89)
                if (_0x51ab89['hasOwnProperty'](_0x2c6b12))
                    _0x5936eb[_0x2c6b12] = _0x51ab89[_0x2c6b12];
        }
        ;
    return function (_0x465bb4, _0x2f4604) {
        var _0x35a9ee = _0x5985;
        _0x53e6a0(_0x465bb4, _0x2f4604);
        function _0x19f8e9() {
            var _0x311762 = _0x5985;
            this[_0x311762('0x632')] = _0x465bb4;
        }
        _0x465bb4[_0x35a9ee('0x64a')] = _0x2f4604 === null ? Object[_0x35a9ee('0x5fb')](_0x2f4604) : (_0x19f8e9['prototype'] = _0x2f4604[_0x35a9ee('0x64a')],
            new _0x19f8e9());
    }
        ;
}();
(function () {
    var _0x45fc26 = function () {
        var _0x2b266b = !![];
        return function (_0x496b7a, _0x13977b) {
            var _0x9f45f = _0x2b266b ? function () {
                if (_0x13977b) {
                    var _0x367c3a = _0x13977b['apply'](_0x496b7a, arguments);
                    return _0x13977b = null,
                        _0x367c3a;
                }
            }
                : function () { }
                ;
            return _0x2b266b = ![],
                _0x9f45f;
        }
            ;
    }();
    (function () {
        _0x45fc26(this, function () {
            var _0x3fc6c2 = _0x5985
                , _0x2268ba = new RegExp('function\x20*\x5c(\x20*\x5c)')
                , _0x386e44 = new RegExp(_0x3fc6c2('0x2ab'), 'i')
                , _0x515a39 = _0x8db5e2('init');
            !_0x2268ba[_0x3fc6c2('0x82')](_0x515a39 + 'chain') || !_0x386e44[_0x3fc6c2('0x82')](_0x515a39 + 'input') ? _0x515a39('0') : _0x8db5e2();
        })();
    }());
    function _0x126cdf(_0x1cc061, _0x624d20, _0x2220ca) {
        var _0x5604bb = _0x5985;
        function _0x2b18fb(_0x19363, _0x3ad3fb) {
            var _0x13b31e = _0x5985;
            if (!_0x624d20[_0x19363]) {
                if (!_0x1cc061[_0x19363]) {
                    var _0x5cfcc5 = 'function' == typeof require && require;
                    if (!_0x3ad3fb && _0x5cfcc5)
                        return _0x5cfcc5(_0x19363, !0x0);
                    if (_0x46fb72)
                        return _0x46fb72(_0x19363, !0x0);
                    var _0x39460b = new Error(_0x13b31e('0xdb') + _0x19363 + '\x27');
                    throw _0x39460b['code'] = 'MODULE_NOT_FOUND',
                    _0x39460b;
                }
                var _0x277341 = _0x624d20[_0x19363] = {
                    'exports': {}
                };
                _0x1cc061[_0x19363][0x0]['call'](_0x277341[_0x13b31e('0x137')], function (_0x302e36) {
                    var _0x1404b2 = _0x1cc061[_0x19363][0x1][_0x302e36];
                    return _0x2b18fb(_0x1404b2 || _0x302e36);
                }, _0x277341, _0x277341['exports'], _0x126cdf, _0x1cc061, _0x624d20, _0x2220ca);
            }
            return _0x624d20[_0x19363][_0x13b31e('0x137')];
        }
        for (var _0x46fb72 = _0x5604bb('0x551') == typeof require && require, _0x579dee = 0x0; _0x579dee < _0x2220ca[_0x5604bb('0x4cc')]; _0x579dee++)
            _0x2b18fb(_0x2220ca[_0x579dee]);
        return _0x2b18fb;
    }
    return _0x126cdf;
}()({
    0x1: [function (_0x49a427, _0x2ecee0, _0x40135c) {
        var _0x21e3fc = _0x4b7fcf;
        'use strict';
        Object[_0x21e3fc('0x351')](_0x40135c, _0x21e3fc('0xb8'), {
            'value': !![]
        });
        var _0x321642 = _0x49a427(_0x21e3fc('0x407'))
            , _0x15d097 = _0x49a427(_0x21e3fc('0x657'))
            , _0x51c826 = _0x49a427(_0x21e3fc('0x13a'))
            , _0x558606 = _0x49a427(_0x21e3fc('0x1c7'))
            , _0xc97264 = _0x49a427(_0x21e3fc('0x11a'))
            , _0x474b5b = _0x49a427(_0x21e3fc('0x128'))
            , _0x3e58cc = _0x49a427(_0x21e3fc('0x1a0'))
            , _0x16a44e = _0x49a427(_0x21e3fc('0x65'))
            , _0x1860cb = _0x49a427(_0x21e3fc('0x694'))
            , _0x11baa5 = _0x49a427(_0x21e3fc('0x44e'))
            , _0x13fb3c = _0x49a427(_0x21e3fc('0x5f0'))
            , _0x2316fb = _0x49a427(_0x21e3fc('0x2a4'))
            , _0x5eec61 = _0x49a427(_0x21e3fc('0x454'))
            , _0x30c650 = _0x49a427('./script/view/PlayGameUI')
            , _0x4b2496 = _0x49a427(_0x21e3fc('0x286'))
            , _0x45cb5c = _0x49a427(_0x21e3fc('0x2d'))
            , _0x264ace = _0x49a427(_0x21e3fc('0x8b'))
            , _0x4495a9 = _0x49a427(_0x21e3fc('0x358'))
            , _0x24c039 = function () {
                var _0x4ab68c = _0x21e3fc;
                function _0x8a44bb() { }
                return _0x8a44bb['init'] = function () {
                    var _0x195eb7 = _0x5985
                        , _0x398bb6 = Laya['ClassUtils'][_0x195eb7('0x5c2')];
                    _0x398bb6(_0x195eb7('0x3a6'), _0x321642['default']),
                        _0x398bb6(_0x195eb7('0x547'), _0x15d097['default']),
                        _0x398bb6('script/view/DareUI.ts', _0x51c826[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x50f'), _0x558606['default']),
                        _0x398bb6(_0x195eb7('0x157'), _0xc97264[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x77'), _0x474b5b[_0x195eb7('0x3b6')]),
                        _0x398bb6('script/view/LoadingView.ts', _0x3e58cc[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x10e'), _0x16a44e[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x510'), _0x1860cb[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x22c'), _0x11baa5[_0x195eb7('0x3b6')]),
                        _0x398bb6('script/view/OpenRewardUI.ts', _0x13fb3c[_0x195eb7('0x3b6')]),
                        _0x398bb6('script/view/OpenTimeBoxUI.ts', _0x2316fb[_0x195eb7('0x3b6')]),
                        _0x398bb6('script/view/PlayGameGemUI.ts', _0x5eec61['default']),
                        _0x398bb6('script/view/PlayGameUI.ts', _0x30c650[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x3c7'), _0x4b2496[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x63b'), _0x45cb5c['default']),
                        _0x398bb6(_0x195eb7('0x4a6'), _0x264ace[_0x195eb7('0x3b6')]),
                        _0x398bb6(_0x195eb7('0x527'), _0x4495a9[_0x195eb7('0x3b6')]);
                }
                    ,
                    _0x8a44bb[_0x4ab68c('0x1d2')] = 0x2ee,
                    _0x8a44bb[_0x4ab68c('0x33c')] = 0x536,
                    _0x8a44bb[_0x4ab68c('0x8d')] = _0x4ab68c('0x2ff'),
                    _0x8a44bb[_0x4ab68c('0x5e8')] = _0x4ab68c('0x30f'),
                    _0x8a44bb['alignV'] = 'top',
                    _0x8a44bb[_0x4ab68c('0x67c')] = _0x4ab68c('0x2dd'),
                    _0x8a44bb[_0x4ab68c('0x2ac')] = _0x4ab68c('0xf2'),
                    _0x8a44bb['sceneRoot'] = '',
                    _0x8a44bb[_0x4ab68c('0x68e')] = ![],
                    _0x8a44bb[_0x4ab68c('0x345')] = ![],
                    _0x8a44bb[_0x4ab68c('0x4d3')] = ![],
                    _0x8a44bb['exportSceneToJson'] = !![],
                    _0x8a44bb;
            }();
        _0x40135c[_0x21e3fc('0x3b6')] = _0x24c039,
            _0x24c039[_0x21e3fc('0x40e')]();
    }
        , {
        './script/view/CupUI': 0x1f,
        './script/view/DareLoseUI': 0x20,
        './script/view/DareUI': 0x21,
        './script/view/GameUI': 0x22,
        './script/view/LevelResultUI': 0x23,
        './script/view/LoadingUI': 0x24,
        './script/view/LoadingView': 0x25,
        './script/view/LucktBoxUI': 0x26,
        './script/view/MoreGameView': 0x27,
        './script/view/OpenBoxUI': 0x28,
        './script/view/OpenRewardUI': 0x29,
        './script/view/OpenTimeBoxUI': 0x2a,
        './script/view/PlayGameGemUI': 0x2b,
        './script/view/PlayGameUI': 0x2c,
        './script/view/RankingGlobalUI': 0x2d,
        './script/view/SignUI': 0x2e,
        './script/view/SkinUI': 0x2f,
        './script/view/ToppingUI': 0x30
    }],
    0x2: [function (_0x12ea17, _0x452ba8, _0x4681a8) {
        var _0x2244a4 = _0x4b7fcf;
        'use strict';
        Object[_0x2244a4('0x351')](_0x4681a8, _0x2244a4('0xb8'), {
            'value': !![]
        });
        var _0x1d9f42 = _0x12ea17('./GameConfig')
            , _0x4dd26f = _0x12ea17(_0x2244a4('0x663'))
            , _0x3c143f = _0x12ea17(_0x2244a4('0x617'))
            , _0x21fa68 = _0x12ea17(_0x2244a4('0x4aa'))
            , _0x26b120 = _0x12ea17(_0x2244a4('0x53f'))
            , _0x5405fd = function () {
                var _0x4e852a = _0x2244a4;
                function _0x177ed2() {
                    var _0x28f929 = _0x5985;
                    console.log("LayaGame Initing");
                    if (window[_0x28f929('0x29f')])
                        Laya3D['init'](_0x1d9f42[_0x28f929('0x3b6')]['width'], _0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x33c')]);
                    else
                        Laya['init'](_0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x1d2')], _0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x33c')], Laya[_0x28f929('0x22e')]);
                    Laya['Physics'] && Laya[_0x28f929('0x1f6')]['enable'](),
                        Laya[_0x28f929('0xc4')] && Laya['DebugPanel']['enable'](),
                        Laya[_0x28f929('0x150')][_0x28f929('0x8d')] = _0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x8d')],
                        Laya[_0x28f929('0x150')]['screenMode'] = _0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x5e8')],
                        Laya[_0x28f929('0x150')][_0x28f929('0x669')] = laya['display'][_0x28f929('0x69e')]['FRAME_FAST'],
                        Laya['URL'][_0x28f929('0x3a3')] = _0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x3a3')];
                    if (_0x1d9f42[_0x28f929('0x3b6')]['debug'] || Laya[_0x28f929('0x12e')][_0x28f929('0x591')](_0x28f929('0x68e')) == _0x28f929('0x636'))
                        Laya['enableDebugPanel']();
                    if (_0x1d9f42[_0x28f929('0x3b6')][_0x28f929('0x4d3')] && Laya[_0x28f929('0x1c6')])
                        Laya[_0x28f929('0x1c6')][_0x28f929('0x692')]();
                    if (_0x1d9f42[_0x28f929('0x3b6')]['stat'])
                        Laya[_0x28f929('0x4ca')][_0x28f929('0x491')]();
                    Laya[_0x28f929('0x5b')] = !![],
                        Laya[_0x28f929('0x3d0')][_0x28f929('0x692')](_0x28f929('0x5f4'), Laya[_0x28f929('0x49f')]['create'](this, this[_0x28f929('0x2d8')]), Laya[_0x28f929('0x3d0')]['FILENAME_VERSION']);
                }
                return _0x177ed2[_0x4e852a('0x64a')][_0x4e852a('0x2d8')] = function () {
                    var _0x5e289d = _0x4e852a;
                    Laya[_0x5e289d('0x55d')]['enable']('fileconfig.json', Laya[_0x5e289d('0x49f')][_0x5e289d('0x5fb')](this, this['onConfigLoaded']));
                }
                    ,
                    _0x177ed2[_0x4e852a('0x64a')][_0x4e852a('0x5f')] = function () {
                        var _0x474a74 = _0x4e852a;
                        _0x4dd26f[_0x474a74('0x3b6')]['SetupEngine']();
                        var _0x2a3b4f = _0x3c143f[_0x474a74('0x1d1')]['CDN'] + _0x3c143f[_0x474a74('0x1d1')][_0x474a74('0x400')] + '/' + _0x3c143f[_0x474a74('0x1d1')]['Version'] + '/';
                        !Laya['Browser'][_0x474a74('0x621')] && _0x3c143f[_0x474a74('0x1d1')][_0x474a74('0x400')] != _0x3c143f[_0x474a74('0x52b')]['Game4399'] && _0x3c143f['GameConst'][_0x474a74('0x400')] != _0x3c143f[_0x474a74('0x52b')][_0x474a74('0x1e0')] && _0x3c143f[_0x474a74('0x1d1')]['Platform'] != _0x3c143f['PlatformType'][_0x474a74('0x32b')] ? (Laya[_0x474a74('0x343')][_0x474a74('0x5fc')] = _0x2a3b4f,
                            console['log']('cnd加载:', _0x2a3b4f)) : console[_0x474a74('0x5df')](_0x474a74('0x121'));
                        _0x3c143f[_0x474a74('0x1d1')][_0x474a74('0x400')] == _0x3c143f[_0x474a74('0x52b')][_0x474a74('0x64')] && (console[_0x474a74('0x5df')](_0x474a74('0x485')),
                            window[_0x474a74('0xa7')] && window[_0x474a74('0xa7')][_0x474a74('0xf3')](function (_0x31ba9e) {
                                var _0x2d58b6 = _0x474a74;
                                console[_0x2d58b6('0x5df')](_0x2d58b6('0x4cd'), _0x31ba9e[_0x2d58b6('0xf3')], _0x2d58b6('0x1e4'), _0x31ba9e[_0x2d58b6('0x26')]),
                                    _0x31ba9e[_0x2d58b6('0xf3')] && (_0x4dd26f[_0x2d58b6('0x3b6')]['DataMgr']['adRemainTimes'] = _0x31ba9e[_0x2d58b6('0x26')]);
                            }));
                        if (_0x3c143f['GameConst'][_0x474a74('0x400')] == _0x3c143f[_0x474a74('0x52b')][_0x474a74('0x32b')] && !Laya[_0x474a74('0x2bb')][_0x474a74('0x621')]) {
                            if (window['hg']) {
                                var _0x174b22 = window['hg'][_0x474a74('0x283')]();
                                _0x3c143f[_0x474a74('0x1d1')][_0x474a74('0x64d')] = _0x174b22[_0x474a74('0x558')],
                                    console[_0x474a74('0x5df')](_0x474a74('0x17f'), _0x174b22),
                                    console[_0x474a74('0x5df')]('打开设置的hago语言：', _0x174b22['language']);
                            }
                        }
                        if (window['wx'] && _0x3c143f[_0x474a74('0x1d1')][_0x474a74('0x400')] == _0x3c143f[_0x474a74('0x52b')][_0x474a74('0x576')])
                            window['wx']['tmSDK']['init']({
                                'hideRequestLog': ![],
                                'appVersion': '1.0.7'
                            }),
                                window['wx'][_0x474a74('0x33a')]['checkFlowIsOpen']({
                                    'positionId': _0x474a74('0x2b5')
                                })[_0x474a74('0x210')](function (_0x3e0a9a) {
                                    var _0x436a69 = _0x474a74
                                        , _0x58972b = _0x3e0a9a['isOpen'];
                                    _0x4dd26f[_0x436a69('0x3b6')][_0x436a69('0x678')][_0x436a69('0x436')] = _0x58972b,
                                        console[_0x436a69('0x5df')](_0x436a69('0x91'), _0x58972b),
                                        _0x4dd26f[_0x436a69('0x3b6')][_0x436a69('0x5d7')]['toUI'](_0x21fa68['UIEnum'][_0x436a69('0x644')]);
                                });
                        else
                            window[_0x474a74('0x124')] && _0x3c143f[_0x474a74('0x1d1')]['Platform'] == _0x3c143f[_0x474a74('0x52b')][_0x474a74('0x1e0')] ? (window['FBInstant'][_0x474a74('0x69f')]()[_0x474a74('0x210')](function () {
                                var _0x5d3f43 = _0x474a74;
                                console[_0x5d3f43('0x5df')](_0x5d3f43('0x3be')),
                                    window[_0x5d3f43('0x124')][_0x5d3f43('0x8')](0x64),
                                    setTimeout(() => {
                                        var _0x5aa747 = _0x5d3f43;
                                        window[_0x5aa747('0x124')]['startGameAsync']()[_0x5aa747('0x210')](function () {
                                            var _0x46326a = _0x5aa747;
                                            LoadRewarded(),
                                                LoadInter(),
                                                console[_0x46326a('0x5df')](_0x46326a('0x453')),
                                                _0x4dd26f[_0x46326a('0x3b6')][_0x46326a('0x5d7')][_0x46326a('0x280')](_0x21fa68[_0x46326a('0x339')][_0x46326a('0x644')]);
                                        });
                                    }
                                        , 0x3e8);
                            }),
                                window['FbRelease'] == null && _0x4dd26f['default'][_0x474a74('0x5d7')][_0x474a74('0x280')](_0x21fa68['UIEnum']['LoadingUI'])) : _0x4dd26f[_0x474a74('0x3b6')][_0x474a74('0x5d7')][_0x474a74('0x280')](_0x21fa68[_0x474a74('0x339')][_0x474a74('0x644')]);
                    }
                    ,
                    _0x177ed2;
            }();
        new _0x5405fd();
    }
        , {
        './GameConfig': 0x1,
        './XGame': 0x4,
        './core/ServerAgency': 0x8,
        './enum/GameConst': 0xf,
        './enum/UIEnum': 0x13
    }],
    0x3: [function (_0x1cce7e, _0x54febf, _0x2c9409) {
        var _0x59c515 = _0x4b7fcf;
        'use strict';
        Object[_0x59c515('0x351')](_0x2c9409, _0x59c515('0xb8'), {
            'value': !![]
        });
        var _0x29ddc3 = _0x1cce7e(_0x59c515('0x663'))
            , _0x389ef8 = _0x1cce7e(_0x59c515('0x617'))
            , _0x14acd1 = function () {
                var _0x2b169f = _0x59c515;
                function _0x591dc1() { }
                _0x591dc1[_0x2b169f('0x64a')]['login'] = function (_0x7f7c7d) {
                    var _0x581948 = _0x2b169f;
                    _0x7f7c7d && _0x7f7c7d({
                        'code': 0x0,
                        'wxcode': _0x581948('0x248')
                    });
                }
                    ,
                    _0x591dc1['prototype']['launchInfo'] = function () {
                        return {};
                    }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x1a3')] = function (_0x3a98d8) {
                        return !![];
                    }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')]['onLoading'] = function (_0x3b7351) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x5ba')] = function (_0x66c60e, _0x56a81b, _0x5a9b43) {
                        var _0x1ca1a1 = _0x2b169f;
                        if (typeof _0x66c60e != _0x1ca1a1('0x51b'))
                            _0x66c60e(!![]);
                    }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x3d3')] = function () { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x383')] = function (_0x42e001) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x649')] = function (_0x494fd4) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x204')] = function (_0x4064a5) { }
                    ,
                    _0x591dc1['prototype'][_0x2b169f('0x595')] = function (_0x4fd2d6, _0x15fb2f) { }
                    ,
                    _0x591dc1['prototype'][_0x2b169f('0x1fd')] = function (_0x37183a) {
                        _0x37183a && _0x37183a(!![]);
                    }
                    ,
                    _0x591dc1['prototype'][_0x2b169f('0x535')] = function () { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x43f')] = function (_0x315070) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x4a7')] = function (_0x4d8e54) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x195')] = function (_0x35ca26) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x462')] = function () { }
                    ,
                    _0x591dc1['prototype'][_0x2b169f('0x3b7')] = function (_0x568c6c) { }
                    ,
                    _0x591dc1['prototype'][_0x2b169f('0x5d8')] = function (_0xd1feb8, _0x2ce483) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x289')] = function () { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x574')] = function (_0x16abb1) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x155')] = function (_0x481aba) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0xc3')] = function (_0x14642d, _0x4e5a2d, _0x49912c) {
                        _0x4e5a2d && _0x4e5a2d(!![]);
                    }
                    ,
                    _0x591dc1['prototype']['play4399Ad'] = function (_0x3e9c21) {
                        _0x3e9c21 && _0x3e9c21(null);
                    }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x2c9')] = function () { }
                    ,
                    _0x591dc1['prototype']['stopRecorderVedio'] = function () { }
                    ;
                ; _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x10c')] = function (_0x4b1465) { }
                    ;
                ; return _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x8')] = function (_0x212d38) { }
                    ,
                    _0x591dc1['prototype']['loadingComplete'] = function () { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x461')] = function () { }
                    ,
                    _0x591dc1['prototype']['vibrateLong'] = function () { }
                    ,
                    _0x591dc1['prototype']['createInnerAudioContext'] = function () { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0xbf')] = function (_0x518dad) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x20f')] = function () { }
                    ,
                    _0x591dc1['prototype']['postMessage'] = function (_0x541291) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x227')] = function (_0x3cb863) { }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')][_0x2b169f('0x283')] = function () {
                        var _0x2c9b91 = _0x2b169f;
                        return {
                            'brand': 'PC',
                            'model': _0x2c9b91('0x60f'),
                            'benchmarkLevel': 0x64
                        };
                    }
                    ,
                    _0x591dc1[_0x2b169f('0x64a')]['opLogin'] = function () { }
                    ,
                    _0x591dc1;
            }();
        _0x2c9409[_0x59c515('0xcf')] = _0x14acd1;
        var _0x28b7a5 = function () {
            var _0x241156 = _0x59c515;
            function _0x825089() { }
            return _0x825089['login'] = function (_0x3a1484) {
                var _0x2fe9d3 = _0x5985;
                window['platform'][_0x2fe9d3('0x41')](_0x3a1484);
            }
                ,
                _0x825089[_0x241156('0x54')] = function () {
                    var _0x2751ea = _0x241156;
                    return window[_0x2751ea('0xf5')][_0x2751ea('0x54')]();
                }
                ,
                _0x825089[_0x241156('0x383')] = function (_0x11e3e3) {
                    var _0x402b85 = _0x241156;
                    window[_0x402b85('0xf5')][_0x402b85('0x383')](_0x11e3e3);
                }
                ,
                _0x825089[_0x241156('0x649')] = function (_0x3ae487) {
                    var _0x640bc7 = _0x241156;
                    window[_0x640bc7('0xf5')][_0x640bc7('0x649')](_0x3ae487);
                }
                ,
                _0x825089[_0x241156('0x204')] = function (_0x3bcbac) {
                    var _0x20b036 = _0x241156;
                    window[_0x20b036('0xf5')][_0x20b036('0x204')](_0x3bcbac);
                }
                ,
                _0x825089['authorize'] = function (_0x136bb9, _0x3dc366) {
                    var _0x1bc124 = _0x241156;
                    window[_0x1bc124('0xf5')][_0x1bc124('0x595')](_0x136bb9, _0x3dc366);
                }
                ,
                _0x825089[_0x241156('0x1fd')] = function (_0x5f4f16) {
                    var _0x141930 = _0x241156;
                    window['platform'][_0x141930('0x1fd')](_0x5f4f16);
                }
                ,
                _0x825089[_0x241156('0x535')] = function () {
                    var _0x24a6b8 = _0x241156;
                    window[_0x24a6b8('0xf5')]['destroyButton']();
                }
                ,
                _0x825089[_0x241156('0x43f')] = function (_0x7cf1ad) {
                    var _0x37e544 = _0x241156;
                    window[_0x37e544('0xf5')][_0x37e544('0x43f')](_0x7cf1ad);
                }
                ,
                _0x825089[_0x241156('0x4a7')] = function (_0x2356c0) {
                    var _0x10a9d0 = _0x241156;
                    window[_0x10a9d0('0xf5')][_0x10a9d0('0x4a7')](_0x2356c0);
                }
                ,
                _0x825089[_0x241156('0x195')] = function (_0x498f6d) {
                    var _0x536c2c = _0x241156;
                    window['platform'][_0x536c2c('0x195')](_0x498f6d);
                }
                ,
                _0x825089[_0x241156('0x462')] = function () {
                    var _0x4dd9d5 = _0x241156;
                    return window[_0x4dd9d5('0xf5')][_0x4dd9d5('0x462')]();
                }
                ,
                _0x825089[_0x241156('0x3b7')] = function (_0xbb3a81) {
                    var _0x4aa203 = _0x241156;
                    window['platform'][_0x4aa203('0x3b7')](_0xbb3a81);
                }
                ,
                _0x825089[_0x241156('0x5d8')] = function (_0x47d384, _0x540451) {
                    var _0x4f30dd = _0x241156;
                    window[_0x4f30dd('0xf5')][_0x4f30dd('0x5d8')](_0x47d384, _0x540451);
                }
                ,
                _0x825089[_0x241156('0x289')] = function () {
                    var _0x128193 = _0x241156;
                    window[_0x128193('0xf5')][_0x128193('0x289')]();
                }
                ,
                _0x825089['setBannerVisible'] = function (_0x36af87) {
                    var _0x2aaf23 = _0x241156;
                    window['platform'][_0x2aaf23('0x574')](_0x36af87);
                }
                ,
                _0x825089[_0x241156('0x155')] = function (_0xc4358e) {
                    var _0x36a1ea = _0x241156;
                    window['platform'][_0x36a1ea('0x155')](_0xc4358e);
                }
                ,
                _0x825089[_0x241156('0xc3')] = function (_0x11abb3, _0x834b1f, _0x23d983) {
                    var _0x3f4047 = _0x241156;
                    if (_0x389ef8['GameConst'][_0x3f4047('0x400')] == _0x389ef8[_0x3f4047('0x52b')][_0x3f4047('0x32b')])
                        window['h5Platform']['createHaGoRewardedVideoAd'](_0x11abb3, _0x834b1f);
                    else
                        _0x389ef8[_0x3f4047('0x1d1')][_0x3f4047('0x400')] == _0x389ef8['PlatformType'][_0x3f4047('0x1e0')] ? window[_0x3f4047('0x50d')][_0x3f4047('0x546')](_0x834b1f) : window['platform'][_0x3f4047('0xc3')](_0x11abb3, _0x834b1f, _0x23d983);
                }
                ,
                _0x825089[_0x241156('0x2c9')] = function () {
                    var _0x3cf849 = _0x241156;
                    window[_0x3cf849('0xf5')]['startRecorderVedio']();
                }
                ,
                _0x825089[_0x241156('0x571')] = function () {
                    var _0x48774b = _0x241156;
                    window[_0x48774b('0xf5')]['stopRecorderVedio']();
                }
                ,
                _0x825089[_0x241156('0x10c')] = function (_0x158a9d) {
                    var _0x15fd49 = _0x241156;
                    window['platform'][_0x15fd49('0x10c')](_0x158a9d);
                }
                ,
                _0x825089['setLoadingProgress'] = function (_0x46340d) {
                    var _0x1640e9 = _0x241156;
                    window[_0x1640e9('0xf5')][_0x1640e9('0x8')](_0x46340d);
                }
                ,
                _0x825089[_0x241156('0x4a2')] = function () {
                    var _0x5c4cd6 = _0x241156;
                    window[_0x5c4cd6('0xf5')]['loadingComplete']();
                }
                ,
                _0x825089[_0x241156('0x461')] = function () {
                    var _0xb9b1c3 = _0x241156;
                    _0x29ddc3[_0xb9b1c3('0x3b6')][_0xb9b1c3('0x678')][_0xb9b1c3('0x5b5')] && window[_0xb9b1c3('0xf5')][_0xb9b1c3('0x461')]();
                }
                ,
                _0x825089[_0x241156('0x6')] = function () {
                    var _0x492dd1 = _0x241156;
                    _0x29ddc3['default'][_0x492dd1('0x678')][_0x492dd1('0x5b5')] && window[_0x492dd1('0xf5')]['vibrateLong']();
                }
                ,
                _0x825089[_0x241156('0x16c')] = function (_0x26f9a8) {
                    window['h5api']['playAd'](_0x26f9a8);
                }
                ,
                _0x825089[_0x241156('0x147')] = function (_0x10b453) {
                    var _0x46bb67 = _0x241156;
                    window[_0x46bb67('0x50d')][_0x46bb67('0x1ed')](_0x10b453);
                }
                ,
                _0x825089[_0x241156('0x653')] = function () {
                    var _0x3bfdc3 = _0x241156;
                    return window[_0x3bfdc3('0xf5')][_0x3bfdc3('0x653')]();
                }
                ,
                _0x825089['setUserCloudStorage'] = function (_0x3810dd) {
                    var _0x1204da = _0x241156;
                    window[_0x1204da('0xf5')][_0x1204da('0xbf')](_0x3810dd);
                }
                ,
                _0x825089[_0x241156('0x24')] = function (_0x3ac0c3) {
                    var _0x45f38a = _0x241156;
                    window[_0x45f38a('0xf5')][_0x45f38a('0x24')](_0x3ac0c3);
                }
                ,
                _0x825089[_0x241156('0x227')] = function (_0x6730d2) {
                    var _0x16b4db = _0x241156;
                    window[_0x16b4db('0xf5')]['onMessage'](_0x6730d2);
                }
                ,
                Object[_0x241156('0x351')](_0x825089, _0x241156('0x0'), {
                    'get': function () {
                        var _0x509f1e = _0x241156;
                        return window[_0x509f1e('0xf5')][_0x509f1e('0x0')];
                    },
                    'set': function (_0x1a71f2) {
                        var _0xef8f1f = _0x241156;
                        window['platform'][_0xef8f1f('0x0')] = _0x1a71f2;
                    },
                    'enumerable': !![],
                    'configurable': !![]
                }),
                _0x825089[_0x241156('0x283')] = function () {
                    var _0xaabb17 = _0x241156;
                    return window[_0xaabb17('0xf5')][_0xaabb17('0x283')]();
                }
                ,
                _0x825089;
        }();
        _0x2c9409['default'] = _0x28b7a5;
    }
        , {
        './XGame': 0x4,
        './enum/GameConst': 0xf
    }],
    0x4: [function (_0x1cd23d, _0x4f5273, _0x242e16) {
        var _0x598484 = _0x4b7fcf;
        'use strict';
        Object[_0x598484('0x351')](_0x242e16, '__esModule', {
            'value': !![]
        });
        var _0x3b74fb = _0x1cd23d(_0x598484('0x4e4'))
            , _0x3da47a = _0x1cd23d(_0x598484('0x48b'))
            , _0x5343c9 = _0x1cd23d(_0x598484('0x69a'))
            , _0x1316c5 = _0x1cd23d('./manager/ConfigManager')
            , _0x3fcb5b = _0x1cd23d(_0x598484('0x51d'))
            , _0x1b5735 = _0x1cd23d(_0x598484('0x20a'))
            , _0x5e6697 = _0x1cd23d('./manager/GameManager')
            , _0x354e96 = _0x1cd23d(_0x598484('0x65b'))
            , _0x276e37 = _0x1cd23d(_0x598484('0x2e0'))
            , _0x18d664 = _0x1cd23d(_0x598484('0x1d0'))
            , _0x168eb4 = _0x1cd23d('./manager/TimeManager')
            , _0x57a6bc = function () {
                var _0x16b4e1 = _0x598484;
                function _0x31ebf3() { }
                return _0x31ebf3[_0x16b4e1('0x458')] = function () {
                    var _0x25b3eb = _0x16b4e1;
                    _0x31ebf3['CfgMgr'] = new _0x1316c5[(_0x25b3eb('0x3b6'))](),
                        _0x31ebf3[_0x25b3eb('0x60d')] = new _0x5343c9[(_0x25b3eb('0x3b6'))](),
                        _0x31ebf3[_0x25b3eb('0x678')] = new _0x1b5735[(_0x25b3eb('0x3b6'))](),
                        _0x31ebf3[_0x25b3eb('0x370')] = new _0x3b74fb['default'](),
                        _0x31ebf3[_0x25b3eb('0x61b')] = new _0x3fcb5b['default'](),
                        _0x31ebf3[_0x25b3eb('0x5d7')] = new _0x3da47a[(_0x25b3eb('0x3b6'))](),
                        _0x31ebf3['SceneMgr'] = new _0x354e96['default'](),
                        _0x31ebf3[_0x25b3eb('0x33b')] = new _0x5e6697[(_0x25b3eb('0x3b6'))](),
                        _0x31ebf3['EffMgr'] = new _0x18d664[(_0x25b3eb('0x3b6'))](),
                        _0x31ebf3[_0x25b3eb('0x1ab')] = new _0x168eb4[(_0x25b3eb('0x3b6'))](),
                        window[_0x25b3eb('0x370')] = _0x31ebf3[_0x25b3eb('0x370')],
                        window[_0x25b3eb('0x61b')] = _0x31ebf3[_0x25b3eb('0x61b')],
                        window[_0x25b3eb('0x5d7')] = _0x31ebf3[_0x25b3eb('0x5d7')],
                        !window[_0x25b3eb('0xf5')] && (window[_0x25b3eb('0xf5')] = new _0x276e37[(_0x25b3eb('0xcf'))]());
                }
                    ,
                    _0x31ebf3;
            }();
        _0x242e16[_0x598484('0x3b6')] = _0x57a6bc;
    }
        , {
        './Platform': 0x3,
        './manager/ConfigManager': 0x14,
        './manager/DataManager': 0x15,
        './manager/EffectManager': 0x16,
        './manager/EventManager': 0x17,
        './manager/GameManager': 0x18,
        './manager/ResourceManager': 0x19,
        './manager/SceneManager': 0x1a,
        './manager/SoundManager': 0x1b,
        './manager/TimeManager': 0x1c,
        './manager/UIManager': 0x1d
    }],
    0x5: [function (_0x14ffb6, _0x8ec3c1, _0x8329fd) {
        var _0x16e6ab = _0x4b7fcf;
        'use strict';
        Object[_0x16e6ab('0x351')](_0x8329fd, _0x16e6ab('0xb8'), {
            'value': !![]
        });
        var _0x48267e = function (_0x418d3f) {
            var _0x1d9e11 = _0x16e6ab;
            __extends(_0x40be39, _0x418d3f);
            function _0x40be39() {
                var _0x41c58a = _0x5985;
                return _0x418d3f[_0x41c58a('0x324')](this) || this;
            }
            return _0x40be39[_0x1d9e11('0x64a')]['onAwake'] = function () {
                var _0xe10532 = _0x1d9e11;
                this[_0xe10532('0x5d3')] = this[_0xe10532('0x67a')],
                    this[_0xe10532('0xb6')] = this[_0xe10532('0x5d3')][_0xe10532('0xb6')],
                    this[_0xe10532('0xb6')][_0xe10532('0x45b')] = new Laya[(_0xe10532('0x592'))](0x0, 0x0, 0x0),
                    this['transform'][_0xe10532('0x61f')] = new Laya[(_0xe10532('0x4b8'))](0x0, 0x0, 0x0, -0x1),
                    this[_0xe10532('0xb6')]['localScale'] = new Laya['Vector3'](0x1, 0x1, 0x1);
            }
                ,
                _0x40be39;
        }(Laya[_0x16e6ab('0x5c')]);
        _0x8329fd[_0x16e6ab('0x3b6')] = _0x48267e;
    }
        , {}],
    0x6: [function (_0x4ec4f7, _0x3dc1a5, _0x50fa75) {
        var _0x411358 = _0x4b7fcf;
        'use strict';
        Object[_0x411358('0x351')](_0x50fa75, _0x411358('0xb8'), {
            'value': !![]
        });
        var _0x524d84 = _0x4ec4f7('../base/GameObjcet3D')
            , _0x586d4c = _0x4ec4f7(_0x411358('0x167'))
            , _0x32ae51 = _0x4ec4f7('../enum/GameEnum')
            , _0x27f938 = function (_0xa54c65) {
                var _0x166bc7 = _0x411358;
                __extends(_0x2432bd, _0xa54c65);
                function _0x2432bd() {
                    var _0x171839 = _0x5985
                        , _0x4991a1 = _0xa54c65[_0x171839('0x324')](this) || this;
                    return _0x4991a1['_lerp'] = new Laya[(_0x171839('0x592'))](),
                        _0x4991a1[_0x171839('0xbc')] = 1.15,
                        _0x4991a1[_0x171839('0x222')] = 1.66,
                        _0x4991a1[_0x171839('0x1a8')] = -0x4,
                        _0x4991a1;
                }
                return _0x2432bd['prototype'][_0x166bc7('0x4fc')] = function () {
                    var _0x58fe03 = _0x166bc7;
                    _0xa54c65['prototype'][_0x58fe03('0x4fc')]['call'](this),
                        this[_0x58fe03('0x98')] = this[_0x58fe03('0x5d3')],
                        this[_0x58fe03('0xb6')][_0x58fe03('0x13')] = new Laya['Vector3'](0x0, this[_0x58fe03('0xbc')], this[_0x58fe03('0x1a8')]),
                        this[_0x58fe03('0xb6')][_0x58fe03('0x2e')] = new Laya[(_0x58fe03('0x592'))](0x0, 0xb4, 0x0);
                }
                    ,
                    _0x2432bd['prototype']['onUpdate'] = function () {
                        var _0x2d41c6 = _0x166bc7;
                        if (_0x586d4c[_0x2d41c6('0x3b6')][_0x2d41c6('0x33b')][_0x2d41c6('0x353')] != _0x32ae51[_0x2d41c6('0x281')]['State'][_0x2d41c6('0x3c1')])
                            return;
                        var _0x675a06 = Laya[_0x2d41c6('0x5ac')][_0x2d41c6('0x479')] / 0x3e8
                            , _0xa05e3b = _0x586d4c[_0x2d41c6('0x3b6')][_0x2d41c6('0x33b')][_0x2d41c6('0x38b')][_0x2d41c6('0x331')][_0x2d41c6('0xb6')][_0x2d41c6('0x13')]['y'] / 0x4 * (this['maxY'] - this[_0x2d41c6('0xbc')]);
                        this[_0x2d41c6('0x355')][_0x2d41c6('0x3a0')](0x0, this[_0x2d41c6('0xbc')] + _0xa05e3b, this['defZ']),
                            Laya[_0x2d41c6('0x592')]['lerp'](this[_0x2d41c6('0xb6')][_0x2d41c6('0x13')], this[_0x2d41c6('0x355')], _0x675a06, this[_0x2d41c6('0x355')]),
                            this[_0x2d41c6('0xb6')][_0x2d41c6('0x13')] = this['_lerp'][_0x2d41c6('0x2f')]();
                    }
                    ,
                    _0x2432bd;
            }(_0x524d84[_0x411358('0x3b6')]);
        _0x50fa75[_0x411358('0x3b6')] = _0x27f938;
    }
        , {
        '../XGame': 0x4,
        '../base/GameObjcet3D': 0x5,
        '../enum/GameEnum': 0x10
    }],
    0x7: [function (_0x204c0d, _0x58ece7, _0x57d3f0) {
        var _0x1a7ba8 = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x57d3f0, '__esModule', {
            'value': !![]
        });
        var _0x49b239 = _0x204c0d(_0x1a7ba8('0x2ce'))
            , _0x4f0d77 = _0x204c0d(_0x1a7ba8('0x167'))
            , _0x1ccc73 = function () {
                var _0x4dfce6 = _0x1a7ba8;
                function _0x4028f8() { }
                return _0x4028f8[_0x4dfce6('0x249')] = function (_0x467f04, _0x5520dd, _0x1a7e5f, _0x3b2b23, _0xaae5a4) {
                    var _0x414ab5 = _0x4dfce6;
                    _0xaae5a4 === void 0x0 && (_0xaae5a4 = ![]);
                    var _0x55d8d3 = {};
                    _0x55d8d3[_0x414ab5('0x5ab')] = _0x414ab5('0x60e'),
                        _0x55d8d3[_0x414ab5('0xf5')] = _0x49b239[_0x414ab5('0x1d1')][_0x414ab5('0x400')],
                        _0x55d8d3[_0x414ab5('0x2c8')] = _0x49b239[_0x414ab5('0x1d1')][_0x414ab5('0x295')],
                        _0x55d8d3[_0x414ab5('0x298')] = _0x4f0d77['default'][_0x414ab5('0x678')]['openId'],
                        _0x55d8d3[_0x414ab5('0x587')] = _0x5520dd;
                    var _0x9dc264 = ''
                        , _0x1c4fd4 = !![];
                    for (var _0x582af0 in _0x55d8d3) {
                        _0x1c4fd4 ? (_0x1c4fd4 = ![],
                            _0x9dc264 += '?') : _0x9dc264 += '&',
                            _0x9dc264 += _0x582af0 + '=' + _0x55d8d3[_0x582af0];
                    }
                    _0x1a7e5f = JSON[_0x414ab5('0x41c')](_0x1a7e5f);
                    var _0xd9c11c = _0x467f04 + _0x9dc264
                        , _0x1727a6 = new Laya[(_0x414ab5('0x5ae'))]();
                    _0x1727a6[_0x414ab5('0x15a')][_0x414ab5('0x5c4')] = 0x3e8,
                        _0x1727a6[_0x414ab5('0x1e6')](Laya[_0x414ab5('0x68f')][_0x414ab5('0x245')], this, function (_0x285007) {
                            _0x3b2b23 && _0x3b2b23(_0x285007);
                        }),
                        _0x1727a6[_0x414ab5('0x1e6')](Laya[_0x414ab5('0x68f')][_0x414ab5('0x300')], this, function (_0x583b1d) {
                            var _0x5199d9 = _0x414ab5;
                            console['error'](_0x5199d9('0x27d') + _0x583b1d),
                                _0x3b2b23 && _0x3b2b23(_0x583b1d);
                        }),
                        _0xaae5a4 ? _0x1727a6[_0x414ab5('0x118')](_0xd9c11c, _0x1a7e5f, _0x414ab5('0x1ee'), _0x414ab5('0x66')) : _0x1727a6[_0x414ab5('0x118')](_0xd9c11c, null, 'get', _0x414ab5('0x66'));
                }
                    ,
                    _0x4028f8;
            }();
        _0x57d3f0['default'] = _0x1ccc73;
    }
        , {
        '../XGame': 0x4,
        '../enum/GameConst': 0xf
    }],
    0x8: [function (_0x57df37, _0x392443, _0x2b3794) {
        var _0x2d16e4 = _0x4b7fcf;
        'use strict';
        Object[_0x2d16e4('0x351')](_0x2b3794, _0x2d16e4('0xb8'), {
            'value': !![]
        });
        var _0x245f94 = _0x57df37(_0x2d16e4('0x2ce'))
            , _0x410e03 = _0x57df37(_0x2d16e4('0x1f3'))
            , _0x8b235b = _0x57df37(_0x2d16e4('0x1b'))
            , _0x1cd88e = _0x57df37(_0x2d16e4('0x167'))
            , _0x398b87 = function () {
                var _0x3a46cf = _0x2d16e4;
                function _0x2bd3ec() { }
                return _0x2bd3ec[_0x3a46cf('0x64a')]['login'] = function () {
                    var _0x2183f3 = _0x3a46cf;
                    if (_0x245f94[_0x2183f3('0x1d1')][_0x2183f3('0x400')] == _0x245f94[_0x2183f3('0x52b')]['OPPOAd']) {
                        _0x8b235b[_0x2183f3('0x3b6')][_0x2183f3('0x41')](null);
                        return;
                    }
                    _0x8b235b['default'][_0x2183f3('0x41')](function (_0x5d822f) {
                        var _0x3bf04f = _0x2183f3;
                        if (_0x5d822f[_0x3bf04f('0x559')] == 0x0) {
                            console['log']('########\x20登录成功\x20', _0x5d822f),
                                _0x1cd88e[_0x3bf04f('0x3b6')]['DataMgr'][_0x3bf04f('0x4ea')] = _0x5d822f[_0x3bf04f('0x161')];
                            var _0x25b2a2 = _0x8b235b[_0x3bf04f('0x3b6')][_0x3bf04f('0x54')]()
                                , _0x388d2c = {};
                            if (_0x25b2a2) {
                                _0x388d2c[_0x3bf04f('0x3a4')] = _0x25b2a2[_0x3bf04f('0x3a4')],
                                    _0x388d2c[_0x3bf04f('0x275')] = JSON[_0x3bf04f('0x41c')](_0x25b2a2[_0x3bf04f('0x275')]);
                                var _0x64594 = _0x25b2a2[_0x3bf04f('0x275')];
                                _0x64594 && _0x64594[_0x3bf04f('0x312')] && _0x64594['account_id'] && (_0x388d2c[_0x3bf04f('0x197')] = JSON[_0x3bf04f('0x41c')]({
                                    'sharecard_id': _0x410e03['default'][_0x3bf04f('0x21e')](_0x64594[_0x3bf04f('0x312')]),
                                    'account_id': _0x410e03[_0x3bf04f('0x3b6')][_0x3bf04f('0x21e')](_0x64594['account_id']),
                                    'from': _0x64594[_0x3bf04f('0x3fa')]
                                }));
                            }
                        } else { }
                    });
                }
                    ,
                    _0x2bd3ec[_0x3a46cf('0x64a')]['loginBack'] = function (_0x838ced) { }
                    ,
                    _0x2bd3ec[_0x3a46cf('0x64a')][_0x3a46cf('0x4d6')] = function (_0x18e07b) {
                        var _0x5b2659 = _0x3a46cf
                            , _0x599161 = {}
                            , _0x1a6e8a = 0x0
                            , _0x16420b = _0x1cd88e[_0x5b2659('0x3b6')][_0x5b2659('0x678')][_0x5b2659('0x6b2')][_0x5b2659('0x4cc')];
                        _0x16420b > 0x1 && (_0x1a6e8a = Math['floor'](Math[_0x5b2659('0x139')]() * _0x16420b));
                        var _0x5d7710 = _0x1cd88e['default'][_0x5b2659('0x678')][_0x5b2659('0x6b2')][_0x1a6e8a];
                        _0x5d7710[_0x5b2659('0x54d')] > 0x0 && (_0x599161[_0x5b2659('0x3f1')] = _0x245f94[_0x5b2659('0x1d1')][_0x5b2659('0xe0')],
                            _0x599161[_0x5b2659('0x432')] = _0x5d7710[_0x5b2659('0x54d')]);
                        var _0x573685 = 0x0;
                        _0x18e07b && (_0x18e07b[_0x5b2659('0x186')][_0x5b2659('0x64f')]++,
                            _0x573685 = _0x18e07b[_0x5b2659('0x186')][_0x5b2659('0x64f')]);
                        var _0x24ffb1 = ![];
                        _0x8b235b['default'][_0x5b2659('0x195')]({
                            'title': _0x5d7710[_0x5b2659('0x396')],
                            'imageUrl': _0x5d7710[_0x5b2659('0x639')],
                            'query': _0x599161,
                            'forceShare': _0x24ffb1,
                            'shareCnt': _0x573685,
                            'success': function (_0x234a60) {
                                var _0x5291e7 = _0x5b2659;
                                _0x18e07b && _0x18e07b[_0x5291e7('0x681')](!![]);
                            },
                            'fail': function (_0x4148b2) {
                                var _0x5de085 = _0x5b2659;
                                typeof _0x4148b2 == 'string' && (console[_0x5de085('0x5df')](_0x4148b2, _0x5de085('0x2ba')),
                                    _0x1cd88e[_0x5de085('0x3b6')][_0x5de085('0x5d7')]['showTips'](_0x4148b2)),
                                    _0x18e07b && _0x18e07b[_0x5de085('0x681')](![]);
                            }
                        });
                    }
                    ,
                    _0x2bd3ec['prototype'][_0x3a46cf('0x1a6')] = function () { }
                    ,
                    _0x2bd3ec['instance'] = new _0x2bd3ec(),
                    _0x2bd3ec;
            }();
        _0x2b3794[_0x2d16e4('0x3b6')] = _0x398b87;
    }
        , {
        '../Platform': 0x3,
        '../XGame': 0x4,
        '../enum/GameConst': 0xf,
        '../utils/Utils': 0x38
    }],
    0x9: [function (_0x19a71a, _0x252708, _0x3f5461) {
        var _0x3c703a = _0x4b7fcf;
        'use strict';
        Object[_0x3c703a('0x351')](_0x3f5461, _0x3c703a('0xb8'), {
            'value': !![]
        });
        var _0x1d5108 = _0x19a71a(_0x3c703a('0x129'))
            , _0x1261f = _0x19a71a(_0x3c703a('0x167'))
            , _0x526cc6 = _0x19a71a(_0x3c703a('0x1ce'))
            , _0x581133 = _0x19a71a(_0x3c703a('0x1b1'))
            , _0x500f94 = _0x19a71a('../utils/Tools')
            , _0x531aeb = function (_0x37dddd) {
                var _0x2654ed = _0x3c703a;
                __extends(_0x3f01e2, _0x37dddd);
                function _0x3f01e2() {
                    return _0x37dddd['call'](this) || this;
                }
                return _0x3f01e2[_0x2654ed('0x64a')][_0x2654ed('0x4fc')] = function () {
                    var _0x331c46 = _0x2654ed;
                    _0x37dddd[_0x331c46('0x64a')][_0x331c46('0x4fc')][_0x331c46('0x324')](this),
                        this[_0x331c46('0xb6')][_0x331c46('0x40f')] = 1.3,
                        this[_0x331c46('0x76')] = this['gameobject']['addChild'](_0x1261f[_0x331c46('0x3b6')][_0x331c46('0x60d')]['GetPrefab'](_0x331c46('0x36'))),
                        this['_rigibody'] = this[_0x331c46('0x5d3')][_0x331c46('0x612')](Laya[_0x331c46('0x78')]),
                        this[_0x331c46('0x19d')]['collisionGroup'] = _0x526cc6['MaskEnum'][_0x331c46('0x34a')],
                        this['_rigibody']['canCollideWith'] = _0x526cc6[_0x331c46('0x138')][_0x331c46('0x331')] | _0x526cc6[_0x331c46('0x138')][_0x331c46('0x384')],
                        this[_0x331c46('0x19d')][_0x331c46('0x3ce')] = new Laya['Vector3'](0x0, 0x0, 0x0),
                        this[_0x331c46('0x19d')][_0x331c46('0x25d')] = new Laya['Vector3'](0x0, 0x1, 0x0),
                        this[_0x331c46('0x19d')][_0x331c46('0x10')] = !![],
                        this[_0x331c46('0x19d')][_0x331c46('0x8a')] = new Laya['Vector3'](0x0, 0x0, 0x0),
                        this[_0x331c46('0x19d')][_0x331c46('0xfc')] = _0x1261f['default'][_0x331c46('0x33b')][_0x331c46('0x508')],
                        this[_0x331c46('0xb6')][_0x331c46('0x522')] = new Laya[(_0x331c46('0x592'))](1.3, 1.3, 1.3);
                }
                    ,
                    _0x3f01e2[_0x2654ed('0x64a')]['InitBall'] = function () {
                        var _0xdf8749 = _0x2654ed
                            , _0x6cc27b = this;
                        this['SetRigibody'](![]),
                            this[_0xdf8749('0x5d3')]['addChild'](this[_0xdf8749('0x76')]),
                            this[_0xdf8749('0x76')][_0xdf8749('0x4ba')] = !![],
                            this[_0xdf8749('0x76')][_0xdf8749('0xb6')]['localPosition'] = Laya[_0xdf8749('0x592')][_0xdf8749('0x7f')],
                            this['_child'][_0xdf8749('0xb6')]['localRotationEuler'] = new Laya[(_0xdf8749('0x592'))](0x5a, 0x0, 0x0),
                            this[_0xdf8749('0xb6')][_0xdf8749('0x45b')] = new Laya[(_0xdf8749('0x592'))](0x0, 1.9, 0x0),
                            this[_0xdf8749('0x65c')] = 1.9,
                            Laya['Tween'][_0xdf8749('0x3fa')](this[_0xdf8749('0xb6')], {
                                'localPositionY': 0x4
                            }, 0x3e8, Laya[_0xdf8749('0x2a3')][_0xdf8749('0x1b7')], Laya['Handler']['create'](this, function () {
                                var _0x566e83 = _0xdf8749;
                                _0x6cc27b['transform']['localPositionY'] = _0x6cc27b[_0x566e83('0x65c')],
                                    _0x6cc27b[_0x566e83('0x695')](!![]);
                            }));
                    }
                    ,
                    _0x3f01e2[_0x2654ed('0x64a')][_0x2654ed('0x489')] = function () {
                        var _0x53c5e0 = _0x2654ed
                            , _0xb0dc56 = Math[_0x53c5e0('0x43e')](this[_0x53c5e0('0xb6')]['localPositionY'] * 0x64) / 0x64;
                        if (_0xb0dc56 > this[_0x53c5e0('0x65c')] + 0.02)
                            this[_0x53c5e0('0x19d')][_0x53c5e0('0x4')] = new Laya[(_0x53c5e0('0x592'))](0x0, -_0x1261f['default'][_0x53c5e0('0x33b')][_0x53c5e0('0x5bd')], 0x0);
                        else
                            _0xb0dc56 < this[_0x53c5e0('0x65c')] - 0.02 ? this[_0x53c5e0('0x19d')][_0x53c5e0('0x4')] = new Laya[(_0x53c5e0('0x592'))](0x0, _0x1261f[_0x53c5e0('0x3b6')][_0x53c5e0('0x33b')]['BallSpeed'], 0x0) : this[_0x53c5e0('0x19d')][_0x53c5e0('0x4')] = Laya[_0x53c5e0('0x592')][_0x53c5e0('0x7f')];
                    }
                    ,
                    _0x3f01e2[_0x2654ed('0x64a')][_0x2654ed('0x695')] = function (_0x44c60a) {
                        var _0x32731f = _0x2654ed;
                        if (this[_0x32731f('0x19d')][_0x32731f('0x3cd')] == _0x44c60a)
                            return;
                        this[_0x32731f('0x19d')][_0x32731f('0x3cd')] = _0x44c60a;
                    }
                    ,
                    _0x3f01e2[_0x2654ed('0x64a')]['RandomPosition'] = function () {
                        var _0x106d0f = _0x2654ed
                            , _0x15977c = this;
                        if (_0x1261f[_0x106d0f('0x3b6')][_0x106d0f('0x33b')][_0x106d0f('0x353')] != _0x581133[_0x106d0f('0x281')][_0x106d0f('0x170')][_0x106d0f('0x3c1')])
                            return;
                        var _0x24b1b5 = _0x500f94[_0x106d0f('0x3b6')][_0x106d0f('0x69b')](-0.8, 0.8);
                        if (this[_0x106d0f('0xb6')]['localPositionX'] > 0x0)
                            _0x24b1b5 = _0x500f94[_0x106d0f('0x3b6')][_0x106d0f('0x69b')](-0.8, -0.1);
                        else
                            this[_0x106d0f('0xb6')][_0x106d0f('0x556')] < 0x0 && (_0x24b1b5 = _0x500f94[_0x106d0f('0x3b6')][_0x106d0f('0x69b')](0.1, 0.8));
                        var _0x13c0df = _0x500f94[_0x106d0f('0x3b6')]['RandomRange'](1.3, 2.5);
                        this[_0x106d0f('0x695')](![]),
                            Laya[_0x106d0f('0x34d')]['to'](this[_0x106d0f('0xb6')], {
                                'localScaleX': 0x0,
                                'localScaleY': 0x0,
                                'localScaleZ': 0x0
                            }, 0x64, null, Laya['Handler'][_0x106d0f('0x5fb')](this, function () {
                                var _0x3865cd = _0x106d0f;
                                _0x15977c['transform'][_0x3865cd('0x45b')] = new Laya[(_0x3865cd('0x592'))](_0x24b1b5, _0x13c0df, 0x0),
                                    Laya[_0x3865cd('0x34d')]['to'](_0x15977c[_0x3865cd('0xb6')], {
                                        'localScaleX': 1.3,
                                        'localScaleY': 1.3,
                                        'localScaleZ': 1.3
                                    }, 0xc8, Laya['Ease'][_0x3865cd('0x1b7')], Laya[_0x3865cd('0x49f')][_0x3865cd('0x5fb')](_0x15977c, function () {
                                        var _0x1cf1fb = _0x3865cd;
                                        _0x15977c[_0x1cf1fb('0xb6')][_0x1cf1fb('0x522')] = new Laya[(_0x1cf1fb('0x592'))](1.3, 1.3, 1.3),
                                            _0x15977c['SetRigibody'](!![]);
                                    }));
                            })),
                            this[_0x106d0f('0x65c')] = _0x13c0df;
                    }
                    ,
                    _0x3f01e2;
            }(_0x1d5108['default']);
        _0x3f5461[_0x3c703a('0x3b6')] = _0x531aeb;
    }
        , {
        '../XGame': 0x4,
        '../base/GameObjcet3D': 0x5,
        '../enum/GameEnum': 0x10,
        '../enum/MaskEnum': 0x11,
        '../utils/Tools': 0x37
    }],
    0xa: [function (_0x4905f5, _0x54f12e, _0xe4bcd7) {
        var _0x1a2559 = _0x4b7fcf;
        'use strict';
        Object[_0x1a2559('0x351')](_0xe4bcd7, _0x1a2559('0xb8'), {
            'value': !![]
        });
        var _0x544d54 = _0x4905f5(_0x1a2559('0x129'))
            , _0x2edc09 = _0x4905f5(_0x1a2559('0x167'))
            , _0x40de9e = function (_0x484780) {
                var _0x2e8e84 = _0x1a2559;
                __extends(_0x5e2e0c, _0x484780);
                function _0x5e2e0c() {
                    var _0x2136cc = _0x5985
                        , _0x30acfe = _0x484780[_0x2136cc('0x324')](this) || this;
                    return _0x30acfe['_rotation'] = new Laya[(_0x2136cc('0x592'))](0x0, 0.1, 0x0),
                        _0x30acfe;
                }
                return _0x5e2e0c[_0x2e8e84('0x64a')][_0x2e8e84('0x4fc')] = function () {
                    var _0x10a1d0 = _0x2e8e84;
                    _0x484780[_0x10a1d0('0x64a')][_0x10a1d0('0x4fc')][_0x10a1d0('0x324')](this),
                        this['_crown'] = this['gameobject'][_0x10a1d0('0x5')](_0x2edc09['default'][_0x10a1d0('0x60d')]['GetPrefab'](_0x10a1d0('0x69d'))),
                        this[_0x10a1d0('0x119')][_0x10a1d0('0xb6')]['localPosition'] = new Laya[(_0x10a1d0('0x592'))](0x0, 0.35, 0x0);
                }
                    ,
                    _0x5e2e0c[_0x2e8e84('0x64a')]['onUpdate'] = function () {
                        var _0x3acbdc = _0x2e8e84;
                        this[_0x3acbdc('0x119')]['transform']['rotate'](this[_0x3acbdc('0x6a8')], !![]);
                        if (this[_0x3acbdc('0x62a')] == null)
                            return;
                        this['transform']['position'] = this[_0x3acbdc('0x62a')][_0x3acbdc('0x13')]['clone']();
                    }
                    ,
                    _0x5e2e0c[_0x2e8e84('0x64a')][_0x2e8e84('0x567')] = function (_0x4ec8d8) {
                        this['_target'] = _0x4ec8d8;
                    }
                    ,
                    _0x5e2e0c;
            }(_0x544d54['default']);
        _0xe4bcd7[_0x1a2559('0x3b6')] = _0x40de9e;
    }
        , {
        '../XGame': 0x4,
        '../base/GameObjcet3D': 0x5
    }],
    0xb: [function (_0x3b7cb9, _0x4233ed, _0x13651b) {
        var _0x3e8144 = _0x4b7fcf;
        'use strict';
        Object[_0x3e8144('0x351')](_0x13651b, _0x3e8144('0xb8'), {
            'value': !![]
        });
        var _0x383b91 = _0x3b7cb9(_0x3e8144('0x129'))
            , _0x435376 = _0x3b7cb9(_0x3e8144('0x1ce'))
            , _0x454f75 = _0x3b7cb9(_0x3e8144('0x1b1'))
            , _0x49302b = _0x3b7cb9(_0x3e8144('0x232'))
            , _0x47fde5 = _0x3b7cb9('../XGame')
            , _0x19aacc = _0x3b7cb9(_0x3e8144('0x550'))
            , _0x270057 = function (_0x43959d) {
                var _0x3870c7 = _0x3e8144;
                __extends(_0x26e8c5, _0x43959d);
                function _0x26e8c5() {
                    var _0x5c2527 = _0x5985
                        , _0x4bf920 = _0x43959d['call'](this) || this;
                    return _0x4bf920['_foceFlag'] = ![],
                        _0x4bf920[_0x5c2527('0x635')] = ![],
                        _0x4bf920['_firstEnterIndex'] = 0x0,
                        _0x4bf920[_0x5c2527('0x22d')] = 0x0,
                        _0x4bf920[_0x5c2527('0x1f')] = {
                            0x0: 0x0,
                            0x1: 0x0
                        },
                        _0x4bf920;
                }
                return _0x26e8c5['prototype']['onAwake'] = function () {
                    var _0x7a1826 = _0x5985;
                    _0x43959d[_0x7a1826('0x64a')][_0x7a1826('0x4fc')][_0x7a1826('0x324')](this),
                        this[_0x7a1826('0x465')] = this[_0x7a1826('0xb6')]['_parent'][_0x7a1826('0x67a')]['getComponent'](_0x19aacc[_0x7a1826('0x3b6')]),
                        this[_0x7a1826('0x19d')] = this['gameobject'][_0x7a1826('0x612')](Laya[_0x7a1826('0x78')]),
                        this[_0x7a1826('0x19d')]['overrideGravity'] = !![],
                        this[_0x7a1826('0x19d')][_0x7a1826('0x25d')] = new Laya[(_0x7a1826('0x592'))](0x1, 0x1, 0x0),
                        this[_0x7a1826('0x19d')][_0x7a1826('0x3ce')] = new Laya[(_0x7a1826('0x592'))](0x0, 0x0, 0x1),
                        this['_rigibody']['gravity'] = new Laya['Vector3'](0x0, -_0x47fde5['default'][_0x7a1826('0x33b')][_0x7a1826('0x608')], 0x0),
                        this[_0x7a1826('0x19d')][_0x7a1826('0x19b')] = 0x0,
                        this['_rigibody'][_0x7a1826('0xa')] = 0x1,
                        this[_0x7a1826('0x19d')][_0x7a1826('0xa1')] = 0.1,
                        this[_0x7a1826('0x19d')][_0x7a1826('0x221')] = _0x435376['MaskEnum']['Hoop'],
                        this[_0x7a1826('0x19d')][_0x7a1826('0x3d1')] = _0x435376[_0x7a1826('0x138')]['Hoop'] | _0x435376[_0x7a1826('0x138')]['Ball'] | _0x435376[_0x7a1826('0x138')][_0x7a1826('0xf4')],
                        this[_0x7a1826('0x19d')]['simulation'][_0x7a1826('0x2b7')] = 0x1 / 0x32,
                        this[_0x7a1826('0x19d')][_0x7a1826('0xfc')] = _0x47fde5[_0x7a1826('0x3b6')][_0x7a1826('0x33b')][_0x7a1826('0x3a1')],
                        this[_0x7a1826('0x5d3')][_0x7a1826('0x5e7')]['castShadow'] = !![],
                        this[_0x7a1826('0xb6')]['localScale'] = new Laya['Vector3'](1.3, 1.3, 1.3),
                        this[_0x7a1826('0x5da')] = this[_0x7a1826('0x5d3')]['addChild'](new Laya[(_0x7a1826('0x55a'))](_0x7a1826('0x384')))[_0x7a1826('0x5a3')](_0x49302b['default']),
                        this[_0x7a1826('0x5da')][_0x7a1826('0x469')](this, 0x1, new Laya[(_0x7a1826('0x592'))](0x0, 0.05, 0x0)),
                        this[_0x7a1826('0x145')] = this[_0x7a1826('0x5d3')]['addChild'](new Laya['Sprite3D'](_0x7a1826('0x384')))['addComponent'](_0x49302b[_0x7a1826('0x3b6')]),
                        this[_0x7a1826('0x145')]['SetCollider'](this, 0x2, new Laya[(_0x7a1826('0x592'))](0x0, -0.05, 0x0));
                }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x32d')] = function (_0x2162b4) {
                        var _0x5bdff2 = _0x3870c7
                            , _0x3cb479 = this;
                        this[_0x5bdff2('0xb6')]['localPosition'] = new Laya[(_0x5bdff2('0x592'))](_0x2162b4, 0.4, 0x0),
                            this[_0x5bdff2('0xb6')][_0x5bdff2('0x25e')] = new Laya[(_0x5bdff2('0x592'))](0x0, 0x0, 0x0),
                            this[_0x5bdff2('0x635')] = ![],
                            this[_0x5bdff2('0x2a8')] = ![],
                            this[_0x5bdff2('0x695')](![]),
                            Laya['Tween'][_0x5bdff2('0x3fa')](this[_0x5bdff2('0xb6')], {
                                'localPositionX': _0x2162b4 * 0x2
                            }, 0x384, Laya[_0x5bdff2('0x2a3')][_0x5bdff2('0x1b7')], Laya[_0x5bdff2('0x49f')]['create'](this, function () {
                                var _0x140fb9 = _0x5bdff2;
                                _0x3cb479[_0x140fb9('0xb6')][_0x140fb9('0x45b')] = new Laya[(_0x140fb9('0x592'))](_0x2162b4, 0.4, 0x0);
                            }));
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')]['AddForce'] = function (_0x497204) {
                        var _0x3e8d62 = _0x3870c7;
                        if (this[_0x3e8d62('0x2a8')] == !![] || _0x47fde5[_0x3e8d62('0x3b6')][_0x3e8d62('0x33b')]['state'] != _0x454f75[_0x3e8d62('0x281')][_0x3e8d62('0x170')][_0x3e8d62('0x3c1')])
                            return;
                        var _0x584ba4 = this['_player'][_0x3e8d62('0x5d3')][_0x3e8d62('0x5')](_0x47fde5[_0x3e8d62('0x3b6')][_0x3e8d62('0x51')][_0x3e8d62('0x36d')](_0x3e8d62('0x22f')));
                        _0x584ba4[_0x3e8d62('0xb6')][_0x3e8d62('0x13')] = this[_0x3e8d62('0xb6')][_0x3e8d62('0x13')][_0x3e8d62('0x2f')](),
                            _0x584ba4['transform'][_0x3e8d62('0x4b1')] = this[_0x3e8d62('0xb6')]['rotation'][_0x3e8d62('0x2f')](),
                            _0x584ba4[_0x3e8d62('0x398')][_0x3e8d62('0x525')](),
                            Laya[_0x3e8d62('0x5ac')][_0x3e8d62('0x1e6')](0x12c, this, function () {
                                var _0x1cd577 = _0x3e8d62;
                                _0x47fde5[_0x1cd577('0x3b6')][_0x1cd577('0x51')]['Despawn'](_0x1cd577('0x22f'), _0x584ba4);
                            });
                        var _0x31ac2c = new Laya[(_0x3e8d62('0x592'))](0x0, 0x0, 0x0);
                        _0x31ac2c['y'] = _0x47fde5['default'][_0x3e8d62('0x33b')]['HoopForceY'];
                        switch (_0x497204) {
                            case _0x454f75[_0x3e8d62('0x281')][_0x3e8d62('0x4ae')][_0x3e8d62('0x327')]:
                                _0x31ac2c['x'] = _0x47fde5[_0x3e8d62('0x3b6')][_0x3e8d62('0x33b')][_0x3e8d62('0x4c2')];
                                break;
                            case _0x454f75[_0x3e8d62('0x281')][_0x3e8d62('0x4ae')]['Right']:
                                _0x31ac2c['x'] = -_0x47fde5['default']['GameMgr']['HoopForceX'];
                                break;
                        }
                        this[_0x3e8d62('0x56a')](_0x31ac2c);
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x489')] = function () {
                        var _0x5d86ee = _0x3870c7;
                        if (_0x47fde5['default']['GameMgr'][_0x5d86ee('0x353')] != _0x454f75[_0x5d86ee('0x281')][_0x5d86ee('0x170')]['Start'])
                            return;
                        this[_0x5d86ee('0x47e')](),
                            this[_0x5d86ee('0x635')] == !![] && Laya['Vector3'][_0x5d86ee('0x173')](this[_0x5d86ee('0xb6')][_0x5d86ee('0x13')], _0x47fde5[_0x5d86ee('0x3b6')]['GameMgr'][_0x5d86ee('0x34a')][_0x5d86ee('0xb6')]['position']) > 0.2 && (this['_sleep'] = ![]),
                            this[_0x5d86ee('0x288')] = this['transform'][_0x5d86ee('0x13')][_0x5d86ee('0x2f')]();
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x47e')] = function () {
                        var _0x556772 = _0x3870c7
                            , _0x1e3c01 = this['transform'][_0x556772('0x13')]['x']
                            , _0x818b76 = this[_0x556772('0xb6')][_0x556772('0x13')]['y'];
                        this[_0x556772('0x2a8')] = _0x1e3c01 <= -1.1 || _0x1e3c01 >= 1.1 || _0x818b76 >= 0x4;
                        if (_0x818b76 >= 0x4) {
                            var _0x10977f = this['_rigibody'][_0x556772('0x4')][_0x556772('0x2f')]();
                            _0x10977f['y'] = -0x1,
                                this[_0x556772('0x19d')][_0x556772('0x4')] = _0x10977f;
                        } else {
                            if (_0x1e3c01 >= 1.1)
                                this[_0x556772('0x56a')](new Laya[(_0x556772('0x592'))](-_0x47fde5[_0x556772('0x3b6')][_0x556772('0x33b')][_0x556772('0x477')], this[_0x556772('0x19d')][_0x556772('0x4')]['y'], 0x0));
                            else
                                _0x1e3c01 <= -1.1 && this['addForce'](new Laya[(_0x556772('0x592'))](_0x47fde5[_0x556772('0x3b6')]['GameMgr'][_0x556772('0x477')], this[_0x556772('0x19d')]['linearVelocity']['y'], 0x0));
                        }
                    }
                    ,
                    _0x26e8c5['prototype'][_0x3870c7('0x56a')] = function (_0x411888) {
                        var _0x190a29 = _0x3870c7;
                        this[_0x190a29('0x695')](!![]),
                            this[_0x190a29('0x19d')]['linearVelocity'] = _0x411888;
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x695')] = function (_0x4debc0) {
                        var _0x4284dc = _0x3870c7;
                        if (this[_0x4284dc('0x19d')]['enabled'] == _0x4debc0)
                            return;
                        this[_0x4284dc('0x19d')]['enabled'] = _0x4debc0;
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x3ca')] = function () {
                        var _0x33048e = _0x3870c7;
                        this[_0x33048e('0x635')] = !![],
                            this[_0x33048e('0x465')][_0x33048e('0x5f2')](),
                            this['_currentOrder'][0x0] = 0x0,
                            this[_0x33048e('0x1f')][0x1] = 0x0;
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x12d')] = function (_0x311142, _0x410a81) {
                        var _0x2601d4 = _0x3870c7;
                        if (this[_0x2601d4('0x635')] == !![])
                            return;
                        if (this['_currentOrder'][0x0] == 0x0)
                            this[_0x2601d4('0x1f')][0x0] = _0x311142;
                        else
                            this[_0x2601d4('0x1f')][0x1] == 0x0 ? _0x311142 != this[_0x2601d4('0x1f')][0x0] ? this[_0x2601d4('0x1f')][0x1] = _0x311142 : console[_0x2601d4('0x5df')](_0x2601d4('0x541'), _0x311142, this[_0x2601d4('0x1f')]) : console[_0x2601d4('0x5df')](_0x2601d4('0x541'), _0x311142, this[_0x2601d4('0x1f')]);
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')]['OnHoppTriggerExit'] = function (_0xa674c6, _0x4e675b) {
                        var _0x1c9643 = _0x3870c7;
                        if (this[_0x1c9643('0x635')] == !![])
                            return;
                        var _0x4d4295 = this[_0x1c9643('0x1f')][0x0]
                            , _0x417f26 = this[_0x1c9643('0x1f')][0x1];
                        if (_0x4d4295 == _0xa674c6)
                            _0x417f26 != 0x0 && (console[_0x1c9643('0x5df')]('两个触发器都已经触发，并且先进先出，成功'),
                                this['addscore']()),
                                this[_0x1c9643('0x1f')][0x0] = 0x0,
                                this[_0x1c9643('0x1f')][0x1] = 0x0;
                        else
                            _0x417f26 == _0xa674c6 ? (this[_0x1c9643('0x1f')][0x1] = 0x0,
                                console['log']('两个触发器都已经触发，并且先进后出')) : (console[_0x1c9643('0x5df')](_0x1c9643('0x474')),
                                    this[_0x1c9643('0x635')] = !![],
                                    this[_0x1c9643('0x1f')][0x0] = 0x0,
                                    this[_0x1c9643('0x1f')][0x1] = 0x0);
                    }
                    ,
                    _0x26e8c5[_0x3870c7('0x64a')][_0x3870c7('0x30d')] = function (_0x496f1f, _0x3ea58e) {
                        var _0x32db29 = _0x3870c7;
                        if (this[_0x32db29('0x635')] == !![])
                            return;
                    }
                    ,
                    _0x26e8c5['prototype'][_0x3870c7('0x48d')] = function (_0x50236f, _0x53e5b4, _0x1d1fa7) {
                        var _0x2f413e = _0x3870c7
                            , _0x405f6e = new Laya[(_0x2f413e('0x114'))](0x1);
                        _0x405f6e[_0x2f413e('0x696')](_0x50236f, _0x53e5b4, _0x1d1fa7, _0x1d1fa7),
                            _0x47fde5[_0x2f413e('0x3b6')]['SceneMgr'][_0x2f413e('0x4af')](_0x405f6e),
                            Laya['timer'][_0x2f413e('0x1e6')](0x3e8, this, function () {
                                var _0x1e8da4 = _0x2f413e;
                                _0x405f6e[_0x1e8da4('0x392')]();
                            });
                    }
                    ,
                    _0x26e8c5;
            }(_0x383b91[_0x3e8144('0x3b6')]);
        _0x13651b[_0x3e8144('0x3b6')] = _0x270057;
    }
        , {
        '../XGame': 0x4,
        '../base/GameObjcet3D': 0x5,
        '../enum/GameEnum': 0x10,
        '../enum/MaskEnum': 0x11,
        './HoopTrigger': 0xc,
        './Player': 0xd
    }],
    0xc: [function (_0x55e238, _0x154a66, _0x247e6a) {
        var _0x50ef80 = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x247e6a, _0x50ef80('0xb8'), {
            'value': !![]
        });
        var _0x2f1813 = _0x55e238(_0x50ef80('0x129'))
            , _0x4c3a98 = _0x55e238(_0x50ef80('0x1ce'))
            , _0x39ad84 = function (_0x574b47) {
                var _0x4975bc = _0x50ef80;
                __extends(_0x29dc32, _0x574b47);
                function _0x29dc32() {
                    var _0x5e0401 = _0x5985
                        , _0x2dcd8a = _0x574b47[_0x5e0401('0x324')](this) || this;
                    return _0x2dcd8a['_posList'] = [],
                        _0x2dcd8a;
                }
                return _0x29dc32[_0x4975bc('0x64a')]['onAwake'] = function () {
                    var _0x1a8db8 = _0x4975bc;
                    _0x574b47[_0x1a8db8('0x64a')][_0x1a8db8('0x4fc')][_0x1a8db8('0x324')](this),
                        this['_collider'] = this[_0x1a8db8('0x5d3')]['addComponent'](Laya['PhysicsCollider']),
                        this['_collider'][_0x1a8db8('0x352')] = new Laya[(_0x1a8db8('0x4a'))](0.2, 0.001, 0.2),
                        this[_0x1a8db8('0x68d')]['isTrigger'] = !![],
                        this[_0x1a8db8('0x68d')][_0x1a8db8('0x221')] = _0x4c3a98[_0x1a8db8('0x138')][_0x1a8db8('0x384')],
                        this[_0x1a8db8('0x68d')]['canCollideWith'] = _0x4c3a98[_0x1a8db8('0x138')]['Ball'];
                }
                    ,
                    _0x29dc32[_0x4975bc('0x64a')][_0x4975bc('0x469')] = function (_0x2135c0, _0x214626, _0x2ec0d2) {
                        var _0x86f09 = _0x4975bc;
                        this[_0x86f09('0x2f8')] = _0x2135c0,
                            this['_index'] = _0x214626,
                            this[_0x86f09('0xb6')][_0x86f09('0x45b')] = _0x2ec0d2;
                    }
                    ,
                    _0x29dc32[_0x4975bc('0x64a')][_0x4975bc('0x27b')] = function (_0x26e7dc) {
                        var _0x1ab6f5 = _0x4975bc;
                        this[_0x1ab6f5('0x2f8')][_0x1ab6f5('0x12d')](this[_0x1ab6f5('0x34e')], this[_0x1ab6f5('0xb6')]['position'][_0x1ab6f5('0x2f')]());
                    }
                    ,
                    _0x29dc32[_0x4975bc('0x64a')][_0x4975bc('0x62e')] = function (_0x526342) {
                        var _0x3d4f45 = _0x4975bc;
                        this[_0x3d4f45('0x2f8')][_0x3d4f45('0x30e')](this[_0x3d4f45('0x34e')], this['transform'][_0x3d4f45('0x13')][_0x3d4f45('0x2f')]());
                    }
                    ,
                    _0x29dc32[_0x4975bc('0x64a')][_0x4975bc('0x16a')] = function (_0x62b648) {
                        var _0x54883f = _0x4975bc;
                        this['_hoop'][_0x54883f('0x30d')](this[_0x54883f('0x34e')], this[_0x54883f('0xb6')][_0x54883f('0x13')][_0x54883f('0x2f')]());
                    }
                    ,
                    _0x29dc32;
            }(_0x2f1813['default']);
        _0x247e6a[_0x50ef80('0x3b6')] = _0x39ad84;
    }
        , {
        '../base/GameObjcet3D': 0x5,
        '../enum/MaskEnum': 0x11
    }],
    0xd: [function (_0xb936e2, _0x1e1be6, _0x3159bb) {
        var _0x57d908 = _0x4b7fcf;
        'use strict';
        Object[_0x57d908('0x351')](_0x3159bb, _0x57d908('0xb8'), {
            'value': !![]
        });
        var _0x19cd79 = _0xb936e2('../base/GameObjcet3D')
            , _0x260a60 = _0xb936e2(_0x57d908('0x167'))
            , _0x272114 = _0xb936e2(_0x57d908('0x1dc'))
            , _0x4905aa = _0xb936e2(_0x57d908('0x1b1'))
            , _0x5d9867 = _0xb936e2(_0x57d908('0x291'))
            , _0x378185 = _0xb936e2(_0x57d908('0x1b'))
            , _0x32ddb9 = function (_0x51a752) {
                var _0x790080 = _0x57d908;
                __extends(_0x12a766, _0x51a752);
                function _0x12a766() {
                    var _0x50ab54 = _0x5985
                        , _0x278e4a = _0x51a752[_0x50ab54('0x324')](this) || this;
                    return _0x278e4a[_0x50ab54('0x3f5')] = -0x1,
                        _0x278e4a[_0x50ab54('0x668')] = 0x0,
                        _0x278e4a[_0x50ab54('0x2a')] = 0.52,
                        _0x278e4a[_0x50ab54('0x414')] = _0x50ab54('0x190'),
                        _0x278e4a[_0x50ab54('0x448')] = _0x50ab54('0x341'),
                        _0x278e4a[_0x50ab54('0x164')] = ![],
                        _0x278e4a;
                }
                return Object[_0x790080('0x351')](_0x12a766[_0x790080('0x64a')], _0x790080('0x331'), {
                    'get': function () {
                        var _0x563595 = _0x790080;
                        return this[_0x563595('0x2f8')];
                    },
                    'enumerable': !![],
                    'configurable': !![]
                }),
                    _0x12a766['prototype'][_0x790080('0x4fc')] = function () {
                        var _0x3871b6 = _0x790080;
                        _0x51a752[_0x3871b6('0x64a')][_0x3871b6('0x4fc')][_0x3871b6('0x324')](this);
                    }
                    ,
                    _0x12a766['prototype'][_0x790080('0x32d')] = function (_0x271c11, _0xed8216) {
                        var _0x2c5e20 = _0x790080;
                        _0xed8216 === void 0x0 && (_0xed8216 = ![]),
                            this[_0x2c5e20('0x5d3')][_0x2c5e20('0x4ba')] = !![],
                            this[_0x2c5e20('0x296')] = _0xed8216,
                            this[_0x2c5e20('0x668')] = 0x0,
                            this[_0x2c5e20('0x5c8')](_0x271c11),
                            this['_isAI'] == ![] && (Laya[_0x2c5e20('0x150')]['on'](Laya['Event'][_0x2c5e20('0x237')], this, this['onMouseDown']),
                                this[_0x2c5e20('0x1b6')] == null && (this['_arrow'] = _0x260a60[_0x2c5e20('0x3b6')]['ResMgr'][_0x2c5e20('0xec')]('Arrow'),
                                    this[_0x2c5e20('0x5d3')][_0x2c5e20('0x5')](this[_0x2c5e20('0x1b6')])),
                                this[_0x2c5e20('0x1b6')]['active'] = !![],
                                Laya['Tween']['clearAll'](this['_arrow']['transform']),
                                this[_0x2c5e20('0x1b6')]['transform'][_0x2c5e20('0x45b')] = new Laya[(_0x2c5e20('0x592'))](this[_0x2c5e20('0x2a')], 0.7, 0x0),
                                this[_0x2c5e20('0x377')]()),
                            this[_0x2c5e20('0x2f8')][_0x2c5e20('0x32d')](this[_0x2c5e20('0x296')] ? -this[_0x2c5e20('0x2a')] : this[_0x2c5e20('0x2a')]);
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')][_0x790080('0x377')] = function () {
                        var _0x446de3 = _0x790080;
                        Laya[_0x446de3('0x34d')]['to'](this[_0x446de3('0x1b6')][_0x446de3('0xb6')], {
                            'localPositionY': 0.8
                        }, 0x12c, null, Laya[_0x446de3('0x49f')][_0x446de3('0x5fb')](this, this[_0x446de3('0x4ff')]));
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')][_0x790080('0x4ff')] = function () {
                        var _0x6ff4a0 = _0x790080;
                        Laya[_0x6ff4a0('0x34d')]['to'](this[_0x6ff4a0('0x1b6')][_0x6ff4a0('0xb6')], {
                            'localPositionY': 0.7
                        }, 0x12c, null, Laya[_0x6ff4a0('0x49f')][_0x6ff4a0('0x5fb')](this, this['moveUp']));
                    }
                    ,
                    _0x12a766['prototype'][_0x790080('0x5c8')] = function (_0x1fdbaf) {
                        var _0x540682 = _0x790080;
                        if (_0x1fdbaf != this[_0x540682('0x3f5')]) {
                            var _0x147995 = _0x260a60[_0x540682('0x3b6')]['CfgMgr'][_0x540682('0x3ef')](_0x1fdbaf)
                                , _0x5d0a75 = _0x260a60['default'][_0x540682('0x60d')][_0x540682('0xec')](_0x147995[_0x540682('0x29d')]);
                            this[_0x540682('0x2f8')] != null && this['_hoop'][_0x540682('0x5d3')][_0x540682('0x392')](),
                                this['_hoop'] = Laya[_0x540682('0x55a')][_0x540682('0x3c')](_0x5d0a75, this[_0x540682('0x5d3')])[_0x540682('0x5a3')](_0x272114[_0x540682('0x3b6')]),
                                this[_0x540682('0x3f5')] = _0x1fdbaf;
                        }
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')][_0x790080('0x175')] = function () {
                        var _0xc295e8 = _0x790080;
                        if (this[_0xc295e8('0x296')] == !![] || _0x260a60[_0xc295e8('0x3b6')]['GameMgr']['state'] != _0x4905aa[_0xc295e8('0x281')]['State'][_0xc295e8('0x3c1')])
                            return;
                        var _0x42a943 = Laya[_0xc295e8('0x150')][_0xc295e8('0x40c')] / Laya[_0xc295e8('0x150')][_0xc295e8('0x1d2')];
                        _0x42a943 > 0.5 && this['Jump'](_0x4905aa[_0xc295e8('0x281')][_0xc295e8('0x4ae')][_0xc295e8('0x1b5')]),
                            _0x42a943 < 0.5 && this[_0xc295e8('0x3f')](_0x4905aa['GameEnum'][_0xc295e8('0x4ae')]['Left']);
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')]['onUpdate'] = function () {
                        var _0xca76cf = _0x790080;
                        if (_0x260a60[_0xca76cf('0x3b6')][_0xca76cf('0x33b')][_0xca76cf('0x353')] != _0x4905aa[_0xca76cf('0x281')][_0xca76cf('0x170')][_0xca76cf('0x3c1')])
                            return;
                        if (this[_0xca76cf('0x296')])
                            this[_0xca76cf('0x1d7')]();
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')][_0x790080('0x1d7')] = function () {
                        var _0x989761 = _0x790080;
                        if (this[_0x989761('0x164')] == !![])
                            return;
                        var _0x15ae96 = 0x0
                            , _0x620c78 = this['_hoop']['transform']['position']['x']
                            , _0xec98de = this[_0x989761('0x2f8')][_0x989761('0xb6')][_0x989761('0x13')]['y']
                            , _0x277cc5 = _0x260a60[_0x989761('0x3b6')][_0x989761('0x33b')][_0x989761('0x34a')]['transform'][_0x989761('0x13')]['y']
                            , _0x3cf512 = _0x5d9867[_0x989761('0x3b6')][_0x989761('0x69b')](0x12c, 0x2bc);
                        _0x15ae96 = _0x620c78 < 0x0 ? _0x4905aa[_0x989761('0x281')][_0x989761('0x4ae')][_0x989761('0x1b5')] : _0x4905aa[_0x989761('0x281')]['CtrlSide'][_0x989761('0x327')];
                        _0x15ae96 > _0x277cc5 && (_0x15ae96 = _0x15ae96 == _0x4905aa[_0x989761('0x281')][_0x989761('0x4ae')][_0x989761('0x1b5')] ? _0x4905aa[_0x989761('0x281')]['CtrlSide'][_0x989761('0x1b5')] : _0x4905aa[_0x989761('0x281')][_0x989761('0x4ae')][_0x989761('0x327')]);
                        var _0x523c5c = Math['random']();
                        _0x523c5c > 0.85 && (_0x15ae96 == _0x4905aa['GameEnum']['CtrlSide'][_0x989761('0x327')] ? _0x15ae96 = _0x4905aa['GameEnum']['CtrlSide'][_0x989761('0x1b5')] : _0x15ae96 = _0x4905aa['GameEnum'][_0x989761('0x4ae')][_0x989761('0x327')]),
                            _0xec98de - _0x277cc5 > 0.5 && (_0x3cf512 = 0x5dc),
                            this[_0x989761('0x164')] = !![],
                            this['Jump'](_0x15ae96),
                            Laya[_0x989761('0x5ac')][_0x989761('0x1e6')](_0x3cf512, this, this[_0x989761('0x306')]);
                    }
                    ,
                    _0x12a766['prototype'][_0x790080('0x306')] = function () {
                        this['jumpFlag'] = ![];
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')][_0x790080('0x3f')] = function (_0x32658c) {
                        var _0x2c70ce = _0x790080;
                        if (_0x260a60['default'][_0x2c70ce('0x33b')][_0x2c70ce('0x353')] != _0x4905aa[_0x2c70ce('0x281')][_0x2c70ce('0x170')][_0x2c70ce('0x3c1')])
                            return;
                        this[_0x2c70ce('0x2f8')][_0x2c70ce('0x272')](_0x32658c),
                            this['_isAI'] == ![] && (Laya[_0x2c70ce('0x34d')][_0x2c70ce('0x1fb')](this['_arrow'][_0x2c70ce('0xb6')]),
                                this[_0x2c70ce('0x1b6')][_0x2c70ce('0x4ba')] = ![]);
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')]['AddScore'] = function () {
                        var _0x58d969 = _0x790080;
                        console[_0x58d969('0x5df')]('加分'),
                            _0x378185[_0x58d969('0x3b6')][_0x58d969('0x461')](),
                            this['showEff'](),
                            this['score']++;
                        this[_0x58d969('0x668')] == 0x4 && _0x260a60['default'][_0x58d969('0x33b')][_0x58d969('0x476')] != _0x4905aa[_0x58d969('0x281')][_0x58d969('0x4b6')][_0x58d969('0x6a6')] && _0x260a60[_0x58d969('0x3b6')][_0x58d969('0xba')]['ShowLastPointEff'](_0x58d969('0x1fc'));
                        _0x260a60[_0x58d969('0x3b6')][_0x58d969('0xba')]['ChangeScore'](this[_0x58d969('0x668')], !this['_isAI']);
                        if (_0x260a60[_0x58d969('0x3b6')][_0x58d969('0x33b')][_0x58d969('0x476')] == _0x4905aa[_0x58d969('0x281')][_0x58d969('0x4b6')]['Special'])
                            _0x260a60['default'][_0x58d969('0x33b')][_0x58d969('0x34a')]['RandomPosition']();
                        else
                            _0x260a60[_0x58d969('0x3b6')]['GameMgr'][_0x58d969('0x476')] == _0x4905aa[_0x58d969('0x281')]['GameType'][_0x58d969('0x579')] && _0x260a60[_0x58d969('0x3b6')][_0x58d969('0x678')]['curRound'] == 0x4 && _0x260a60[_0x58d969('0x3b6')][_0x58d969('0x33b')]['Ball'][_0x58d969('0x4ef')]();
                    }
                    ,
                    _0x12a766[_0x790080('0x64a')][_0x790080('0xfd')] = function () {
                        var _0x14fbca = _0x790080
                            , _0x4552af = _0x260a60[_0x14fbca('0x3b6')][_0x14fbca('0x33b')][_0x14fbca('0x476')] == _0x4905aa[_0x14fbca('0x281')][_0x14fbca('0x4b6')][_0x14fbca('0x6a6')] ? this[_0x14fbca('0x448')] : this[_0x14fbca('0x414')]
                            , _0x409818 = _0x260a60[_0x14fbca('0x3b6')]['EffMgr'][_0x14fbca('0x36d')](_0x4552af);
                        this[_0x14fbca('0x5d3')]['addChild'](_0x409818),
                            _0x409818[_0x14fbca('0xb6')][_0x14fbca('0x13')] = _0x260a60[_0x14fbca('0x3b6')][_0x14fbca('0x33b')][_0x14fbca('0x34a')][_0x14fbca('0xb6')][_0x14fbca('0x13')]['clone'](),
                            _0x409818[_0x14fbca('0x398')]['play'](),
                            Laya[_0x14fbca('0x5ac')][_0x14fbca('0x1e6')](0x3e8, this, function () {
                                var _0xb627f = _0x14fbca;
                                _0x260a60[_0xb627f('0x3b6')][_0xb627f('0x51')][_0xb627f('0x2c1')](_0x4552af, _0x409818);
                            });
                    }
                    ,
                    _0x12a766;
            }(_0x19cd79['default']);
        _0x3159bb[_0x57d908('0x3b6')] = _0x32ddb9;
    }
        , {
        '../Platform': 0x3,
        '../XGame': 0x4,
        '../base/GameObjcet3D': 0x5,
        '../enum/GameEnum': 0x10,
        '../utils/Tools': 0x37,
        './Hoop': 0xb
    }],
    0xe: [function (_0x55c1d3, _0x5a257d, _0x54c4cc) {
        var _0x5d78be = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x54c4cc, _0x5d78be('0xb8'), {
            'value': !![]
        });
        var _0x1b443f = {
            'Res_Load_Progress': _0x5d78be('0xfe'),
            'Res_Load_Complete': 'Res_Load_Complete',
            'Switch_Page': 'Switch_Page',
            'Skin_ClickItem': _0x5d78be('0x117'),
            'Reward_ClickItem': _0x5d78be('0x115'),
            'Reward_UpdateInfo': _0x5d78be('0x171'),
            'AddScore': _0x5d78be('0x5f2'),
            'GameStart': _0x5d78be('0x515'),
            'GameEnd': _0x5d78be('0x46f'),
            'Res_Load_NetFail': _0x5d78be('0x1e3'),
            'Update_Items': _0x5d78be('0x4bf'),
            'Battle_AddPlayer': _0x5d78be('0x44f'),
            'Battle_DelPlayer': _0x5d78be('0x2f2'),
            'Battle_AddScore': _0x5d78be('0x1a'),
            'Battle_AiAddScore': 'Battle_AiAddScore',
            'Battle_AlertInfo': _0x5d78be('0x41f'),
            'Battle_UpdateFeeling': 'Battle_UpdateFeeling'
        };
        _0x54c4cc[_0x5d78be('0x4c3')] = _0x1b443f;
        var _0x466e4b = {
            'Step0': 0x0,
            'Step1': 0x1,
            'Step2': 0x2,
            'Step3': 0x3
        };
        _0x54c4cc[_0x5d78be('0x588')] = _0x466e4b;
    }
        , {}],
    0xf: [function (_0x350918, _0x222c46, _0x35cfd0) {
        var _0x58391b = _0x4b7fcf;
        'use strict';
        Object[_0x58391b('0x351')](_0x35cfd0, _0x58391b('0xb8'), {
            'value': !![]
        });
        var _0x291b0d = {
            'on': 'on',
            'off': _0x58391b('0x585')
        }
            , _0x1e6283 = {
                'QQAd': 'QQAd',
                'TouTAd': _0x58391b('0xd1'),
                'OPPOAd': _0x58391b('0x5a2'),
                'VivoAd': _0x58391b('0x691'),
                'BaiduAd': 'BaiduAd',
                'WXAd': _0x58391b('0x576'),
                'Game4399': _0x58391b('0x64'),
                'HagoAd': _0x58391b('0x32b'),
                'FacebookAd': 'FacebookAd'
            };
        _0x35cfd0[_0x58391b('0x52b')] = _0x1e6283;
        var _0x322592 = {
            'Platform': _0x1e6283['FacebookAd'],
            'AppID': _0x58391b('0x4ac'),
            'Version': 'tao1.0.8',
            'Language': '',
            'CDN': _0x58391b('0x1f9'),
            'NetLog': !![],
            'Env': _0x58391b('0x3a8'),
            'ShareId': '',
            'SourceOpenid': '',
            'Openid': '',
            'Session_key': '',
            'Channel': '',
            'ShareSwitch': _0x291b0d['on'],
            'HttpServer': _0x58391b('0x5d9'),
            'canShare': function () {
                var _0x3eadd2 = _0x58391b;
                return _0x322592[_0x3eadd2('0xc1')] == _0x291b0d['on'];
            }
        };
        _0x35cfd0[_0x58391b('0x1d1')] = _0x322592;
    }
        , {}],
    0x10: [function (_0x30d2b8, _0x1fec27, _0x4fd35b) {
        var _0x57e204 = _0x4b7fcf;
        'use strict';
        Object[_0x57e204('0x351')](_0x4fd35b, _0x57e204('0xb8'), {
            'value': !![]
        });
        var _0x1af9e6 = {
            'State': {
                'Start': 0x1,
                'End': 0x2
            },
            'Scenes': {
                'Desk': _0x57e204('0x6b9'),
                'City': _0x57e204('0x2fa'),
                'Fram': 'Fram',
                'Garden': _0x57e204('0x4fa'),
                'LivingRoom': _0x57e204('0x4ed')
            },
            'Board': {
                'Wood': 0x1,
                'Metal': 0x2
            },
            'CtrlSide': {
                'Left': 0x1,
                'Right': 0x2
            },
            'GameType': {
                'Normal': 0x1,
                'Special': 0x2,
                'Challenge': 0x3
            }
        };
        _0x4fd35b[_0x57e204('0x281')] = _0x1af9e6;
    }
        , {}],
    0x11: [function (_0x54ea3d, _0x3fc117, _0x152f3b) {
        var _0x29e8b0 = _0x4b7fcf;
        'use strict';
        Object[_0x29e8b0('0x351')](_0x152f3b, _0x29e8b0('0xb8'), {
            'value': !![]
        });
        var _0x2df23f = {
            'Defaultfilter': Laya[_0x29e8b0('0x3ee')]['COLLISIONFILTERGROUP_DEFAULTFILTER'],
            'Hoop': Laya[_0x29e8b0('0x3ee')]['COLLISIONFILTERGROUP_CUSTOMFILTER1'],
            'Wall': Laya['Physics3DUtils'][_0x29e8b0('0xcd')],
            'Ball': Laya[_0x29e8b0('0x3ee')][_0x29e8b0('0x278')],
            'Trigger': Laya[_0x29e8b0('0x3ee')][_0x29e8b0('0x209')],
            'Ray': Laya['Physics3DUtils'][_0x29e8b0('0x2d6')],
            'BallTrigger': Laya['Physics3DUtils'][_0x29e8b0('0x441')]
        };
        _0x152f3b[_0x29e8b0('0x138')] = _0x2df23f;
    }
        , {}],
    0x12: [function (_0x2cb091, _0x1ba8bb, _0x3dac3d) {
        var _0x4e6668 = _0x4b7fcf;
        'use strict';
        Object[_0x4e6668('0x351')](_0x3dac3d, _0x4e6668('0xb8'), {
            'value': !![]
        });
        var _0x52b172 = {
            'Box': _0x4e6668('0xea'),
            'Dare': _0x4e6668('0x3c0'),
            'Skin': 'res/atlas/skin.atlas',
            'Game': _0x4e6668('0x5b2'),
            'Level': _0x4e6668('0x35f'),
            'Reward': _0x4e6668('0x90'),
            'LuckBox': 'res/atlas/luckyBox.atlas',
            'Ranking': _0x4e6668('0x4ab'),
            'Robot': _0x4e6668('0x183')
        };
        _0x3dac3d[_0x4e6668('0x1c')] = _0x52b172;
        var _0x29267c = {
            'Ai': _0x4e6668('0x253'),
            'Badge': _0x4e6668('0xe4'),
            'Global': _0x4e6668('0x39f'),
            'Items': 'res/jsons/Items.json',
            'Map': 'res/jsons/Map.json',
            'Reward': _0x4e6668('0x11f'),
            'Robot': _0x4e6668('0xd5'),
            'ScreenFont': _0x4e6668('0x1c1'),
            'Ad': 'res/jsons/Ad.json',
            'lang': _0x4e6668('0x443')
        };
        _0x3dac3d[_0x4e6668('0x570')] = _0x29267c;
        var _0x19b1e3 = {
            'Hoops': _0x4e6668('0x2f1'),
            'Balls': _0x4e6668('0x241'),
            'RewardItem': _0x4e6668('0x21a'),
            'SkinItem': _0x4e6668('0x67f'),
            'SignItem': _0x4e6668('0x17c'),
            'RankItem': 'prefab/rankItem.json',
            'AdItem': 'prefab/adItem.json',
            'Particles': _0x4e6668('0x6a1')
        };
        _0x3dac3d['Prefabs'] = _0x19b1e3;
        var _0x208539 = {
            'Number0': _0x4e6668('0x3fe'),
            'Number1': _0x4e6668('0x2df'),
            'Number2': _0x4e6668('0x3a'),
            'Number3': _0x4e6668('0x406'),
            'Number4': '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/Number_4.lmat',
            'Number5': _0x4e6668('0x450'),
            'Stage1': '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage1.lmat',
            'Stage2': _0x4e6668('0x4e5'),
            'Stage3': '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage3.lmat',
            'Stage4': _0x4e6668('0x4eb'),
            'Stage5': '3d/prefabs/Conventional/Assets/Resourecs/Materials/Number/stage5.lmat',
            'Plane1': _0x4e6668('0x470'),
            'Plane2': _0x4e6668('0x2e2'),
            'Plane3': _0x4e6668('0x10f'),
            'Plane4': _0x4e6668('0x180'),
            'Plane5': _0x4e6668('0x45e')
        };
        _0x3dac3d[_0x4e6668('0x49e')] = _0x208539;
        var _0x166269 = {
            'Game': _0x4e6668('0x89'),
            'ShowSkin': _0x4e6668('0x4bb')
        };
        _0x3dac3d[_0x4e6668('0x516')] = _0x166269;
        var _0x552d39 = {
            'Hoop': 0x1,
            'Ball': 0x2
        };
        _0x3dac3d[_0x4e6668('0x4cb')] = _0x552d39;
        var _0x2be0ec = {
            'Snow': _0x4e6668('0xfb'),
            'Grassland0': _0x4e6668('0x8f'),
            'Grassland1': _0x4e6668('0x5eb'),
            'Desert': _0x4e6668('0x602')
        };
        _0x3dac3d['TextureType'] = _0x2be0ec;
        var _0x18a37f = 'res/sound/'
            , _0xa431ff = {
                'BtnClick': _0x18a37f + _0x4e6668('0x224')
            };
        _0x3dac3d[_0x4e6668('0x4a8')] = _0xa431ff;
        var _0x330cd8 = {
            'GAME_OPEN_GAME': 0x1,
            'GAME_BEGIN_GAME': 0x2,
            'GAME_RESULT_GAME': 0x3,
            'GAME_ONE_GAME_BEGIN': 0x4,
            'GAME_MAIN_ICON': 0x1,
            'GAME_RESULT_ICON': 0xc9,
            'GAME_MAIN_RIGHT_ICON': 0xc,
            'GAME_MAIN_LEFT_ICON': 0xb,
            'GAME_STOP_ICON': 0x15,
            'GAME__SUCCESS_ICON': 0x1f
        };
        _0x3dac3d[_0x4e6668('0x4b6')] = _0x330cd8;
    }
        , {}],
    0x13: [function (_0x1f0d2b, _0x3a7535, _0x409b8f) {
        var _0x351c39 = _0x4b7fcf;
        'use strict';
        Object[_0x351c39('0x351')](_0x409b8f, _0x351c39('0xb8'), {
            'value': !![]
        });
        var _0x5d8616 = {
            'PlayGameUI': {
                'id': 0x0,
                'class': _0x351c39('0x40a'),
                'showPrompt': !![],
                'banner': !![]
            },
            'LoadingUI': {
                'id': 0x1,
                'class': _0x351c39('0x77'),
                'banner': !![]
            },
            'GameUI': {
                'id': 0x2,
                'class': _0x351c39('0x50f'),
                'adunit': [],
                'showPrompt': !![],
                'banner': !![]
            },
            'LevelResultUI': {
                'id': 0x3,
                'class': _0x351c39('0x157'),
                'showPrompt': ![],
                'banner': !![]
            },
            'SetUI': {
                'id': 0x4,
                'class': _0x351c39('0x95'),
                'banner': !![]
            },
            'ToppingUI': {
                'id': 0x5,
                'class': _0x351c39('0x527'),
                'banner': !![]
            },
            'UnlockFoodUI': {
                'id': 0x7,
                'class': 'script/view/UnlockFoodUI.ts',
                'banner': !![]
            },
            'OpenBoxUI': {
                'id': 0x8,
                'class': _0x351c39('0x22c'),
                'showPrompt': ![],
                'banner': !![]
            },
            'OpenRewardUI': {
                'id': 0x9,
                'class': _0x351c39('0x2f3'),
                'showPrompt': ![],
                'banner': !![]
            },
            'CupUI': {
                'id': 0xa,
                'class': _0x351c39('0x3a6'),
                'showPrompt': ![],
                'banner': !![]
            },
            'DareLoseUI': {
                'id': 0xb,
                'class': _0x351c39('0x547'),
                'tween': !![],
                'showPrompt': ![],
                'banner': !![]
            },
            'OpenTimeBoxUI': {
                'id': 0xc,
                'class': _0x351c39('0x3f4'),
                'showPrompt': ![],
                'banner': !![]
            },
            'LucktBoxUI': {
                'id': 0xd,
                'class': _0x351c39('0x10e'),
                'showPrompt': ![],
                'banner': !![]
            },
            'PlayGameGemUI': {
                'id': 0xe,
                'class': _0x351c39('0x229'),
                'showPrompt': ![],
                'banner': !![]
            },
            'DareUI': {
                'id': 0xf,
                'class': _0x351c39('0x1ef'),
                'banner': !![]
            },
            'SignUI': {
                'id': 0x11,
                'class': 'script/view/SignUI.ts',
                'showPrompt': ![],
                'banner': !![]
            },
            'SkinUI': {
                'id': 0x12,
                'class': _0x351c39('0x4a6'),
                'adunit': [],
                'showPrompt': !![],
                'banner': !![]
            },
            'RankingGlobalUI': {
                'id': 0x13,
                'class': 'script/view/RankingGlobalUI.ts',
                'adunit': [],
                'banner': !![]
            },
            'MoveGameUI': {
                'id': 0x14,
                'class': _0x351c39('0x510'),
                'showPrompt': ![],
                'banner': !![]
            },
            'LoadView': {
                'id': 0x15,
                'class': _0x351c39('0x252'),
                'showPrompt': ![]
            }
        };
        _0x409b8f[_0x351c39('0x339')] = _0x5d8616;
    }
        , {}],
    0x14: [function (_0x25bebe, _0x291ded, _0x576b0e) {
        var _0x43e5c3 = _0x4b7fcf;
        'use strict';
        Object[_0x43e5c3('0x351')](_0x576b0e, _0x43e5c3('0xb8'), {
            'value': !![]
        });
        var _0x59f2a2 = _0x25bebe(_0x43e5c3('0x1b2'))
            , _0x266983 = _0x25bebe('../enum/GameConst')
            , _0x1518e4 = function () {
                var _0x1669ef = _0x43e5c3;
                function _0x2c8702() { }
                return _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0xad')] = function () {
                    var _0x2d808d = _0x1669ef;
                    this[_0x2d808d('0x4b4')](),
                        this[_0x2d808d('0x112')](),
                        this[_0x2d808d('0x4c8')] = this[_0x2d808d('0x2e4')](_0x59f2a2['Jsons'][_0x2d808d('0x337')]),
                        this['mapCfg'] = this['initData'](_0x59f2a2['Jsons']['Map']),
                        this[_0x2d808d('0x421')] = this[_0x2d808d('0x2e4')](_0x59f2a2[_0x2d808d('0x570')][_0x2d808d('0x3bb')]),
                        this['robotCfg'] = this[_0x2d808d('0x2e4')](_0x59f2a2['Jsons']['Robot']),
                        this[_0x2d808d('0x4d8')] = this[_0x2d808d('0x2e4')](_0x59f2a2[_0x2d808d('0x570')]['ScreenFont']),
                        this['langCfg'] = this[_0x2d808d('0x2e4')](_0x59f2a2[_0x2d808d('0x570')][_0x2d808d('0x4e')]);
                }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')]['initAdData'] = function () {
                        var _0xdc5a41 = _0x1669ef;
                        this[_0xdc5a41('0x2a6')] = new Object();
                        var _0x1b0a7d = Laya[_0xdc5a41('0x5e')][_0xdc5a41('0xcb')](_0x59f2a2['Jsons']['Ad']);
                        if (_0x1b0a7d == null)
                            console[_0xdc5a41('0x560')](_0xdc5a41('0xae') + _0x59f2a2['Jsons'][_0xdc5a41('0x19')] + '表');
                        else {
                            this['adCfg'][_0xdc5a41('0x4cc')] = _0x1b0a7d[_0xdc5a41('0x4cc')];
                            for (var _0x37d03c = 0x0; _0x37d03c < _0x1b0a7d[_0xdc5a41('0x4cc')]; _0x37d03c++) {
                                this[_0xdc5a41('0x2a6')][_0x1b0a7d[_0x37d03c]['Id']] = _0x1b0a7d[_0x37d03c][_0x266983[_0xdc5a41('0x1d1')]['Platform']];
                            }
                        }
                    }
                    ,
                    _0x2c8702['prototype'][_0x1669ef('0x2e4')] = function (_0x2e7dec) {
                        var _0x1b85d5 = _0x1669ef
                            , _0x42e512 = new Object()
                            , _0x4bbe73 = Laya[_0x1b85d5('0x5e')][_0x1b85d5('0xcb')](_0x2e7dec);
                        if (_0x4bbe73 == null)
                            return console['error'](_0x1b85d5('0xae') + _0x2e7dec + '表'),
                                null;
                        else {
                            _0x42e512[_0x1b85d5('0x4cc')] = _0x4bbe73[_0x1b85d5('0x4cc')];
                            for (var _0x4d5542 = 0x0; _0x4d5542 < _0x4bbe73[_0x1b85d5('0x4cc')]; _0x4d5542++) {
                                _0x42e512[_0x4bbe73[_0x4d5542]['Id']] = _0x4bbe73[_0x4d5542];
                            }
                            return _0x42e512;
                        }
                    }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0x4b4')] = function () {
                        var _0xc6fdcc = _0x1669ef;
                        this[_0xc6fdcc('0x3ab')] = new Object();
                        var _0x19f9c0 = Laya[_0xc6fdcc('0x5e')][_0xc6fdcc('0xcb')](_0x59f2a2['Jsons'][_0xc6fdcc('0x19')]);
                        if (_0x19f9c0 == null)
                            console[_0xc6fdcc('0x560')]('兼容错误，找不到' + _0x59f2a2[_0xc6fdcc('0x570')][_0xc6fdcc('0x19')] + '表');
                        else {
                            this['globalCfg'][_0xc6fdcc('0x4cc')] = _0x19f9c0['length'];
                            for (var _0x7f58ca = 0x0; _0x7f58ca < _0x19f9c0[_0xc6fdcc('0x4cc')]; _0x7f58ca++) {
                                this[_0xc6fdcc('0x3ab')][_0x19f9c0[_0x7f58ca][_0xc6fdcc('0x74')]] = _0x19f9c0[_0x7f58ca][_0xc6fdcc('0x52c')];
                            }
                        }
                    }
                    ,
                    _0x2c8702['prototype']['getMapCfg'] = function (_0x1c845b) {
                        return this['mapCfg'][_0x1c845b];
                    }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0x66c')] = function (_0x52e21d) {
                        var _0x20ab2e = _0x1669ef;
                        return this[_0x20ab2e('0x2a6')][_0x52e21d];
                    }
                    ,
                    _0x2c8702['prototype'][_0x1669ef('0x3ef')] = function (_0x8eb926) {
                        var _0x41712b = _0x1669ef;
                        return this[_0x41712b('0x4c8')][_0x8eb926];
                    }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0x235')] = function (_0x5c3984, _0x19bd73) {
                        var _0x690318 = _0x1669ef, _0x8b8e83;
                        switch (_0x19bd73) {
                            case 'hi':
                                _0x8b8e83 = this['langCfg'][_0x5c3984]['Hindi'];
                                break;
                            case _0x690318('0x3b1'):
                                _0x8b8e83 = this['langCfg'][_0x5c3984][_0x690318('0x131')];
                                break;
                            case 'id':
                                _0x8b8e83 = this[_0x690318('0x205')][_0x5c3984]['Indonesian'];
                                break;
                            case 'th':
                                _0x8b8e83 = this[_0x690318('0x205')][_0x5c3984]['Thai'];
                                break;
                            case 'vi':
                                _0x8b8e83 = this[_0x690318('0x205')][_0x5c3984][_0x690318('0x18e')];
                                break;
                            case _0x690318('0x342'):
                                _0x8b8e83 = this[_0x690318('0x205')][_0x5c3984][_0x690318('0x6ab')];
                                break;
                            case 'ar':
                                _0x8b8e83 = this[_0x690318('0x205')][_0x5c3984][_0x690318('0x62f')];
                                break;
                            default:
                                _0x8b8e83 = this['langCfg'][_0x5c3984][_0x690318('0x131')];
                                break;
                        }
                        return _0x8b8e83;
                    }
                    ,
                    _0x2c8702['prototype'][_0x1669ef('0x430')] = function (_0x3ea8b3) {
                        var _0x4fde5e = _0x1669ef
                            , _0x1233cb = [];
                        for (var _0x243ed1 = 0x1; _0x243ed1 <= this[_0x4fde5e('0x4c8')][_0x4fde5e('0x4cc')]; _0x243ed1++) {
                            this['itemCfg'][_0x243ed1]['Type'] == _0x3ea8b3 && _0x1233cb['push'](this[_0x4fde5e('0x4c8')][_0x243ed1]);
                        }
                        return _0x1233cb;
                    }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0x257')] = function (_0x4a6b6b) {
                        return this['robotCfg'][_0x4a6b6b];
                    }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0xeb')] = function (_0x466d73) {
                        var _0x30a526 = _0x1669ef
                            , _0x55a990 = this[_0x30a526('0x3ab')][_0x466d73];
                        if (_0x55a990)
                            return _0x55a990;
                        return 0x0;
                    }
                    ,
                    _0x2c8702[_0x1669ef('0x64a')][_0x1669ef('0x11')] = function (_0x4026ec) {
                        var _0x17e583 = _0x1669ef;
                        return this[_0x17e583('0x421')][_0x4026ec];
                    }
                    ,
                    _0x2c8702;
            }();
        _0x576b0e['default'] = _0x1518e4;
    }
        , {
        '../enum/GameConst': 0xf,
        '../enum/ResEnum': 0x12
    }],
    0x15: [function (_0x294e63, _0x535d66, _0x102f85) {
        var _0x4c6f27 = _0x4b7fcf;
        'use strict';
        Object[_0x4c6f27('0x351')](_0x102f85, _0x4c6f27('0xb8'), {
            'value': !![]
        });
        var _0x5e7681 = _0x294e63(_0x4c6f27('0x291'))
            , _0x2dc6c2 = _0x294e63(_0x4c6f27('0x167'))
            , _0x46714b = _0x294e63('../enum/GameConst')
            , _0x2731eb = _0x294e63(_0x4c6f27('0x47a'))
            , _0x30316c = _0x294e63(_0x4c6f27('0x1b'))
            , _0x56f917 = function () {
                var _0x2f0963 = _0x4c6f27;
                function _0x1dc0b1() {
                    var _0x44fc03 = _0x5985;
                    this[_0x44fc03('0x243')] = {},
                        this['ballUnlockMap'] = {},
                        this[_0x44fc03('0x57e')] = {},
                        this[_0x44fc03('0x125')] = {},
                        this[_0x44fc03('0x5fd')] = _0x44fc03('0x29b'),
                        this[_0x44fc03('0x256')] = _0x44fc03('0x659'),
                        this['openId'] = '',
                        this['_nickName'] = '',
                        this[_0x44fc03('0x5f6')] = '',
                        this['_hoopUnlockList'] = '',
                        this[_0x44fc03('0x4b5')] = '',
                        this[_0x44fc03('0x3e1')] = '',
                        this[_0x44fc03('0x265')] = ![],
                        this['_bVibration'] = !![],
                        this[_0x44fc03('0x24a')] = !![],
                        this[_0x44fc03('0x3b0')] = 0x13,
                        this[_0x44fc03('0xf0')] = 0x7,
                        this[_0x44fc03('0x45a')] = 0x1,
                        this['_coinCount'] = 0x0,
                        this['_badgeLevel'] = 0x1,
                        this['_maxScore'] = 0x1,
                        this[_0x44fc03('0x2c3')] = 0x0,
                        this[_0x44fc03('0x67d')] = 0x0,
                        this[_0x44fc03('0x41a')] = 0x0,
                        this[_0x44fc03('0x467')] = 0x0,
                        this[_0x44fc03('0x110')] = 0x0,
                        this[_0x44fc03('0x10a')] = 0x0,
                        this[_0x44fc03('0x59c')] = 0x0,
                        this['_timeBoxLastTime'] = 0x0,
                        this[_0x44fc03('0x44a')] = 0x0,
                        this['_recordTime'] = 0x0,
                        this[_0x44fc03('0x318')] = 0x1,
                        this['isTmAdOpen'] = ![],
                        this[_0x44fc03('0x6b2')] = [{
                            'shareid': 0x14f,
                            'imageurl': _0x44fc03('0x11d'),
                            'title': _0x44fc03('0x44c')
                        }, {
                            'shareid': 0x150,
                            'imageurl': _0x44fc03('0x6b'),
                            'title': _0x44fc03('0x2fe')
                        }];
                }
                return _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x40e')] = function () {
                    var _0x44cfb9 = _0x2f0963, _0x1ebecc = this, _0x388b73, _0x25faf4;
                    for (_0x388b73 in this) {
                        if (_0x388b73[_0x44cfb9('0x1dd')]('_') == 0x0) {
                            _0x25faf4 = Laya['LocalStorage'][_0x44cfb9('0x193')](_0x388b73);
                            if (!_0x5e7681[_0x44cfb9('0x3b6')]['isEmpty'](_0x25faf4)) {
                                if (this[_0x44cfb9('0x5fd')]['indexOf'](_0x388b73) != -0x1)
                                    this[_0x388b73] = _0x25faf4;
                                else
                                    this[_0x44cfb9('0x256')][_0x44cfb9('0x1dd')](_0x388b73) != -0x1 ? this[_0x388b73] = _0x25faf4 == _0x44cfb9('0x636') ? !![] : ![] : this[_0x388b73] = parseInt(_0x25faf4);
                            }
                            this['defaultValMap'][_0x388b73] = this[_0x388b73];
                        }
                    }
                    _0x46714b['GameConst'][_0x44cfb9('0x400')] == _0x46714b['PlatformType'][_0x44cfb9('0x5a2')] && (_0x30316c['default'][_0x44cfb9('0x8')](0x64),
                        setTimeout(function () {
                            var _0x28f4f1 = _0x44cfb9;
                            _0x30316c[_0x28f4f1('0x3b6')][_0x28f4f1('0x4a2')]();
                        }, 0x1f4)),
                        this[_0x44cfb9('0x651')](),
                        this[_0x44cfb9('0x652')](),
                        _0x2dc6c2[_0x44cfb9('0x3b6')][_0x44cfb9('0x4ce')][_0x44cfb9('0xeb')]('RankOpen') == 0x1 && _0x2731eb[_0x44cfb9('0x3b6')][_0x44cfb9('0x249')](_0x46714b['GameConst'][_0x44cfb9('0x2da')], 0x1, null, function (_0x30a4be) {
                            var _0x217d95 = _0x44cfb9
                                , _0x32ebfb = _0x30a4be;
                            typeof _0x30a4be == _0x217d95('0x47d') && (_0x32ebfb = JSON['parse'](_0x30a4be));
                            if (_0x32ebfb[_0x217d95('0x4f1')] != 0x1) {
                                Laya['Browser'][_0x217d95('0x667')] && console['error']('从服务器获取玩家数据失败:', _0x32ebfb);
                                return;
                            }
                            console[_0x217d95('0x5df')](_0x217d95('0x266'), _0x32ebfb);
                            if (_0x32ebfb[_0x217d95('0x555')]['_maxScore'])
                                for (var _0x58bad1 in _0x32ebfb['data']) {
                                    _0x1ebecc[_0x58bad1] = _0x32ebfb[_0x217d95('0x555')][_0x58bad1];
                                }
                            _0x1ebecc[_0x217d95('0x651')](),
                                _0x1ebecc[_0x217d95('0x652')]();
                        }
                        [_0x44cfb9('0x484')](this), ![]);
                }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x651')] = function () {
                        var _0x3e1103 = _0x2f0963;
                        this[_0x3e1103('0x149')]['length'] <= 0x0 && (this['_hoopUnlockList'] = '1,2,3,7,13');
                        var _0x5abb16 = _0x5e7681[_0x3e1103('0x3b6')][_0x3e1103('0x37f')](this[_0x3e1103('0x149')]);
                        for (var _0x239ff3 = 0x0; _0x239ff3 < _0x5abb16[_0x3e1103('0x4cc')]; _0x239ff3++) {
                            this[_0x3e1103('0x243')][_0x5abb16[_0x239ff3]] = _0x5abb16[_0x239ff3];
                        }
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x652')] = function () {
                        var _0x1285e0 = _0x2f0963;
                        this[_0x1285e0('0x4b5')][_0x1285e0('0x4cc')] <= 0x0 && (this[_0x1285e0('0x4b5')] = _0x1285e0('0xa8'));
                        var _0x549a1b = _0x5e7681['default'][_0x1285e0('0x37f')](this[_0x1285e0('0x4b5')]);
                        for (var _0x520947 = 0x0; _0x520947 < _0x549a1b[_0x1285e0('0x4cc')]; _0x520947++) {
                            this[_0x1285e0('0x45f')][_0x549a1b[_0x520947]] = _0x549a1b[_0x520947];
                        }
                    }
                    ,
                    _0x1dc0b1['prototype'][_0x2f0963('0x202')] = function (_0x54db8d) {
                        var _0x597992 = _0x2f0963;
                        return this[_0x597992('0x45f')][_0x54db8d];
                    }
                    ,
                    _0x1dc0b1['prototype'][_0x2f0963('0x39b')] = function (_0x57993c) {
                        var _0x2a73c5 = _0x2f0963;
                        this[_0x2a73c5('0x45f')][_0x57993c] = _0x57993c,
                            this[_0x2a73c5('0x4b5')] += ',' + _0x57993c[_0x2a73c5('0xcc')](),
                            this[_0x2a73c5('0x4f8')](_0x2a73c5('0x4b5'), !![]);
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x290')] = function (_0x1e2ac8) {
                        var _0x150c79 = _0x2f0963;
                        return this[_0x150c79('0x243')][_0x1e2ac8];
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x45c')] = function (_0x25d6a9) {
                        var _0x50cd61 = _0x2f0963;
                        this[_0x50cd61('0x243')][_0x25d6a9] = _0x25d6a9,
                            this[_0x50cd61('0x149')] += ',' + _0x25d6a9[_0x50cd61('0xcc')](),
                            this['saveData'](_0x50cd61('0x149'), !![]);
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x63e')] = function () {
                        var _0x17f7f6 = _0x2f0963;
                        this[_0x17f7f6('0x59c')]++,
                            this['setTimeBoxTime'](0x0),
                            this['saveData']('_timeBoxIndex', !![]);
                    }
                    ,
                    _0x1dc0b1['prototype']['getTimBoxIndex'] = function () {
                        var _0x4a20ef = _0x2f0963;
                        return this[_0x4a20ef('0x59c')];
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x21f')] = function (_0x1b833e) {
                        var _0x392428 = _0x2f0963;
                        this[_0x392428('0x581')] = _0x1b833e,
                            this[_0x392428('0x4f8')](_0x392428('0x581'));
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x63a')] = function () {
                        var _0x43196c = _0x2f0963;
                        return this[_0x43196c('0x581')];
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0xd3')] = function () {
                        return this['_recordstate'];
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')]['setRecordState'] = function (_0x13aba9) {
                        var _0x31324d = _0x2f0963;
                        this[_0x31324d('0x44a')] = _0x13aba9;
                    }
                    ,
                    Object[_0x2f0963('0x351')](_0x1dc0b1['prototype'], _0x2f0963('0x586'), {
                        'get': function () {
                            var _0x4215a6 = _0x2f0963;
                            return this[_0x4215a6('0x467')] ? this[_0x4215a6('0x467')] : 0x0;
                        },
                        'set': function (_0x1d9402) {
                            this['_loginCount'] = _0x1d9402,
                                this['saveData']('_loginCount', !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1['prototype'], 'signDate', {
                        'get': function () {
                            var _0xe4a196 = _0x2f0963;
                            return this['_signDate'] ? this[_0xe4a196('0x3e1')] : '';
                        },
                        'set': function (_0x261f1b) {
                            var _0x5588c6 = _0x2f0963;
                            this[_0x5588c6('0x3e1')] = _0x261f1b,
                                this[_0x5588c6('0x4f8')]('_signDate', !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object['defineProperty'](_0x1dc0b1['prototype'], 'signCount', {
                        'get': function () {
                            var _0x436030 = _0x2f0963;
                            return this[_0x436030('0x110')] ? this['_signCount'] : 0x0;
                        },
                        'set': function (_0x20004e) {
                            var _0x44615c = _0x2f0963;
                            this[_0x44615c('0x110')] = _0x20004e,
                                this[_0x44615c('0x4f8')](_0x44615c('0x110'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1['prototype'], _0x2f0963('0x38d'), {
                        'get': function () {
                            var _0x812737 = _0x2f0963;
                            return this['_signTotalCount'] ? this[_0x812737('0x10a')] : 0x0;
                        },
                        'set': function (_0x345146) {
                            var _0x36aaa4 = _0x2f0963;
                            this[_0x36aaa4('0x10a')] = _0x345146,
                                this[_0x36aaa4('0x4f8')]('_signTotalCount', !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0x1a2'), {
                        'get': function () {
                            var _0x1f21b2 = _0x2f0963;
                            return this[_0x1f21b2('0x41a')] ? this['_shareCount'] : 0x0;
                        },
                        'set': function (_0x2d10c3) {
                            var _0x5c99c4 = _0x2f0963;
                            this[_0x5c99c4('0x41a')] = _0x2d10c3,
                                this[_0x5c99c4('0x4f8')](_0x5c99c4('0x41a'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], 'videoCount', {
                        'get': function () {
                            var _0x21a32c = _0x2f0963;
                            return this[_0x21a32c('0x67d')] ? this[_0x21a32c('0x67d')] : 0x0;
                        },
                        'set': function (_0x1ca9b9) {
                            var _0x83f5a3 = _0x2f0963;
                            this[_0x83f5a3('0x67d')] = _0x1ca9b9,
                                this['saveData'](_0x83f5a3('0x67d'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1['prototype'], 'guideStep', {
                        'get': function () {
                            var _0x323d0f = _0x2f0963;
                            return this[_0x323d0f('0x2c3')] ? this[_0x323d0f('0x2c3')] : 0x0;
                        },
                        'set': function (_0x3a3869) {
                            var _0x2c3e4a = _0x2f0963;
                            this['_guideStep'] = _0x3a3869,
                                this[_0x2c3e4a('0x4f8')]('_guideStep', !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0x578'), {
                        'get': function () {
                            var _0x8a8ca4 = _0x2f0963;
                            return this[_0x8a8ca4('0x513')] ? this[_0x8a8ca4('0x513')] : '';
                        },
                        'set': function (_0x5efc9b) {
                            var _0x2f2642 = _0x2f0963;
                            this[_0x2f2642('0x513')] = _0x5efc9b,
                                this['saveData'](_0x2f2642('0x513'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], 'headUrl', {
                        'get': function () {
                            return this['_headUrl'] ? this['_headUrl'] : '';
                        },
                        'set': function (_0x3e0fa1) {
                            var _0xadfe41 = _0x2f0963;
                            this[_0xadfe41('0x5f6')] = _0x3e0fa1,
                                this[_0xadfe41('0x4f8')](_0xadfe41('0x5f6'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0xf'), {
                        'get': function () {
                            var _0x430432 = _0x2f0963;
                            return this[_0x430432('0x37')];
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x45')] = function (_0x5eb380) {
                        var _0x35f488 = _0x2f0963;
                        this[_0x35f488('0x37')] += _0x5eb380,
                            this[_0x35f488('0x4f8')]('_coinCount', !![]);
                    }
                    ,
                    Object['defineProperty'](_0x1dc0b1[_0x2f0963('0x64a')], 'bIsNewer', {
                        'get': function () {
                            return this['_bIsNewer'];
                        },
                        'set': function (_0xee240c) {
                            var _0x405379 = _0x2f0963;
                            this[_0x405379('0x265')] = _0xee240c,
                                this[_0x405379('0x4f8')](_0x405379('0x265'));
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object['defineProperty'](_0x1dc0b1['prototype'], _0x2f0963('0x5b5'), {
                        'get': function () {
                            var _0x15d985 = _0x2f0963;
                            return this[_0x15d985('0x2c4')];
                        },
                        'set': function (_0x1328ba) {
                            var _0x49975b = _0x2f0963;
                            this['_bVibration'] = _0x1328ba,
                                this[_0x49975b('0x4f8')](_0x49975b('0x2c4'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object['defineProperty'](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0x2bf'), {
                        'get': function () {
                            return this['_bSound'];
                        },
                        'set': function (_0x1340cb) {
                            var _0x2585c5 = _0x2f0963;
                            this['_bSound'] = _0x1340cb,
                                this[_0x2585c5('0x4f8')](_0x2585c5('0x24a'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0x319'), {
                        'get': function () {
                            var _0x4c42f2 = _0x2f0963;
                            return this[_0x4c42f2('0x350')];
                        },
                        'set': function (_0x48d503) {
                            var _0x4a97c0 = _0x2f0963;
                            this['_badgeLevel'] = _0x48d503,
                                this['saveData'](_0x4a97c0('0x350'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0x144'), {
                        'get': function () {
                            var _0x15c850 = _0x2f0963;
                            return this[_0x15c850('0x246')];
                        },
                        'set': function (_0x11e23c) {
                            var _0xd9644 = _0x2f0963;
                            this[_0xd9644('0x246')] = _0x11e23c,
                                this[_0xd9644('0x4f8')](_0xd9644('0x246'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1[_0x2f0963('0x64a')], _0x2f0963('0x60'), {
                        'get': function () {
                            var _0x68cb7d = _0x2f0963;
                            return this[_0x68cb7d('0x45a')];
                        },
                        'set': function (_0x4298f3) {
                            var _0x18b283 = _0x2f0963;
                            this[_0x18b283('0x45a')] = _0x4298f3,
                                this[_0x18b283('0x4f8')]('_curRound', !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object[_0x2f0963('0x351')](_0x1dc0b1['prototype'], _0x2f0963('0x486'), {
                        'get': function () {
                            var _0x1e5ef5 = _0x2f0963;
                            return this[_0x1e5ef5('0x3b0')];
                        },
                        'set': function (_0x1733e4) {
                            var _0x2450bd = _0x2f0963;
                            this[_0x2450bd('0x3b0')] = _0x1733e4,
                                this['saveData'](_0x2450bd('0x3b0'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object['defineProperty'](_0x1dc0b1['prototype'], _0x2f0963('0x33f'), {
                        'get': function () {
                            var _0x25a3a3 = _0x2f0963;
                            return this[_0x25a3a3('0xf0')];
                        },
                        'set': function (_0x4c0b62) {
                            var _0x3c18e4 = _0x2f0963;
                            this[_0x3c18e4('0xf0')] = _0x4c0b62,
                                this[_0x3c18e4('0x4f8')](_0x3c18e4('0xf0'), !![]);
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0x4f8')] = function (_0x1c7e93, _0x50cc1d) {
                        var _0x26e81b = _0x2f0963;
                        _0x50cc1d === void 0x0 && (_0x50cc1d = ![]);
                        if (_0x50cc1d) {
                            var _0x38ddfc = void 0x0
                                , _0x4f34f9 = ![];
                            if (_0x1c7e93 == 'all')
                                for (_0x38ddfc in this) {
                                    _0x38ddfc['indexOf']('_') == 0x0 && (this[_0x26e81b('0x5c9')](_0x38ddfc),
                                        _0x4f34f9 = !![]);
                                }
                            else {
                                this[_0x26e81b('0x125')][_0x1c7e93] = _0x1c7e93;
                                for (_0x38ddfc in this[_0x26e81b('0x125')]) {
                                    this[_0x26e81b('0x5c9')](_0x38ddfc),
                                        delete this[_0x26e81b('0x125')][_0x38ddfc],
                                        _0x4f34f9 = !![];
                                }
                            }
                        } else
                            this[_0x26e81b('0x125')][_0x1c7e93] = _0x1c7e93;
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')]['cacheData'] = function (_0x109b33) {
                        var _0x5b4b07 = _0x2f0963;
                        Laya[_0x5b4b07('0x116')][_0x5b4b07('0x5ee')](_0x109b33, this[_0x109b33]),
                            _0x2dc6c2['default'][_0x5b4b07('0x4ce')][_0x5b4b07('0xeb')](_0x5b4b07('0x7a')) == 0x1 && _0x2731eb[_0x5b4b07('0x3b6')][_0x5b4b07('0x249')](_0x46714b[_0x5b4b07('0x1d1')][_0x5b4b07('0x2da')], 0x2, {
                                'key': _0x109b33,
                                'value': JSON[_0x5b4b07('0x41c')](this[_0x109b33])
                            }, function (_0x3d27a5) {
                                var _0x5ca7b0 = _0x5b4b07
                                    , _0x31fe01 = _0x3d27a5;
                                typeof _0x3d27a5 == 'string' && (_0x31fe01 = JSON[_0x5ca7b0('0x66f')](_0x3d27a5)),
                                    _0x31fe01[_0x5ca7b0('0x4f1')] != 0x1 && Laya[_0x5ca7b0('0x2bb')][_0x5ca7b0('0x667')] && console[_0x5ca7b0('0x560')](_0x5ca7b0('0x153'), _0x109b33);
                            }
                            [_0x5b4b07('0x484')](this), !![]);
                    }
                    ,
                    _0x1dc0b1[_0x2f0963('0x64a')][_0x2f0963('0xdd')] = function () {
                        var _0x4d57e1 = _0x2f0963;
                        Laya[_0x4d57e1('0x116')][_0x4d57e1('0x466')]();
                        var _0x1793f8;
                        for (_0x1793f8 in this) {
                            _0x1793f8[_0x4d57e1('0x1dd')]('_') == 0x0 && (this[_0x1793f8] = this[_0x4d57e1('0x57e')][_0x1793f8]);
                        }
                        Laya[_0x4d57e1('0x5ac')][_0x4d57e1('0x466')](this, this[_0x4d57e1('0x4f8')]),
                            this[_0x4d57e1('0x40e')]();
                    }
                    ,
                    _0x1dc0b1;
            }();
        _0x102f85['default'] = _0x56f917;
    }
        , {
        '../Platform': 0x3,
        '../XGame': 0x4,
        '../core/Http': 0x7,
        '../enum/GameConst': 0xf,
        '../utils/Tools': 0x37
    }],
    0x16: [function (_0x826b35, _0x38ff29, _0x1625af) {
        var _0x1a259a = _0x4b7fcf;
        'use strict';
        Object[_0x1a259a('0x351')](_0x1625af, _0x1a259a('0xb8'), {
            'value': !![]
        });
        var _0x3e821e = _0x826b35('../XGame')
            , _0xc96dd6 = function () {
                var _0x3ad6e4 = _0x1a259a;
                function _0x346a7b() {
                    var _0xb7a5e3 = _0x5985;
                    this[_0xb7a5e3('0xf8')] = {};
                }
                return _0x346a7b[_0x3ad6e4('0x64a')]['Initialization'] = function () {
                    var _0x2cc090 = _0x3ad6e4;
                    this[_0x2cc090('0x64b')] = _0x3e821e[_0x2cc090('0x3b6')][_0x2cc090('0xba')][_0x2cc090('0x3a4')][_0x2cc090('0x5')](new Laya['Sprite3D'](_0x2cc090('0x33d')));
                }
                    ,
                    _0x346a7b['prototype'][_0x3ad6e4('0x36d')] = function (_0x52b2f7) {
                        var _0x493ba2 = _0x3ad6e4;
                        this[_0x493ba2('0xf8')][_0x52b2f7] == null && (this['_pool'][_0x52b2f7] = new Array());
                        var _0x3b9352 = this[_0x493ba2('0xf8')][_0x52b2f7]
                            , _0x5075d2 = _0x3b9352[_0x493ba2('0x284')]();
                        if (_0x5075d2 == null) {
                            var _0x48ce2 = _0x3e821e[_0x493ba2('0x3b6')]['ResMgr'][_0x493ba2('0xec')](_0x52b2f7);
                            _0x5075d2 = Laya[_0x493ba2('0x55a')][_0x493ba2('0x3c')](_0x48ce2, this['_obj']);
                        }
                        return this[_0x493ba2('0x64b')][_0x493ba2('0x26c')](_0x5075d2),
                            _0x5075d2[_0x493ba2('0x4ba')] = !![],
                            _0x5075d2;
                    }
                    ,
                    _0x346a7b[_0x3ad6e4('0x64a')][_0x3ad6e4('0x2c1')] = function (_0x22703e, _0x1e2680) {
                        var _0x13d167 = _0x3ad6e4;
                        this[_0x13d167('0x64b')][_0x13d167('0x5')](_0x1e2680),
                            _0x1e2680['particleSystem'][_0x13d167('0x3d8')](),
                            _0x1e2680[_0x13d167('0x4ba')] = ![],
                            this['_pool'][_0x22703e][_0x13d167('0xff')](_0x1e2680);
                    }
                    ,
                    _0x346a7b;
            }();
        _0x1625af[_0x1a259a('0x3b6')] = _0xc96dd6;
    }
        , {
        '../XGame': 0x4
    }],
    0x17: [function (_0x2e2caf, _0x2e048, _0x122ec5) {
        var _0x1c8005 = _0x4b7fcf;
        'use strict';
        Object[_0x1c8005('0x351')](_0x122ec5, _0x1c8005('0xb8'), {
            'value': !![]
        });
        var _0x59a2ab = function (_0x380295) {
            __extends(_0x432236, _0x380295);
            function _0x432236() {
                var _0x1bc395 = _0x5985;
                return _0x380295[_0x1bc395('0x324')](this) || this;
            }
            return _0x432236;
        }(Laya[_0x1c8005('0x5d6')]);
        _0x122ec5[_0x1c8005('0x3b6')] = _0x59a2ab;
    }
        , {}],
    0x18: [function (_0xae297f, _0x47fc36, _0x57a130) {
        var _0x38fc6d = _0x4b7fcf;
        'use strict';
        Object[_0x38fc6d('0x351')](_0x57a130, _0x38fc6d('0xb8'), {
            'value': !![]
        });
        var _0x427bb9 = _0xae297f(_0x38fc6d('0x167'))
            , _0x109e92 = _0xae297f(_0x38fc6d('0xd0'))
            , _0x2232dd = _0xae297f(_0x38fc6d('0x1b1'))
            , _0x281468 = _0xae297f(_0x38fc6d('0x5e2'))
            , _0x503b4b = _0xae297f('../entity/Player')
            , _0x43d18e = _0xae297f(_0x38fc6d('0x505'))
            , _0x18f3bd = _0xae297f('../Platform')
            , _0x17ef23 = _0xae297f('../enum/GameConst')
            , _0x4684be = function () {
                var _0x37060c = _0x38fc6d;
                function _0x75d9c() {
                    var _0x2a6c58 = _0x5985;
                    this[_0x2a6c58('0x353')] = _0x2232dd[_0x2a6c58('0x281')]['State'][_0x2a6c58('0x379')];
                }
                return Object['defineProperty'](_0x75d9c[_0x37060c('0x64a')], _0x37060c('0x34a'), {
                    'get': function () {
                        var _0x55bc85 = _0x37060c;
                        return this[_0x55bc85('0x162')];
                    },
                    'enumerable': !![],
                    'configurable': !![]
                }),
                    Object[_0x37060c('0x351')](_0x75d9c[_0x37060c('0x64a')], 'Player', {
                        'get': function () {
                            var _0x272670 = _0x37060c;
                            return this[_0x272670('0x465')];
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    Object['defineProperty'](_0x75d9c[_0x37060c('0x64a')], _0x37060c('0x631'), {
                        'get': function () {
                            var _0x2da2be = _0x37060c;
                            return this[_0x2da2be('0x468')];
                        },
                        'enumerable': !![],
                        'configurable': !![]
                    }),
                    _0x75d9c['prototype']['Initialization'] = function () {
                        var _0x5a0f3c = _0x37060c;
                        this['initConfig'](),
                            this['initCrown'](),
                            this[_0x5a0f3c('0x3ae')]();
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')]['StartGame'] = function (_0x3719bb, _0x471687, _0x2c790b, _0x506757, _0x2b8dbd, _0x1c98fe) {
                        var _0x3af90a = _0x37060c
                            , _0x4faa6e = this;
                        _0x2b8dbd === void 0x0 && (_0x2b8dbd = _0x427bb9['default'][_0x3af90a('0x678')]['ballSkinId']);
                        _0x1c98fe === void 0x0 && (_0x1c98fe = ![]);
                        console[_0x3af90a('0x5df')](_0x3af90a('0x372'), _0x427bb9[_0x3af90a('0x3b6')][_0x3af90a('0x678')][_0x3af90a('0x60')]);
                        _0x17ef23['GameConst']['Platform'] == _0x17ef23[_0x3af90a('0x52b')][_0x3af90a('0xd1')] && _0x18f3bd[_0x3af90a('0x3b6')][_0x3af90a('0x2c9')]();
                        this[_0x3af90a('0x3b5')](),
                            Laya[_0x3af90a('0x5ac')][_0x3af90a('0x466')](this, this[_0x3af90a('0x573')]),
                            Laya[_0x3af90a('0x5ac')][_0x3af90a('0x1b9')] = 0x1,
                            this[_0x3af90a('0x476')] = _0x506757;
                        var _0x1393e6 = _0x427bb9[_0x3af90a('0x3b6')]['CfgMgr'][_0x3af90a('0x2be')](_0x3719bb);
                        this[_0x3af90a('0x50a')] = _0x1393e6[_0x3af90a('0x647')],
                            this[_0x3af90a('0x3cb')] = 0x0,
                            this[_0x3af90a('0x59b')] = _0x1393e6['Name'],
                            _0x427bb9[_0x3af90a('0x3b6')][_0x3af90a('0x370')][_0x3af90a('0x393')](_0x281468[_0x3af90a('0x4c3')][_0x3af90a('0x515')]);
                        if (this[_0x3af90a('0x476')] == _0x2232dd[_0x3af90a('0x281')]['GameType']['Special'])
                            this[_0x3af90a('0x162')] = _0x427bb9[_0x3af90a('0x3b6')]['SceneMgr']['AddBall'](_0x3af90a('0xd6'));
                        else {
                            var _0x1393e6 = _0x427bb9[_0x3af90a('0x3b6')][_0x3af90a('0x4ce')][_0x3af90a('0x3ef')](_0x2b8dbd);
                            this[_0x3af90a('0x162')] = _0x427bb9[_0x3af90a('0x3b6')][_0x3af90a('0xba')][_0x3af90a('0x35')](_0x1393e6[_0x3af90a('0x29d')]),
                                this[_0x3af90a('0x162')][_0x3af90a('0x5d3')][_0x3af90a('0x4ba')] = !![];
                        }
                        this[_0x3af90a('0x162')][_0x3af90a('0x672')](),
                            this['_player'][_0x3af90a('0x32d')](_0x471687),
                            this[_0x3af90a('0x476')] == _0x2232dd[_0x3af90a('0x281')][_0x3af90a('0x4b6')]['Special'] || _0x1c98fe ? this[_0x3af90a('0x468')][_0x3af90a('0x5d3')][_0x3af90a('0x4ba')] = ![] : this[_0x3af90a('0x468')][_0x3af90a('0x32d')](_0x2c790b, !![]),
                            _0x427bb9['default'][_0x3af90a('0xba')][_0x3af90a('0x382')](_0x3719bb, _0x506757, function () {
                                var _0x5dfbd3 = _0x3af90a;
                                _0x4faa6e[_0x5dfbd3('0x162')][_0x5dfbd3('0x695')](!![]),
                                    Laya['timer']['frameLoop'](0x1, _0x4faa6e, _0x4faa6e[_0x5dfbd3('0x573')]);
                            }),
                            Laya[_0x3af90a('0x5ac')][_0x3af90a('0x1e6')](0x514, this, function () {
                                var _0x20ce1 = _0x3af90a;
                                _0x4faa6e[_0x20ce1('0x353')] = _0x2232dd[_0x20ce1('0x281')][_0x20ce1('0x170')]['Start'];
                            });
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')][_0x37060c('0x573')] = function () {
                        var _0x534c7f = _0x37060c;
                        this['_currentTime'] += 0x1 / 0x3c,
                            this[_0x534c7f('0x476')] != _0x2232dd['GameEnum']['GameType'][_0x534c7f('0x6a6')] && (this[_0x534c7f('0x465')][_0x534c7f('0x668')] > 0x0 && (this[_0x534c7f('0x465')][_0x534c7f('0x668')] > this[_0x534c7f('0x468')]['score'] ? this[_0x534c7f('0x9b')](!![]) : this[_0x534c7f('0x3b5')]()),
                                this[_0x534c7f('0x468')][_0x534c7f('0x668')] > 0x0 && (this[_0x534c7f('0x465')][_0x534c7f('0x668')] < this[_0x534c7f('0x468')][_0x534c7f('0x668')] && this[_0x534c7f('0x9b')](![]))),
                            (this[_0x534c7f('0x465')][_0x534c7f('0x668')] >= 0x5 || this[_0x534c7f('0x468')][_0x534c7f('0x668')] >= 0x5) && ((this[_0x534c7f('0x476')] == _0x2232dd['GameEnum'][_0x534c7f('0x4b6')][_0x534c7f('0x579')] || this[_0x534c7f('0x476')] == _0x2232dd['GameEnum'][_0x534c7f('0x4b6')][_0x534c7f('0x473')]) && this[_0x534c7f('0x46f')](this[_0x534c7f('0x465')][_0x534c7f('0x668')] >= this[_0x534c7f('0x468')]['score'])),
                            this['_currentTime'] >= this[_0x534c7f('0x50a')] && (this['RoundType'] == _0x2232dd[_0x534c7f('0x281')][_0x534c7f('0x4b6')][_0x534c7f('0x579')] || this[_0x534c7f('0x476')] == _0x2232dd[_0x534c7f('0x281')][_0x534c7f('0x4b6')][_0x534c7f('0x473')] ? this['GameEnd'](this[_0x534c7f('0x465')][_0x534c7f('0x668')] >= this[_0x534c7f('0x468')][_0x534c7f('0x668')]) : this[_0x534c7f('0x46f')](!![]));
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')][_0x37060c('0x49d')] = function () {
                        var _0x178463 = _0x37060c;
                        return Math[_0x178463('0x80')](this[_0x178463('0x50a')] - this[_0x178463('0x3cb')]);
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')][_0x37060c('0x46f')] = function (_0x337e19) {
                        var _0x597bd7 = _0x37060c
                            , _0x15f1b1 = this;
                        Laya[_0x597bd7('0x5ac')][_0x597bd7('0x466')](this, this[_0x597bd7('0x573')]),
                            this[_0x597bd7('0x353')] = _0x2232dd['GameEnum'][_0x597bd7('0x170')][_0x597bd7('0x379')];
                        var _0x28cd84 = _0x597bd7('0x26e');
                        this[_0x597bd7('0x476')] == _0x2232dd[_0x597bd7('0x281')][_0x597bd7('0x4b6')][_0x597bd7('0x6a6')] && (_0x28cd84 = 'fx_05');
                        var _0x2b8114 = _0x427bb9[_0x597bd7('0x3b6')][_0x597bd7('0x51')][_0x597bd7('0x36d')](_0x28cd84);
                        _0x427bb9['default']['SceneMgr'][_0x597bd7('0x4af')](_0x2b8114),
                            _0x2b8114[_0x597bd7('0xb6')][_0x597bd7('0x45b')] = new Laya[(_0x597bd7('0x592'))](0x0, 0.6, 0x0),
                            _0x2b8114[_0x597bd7('0x398')]['looping'] = ![],
                            _0x2b8114[_0x597bd7('0x398')][_0x597bd7('0x525')](),
                            Laya[_0x597bd7('0x5ac')][_0x597bd7('0x1e6')](0x3e8, this, function () {
                                var _0x41f326 = _0x597bd7;
                                _0x427bb9[_0x41f326('0x3b6')]['EffMgr'][_0x41f326('0x2c1')](_0x28cd84, _0x2b8114);
                            }),
                            Laya[_0x597bd7('0x34d')]['to'](Laya[_0x597bd7('0x5ac')], {
                                'scale': 0.2
                            }, 0x3e8, null, Laya['Handler']['create'](this, function () {
                                var _0x4ec373 = _0x597bd7;
                                _0x17ef23['GameConst'][_0x4ec373('0x400')] == _0x17ef23[_0x4ec373('0x52b')]['TouTAd'] && _0x18f3bd['default'][_0x4ec373('0x571')]();
                                Laya['timer'][_0x4ec373('0x1b9')] = 0x1,
                                    _0x427bb9['default']['SceneMgr'][_0x4ec373('0x4fb')]();
                                switch (_0x15f1b1[_0x4ec373('0x476')]) {
                                    case _0x2232dd[_0x4ec373('0x281')][_0x4ec373('0x4b6')][_0x4ec373('0x579')]:
                                        window[_0x4ec373('0x50d')][_0x4ec373('0x568')](),
                                            Laya['timer'][_0x4ec373('0x1e6')](0x1f4, this, function () {
                                                var _0x1c81d8 = _0x4ec373;
                                                _0x427bb9[_0x1c81d8('0x3b6')][_0x1c81d8('0x5d7')][_0x1c81d8('0x280')](_0x109e92[_0x1c81d8('0x339')]['LevelResultUI'], {
                                                    'round': _0x427bb9[_0x1c81d8('0x3b6')]['DataMgr'][_0x1c81d8('0x60')],
                                                    'succes': _0x337e19
                                                });
                                            });
                                        break;
                                    case _0x2232dd[_0x4ec373('0x281')][_0x4ec373('0x4b6')][_0x4ec373('0x6a6')]:
                                        _0x427bb9[_0x4ec373('0x3b6')][_0x4ec373('0x370')][_0x4ec373('0x393')](_0x281468[_0x4ec373('0x4c3')][_0x4ec373('0x46f')]);
                                        break;
                                    case _0x2232dd[_0x4ec373('0x281')][_0x4ec373('0x4b6')][_0x4ec373('0x473')]:
                                        _0x427bb9[_0x4ec373('0x3b6')][_0x4ec373('0x5d7')][_0x4ec373('0x280')](_0x109e92[_0x4ec373('0x339')][_0x4ec373('0x660')], _0x337e19);
                                        break;
                                }
                            }));
                    }
                    ,
                    _0x75d9c['prototype'][_0x37060c('0x9b')] = function (_0x55f836) {
                        var _0x2e79ae = _0x37060c;
                        this[_0x2e79ae('0x119')][_0x2e79ae('0x5d3')]['active'] = !![],
                            _0x55f836 == !![] ? this[_0x2e79ae('0x119')][_0x2e79ae('0x567')](this[_0x2e79ae('0x465')][_0x2e79ae('0x331')][_0x2e79ae('0xb6')]) : this[_0x2e79ae('0x119')][_0x2e79ae('0x567')](this[_0x2e79ae('0x468')][_0x2e79ae('0x331')][_0x2e79ae('0xb6')]);
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')][_0x37060c('0x3b5')] = function () {
                        var _0xfa1f82 = _0x37060c;
                        this[_0xfa1f82('0x119')][_0xfa1f82('0x5d3')]['active'] = ![];
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')][_0x37060c('0x686')] = function () {
                        var _0x482ac6 = _0x37060c
                            , _0xf24f1 = _0x427bb9[_0x482ac6('0x3b6')][_0x482ac6('0xba')][_0x482ac6('0x4af')](new Laya[(_0x482ac6('0x55a'))](_0x482ac6('0x69d')));
                        this[_0x482ac6('0x119')] = _0xf24f1['addComponent'](_0x43d18e['default']),
                            this[_0x482ac6('0x3b5')]();
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')]['initPlayer'] = function () {
                        var _0x31bfe3 = _0x37060c
                            , _0x1a2e43 = _0x427bb9[_0x31bfe3('0x3b6')]['SceneMgr']['AddToStage'](new Laya['Sprite3D']('Player'))
                            , _0x4dac1d = _0x427bb9[_0x31bfe3('0x3b6')][_0x31bfe3('0xba')][_0x31bfe3('0x4af')](new Laya[(_0x31bfe3('0x55a'))](_0x31bfe3('0x631')));
                        this['_player'] = _0x1a2e43[_0x31bfe3('0x5a3')](_0x503b4b['default']),
                            this[_0x31bfe3('0x468')] = _0x4dac1d[_0x31bfe3('0x5a3')](_0x503b4b['default']);
                    }
                    ,
                    _0x75d9c[_0x37060c('0x64a')][_0x37060c('0x102')] = function () {
                        var _0x1a2bef = _0x37060c;
                        this[_0x1a2bef('0x4c2')] = _0x427bb9[_0x1a2bef('0x3b6')][_0x1a2bef('0x4ce')][_0x1a2bef('0xeb')](_0x1a2bef('0x626')),
                            this[_0x1a2bef('0x206')] = _0x427bb9['default']['CfgMgr'][_0x1a2bef('0xeb')](_0x1a2bef('0xa6')),
                            this[_0x1a2bef('0x477')] = _0x427bb9['default']['CfgMgr']['getGlobalCfg'](_0x1a2bef('0x182')),
                            this[_0x1a2bef('0x3a1')] = _0x427bb9['default'][_0x1a2bef('0x4ce')]['getGlobalCfg'](_0x1a2bef('0x3a1')),
                            this[_0x1a2bef('0x608')] = _0x427bb9[_0x1a2bef('0x3b6')][_0x1a2bef('0x4ce')][_0x1a2bef('0xeb')](_0x1a2bef('0x608')),
                            this[_0x1a2bef('0x508')] = _0x427bb9[_0x1a2bef('0x3b6')][_0x1a2bef('0x4ce')][_0x1a2bef('0xeb')](_0x1a2bef('0x508')),
                            this[_0x1a2bef('0x5bd')] = _0x427bb9[_0x1a2bef('0x3b6')][_0x1a2bef('0x4ce')][_0x1a2bef('0xeb')](_0x1a2bef('0x5bd'));
                    }
                    ,
                    _0x75d9c['prototype'][_0x37060c('0x360')] = function (_0x32b621, _0xa553f0) {
                        var _0x149300 = _0x37060c;
                        _0x17ef23[_0x149300('0x1d1')][_0x149300('0x400')] == _0x17ef23[_0x149300('0x52b')][_0x149300('0x576')] && window['wx'] && window['wx'][_0x149300('0x33a')][_0x149300('0x5b9')]({
                            'positionId': _0x32b621
                        })[_0x149300('0x210')](function (_0x23f96a) {
                            _0xa553f0 && _0xa553f0(_0x23f96a);
                        });
                    }
                    ,
                    _0x75d9c;
            }();
        _0x57a130[_0x38fc6d('0x3b6')] = _0x4684be;
    }
        , {
        '../Platform': 0x3,
        '../XGame': 0x4,
        '../entity/Crown': 0xa,
        '../entity/Player': 0xd,
        '../enum/EventEnum': 0xe,
        '../enum/GameConst': 0xf,
        '../enum/GameEnum': 0x10,
        '../enum/UIEnum': 0x13
    }],
    0x19: [function (_0x21f64a, _0x9fcab, _0x266da7) {
        var _0x18b6af = _0x4b7fcf;
        'use strict';
        Object[_0x18b6af('0x351')](_0x266da7, _0x18b6af('0xb8'), {
            'value': !![]
        });
        var _0xd11727 = _0x21f64a(_0x18b6af('0x167'))
            , _0x23e6de = _0x21f64a(_0x18b6af('0x5e2'))
            , _0x372087 = _0x21f64a(_0x18b6af('0x1b2'))
            , _0x2ab338 = function () {
                var _0x156d1c = _0x18b6af;
                function _0x53870c() {
                    var _0x404fb1 = _0x5985;
                    this[_0x404fb1('0x3e6')] = {};
                }
                return _0x53870c[_0x156d1c('0x64a')]['PreloadResources'] = function () {
                    var _0x232943 = _0x156d1c;
                    Laya[_0x232943('0x5e')][_0x232943('0x5fb')](_0x53870c[_0x232943('0x3f2')], Laya[_0x232943('0x49f')]['create'](this, this[_0x232943('0x429')]), Laya[_0x232943('0x49f')][_0x232943('0x5fb')](this, this[_0x232943('0x12a')]));
                }
                    ,
                    _0x53870c[_0x156d1c('0x64a')][_0x156d1c('0x429')] = function (_0x320bd5) {
                        var _0x5b467a = _0x156d1c;
                        _0x320bd5 ? (this[_0x5b467a('0x3da')](_0x372087[_0x5b467a('0x29')][_0x5b467a('0x30a')]),
                            this[_0x5b467a('0x3da')](_0x372087['Prefabs'][_0x5b467a('0x6b1')]),
                            this['initPrefab'](_0x372087[_0x5b467a('0x29')][_0x5b467a('0x447')]),
                            _0xd11727[_0x5b467a('0x3b6')]['CfgMgr'][_0x5b467a('0xad')](),
                            _0xd11727['default'][_0x5b467a('0x678')]['init'](),
                            _0xd11727['default'][_0x5b467a('0x1ab')][_0x5b467a('0x32d')](),
                            _0xd11727[_0x5b467a('0x3b6')][_0x5b467a('0xba')][_0x5b467a('0x32d')](),
                            _0xd11727[_0x5b467a('0x3b6')][_0x5b467a('0x51')][_0x5b467a('0x32d')](),
                            _0xd11727[_0x5b467a('0x3b6')]['GameMgr'][_0x5b467a('0x32d')](),
                            _0xd11727[_0x5b467a('0x3b6')][_0x5b467a('0x370')][_0x5b467a('0x393')](_0x23e6de[_0x5b467a('0x4c3')]['Res_Load_Complete'], [0x64])) : (console['log'](_0x5b467a('0x40d')),
                                _0xd11727['default'][_0x5b467a('0x370')][_0x5b467a('0x393')](_0x23e6de[_0x5b467a('0x4c3')][_0x5b467a('0x1e3')]));
                    }
                    ,
                    _0x53870c['prototype']['onPreLoadResProgress'] = function (_0x47a499) {
                        var _0x4d713c = _0x156d1c;
                        _0xd11727[_0x4d713c('0x3b6')]['EventMgr'][_0x4d713c('0x393')](_0x23e6de[_0x4d713c('0x4c3')][_0x4d713c('0xfe')], _0x47a499);
                    }
                    ,
                    _0x53870c[_0x156d1c('0x64a')][_0x156d1c('0x3da')] = function (_0x31f34f, _0x3404e2) {
                        var _0x4df18d = _0x156d1c;
                        _0x3404e2 === void 0x0 && (_0x3404e2 = 0x1);
                        var _0x183334 = Laya['loader'][_0x4df18d('0xcb')](_0x31f34f);
                        if (_0x183334 == undefined) {
                            console['error'](_0x4df18d('0xc7'), _0x31f34f);
                            return;
                        }
                        _0x183334 = _0x183334[_0x4df18d('0xdc')](0x0);
                        for (var _0x3975d8 = 0x0; _0x3975d8 < _0x183334[_0x4df18d('0x3f0')]; _0x3975d8++) {
                            var _0x3eaea8 = _0x183334['getChildAt'](_0x3975d8);
                            if (_0x3404e2 == 0x1)
                                this['_prefabMap'][_0x3eaea8[_0x4df18d('0x8c')]] = _0x3eaea8;
                            else {
                                if (_0x3404e2 == 0x2)
                                    for (var _0x173583 = 0x0; _0x173583 < _0x3eaea8[_0x4df18d('0x3f0')]; _0x173583++) {
                                        var _0x232cb4 = _0x3eaea8[_0x4df18d('0xdc')](_0x173583);
                                        this[_0x4df18d('0x3e6')][_0x232cb4[_0x4df18d('0x8c')]] = _0x232cb4;
                                    }
                            }
                        }
                    }
                    ,
                    _0x53870c[_0x156d1c('0x64a')]['GetPrefab'] = function (_0x2b7294) {
                        var _0x3ee171 = _0x156d1c;
                        return this[_0x3ee171('0x3e6')][_0x2b7294];
                    }
                    ,
                    _0x53870c[_0x156d1c('0x64a')][_0x156d1c('0x1b8')] = function (_0x189313) {
                        var _0x4080ba = _0x156d1c
                            , _0x42346a = Laya['loader']['getRes'](_0x189313);
                        return _0x42346a == null && console[_0x4080ba('0x560')](_0x4080ba('0x2ed'), _0x189313),
                            _0x42346a;
                    }
                    ,
                    _0x53870c['PreloadRes'] = [{
                        'url': _0x372087['EAtlas']['Game'],
                        'type': Laya[_0x156d1c('0x3d6')]['ATLAS']
                    }, {
                        'url': _0x372087[_0x156d1c('0x1c')]['Level'],
                        'type': Laya['Loader'][_0x156d1c('0x5f5')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x1c')][_0x156d1c('0x6ae')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x5f5')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x1c')][_0x156d1c('0x9f')],
                        'type': Laya['Loader'][_0x156d1c('0x5f5')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x1c')][_0x156d1c('0x2b9')],
                        'type': Laya[_0x156d1c('0x3d6')]['ATLAS']
                    }, {
                        'url': _0x372087[_0x156d1c('0x1c')][_0x156d1c('0x3bb')],
                        'type': Laya['Loader'][_0x156d1c('0x5f5')]
                    }, {
                        'url': _0x372087['EAtlas'][_0x156d1c('0x36c')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x5f5')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x1c')][_0x156d1c('0xb3')],
                        'type': Laya['Loader']['ATLAS']
                    }, {
                        'url': _0x372087[_0x156d1c('0x29')][_0x156d1c('0x6b1')],
                        'type': Laya[_0x156d1c('0x3d6')]['HIERARCHY']
                    }, {
                        'url': _0x372087['Prefabs']['Balls'],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x268')]
                    }, {
                        'url': _0x372087['Prefabs']['Particles'],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x268')]
                    }, {
                        'url': _0x372087['Prefabs'][_0x156d1c('0x22')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x2e1')]
                    }, {
                        'url': _0x372087['Prefabs'][_0x156d1c('0x67')],
                        'type': Laya['Loader'][_0x156d1c('0x2e1')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x29')]['SignItem'],
                        'type': Laya[_0x156d1c('0x3d6')]['PREFAB']
                    }, {
                        'url': _0x372087[_0x156d1c('0x29')]['RankItem'],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x2e1')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x29')][_0x156d1c('0x126')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x2e1')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x516')][_0x156d1c('0x17a')],
                        'type': Laya[_0x156d1c('0x3d6')]['HIERARCHY']
                    }, {
                        'url': _0x372087[_0x156d1c('0x516')][_0x156d1c('0x21b')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x268')]
                    }, {
                        'url': _0x372087['Jsons'][_0x156d1c('0x19')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x259')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x570')][_0x156d1c('0x337')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x259')]
                    }, {
                        'url': _0x372087['Jsons'][_0x156d1c('0x263')],
                        'type': Laya['Loader'][_0x156d1c('0x259')]
                    }, {
                        'url': _0x372087['Jsons'][_0x156d1c('0x3bb')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x259')]
                    }, {
                        'url': _0x372087['Jsons'][_0x156d1c('0xb3')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x259')]
                    }, {
                        'url': _0x372087['Jsons'][_0x156d1c('0x46d')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x259')]
                    }, {
                        'url': _0x372087[_0x156d1c('0x570')]['Ad'],
                        'type': Laya[_0x156d1c('0x3d6')]['JSON']
                    }, {
                        'url': _0x372087[_0x156d1c('0x570')][_0x156d1c('0x4e')],
                        'type': Laya[_0x156d1c('0x3d6')][_0x156d1c('0x259')]
                    }],
                    _0x53870c;
            }();
        _0x266da7[_0x18b6af('0x3b6')] = _0x2ab338;
    }
        , {
        '../XGame': 0x4,
        '../enum/EventEnum': 0xe,
        '../enum/ResEnum': 0x12
    }],
    0x1a: [function (_0x501ee5, _0x45cf54, _0x428c22) {
        var _0x1412b4 = _0x4b7fcf;
        'use strict';
        Object[_0x1412b4('0x351')](_0x428c22, '__esModule', {
            'value': !![]
        });
        var _0x1498e8 = _0x501ee5(_0x1412b4('0x1b2'))
            , _0x1b8d7d = _0x501ee5(_0x1412b4('0x1ce'))
            , _0x42c4b3 = _0x501ee5('../controller/CameraController')
            , _0x209734 = _0x501ee5(_0x1412b4('0x5f1'))
            , _0x4ed425 = _0x501ee5('../XGame')
            , _0x4d3ca2 = _0x501ee5('../enum/GameEnum')
            , _0x211d5d = _0x501ee5(_0x1412b4('0x5e2'))
            , _0xd48abc = _0x501ee5(_0x1412b4('0x291'))
            , _0xa82ba7 = function () {
                var _0x2c0d54 = _0x1412b4;
                function _0xe414a2() {
                    var _0x36f502 = _0x5985;
                    this['_changjing'] = {},
                        this['_ballPool'] = {},
                        this[_0x36f502('0x200')] = {},
                        this[_0x36f502('0x480')] = {};
                }
                return _0xe414a2[_0x2c0d54('0x64a')]['Initialization'] = function () {
                    var _0x457518 = _0x2c0d54;
                    this['scene'] = Laya[_0x457518('0x150')][_0x457518('0x5')](Laya['loader']['getRes'](_0x1498e8[_0x457518('0x516')]['Game'])),
                        this[_0x457518('0x520')] = this['scene']['getChildByName'](_0x457518('0x83'))[_0x457518('0x5a3')](_0x42c4b3[_0x457518('0x3b6')]),
                        this[_0x457518('0x679')] = this[_0x457518('0x3a4')]['getChildByName'](_0x457518('0x5db')),
                        this[_0x457518('0x1bd')] = this['scene'][_0x457518('0x3aa')](_0x457518('0x69e')),
                        this['_stage'] = this['_node']['getChildByName'](_0x457518('0x64c'))[_0x457518('0x3aa')]('Scene01'),
                        this[_0x457518('0x5e9')] = this[_0x457518('0x1bd')][_0x457518('0x3aa')](_0x457518('0x233')),
                        this[_0x457518('0x620')] = this['_node'][_0x457518('0x3aa')]('human'),
                        this[_0x457518('0x526')] = this[_0x457518('0x1bd')]['getChildByName'](_0x457518('0x539')),
                        this['_flag_left'] = this[_0x457518('0x526')][_0x457518('0x3aa')]('flag_left'),
                        this[_0x457518('0xa0')] = this['_flags'][_0x457518('0x3aa')]('flag_right'),
                        this[_0x457518('0x399')] = this[_0x457518('0x526')][_0x457518('0x3aa')](_0x457518('0x28d')),
                        this[_0x457518('0x334')] = this[_0x457518('0x526')]['getChildByName'](_0x457518('0x1d6')),
                        this[_0x457518('0x101')] = this[_0x457518('0x583')]['getChildByName']('Scene_Me'),
                        this['_flag_renderer_right'] = this[_0x457518('0xa0')][_0x457518('0x3aa')]('Scene_Him');
                    var _0x3e4864 = this[_0x457518('0x1bd')][_0x457518('0x3aa')]('wall_down')
                        , _0xc04fea = _0x3e4864[_0x457518('0x612')](Laya[_0x457518('0xa5')]);
                    _0xc04fea[_0x457518('0x221')] = _0x1b8d7d[_0x457518('0x138')][_0x457518('0xf4')],
                        this[_0x457518('0x3a4')]['physicsSimulation']['fixedTimeStep'] = 0x1 / 0x32,
                        this[_0x457518('0x2cc')](),
                        this[_0x457518('0x45d')](),
                        Laya[_0x457518('0x5ac')][_0x457518('0x55')](0x1, this, this['lookAtPlayer']);
                }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')][_0x2c0d54('0x382')] = function (_0x355d02, _0x2f8ec2, _0x3708c4) {
                        var _0x321f47 = _0x2c0d54;
                        this[_0x321f47('0x285')](_0x355d02);
                        var _0xb0e0d2 = _0x2f8ec2 != _0x4d3ca2[_0x321f47('0x281')][_0x321f47('0x4b6')]['Special'];
                        this[_0x321f47('0x526')][_0x321f47('0x4ba')] = _0xb0e0d2,
                            _0xb0e0d2 ? this[_0x321f47('0x683')](_0x3708c4) : _0x3708c4();
                    }
                    ,
                    _0xe414a2['prototype'][_0x2c0d54('0x4af')] = function (_0x130980) {
                        var _0x478477 = _0x2c0d54;
                        return this[_0x478477('0x3d4')][_0x478477('0x5')](_0x130980);
                    }
                    ,
                    _0xe414a2['prototype']['AddBall'] = function (_0x1863b9) {
                        var _0xb33704 = _0x2c0d54;
                        for (var _0x74f367 in this[_0xb33704('0x274')]) {
                            this[_0xb33704('0x274')][_0xb33704('0x4e1')](_0x74f367) && (this[_0xb33704('0x274')][_0x74f367][_0xb33704('0x5d3')][_0xb33704('0x4ba')] = ![]);
                        }
                        var _0x53ce9c = this['_ballPool'][_0x1863b9];
                        if (_0x53ce9c == null) {
                            var _0x11cf49 = Laya['Sprite3D'][_0xb33704('0x3c')](_0x4ed425[_0xb33704('0x3b6')][_0xb33704('0x60d')]['GetPrefab'](_0x1863b9));
                            _0x11cf49[_0xb33704('0x5e7')][_0xb33704('0x3bc')] = !![];
                            var _0x36f220 = this[_0xb33704('0x4af')](_0x11cf49);
                            _0x53ce9c = _0x36f220[_0xb33704('0x5a3')](_0x209734[_0xb33704('0x3b6')]),
                                this[_0xb33704('0x274')][_0x1863b9] = _0x53ce9c;
                        }
                        return _0x53ce9c[_0xb33704('0x5d3')][_0xb33704('0x4ba')] = !![],
                            _0x53ce9c;
                    }
                    ,
                    _0xe414a2['prototype']['playFlagDownAnim'] = function (_0x1e6b76) {
                        var _0x23d9bb = _0x2c0d54;
                        this[_0x23d9bb('0x526')][_0x23d9bb('0xb6')][_0x23d9bb('0x40f')] = 0x4,
                            Laya[_0x23d9bb('0x34d')]['to'](this['_flags'][_0x23d9bb('0xb6')], {
                                'localPositionY': 0x0
                            }, 0x4b0, Laya[_0x23d9bb('0x2a3')][_0x23d9bb('0x1b7')], Laya['Handler'][_0x23d9bb('0x5fb')](this, _0x1e6b76));
                    }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')][_0x2c0d54('0x22b')] = function () {
                        var _0x26cec7 = _0x2c0d54;
                        if (_0x4ed425[_0x26cec7('0x3b6')][_0x26cec7('0x33b')][_0x26cec7('0x353')] != _0x4d3ca2[_0x26cec7('0x281')][_0x26cec7('0x170')]['Start'])
                            return;
                        var _0x387414 = _0x4ed425[_0x26cec7('0x3b6')][_0x26cec7('0x33b')][_0x26cec7('0x38b')]['Hoop'][_0x26cec7('0xb6')]['position'][_0x26cec7('0x2f')]();
                        _0x387414['y'] = this['_referee'][_0x26cec7('0xb6')]['position']['y'],
                            _0x387414['z'] = 0x0,
                            this[_0x26cec7('0x620')][_0x26cec7('0xb6')]['lookAt'](_0x387414, Laya[_0x26cec7('0x592')][_0x26cec7('0x30')]);
                    }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')][_0x2c0d54('0x2cc')] = function () {
                        var _0x5bc12d = _0x2c0d54
                            , _0x58dca5 = this[_0x5bc12d('0x1bd')][_0x5bc12d('0x3aa')]('res')
                            , _0x2bd7b9 = _0x58dca5['getChildByName'](_0x5bc12d('0x258'));
                        for (var _0x26f8d5 = 0x0; _0x26f8d5 < _0x2bd7b9['numChildren']; _0x26f8d5++) {
                            var _0x2e3ae3 = _0x2bd7b9[_0x5bc12d('0xdc')](_0x26f8d5);
                            this[_0x5bc12d('0x200')][_0x26f8d5] = _0x2e3ae3['meshRenderer'][_0x5bc12d('0x598')];
                        }
                        var _0x1b9c3e = _0x58dca5[_0x5bc12d('0x3aa')](_0x5bc12d('0x94'))
                            , _0x1e9e1d = _0x58dca5[_0x5bc12d('0x3aa')]('stage');
                        for (var _0x26f8d5 = 0x0; _0x26f8d5 < _0x1b9c3e[_0x5bc12d('0x3f0')]; _0x26f8d5++) {
                            var _0x480b44 = _0x1b9c3e['getChildAt'](_0x26f8d5)
                                , _0x1efe88 = _0x1e9e1d[_0x5bc12d('0xdc')](_0x26f8d5);
                            this[_0x5bc12d('0x480')][_0x26f8d5] = [_0x480b44['meshRenderer'][_0x5bc12d('0x598')], _0x1efe88[_0x5bc12d('0x5e7')]['material']];
                        }
                        _0x58dca5[_0x5bc12d('0x392')](!![]);
                    }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')][_0x2c0d54('0x45d')] = function () {
                        var _0x4a41e1 = _0x2c0d54;
                        this[_0x4a41e1('0x679')]['shadow'] = !![],
                            this[_0x4a41e1('0x679')][_0x4a41e1('0x481')] = 0x800,
                            this[_0x4a41e1('0x679')][_0x4a41e1('0x557')] = 0x1,
                            this['_light'][_0x4a41e1('0x242')] = 0x3,
                            this[_0x4a41e1('0x5e9')][_0x4a41e1('0x5e7')]['receiveShadow'] = !![];
                    }
                    ,
                    _0xe414a2['prototype']['openStage'] = function (_0x80ca61) {
                        var _0x15bbf7 = _0x2c0d54
                            , _0x31359c = this['_stageMaterial'][_0x80ca61 - 0x1]
                            , _0x5dfdda = _0x31359c[0x0]
                            , _0x214245 = _0x31359c[0x1];
                        this['_stage']['skinnedMeshRenderer'][_0x15bbf7('0x598')] = _0x5dfdda,
                            this[_0x15bbf7('0x101')][_0x15bbf7('0x216')][_0x15bbf7('0x598')] = _0x5dfdda,
                            this[_0x15bbf7('0x637')][_0x15bbf7('0x216')][_0x15bbf7('0x598')] = _0x5dfdda,
                            this['_referee'][_0x15bbf7('0x5e7')]['material'] = _0x5dfdda,
                            this[_0x15bbf7('0x5e9')]['meshRenderer'][_0x15bbf7('0x598')] = _0x214245,
                            this[_0x15bbf7('0x4f6')](0x0, !![]),
                            this['ChangeScore'](0x0, ![]),
                            this[_0x15bbf7('0x4fb')]();
                    }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')]['DisableEff'] = function () {
                        var _0x4f6cee = _0x2c0d54;
                        this[_0x4f6cee('0x24d')] != null && (_0x4ed425[_0x4f6cee('0x3b6')][_0x4f6cee('0x51')][_0x4f6cee('0x2c1')](this[_0x4f6cee('0x2b0')], this[_0x4f6cee('0x24d')]),
                            this['_eff'] = null);
                    }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')][_0x2c0d54('0x247')] = function (_0x135350) {
                        var _0x3ddc4f = _0x2c0d54;
                        this[_0x3ddc4f('0x24d')] == null && (this[_0x3ddc4f('0x2b0')] = _0x135350,
                            this[_0x3ddc4f('0x24d')] = _0x4ed425[_0x3ddc4f('0x3b6')][_0x3ddc4f('0x51')][_0x3ddc4f('0x36d')](_0x135350),
                            this['AddToStage'](this[_0x3ddc4f('0x24d')]),
                            this[_0x3ddc4f('0x24d')][_0x3ddc4f('0x398')][_0x3ddc4f('0x416')] = !![],
                            this['_eff'][_0x3ddc4f('0xb6')]['localRotationEulerX'] = -0x5a,
                            _0x135350 == _0x3ddc4f('0x2b4') ? this[_0x3ddc4f('0x24d')][_0x3ddc4f('0xb6')][_0x3ddc4f('0x45b')] = new Laya[(_0x3ddc4f('0x592'))](0x0, 0x0, 0x1) : this['_eff'][_0x3ddc4f('0xb6')][_0x3ddc4f('0x45b')] = new Laya['Vector3'](0x0, 3.5, 0x0));
                    }
                    ,
                    _0xe414a2[_0x2c0d54('0x64a')]['ChangeScore'] = function (_0x5364de, _0x19b516) {
                        var _0x3e78a4 = _0x2c0d54
                            , _0x40e1d4 = this['_numberMaterial'][_0x5364de];
                        _0x19b516 == !![] ? (_0x4ed425[_0x3e78a4('0x3b6')]['EventMgr']['event'](_0x211d5d['EventEnum'][_0x3e78a4('0x5f2')], _0x5364de),
                            _0x5364de > 0x0 && _0x4ed425[_0x3e78a4('0x3b6')]['EventMgr']['event'](_0x211d5d[_0x3e78a4('0x4c3')][_0x3e78a4('0x1a1')], _0xd48abc[_0x3e78a4('0x3b6')][_0x3e78a4('0x139')](0x1, 0x2))) : _0x5364de > 0x0 && _0x4ed425[_0x3e78a4('0x3b6')][_0x3e78a4('0x370')][_0x3e78a4('0x393')](_0x211d5d[_0x3e78a4('0x4c3')][_0x3e78a4('0x1a1')], _0xd48abc[_0x3e78a4('0x3b6')][_0x3e78a4('0x139')](0x3, 0x7));
                        if (_0x40e1d4 == null)
                            return;
                        _0x19b516 == !![] ? this[_0x3e78a4('0x399')][_0x3e78a4('0x5e7')][_0x3e78a4('0x598')] = _0x40e1d4 : this[_0x3e78a4('0x334')][_0x3e78a4('0x5e7')]['material'] = _0x40e1d4;
                    }
                    ,
                    _0xe414a2;
            }();
        _0x428c22[_0x1412b4('0x3b6')] = _0xa82ba7;
    }
        , {
        '../XGame': 0x4,
        '../controller/CameraController': 0x6,
        '../entity/Ball': 0x9,
        '../enum/EventEnum': 0xe,
        '../enum/GameEnum': 0x10,
        '../enum/MaskEnum': 0x11,
        '../enum/ResEnum': 0x12,
        '../utils/Tools': 0x37
    }],
    0x1b: [function (_0x1c1dc8, _0x453e59, _0x44cfff) {
        var _0x232c60 = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x44cfff, '__esModule', {
            'value': !![]
        });
        var _0x719991 = _0x1c1dc8(_0x232c60('0x1b2'))
            , _0x1bb366 = function () {
                var _0x37c60f = _0x232c60;
                function _0x2aeb86() {
                    var _0x55121a = _0x5985;
                    this[_0x55121a('0x6bb')] = _0x55121a('0x6bb'),
                        this['isStoped'] = ![],
                        this[_0x55121a('0x231')] = !![];
                    var _0x575041 = window[_0x55121a('0x189')][_0x55121a('0x193')](this[_0x55121a('0x6bb')]);
                    _0x575041 && (this[_0x55121a('0x231')] = _0x575041 == '1');
                }
                return Object['defineProperty'](_0x2aeb86[_0x37c60f('0x64a')], _0x37c60f('0x455'), {
                    'get': function () {
                        return this['_isOpenVoice'];
                    },
                    'set': function (_0x3d9b17) {
                        var _0x5592b2 = _0x37c60f;
                        this[_0x5592b2('0x231')] = _0x3d9b17,
                            _0x3d9b17 ? this[_0x5592b2('0x518')]() : this[_0x5592b2('0x65a')](),
                            window['localStorage'][_0x5592b2('0x5ee')](this[_0x5592b2('0x6bb')], _0x3d9b17 ? '1' : '0');
                    },
                    'enumerable': !![],
                    'configurable': !![]
                }),
                    _0x2aeb86['prototype'][_0x37c60f('0x40e')] = function () {
                        var _0x558b9e = _0x37c60f;
                        Laya[_0x558b9e('0x31a')][_0x558b9e('0x478')] = !![];
                    }
                    ,
                    _0x2aeb86[_0x37c60f('0x64a')]['playBGM'] = function () {
                        if (this['isOpenVoice']) { }
                    }
                    ,
                    _0x2aeb86[_0x37c60f('0x64a')][_0x37c60f('0x65a')] = function () { }
                    ,
                    _0x2aeb86[_0x37c60f('0x64a')]['playBtnClick'] = function () {
                        var _0x3dd05b = _0x37c60f;
                        this['isOpenVoice'] && this['playSound'](_0x719991[_0x3dd05b('0x4a8')]['BtnClick']);
                    }
                    ,
                    _0x2aeb86[_0x37c60f('0x64a')][_0x37c60f('0x385')] = function (_0x5e2f8a) {
                        var _0xdc23aa = _0x37c60f;
                        this[_0xdc23aa('0x455')] && Laya[_0xdc23aa('0x31a')][_0xdc23aa('0x385')](_0x5e2f8a);
                    }
                    ,
                    _0x2aeb86[_0x37c60f('0x64a')][_0x37c60f('0x308')] = function (_0x3a1500) {
                        var _0x3c4e2e = _0x37c60f;
                        Laya[_0x3c4e2e('0x31a')]['setSoundVolume'](_0x3a1500);
                    }
                    ,
                    _0x2aeb86[_0x37c60f('0x64a')][_0x37c60f('0x29c')] = function (_0x147bde) {
                        var _0x2c6d83 = _0x37c60f;
                        Laya['SoundManager'][_0x2c6d83('0x29c')](_0x147bde);
                    }
                    ,
                    _0x2aeb86;
            }();
        _0x44cfff[_0x232c60('0x3b6')] = _0x1bb366;
    }
        , {
        '../enum/ResEnum': 0x12
    }],
    0x1c: [function (_0x58a153, _0x1133b5, _0x5ae0e4) {
        var _0xb36a9 = _0x4b7fcf;
        'use strict';
        Object[_0xb36a9('0x351')](_0x5ae0e4, _0xb36a9('0xb8'), {
            'value': !![]
        });
        var _0x3417e0 = _0x58a153(_0xb36a9('0x167'))
            , _0x44e70a = function () {
                var _0x266350 = _0xb36a9;
                function _0x598b90() {
                    var _0x4b7678 = _0x5985;
                    this[_0x4b7678('0x4a5')] = 0x0,
                        this[_0x4b7678('0x405')] = 0x0;
                }
                return _0x598b90[_0x266350('0x64a')][_0x266350('0x32d')] = function () { }
                    ,
                    _0x598b90[_0x266350('0x64a')][_0x266350('0x7e')] = function () {
                        var _0x5c7c6d = _0x266350
                            , _0x12232f = _0x3417e0['default'][_0x5c7c6d('0x678')][_0x5c7c6d('0x531')]()
                            , _0x3553d0 = _0x3417e0[_0x5c7c6d('0x3b6')][_0x5c7c6d('0x678')][_0x5c7c6d('0x63a')]()
                            , _0x4f5e06 = _0x3417e0[_0x5c7c6d('0x3b6')][_0x5c7c6d('0x4ce')][_0x5c7c6d('0xeb')]('TimeBox')
                            , _0x3e2fa1 = _0x4f5e06['split']('|')
                            , _0x534c68 = _0x3e2fa1[_0x12232f][_0x5c7c6d('0x1f8')](',');
                        this['_timeBoxEndTime'] = Number(_0x534c68[0x0]),
                            this['timeBoxTime'] = this['_timeBoxEndTime'] - _0x3553d0,
                            Laya['timer']['loop'](0x3e8, this, this[_0x5c7c6d('0x4b2')]);
                    }
                    ,
                    _0x598b90[_0x266350('0x64a')]['updateTimeBox'] = function () {
                        var _0x48f565 = _0x266350;
                        _0x3417e0[_0x48f565('0x3b6')][_0x48f565('0x678')][_0x48f565('0x21f')](Math['abs'](this['timeBoxTime'] - this[_0x48f565('0x405')])),
                            this['timeBoxTime'] <= 0x0 && (this['timeBoxTime'] = 0x0,
                                Laya['timer'][_0x48f565('0x466')](this, this[_0x48f565('0x4b2')])),
                            this[_0x48f565('0x4a5')]--;
                    }
                    ,
                    _0x598b90;
            }();
        _0x5ae0e4['default'] = _0x44e70a;
    }
        , {
        '../XGame': 0x4
    }],
    0x1d: [function (_0x5099ec, _0x193580, _0x34d5bc) {
        var _0x26e214 = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x34d5bc, _0x26e214('0xb8'), {
            'value': !![]
        });
        var _0x5e8b30 = _0x5099ec(_0x26e214('0x1b'))
            , _0x4979b3 = function () {
                var _0x2384e1 = _0x26e214;
                function _0x21eb4e() {
                    var _0xe40fc0 = _0x5985;
                    this[_0xe40fc0('0x223')] = 0x3e8,
                        this['_tipsZOrder'] = 0x186a0,
                        this['_uiArray'] = [],
                        this[_0xe40fc0('0x17')] = !![];
                }
                return _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x280')] = function (_0x33c4c3, _0x409234) {
                    var _0x1e7ef5 = _0x2384e1;
                    _0x409234 === void 0x0 && (_0x409234 = null);
                    if (_0x33c4c3 == undefined || _0x33c4c3 == null)
                        return;
                    for (var _0x204753 = this[_0x1e7ef5('0x365')][_0x1e7ef5('0x4cc')] - 0x1; _0x204753 >= 0x0; _0x204753--) {
                        var _0x53eb7d = this['_uiArray'][_0x204753];
                        this[_0x1e7ef5('0x13c')](_0x53eb7d, null);
                    }
                    this[_0x1e7ef5('0x365')][_0x1e7ef5('0x4cc')] = 0x0,
                        this[_0x1e7ef5('0x62d')](_0x33c4c3, _0x409234, !![]);
                }
                    ,
                    _0x21eb4e['prototype'][_0x2384e1('0x29a')] = function (_0x2547e8, _0x2f87b3) {
                        var _0x57ff44 = _0x2384e1;
                        _0x2f87b3 === void 0x0 && (_0x2f87b3 = null);
                        if (_0x2547e8 == undefined || _0x2547e8 == null)
                            return;
                        var _0x1a2b90;
                        for (var _0x454720 = this[_0x57ff44('0x365')]['length'] - 0x1; _0x454720 >= 0x0; _0x454720--) {
                            _0x1a2b90 = this['_uiArray'][_0x454720];
                            if (_0x1a2b90['uiconfig'] == _0x2547e8) {
                                this[_0x57ff44('0x13c')](_0x1a2b90, _0x2f87b3),
                                    this[_0x57ff44('0x365')][_0x57ff44('0x6ba')](_0x454720, 0x1);
                                break;
                            }
                        }
                        this[_0x57ff44('0x433')](_0x1a2b90, ![]);
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x62d')] = function (_0x1cde61, _0x2202e5, _0x11fa64) {
                        var _0x37e33f = _0x2384e1;
                        _0x2202e5 === void 0x0 && (_0x2202e5 = null);
                        _0x11fa64 === void 0x0 && (_0x11fa64 = !![]);
                        if (_0x1cde61 == undefined || _0x1cde61 == null)
                            return;
                        _0x1cde61['res'] && _0x1cde61[_0x37e33f('0x42f')][_0x37e33f('0x4cc')] > 0x0 ? Laya[_0x37e33f('0x5e')][_0x37e33f('0x297')](_0x1cde61[_0x37e33f('0x42f')], Laya[_0x37e33f('0x49f')][_0x37e33f('0x5fb')](this, function () {
                            this['createUI'](_0x1cde61, _0x2202e5, _0x11fa64);
                        })) : this[_0x37e33f('0x348')](_0x1cde61, _0x2202e5, _0x11fa64);
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x309')] = function (_0x3a6581, _0x59ccd9, _0x2e5e04) {
                        var _0x1abde8 = _0x2384e1;
                        _0x59ccd9 === void 0x0 && (_0x59ccd9 = null);
                        _0x2e5e04 === void 0x0 && (_0x2e5e04 = !![]);
                        if (_0x3a6581 == undefined || _0x3a6581 == null)
                            return;
                        var _0x2e0e53 = this[_0x1abde8('0x2eb')](_0x3a6581);
                        if (_0x2e0e53) {
                            _0x59ccd9 != null && _0x2e0e53[_0x1abde8('0x3ea')](_0x59ccd9);
                            _0x2e0e53['visible'] = _0x2e5e04;
                            return;
                        }
                        this[_0x1abde8('0x62d')](_0x3a6581, _0x59ccd9, _0x2e5e04);
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x348')] = function (_0xa1b4d, _0xf8659d, _0x1667f4) {
                        var _0x2de6c1 = _0x2384e1;
                        _0xf8659d === void 0x0 && (_0xf8659d = null);
                        _0x1667f4 === void 0x0 && (_0x1667f4 = !![]);
                        if (_0xa1b4d == undefined || _0xa1b4d == null)
                            return;
                        var _0x4a7015 = Laya[_0x2de6c1('0x59d')][_0x2de6c1('0x538')](_0xa1b4d[_0x2de6c1('0x445')]);
                        if (_0x4a7015 == null) {
                            console['error'](_0x2de6c1('0xb5'), _0xa1b4d);
                            return;
                        }
                        var _0x40015b = new _0x4a7015(_0xa1b4d);
                        _0x40015b[_0x2de6c1('0x238')] = _0xa1b4d,
                            _0xf8659d != null && _0x40015b['updateData'](_0xf8659d),
                            _0x40015b[_0x2de6c1('0x389')] = this[_0x2de6c1('0x223')]++,
                            _0x40015b[_0x2de6c1('0x5bf')] = _0x1667f4,
                            Laya[_0x2de6c1('0x150')][_0x2de6c1('0x5')](_0x40015b),
                            this[_0x2de6c1('0x365')][_0x2de6c1('0xff')](_0x40015b),
                            _0x40015b['visible'] && (this[_0x2de6c1('0x433')](_0x40015b, !![]),
                                _0xa1b4d[_0x2de6c1('0x1a4')] && (Laya['Tween'][_0x2de6c1('0x3fa')](_0x40015b, {
                                    'scaleX': 0.8,
                                    'scaleY': 0.8
                                }, 0xc8, Laya[_0x2de6c1('0x2a3')]['backOut']),
                                    _0x40015b[_0x2de6c1('0x507')] = _0xa1b4d[_0x2de6c1('0x1a4')]));
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')]['onUIClose'] = function (_0x2c9815, _0x30ac84) {
                        var _0x2c8cb0 = _0x2384e1;
                        if (_0x2c9815['uitween'])
                            Laya[_0x2c8cb0('0x34d')]['to'](_0x2c9815, {
                                'scaleX': 0.8,
                                'scaleY': 0.8
                            }, 0xc8, Laya['Ease'][_0x2c8cb0('0x41e')], Laya[_0x2c8cb0('0x49f')][_0x2c8cb0('0x5fb')](this, function () {
                                this['destroyUI'](_0x2c9815);
                                if (_0x30ac84)
                                    _0x30ac84['method']();
                            }));
                        else {
                            this[_0x2c8cb0('0x563')](_0x2c9815);
                            if (_0x30ac84)
                                _0x30ac84['method']();
                        }
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x563')] = function (_0x152720) {
                        var _0x29b30c = _0x2384e1;
                        this['checkBanner'](_0x152720, ![]);
                        if (_0x152720[_0x29b30c('0xd8')]) {
                            var _0x1bb3f9 = void 0x0;
                            for (var _0x241118 = 0x0; _0x241118 < _0x152720[_0x29b30c('0xd8')]['length']; _0x241118++) {
                                _0x1bb3f9 = _0x152720['_aniList'][_0x241118],
                                    _0x1bb3f9 && _0x1bb3f9[_0x29b30c('0x466')] && _0x1bb3f9[_0x29b30c('0x466')]();
                            }
                        }
                        Laya[_0x29b30c('0x5ac')][_0x29b30c('0x1fb')](_0x152720),
                            Laya[_0x29b30c('0x150')][_0x29b30c('0x26c')](_0x152720),
                            _0x152720[_0x29b30c('0x42')](),
                            _0x152720['destroy']();
                    }
                    ,
                    _0x21eb4e['prototype'][_0x2384e1('0x2eb')] = function (_0x19ba5a) {
                        var _0x1b1a67 = _0x2384e1;
                        if (_0x19ba5a == undefined || _0x19ba5a == null)
                            return;
                        for (var _0x27961e = this[_0x1b1a67('0x365')][_0x1b1a67('0x4cc')] - 0x1; _0x27961e >= 0x0; _0x27961e--) {
                            var _0x3fca97 = this[_0x1b1a67('0x365')][_0x27961e];
                            if (_0x3fca97['uiconfig'] == _0x19ba5a)
                                return _0x3fca97;
                        }
                        return null;
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x279')] = function (_0x1fd963, _0x30791b) {
                        var _0x5a0386 = _0x2384e1;
                        if (_0x1fd963 == undefined || _0x1fd963 == null)
                            return;
                        var _0x546c71 = this[_0x5a0386('0x2eb')](_0x1fd963);
                        _0x546c71 && (_0x546c71[_0x5a0386('0x5bf')] = _0x30791b,
                            _0x30791b && (_0x546c71[_0x5a0386('0x389')] = this[_0x5a0386('0x223')]++),
                            this['checkBanner'](_0x546c71, _0x30791b));
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')]['setTop'] = function (_0x2fae2f) {
                        var _0x1be965 = _0x2384e1;
                        if (_0x2fae2f == undefined || _0x2fae2f == null)
                            return;
                        var _0x5b662d = this[_0x1be965('0x2eb')](_0x2fae2f);
                        _0x5b662d && (_0x5b662d[_0x1be965('0x389')] = this[_0x1be965('0x223')]++);
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x46e')] = function (_0x59c993) {
                        var _0x1957c4 = _0x2384e1, _0x3bcd61 = this['_arrTips'], _0x4685c6;
                        if (_0x3bcd61 == null) {
                            _0x3bcd61 = [];
                            var _0xd4f1ef = new Laya[(_0x1957c4('0x6ae'))]();
                            Laya['stage'][_0x1957c4('0x5')](_0xd4f1ef),
                                _0xd4f1ef[_0x1957c4('0x389')] = this['_tipsZOrder'];
                            for (var _0x19e43f = 0x0; _0x19e43f < 0x3; _0x19e43f++) {
                                var _0x2be8db = new Laya['Box']();
                                _0x2be8db[_0x1957c4('0x552')] = _0x2be8db['anchorY'] = 0.5,
                                    _0x2be8db[_0x1957c4('0x2f4')] = 0x0;
                                var _0x57072f = new Laya[(_0x1957c4('0x55c'))](_0x1957c4('0x423'));
                                _0x2be8db[_0x1957c4('0x5')](_0x57072f),
                                    _0x57072f[_0x1957c4('0x1d2')] = 0x320,
                                    _0x57072f[_0x1957c4('0x33c')] = 0x50,
                                    _0x4685c6 = new Laya[(_0x1957c4('0x141'))](),
                                    _0x2be8db[_0x1957c4('0x5')](_0x4685c6),
                                    _0x4685c6[_0x1957c4('0xc9')] = 0x24,
                                    _0x4685c6[_0x1957c4('0x3')] = _0x1957c4('0x111'),
                                    _0x4685c6[_0x1957c4('0x1d2')] = 0x320,
                                    _0x4685c6[_0x1957c4('0x33c')] = 0x32,
                                    _0x4685c6['y'] = 0xf,
                                    _0x4685c6[_0x1957c4('0x73')] = _0x1957c4('0x59f'),
                                    _0x4685c6['valign'] = _0x1957c4('0x46b'),
                                    _0x4685c6[_0x1957c4('0x2f4')] = 0x0,
                                    _0x3bcd61['push'](_0x4685c6),
                                    _0xd4f1ef[_0x1957c4('0x5')](_0x2be8db),
                                    _0x2be8db[_0x1957c4('0x5bf')] = ![];
                            }
                            this[_0x1957c4('0x575')] = _0x3bcd61,
                                _0xd4f1ef[_0x1957c4('0x1d2')] = 0x258,
                                _0xd4f1ef[_0x1957c4('0x2f4')] = 0x0,
                                _0xd4f1ef[_0x1957c4('0x627')] = -0x64;
                        }
                        if (_0x3bcd61[_0x1957c4('0x4cc')] == 0x0)
                            return;
                        _0x4685c6 = _0x3bcd61[_0x1957c4('0x284')](),
                            _0x4685c6[_0x1957c4('0x338')] = _0x59c993;
                        var _0x5e926e = 0x7d0;
                        _0x4685c6[_0x1957c4('0x3')] = _0x1957c4('0x111');
                        var _0xb6b39d = _0x4685c6[_0x1957c4('0x234')];
                        _0xb6b39d[_0x1957c4('0x5bf')] = !![],
                            _0xb6b39d[_0x1957c4('0x1b9')](0.8, 0.8),
                            _0xb6b39d['alpha'] = 0x1,
                            Laya[_0x1957c4('0x34d')]['to'](_0xb6b39d, {
                                'scaleX': 0x1,
                                'scaleY': 0x1
                            }, 0xc8, Laya[_0x1957c4('0x2a3')][_0x1957c4('0x3c3')], Laya[_0x1957c4('0x49f')][_0x1957c4('0x5fb')](this, function (_0x2fd8e6) {
                                var _0x584a7c = _0x1957c4;
                                Laya[_0x584a7c('0x5ac')]['once'](_0x5e926e - 0x258, this, function () {
                                    var _0x16808c = _0x584a7c;
                                    Laya['Tween']['to'](_0xb6b39d, {
                                        'alpha': 0x0
                                    }, 0x190, null, Laya[_0x16808c('0x49f')][_0x16808c('0x5fb')](this, function () {
                                        var _0x481a3d = _0x16808c;
                                        _0x2fd8e6[_0x481a3d('0x234')][_0x481a3d('0x5bf')] = ![],
                                            _0x3bcd61[_0x481a3d('0xff')](_0x2fd8e6);
                                    }));
                                });
                            }, [_0x4685c6]));
                    }
                    ,
                    _0x21eb4e[_0x2384e1('0x64a')][_0x2384e1('0x433')] = function (_0x56491b, _0x47f056) {
                        var _0xf58a9e = _0x2384e1;
                        if (_0x56491b == null || _0x56491b == undefined || _0x56491b[_0xf58a9e('0x238')] == undefined || _0x56491b[_0xf58a9e('0x238')] == null)
                            return;
                        _0x47f056 ? _0x56491b[_0xf58a9e('0x238')][_0xf58a9e('0x63c')] != null ? window[_0xf58a9e('0x50d')][_0xf58a9e('0x5d8')]() : window[_0xf58a9e('0x50d')][_0xf58a9e('0x289')]() : window[_0xf58a9e('0x50d')]['closeBannerAd']();
                    }
                    ,
                    _0x21eb4e['prototype'][_0x2384e1('0x287')] = function (_0x139669) {
                        var _0x4a1f6a = _0x2384e1;
                        console[_0x4a1f6a('0x5df')]('返回的错误码是：' + _0x139669, this['_bannerFlag']);
                        if (_0x139669 == 0x0)
                            _0x5e8b30[_0x4a1f6a('0x3b6')][_0x4a1f6a('0x574')](this[_0x4a1f6a('0x17')]);
                        else {
                            if (_0x139669 == 0x3eb || _0x139669 == 0x3e8) { }
                        }
                    }
                    ,
                    _0x21eb4e;
            }();
        _0x34d5bc[_0x26e214('0x3b6')] = _0x4979b3;
    }
        , {
        '../Platform': 0x3
    }],
    0x1e: [function (_0x2d6e05, _0x5b705d, _0x1aba9f) {
        var _0x5ce06b = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x1aba9f, _0x5ce06b('0xb8'), {
            'value': !![]
        });
        var _0x1d2d4a = _0x2d6e05(_0x5ce06b('0x291'))
            , _0x43d45a = _0x2d6e05(_0x5ce06b('0x167'))
            , _0x2ebebc = _0x2d6e05(_0x5ce06b('0x5e2'))
            , _0x42a283 = function (_0x5a6113) {
                var _0x109e9c = _0x5ce06b;
                __extends(_0x38b64a, _0x5a6113);
                function _0x38b64a() {
                    var _0xb852eb = _0x5985
                        , _0x64ea67 = _0x5a6113[_0xb852eb('0x324')](this) || this;
                    return _0x64ea67[_0xb852eb('0x517')] = -0x1,
                        _0x64ea67[_0xb852eb('0x4c6')] = 0x0,
                        _0x64ea67[_0xb852eb('0xd2')] = 0x0,
                        _0x64ea67['_initX'] = 0x0,
                        _0x64ea67['_startIndex'] = 0x0,
                        _0x64ea67[_0xb852eb('0x51e')] = ![],
                        _0x64ea67;
                }
                return _0x38b64a[_0x109e9c('0x64a')]['onEnable'] = function () {
                    var _0x55ab92 = _0x109e9c;
                    this[_0x55ab92('0x47f')] = this['owner'];
                }
                    ,
                    _0x38b64a['prototype']['addEvent'] = function (_0x519816) {
                        var _0x1d7b12 = _0x109e9c;
                        _0x519816 === void 0x0 && (_0x519816 = !![]),
                            this[_0x1d7b12('0x604')] = _0x519816,
                            _0x519816 ? (this['dragBox']['on'](Laya[_0x1d7b12('0x68f')][_0x1d7b12('0x237')], this, this[_0x1d7b12('0x5c6')]),
                                this['dragBox']['on'](Laya[_0x1d7b12('0x68f')][_0x1d7b12('0x36b')], this, this['onMouseUpHandle']),
                                this['dragBox']['on'](Laya[_0x1d7b12('0x68f')][_0x1d7b12('0x611')], this, this['onMouseMoveHandle'])) : (this[_0x1d7b12('0x47f')]['on'](Laya[_0x1d7b12('0x68f')][_0x1d7b12('0x237')], this, this['onMouseDownHandle']),
                                    this['gameObject']['on'](Laya[_0x1d7b12('0x68f')]['MOUSE_UP'], this, this[_0x1d7b12('0x307')]),
                                    this[_0x1d7b12('0x47f')]['on'](Laya[_0x1d7b12('0x68f')][_0x1d7b12('0x611')], this, this[_0x1d7b12('0xe3')]));
                    }
                    ,
                    _0x38b64a[_0x109e9c('0x64a')][_0x109e9c('0x40e')] = function (_0x5375a2) {
                        var _0x2ee50a = _0x109e9c;
                        this[_0x2ee50a('0x4c6')] = _0x5375a2[_0x2ee50a('0x5fa')],
                            this[_0x2ee50a('0xd2')] = _0x5375a2[_0x2ee50a('0x4a3')],
                            this['_startIndex'] = _0x5375a2[_0x2ee50a('0x638')],
                            this[_0x2ee50a('0x100')] = _0x5375a2[_0x2ee50a('0x3ad')] - 0x1,
                            this[_0x2ee50a('0x517')] = _0x5375a2['curIndex'],
                            this[_0x2ee50a('0x6e')] = _0x5375a2[_0x2ee50a('0x6e')],
                            this[_0x2ee50a('0x70')] = _0x5375a2['dragSkinBox'],
                            this['bouceBack'](![]);
                    }
                    ,
                    _0x38b64a[_0x109e9c('0x64a')][_0x109e9c('0x5c6')] = function () {
                        var _0x570c47 = _0x109e9c;
                        this['downFlag'] = !![],
                            this[_0x570c47('0x482')] = Laya[_0x570c47('0x150')][_0x570c47('0x40c')],
                            this[_0x570c47('0x661')] = this['_firstX'];
                    }
                    ,
                    _0x38b64a[_0x109e9c('0x64a')][_0x109e9c('0xe3')] = function () {
                        var _0x3817f7 = _0x109e9c;
                        this[_0x3817f7('0x2ea')] && (this[_0x3817f7('0x6c')] = Laya[_0x3817f7('0x150')][_0x3817f7('0x40c')] - this[_0x3817f7('0x482')],
                            this[_0x3817f7('0x53d')](this[_0x3817f7('0x6c')]),
                            this[_0x3817f7('0x482')] = Laya[_0x3817f7('0x150')][_0x3817f7('0x40c')]);
                    }
                    ,
                    _0x38b64a[_0x109e9c('0x64a')][_0x109e9c('0x307')] = function () {
                        var _0x1eae8f = _0x109e9c;
                        if (this[_0x1eae8f('0x482')] - this[_0x1eae8f('0x661')] > 0x1)
                            this[_0x1eae8f('0x517')]--,
                                this['dragFlag'] = !![];
                        else
                            this[_0x1eae8f('0x482')] - this[_0x1eae8f('0x661')] < -0x1 ? (this[_0x1eae8f('0x51e')] = !![],
                                this['_newIndex']++) : this[_0x1eae8f('0x51e')] = ![];
                        this['_newIndex'] = _0x1d2d4a['default'][_0x1eae8f('0x655')](this[_0x1eae8f('0x517')], this[_0x1eae8f('0x276')], this['_maxIndex']),
                            this[_0x1eae8f('0x419')](),
                            this[_0x1eae8f('0x2ea')] = ![];
                    }
                    ,
                    _0x38b64a[_0x109e9c('0x64a')][_0x109e9c('0x53d')] = function (_0x47cf1d) {
                        var _0x12b316 = _0x109e9c;
                        this[_0x12b316('0x47f')]['x'] += _0x47cf1d;
                    }
                    ,
                    _0x38b64a['prototype'][_0x109e9c('0x419')] = function (_0x54bbef) {
                        var _0x64d74b = _0x109e9c;
                        _0x54bbef === void 0x0 && (_0x54bbef = !![]),
                            _0x54bbef ? Laya[_0x64d74b('0x34d')]['to'](this[_0x64d74b('0x47f')], {
                                'x': this[_0x64d74b('0xd2')] + this[_0x64d74b('0x517')] * this[_0x64d74b('0x4c6')] * -0x1
                            }, 0x64) : this[_0x64d74b('0x47f')]['x'] = this[_0x64d74b('0xd2')] + this[_0x64d74b('0x517')] * this[_0x64d74b('0x4c6')] * -0x1,
                            _0x43d45a['default']['EventMgr'][_0x64d74b('0x393')](_0x2ebebc[_0x64d74b('0x4c3')]['Switch_Page'], [this[_0x64d74b('0x517')], this[_0x64d74b('0x51e')]]);
                    }
                    ,
                    _0x38b64a[_0x109e9c('0x64a')][_0x109e9c('0x39d')] = function () {
                        var _0x7be9c8 = _0x109e9c;
                        this[_0x7be9c8('0x604')] ? (this[_0x7be9c8('0x6e')][_0x7be9c8('0x585')](Laya['Event'][_0x7be9c8('0x237')], this, this[_0x7be9c8('0x5c6')]),
                            this['dragBox'][_0x7be9c8('0x585')](Laya['Event'][_0x7be9c8('0x36b')], this, this[_0x7be9c8('0x307')]),
                            this[_0x7be9c8('0x6e')]['off'](Laya[_0x7be9c8('0x68f')][_0x7be9c8('0x611')], this, this[_0x7be9c8('0xe3')])) : (this['gameObject'][_0x7be9c8('0x585')](Laya['Event'][_0x7be9c8('0x237')], this, this[_0x7be9c8('0x5c6')]),
                                this['gameObject']['off'](Laya[_0x7be9c8('0x68f')][_0x7be9c8('0x36b')], this, this['onMouseUpHandle']),
                                this[_0x7be9c8('0x47f')][_0x7be9c8('0x585')](Laya[_0x7be9c8('0x68f')][_0x7be9c8('0x611')], this, this[_0x7be9c8('0xe3')]));
                    }
                    ,
                    _0x38b64a;
            }(Laya[_0x5ce06b('0x23f')]);
        _0x1aba9f[_0x5ce06b('0x3b6')] = _0x42a283;
    }
        , {
        '../XGame': 0x4,
        '../enum/EventEnum': 0xe,
        '../utils/Tools': 0x37
    }],
    0x1f: [function (_0x56b7f9, _0x2a7e8b, _0x30f4ea) {
        var _0x476ea0 = _0x4b7fcf;
        'use strict';
        Object[_0x476ea0('0x351')](_0x30f4ea, _0x476ea0('0xb8'), {
            'value': !![]
        });
        var _0x3b9cd4 = _0x56b7f9('../../ui/layaMaxUI')
            , _0x14b71f = _0x56b7f9(_0x476ea0('0xce'))
            , _0x4c0ee1 = _0x56b7f9(_0x476ea0('0x69c'))
            , _0x144f67 = _0x56b7f9(_0x476ea0('0x20c'))
            , _0x154c68 = _0x56b7f9(_0x476ea0('0x46'))
            , _0x15b7be = function (_0x31f980) {
                var _0x17488d = _0x476ea0;
                __extends(_0x1a8d44, _0x31f980);
                function _0x1a8d44(_0x4ea74d) {
                    var _0x23177c = _0x5985
                        , _0xdedf7e = _0x31f980[_0x23177c('0x324')](this) || this;
                    return _0x4ea74d[_0x23177c('0x123')] = _0x14b71f['default'][_0x23177c('0x4ce')][_0x23177c('0x66c')](0x7),
                        _0xdedf7e;
                }
                return _0x1a8d44[_0x17488d('0x64a')][_0x17488d('0x4fc')] = function () {
                    var _0x219ad1 = _0x17488d;
                    this[_0x219ad1('0x56c')]['text'] = _0x14b71f[_0x219ad1('0x3b6')][_0x219ad1('0x4ce')]['getLangById'](0x16, _0x154c68[_0x219ad1('0x1d1')][_0x219ad1('0x64d')]),
                        this['collectKeysTxt'][_0x219ad1('0x338')] = _0x14b71f[_0x219ad1('0x3b6')]['CfgMgr'][_0x219ad1('0x235')](0x1e, _0x154c68[_0x219ad1('0x1d1')][_0x219ad1('0x64d')]),
                        this[_0x219ad1('0x1d5')]();
                }
                    ,
                    _0x1a8d44['prototype'][_0x17488d('0x1d5')] = function () {
                        var _0x2682f9 = _0x17488d;
                        this[_0x2682f9('0x55')](0x1, this, this[_0x2682f9('0x573')]),
                            Laya['Tween'][_0x2682f9('0x3fa')](this[_0x2682f9('0x2ad')], {
                                'scaleX': 1.5,
                                'scaleY': 1.5
                            }, 0x1f4, Laya['Ease']['elasticInOut']),
                            this[_0x2682f9('0x51a')](this[_0x2682f9('0x50c')], this[_0x2682f9('0x4e8')]),
                            _0x144f67['default'][_0x2682f9('0x72')](this, this[_0x2682f9('0x50c')], Laya[_0x2682f9('0x150')][_0x2682f9('0x15e')] - 0xdc, 0x366);
                    }
                    ,
                    _0x1a8d44['prototype'][_0x17488d('0x4e8')] = function () {
                        var _0x30592f = _0x17488d;
                        _0x14b71f[_0x30592f('0x3b6')][_0x30592f('0x5d7')][_0x30592f('0x280')](_0x4c0ee1[_0x30592f('0x339')][_0x30592f('0x18d')]);
                    }
                    ,
                    _0x1a8d44[_0x17488d('0x64a')][_0x17488d('0x573')] = function () {
                        var _0x2232da = _0x17488d;
                        this[_0x2232da('0x65e')]['rotation'] += 0x1;
                    }
                    ,
                    _0x1a8d44[_0x17488d('0x64a')][_0x17488d('0x42')] = function () {
                        var _0x543df2 = _0x17488d;
                        this['clearTimer'](this, this[_0x543df2('0x573')]),
                            _0x31f980['prototype'][_0x543df2('0x42')][_0x543df2('0x324')](this);
                    }
                    ,
                    _0x1a8d44;
            }(_0x3b9cd4['ui']['view'][_0x476ea0('0x5f7')]);
        _0x30f4ea[_0x476ea0('0x3b6')] = _0x15b7be;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37
    }],
    0x20: [function (_0x208e8b, _0x5199b2, _0x2e4760) {
        var _0xfbe396 = _0x4b7fcf;
        'use strict';
        Object[_0xfbe396('0x351')](_0x2e4760, '__esModule', {
            'value': !![]
        });
        var _0x526093 = _0x208e8b(_0xfbe396('0x662'))
            , _0xd152ee = _0x208e8b(_0xfbe396('0xce'))
            , _0x1bd1fe = _0x208e8b(_0xfbe396('0x20c'))
            , _0x126080 = _0x208e8b('../../Platform')
            , _0x17cd94 = _0x208e8b('../../enum/UIEnum')
            , _0x32c604 = _0x208e8b(_0xfbe396('0x34f'))
            , _0x5f2af7 = _0x208e8b(_0xfbe396('0x46'))
            , _0x5b435e = _0x208e8b('./item/AdItem')
            , _0x5452e5 = _0x208e8b('../../utils/Utils')
            , _0x4da1c2 = _0x208e8b('../../enum/EventEnum')
            , _0x33046a = function (_0x450b89) {
                var _0x59173f = _0xfbe396;
                __extends(_0x5b30d9, _0x450b89);
                function _0x5b30d9(_0x460408) {
                    var _0x277f28 = _0x5985
                        , _0x84be80 = _0x450b89[_0x277f28('0x324')](this) || this;
                    return _0x84be80[_0x277f28('0x236')] = -0x1,
                        _0x84be80['_addCoin'] = 0x0,
                        _0x84be80[_0x277f28('0x3e4')] = [],
                        _0x460408[_0x277f28('0x123')] = _0xd152ee[_0x277f28('0x3b6')][_0x277f28('0x4ce')][_0x277f28('0x66c')](0x9),
                        _0x84be80;
                }
                return _0x5b30d9[_0x59173f('0x64a')]['onAwake'] = function () {
                    var _0x56c38e = _0x59173f;
                    this[_0x56c38e('0x218')](),
                        this[_0x56c38e('0x1d5')](),
                        this[_0x56c38e('0x199')][_0x56c38e('0x338')] = _0x1bd1fe[_0x56c38e('0x3b6')][_0x56c38e('0x456')](_0xd152ee[_0x56c38e('0x3b6')]['DataMgr'][_0x56c38e('0xf')]),
                        Laya[_0x56c38e('0x5ac')]['frameLoop'](0x1, this, this[_0x56c38e('0x6a3')]);
                }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x5dc')] = function () {
                        var _0x176b33 = _0x59173f;
                        Laya['timer'][_0x176b33('0x1fb')](this);
                    }
                    ,
                    _0x5b30d9['prototype']['updateData'] = function (_0x4914b1) {
                        var _0x311f7e = _0x59173f;
                        this[_0x311f7e('0x58c')] = _0x4914b1,
                            this['resultTxt'][_0x311f7e('0x338')] = this[_0x311f7e('0x58c')] ? _0xd152ee[_0x311f7e('0x3b6')][_0x311f7e('0x4ce')][_0x311f7e('0x235')](0x16, _0x5f2af7[_0x311f7e('0x1d1')][_0x311f7e('0x64d')]) : _0xd152ee[_0x311f7e('0x3b6')][_0x311f7e('0x4ce')][_0x311f7e('0x235')](0x18, _0x5f2af7[_0x311f7e('0x1d1')]['Language']),
                            this['txtRevival']['text'] = this[_0x311f7e('0x58c')] ? _0xd152ee[_0x311f7e('0x3b6')][_0x311f7e('0x4ce')]['getLangById'](0x17, _0x5f2af7[_0x311f7e('0x1d1')][_0x311f7e('0x64d')]) : _0xd152ee['default'][_0x311f7e('0x4ce')][_0x311f7e('0x235')](0x19, _0x5f2af7[_0x311f7e('0x1d1')]['Language']),
                            this[_0x311f7e('0x1da')][_0x311f7e('0x5bf')] = this[_0x311f7e('0x58c')],
                            this['imgSkin']['visible'] = !this['_succes'];
                        if (this[_0x311f7e('0x58c')]) {
                            var _0x110bb4 = !![];
                            window[_0x311f7e('0x32c')] && (_0x110bb4 = typeof window[_0x311f7e('0x32c')][_0x311f7e('0x648')] != _0x311f7e('0x51b'));
                            console[_0x311f7e('0x5df')](_0x110bb4, _0x311f7e('0x3ff'));
                            _0x5f2af7[_0x311f7e('0x1d1')][_0x311f7e('0x400')] == _0x5f2af7[_0x311f7e('0x52b')][_0x311f7e('0xd1')] && (this[_0x311f7e('0x5bb')]['x'] = 390.5,
                                this['btnSharekVedio'][_0x311f7e('0x5bf')] = !![]);
                            var _0x25d839 = _0xd152ee[_0x311f7e('0x3b6')]['CfgMgr']['getGlobalCfg'](_0x311f7e('0x41d'))
                                , _0x2c36b3 = _0x1bd1fe['default']['TransferStringToNumberArr'](_0x25d839);
                            this['_addCoin'] = _0x2c36b3[_0x1bd1fe[_0x311f7e('0x3b6')][_0x311f7e('0x139')](0x0, _0x2c36b3[_0x311f7e('0x4cc')] - 0x1)],
                                this['txtAddGem'][_0x311f7e('0x338')] = '+' + this['_addCoin'],
                                _0xd152ee['default']['DataMgr'][_0x311f7e('0x45')](this[_0x311f7e('0x273')]),
                                console['log'](_0x311f7e('0x5f8')),
                                _0x5f2af7[_0x311f7e('0x1d1')]['Platform'] == _0x5f2af7[_0x311f7e('0x52b')][_0x311f7e('0x576')] && _0xd152ee[_0x311f7e('0x3b6')][_0x311f7e('0x678')][_0x311f7e('0x436')] && (this[_0x311f7e('0x5b7')][_0x311f7e('0x5bf')] = !![],
                                    this[_0x311f7e('0x360')]());
                        } else {
                            _0x5f2af7[_0x311f7e('0x1d1')][_0x311f7e('0x400')] == _0x5f2af7[_0x311f7e('0x52b')]['TouTAd'] && (this[_0x311f7e('0x5bb')]['x'] = 0xdd,
                                this[_0x311f7e('0xef')]['visible'] = ![]);
                            var _0x2c36b3 = _0x1bd1fe[_0x311f7e('0x3b6')][_0x311f7e('0x37f')](_0xd152ee['default'][_0x311f7e('0x4ce')][_0x311f7e('0xeb')](_0x311f7e('0x4d7')));
                            this[_0x311f7e('0x236')] = _0x2c36b3[_0x1bd1fe['default'][_0x311f7e('0x139')](0x0, _0x2c36b3['length'] - 0x1)];
                            var _0x10eab7 = _0xd152ee[_0x311f7e('0x3b6')][_0x311f7e('0x4ce')][_0x311f7e('0x3ef')](this[_0x311f7e('0x236')]);
                            this['imgSkin'][_0x311f7e('0x3c4')] = _0x311f7e('0x3a7') + _0x10eab7['ResIcon'] + _0x311f7e('0x99'),
                                console['log'](_0x311f7e('0x3f6')),
                                _0x5f2af7[_0x311f7e('0x1d1')][_0x311f7e('0x400')] == _0x5f2af7[_0x311f7e('0x52b')][_0x311f7e('0x576')] && _0xd152ee[_0x311f7e('0x3b6')]['DataMgr']['isTmAdOpen'] && (this[_0x311f7e('0x645')]['visible'] = !![],
                                    this[_0x311f7e('0x360')]());
                        }
                    }
                    ,
                    _0x5b30d9['prototype']['initView'] = function () {
                        var _0x1d4b30 = _0x59173f;
                        this[_0x1d4b30('0xe1')][_0x1d4b30('0x338')] = _0xd152ee[_0x1d4b30('0x3b6')][_0x1d4b30('0x4ce')][_0x1d4b30('0x235')](0x13, _0x5f2af7[_0x1d4b30('0x1d1')][_0x1d4b30('0x64d')]),
                            this[_0x1d4b30('0xef')]['gray'] = ![],
                            this[_0x1d4b30('0xef')]['mouseEnabled'] = !![],
                            _0x5f2af7[_0x1d4b30('0x1d1')][_0x1d4b30('0x400')] == _0x5f2af7[_0x1d4b30('0x52b')][_0x1d4b30('0x64')] && this[_0x1d4b30('0x6a2')]();
                    }
                    ,
                    _0x5b30d9['prototype'][_0x59173f('0x1d5')] = function () {
                        var _0x38c564 = _0x59173f;
                        this['regClick'](this['btnBack'], this[_0x38c564('0x2f9')]),
                            this['regClick'](this[_0x38c564('0x5bb')], this[_0x38c564('0x565')]),
                            this[_0x38c564('0x51a')](this[_0x38c564('0xef')], this['onClikShareVedio']),
                            _0xd152ee[_0x38c564('0x3b6')][_0x38c564('0x370')]['on'](_0x4da1c2['EventEnum'][_0x38c564('0x4bf')], this, this[_0x38c564('0xa4')]);
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x6a2')] = function () {
                        var _0x156637 = _0x59173f
                            , _0x3d0ea1 = _0xd152ee[_0x156637('0x3b6')][_0x156637('0x678')][_0x156637('0x318')];
                        console[_0x156637('0x5df')]('剩余次数', _0x3d0ea1),
                            _0x3d0ea1 <= 0x0 && (this['btnRevival'][_0x156637('0x4b0')] = !![],
                                this[_0x156637('0x5bb')][_0x156637('0x4b0')] = !![]);
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x2f9')] = function () {
                        var _0x56bbe7 = _0x59173f;
                        logEvent(_0x56bbe7('0x321')),
                            _0xd152ee['default']['UIMgr'][_0x56bbe7('0x280')](_0x17cd94[_0x56bbe7('0x339')]['GameUI']);
                    }
                    ,
                    _0x5b30d9['prototype']['watchTvCallback'] = function (_0xe8c9, _0x135b40, _0x14b983) {
                        var _0x3eff2d = _0x59173f;
                        _0x135b40 === void 0x0 && (_0x135b40 = null);
                        _0x14b983 === void 0x0 && (_0x14b983 = null);
                        if (_0x135b40) {
                            _0xd152ee[_0x3eff2d('0x3b6')][_0x3eff2d('0x5d7')][_0x3eff2d('0x46e')](_0x135b40);
                            return;
                        }
                        if (_0xe8c9) {
                            if (this[_0x3eff2d('0x58c')])
                                this[_0x3eff2d('0x5bb')][_0x3eff2d('0x5bf')] = ![],
                                    this[_0x3eff2d('0xe1')][_0x3eff2d('0x5bf')] = ![],
                                    this['txtAddGem'][_0x3eff2d('0x338')] = '+' + this['_addCoin'] * 0x2,
                                    _0xd152ee[_0x3eff2d('0x3b6')]['DataMgr'][_0x3eff2d('0x45')](this['_addCoin']),
                                    Laya[_0x3eff2d('0x5ac')][_0x3eff2d('0x1e6')](0x3e8, this, function () {
                                        var _0x1bc104 = _0x3eff2d;
                                        _0xd152ee[_0x1bc104('0x3b6')]['UIMgr'][_0x1bc104('0x280')](_0x17cd94[_0x1bc104('0x339')][_0x1bc104('0x5b4')]);
                                    });
                            else {
                                _0xd152ee['default'][_0x3eff2d('0x5d7')][_0x3eff2d('0x280')](_0x17cd94[_0x3eff2d('0x339')][_0x3eff2d('0x255')]);
                                var _0x19db37 = _0x1bd1fe['default'][_0x3eff2d('0x37f')](_0xd152ee[_0x3eff2d('0x3b6')][_0x3eff2d('0x4ce')][_0x3eff2d('0xeb')](_0x3eff2d('0x16e')))
                                    , _0x15dce9 = _0x19db37[_0x1bd1fe['default'][_0x3eff2d('0x139')](0x0, _0x19db37[_0x3eff2d('0x4cc')] - 0x1)];
                                _0xd152ee['default']['GameMgr'][_0x3eff2d('0x4e2')](_0x1bd1fe[_0x3eff2d('0x3b6')][_0x3eff2d('0x139')](0x1, 0x4), this[_0x3eff2d('0x236')], _0x15dce9, _0x32c604[_0x3eff2d('0x281')][_0x3eff2d('0x4b6')]['Challenge']);
                            }
                        } else
                            _0xd152ee[_0x3eff2d('0x3b6')][_0x3eff2d('0x5d7')]['showTips'](_0x3eff2d('0x219'));
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')]['onClickRevival'] = function () {
                        var _0x2ec5dd = _0x59173f;
                        logEvent('end_challenge\x20double_ad'),
                            _0x5f2af7['GameConst'][_0x2ec5dd('0x400')] != _0x5f2af7['PlatformType'][_0x2ec5dd('0x64')] ? this[_0x2ec5dd('0x58c')] ? _0x1bd1fe[_0x2ec5dd('0x3b6')][_0x2ec5dd('0x1e5')](_0xd152ee[_0x2ec5dd('0x3b6')][_0x2ec5dd('0x4ce')][_0x2ec5dd('0x66c')](0x15), this, this[_0x2ec5dd('0x21d')][_0x2ec5dd('0x484')](this)) : _0x1bd1fe[_0x2ec5dd('0x3b6')]['onClickWatchTV'](_0xd152ee[_0x2ec5dd('0x3b6')][_0x2ec5dd('0x4ce')][_0x2ec5dd('0x66c')](0x16), this, this['watchTvCallback'][_0x2ec5dd('0x484')](this)) : this[_0x2ec5dd('0x58c')] ? _0x1bd1fe[_0x2ec5dd('0x3b6')][_0x2ec5dd('0x56b')](this[_0x2ec5dd('0x14b')]['bind'](this)) : _0x1bd1fe[_0x2ec5dd('0x3b6')]['onPlay4399Ad'](this['watch4399Callback'][_0x2ec5dd('0x484')](this));
                    }
                    ,
                    _0x5b30d9['prototype'][_0x59173f('0x14b')] = function (_0x2a6132) {
                        var _0x3bdf39 = _0x59173f;
                        if (!_0x2a6132)
                            return;
                        console['log']('代码:' + _0x2a6132['code'] + _0x3bdf39('0x2f6') + _0x2a6132[_0x3bdf39('0x152')]);
                        if (_0x2a6132[_0x3bdf39('0x559')] === 0x2710)
                            console['log'](_0x3bdf39('0x422'));
                        else {
                            if (_0x2a6132['code'] === 0x2711) {
                                console[_0x3bdf39('0x5df')](_0x3bdf39('0x543'));
                                if (_0xd152ee['default'][_0x3bdf39('0x678')]['adRemainTimes'] <= 0x0)
                                    _0xd152ee[_0x3bdf39('0x3b6')]['DataMgr'][_0x3bdf39('0x318')] = 0x0;
                                else {
                                    _0xd152ee[_0x3bdf39('0x3b6')][_0x3bdf39('0x678')][_0x3bdf39('0x318')]--,
                                        this['changeAdIcon']();
                                    if (this[_0x3bdf39('0x58c')])
                                        this['btnRevival'][_0x3bdf39('0x5bf')] = ![],
                                            this[_0x3bdf39('0xe1')][_0x3bdf39('0x5bf')] = ![],
                                            this['txtAddGem'][_0x3bdf39('0x338')] = '+' + this[_0x3bdf39('0x273')] * 0x2,
                                            _0xd152ee[_0x3bdf39('0x3b6')][_0x3bdf39('0x678')][_0x3bdf39('0x45')](this[_0x3bdf39('0x273')]),
                                            Laya[_0x3bdf39('0x5ac')]['once'](0x3e8, this, function () {
                                                var _0x576750 = _0x3bdf39;
                                                _0xd152ee[_0x576750('0x3b6')][_0x576750('0x5d7')][_0x576750('0x280')](_0x17cd94[_0x576750('0x339')][_0x576750('0x5b4')]);
                                            });
                                    else {
                                        _0xd152ee['default']['UIMgr'][_0x3bdf39('0x280')](_0x17cd94['UIEnum'][_0x3bdf39('0x255')]);
                                        var _0x41b653 = _0x1bd1fe[_0x3bdf39('0x3b6')][_0x3bdf39('0x37f')](_0xd152ee['default']['CfgMgr'][_0x3bdf39('0xeb')](_0x3bdf39('0x16e')))
                                            , _0x21f420 = _0x41b653[_0x1bd1fe[_0x3bdf39('0x3b6')][_0x3bdf39('0x139')](0x0, _0x41b653[_0x3bdf39('0x4cc')] - 0x1)];
                                        _0xd152ee[_0x3bdf39('0x3b6')][_0x3bdf39('0x33b')][_0x3bdf39('0x4e2')](_0x1bd1fe[_0x3bdf39('0x3b6')][_0x3bdf39('0x139')](0x1, 0x4), this[_0x3bdf39('0x236')], _0x21f420, _0x32c604[_0x3bdf39('0x281')][_0x3bdf39('0x4b6')][_0x3bdf39('0x473')]);
                                    }
                                }
                            } else {
                                if (_0xd152ee[_0x3bdf39('0x3b6')][_0x3bdf39('0x678')][_0x3bdf39('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x360')] = function () {
                        var _0x48bc00 = _0x59173f;
                        _0xd152ee[_0x48bc00('0x3b6')]['GameMgr'][_0x48bc00('0x360')](_0x48bc00('0x417'), this[_0x48bc00('0x3c2')][_0x48bc00('0x484')](this));
                    }
                    ,
                    _0x5b30d9['prototype']['resAdHandle'] = function (_0x25b701) {
                        if (!_0x25b701)
                            return;
                        this['updateItem'](_0x25b701);
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0xa4')] = function (_0x28fe01) {
                        var _0x476017 = _0x59173f;
                        this['clearItems'](),
                            this['itemArr'] = [];
                        var _0x37d0c5 = _0x28fe01[_0x476017('0x519')];
                        if (this['_succes'])
                            for (var _0x41cab6 = 0x0; _0x41cab6 < 0x4; _0x41cab6++) {
                                if (!_0x37d0c5[_0x41cab6])
                                    return;
                                var _0x5d440e = new _0x5b435e[(_0x476017('0x3b6'))]();
                                this[_0x476017('0x320')][_0x476017('0x5')](_0x5d440e['gameobject']),
                                    _0x5d440e['gameobject']['x'] = (_0x5d440e['gameobject'][_0x476017('0x1d2')] + 0x14) * _0x41cab6,
                                    this[_0x476017('0x3e4')][_0x476017('0xff')](_0x5d440e[_0x476017('0x5d3')]),
                                    _0x5d440e[_0x476017('0x303')](_0x37d0c5[_0x41cab6][_0x476017('0x67b')], _0x37d0c5[_0x41cab6][_0x476017('0x1fe')], _0x37d0c5[_0x41cab6]['show_config']);
                            }
                        else {
                            for (var _0x41cab6 = 0x0; _0x41cab6 < 0x6; _0x41cab6++) {
                                if (!_0x37d0c5[_0x41cab6])
                                    return;
                                var _0x5d440e = new _0x5b435e['default']();
                                this[_0x476017('0x215')]['addChild'](_0x5d440e[_0x476017('0x5d3')]),
                                    this[_0x476017('0x3e4')][_0x476017('0xff')](_0x5d440e[_0x476017('0x5d3')]),
                                    _0x5d440e['setData'](_0x37d0c5[_0x41cab6][_0x476017('0x67b')], _0x37d0c5[_0x41cab6][_0x476017('0x1fe')], _0x37d0c5[_0x41cab6][_0x476017('0x19e')]);
                            }
                            _0x5452e5[_0x476017('0x3b6')][_0x476017('0x4c7')](this[_0x476017('0x3e4')], 0x2, 0x13, 0x1ac, 0x1c2, 0x14);
                        }
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x4bc')] = function () {
                        var _0x471e29 = this;
                        setTimeout(function () {
                            var _0x354632 = _0x5985;
                            _0x126080[_0x354632('0x3b6')]['clipVideo'](_0x471e29[_0x354632('0x656')]['bind'](_0x471e29));
                        }, 0x1f4);
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x656')] = function () {
                        var _0x3c1c44 = _0x59173f;
                        this[_0x3c1c44('0xef')][_0x3c1c44('0x4b0')] = !![],
                            this[_0x3c1c44('0xef')]['mouseEnabled'] = ![];
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x6a3')] = function () {
                        var _0x2b009b = _0x59173f;
                        this[_0x2b009b('0x187')][_0x2b009b('0x4b1')] += Laya['timer']['delta'] / 0x64;
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x1f1')] = function () {
                        var _0x20a8bb = _0x59173f;
                        if (!this[_0x20a8bb('0x3e4')])
                            return;
                        this[_0x20a8bb('0x3e4')][_0x20a8bb('0x596')](function (_0x1662d1) {
                            var _0x13f36a = _0x20a8bb;
                            _0x1662d1[_0x13f36a('0x594')]();
                        }),
                            this['itemArr'][_0x20a8bb('0x4cc')] = 0x0,
                            this['itemArr'] = null;
                    }
                    ,
                    _0x5b30d9[_0x59173f('0x64a')][_0x59173f('0x72')] = function (_0x4eb7c4) {
                        var _0x219eb8 = _0x59173f
                            , _0x1bb246 = this;
                        _0x4eb7c4[_0x219eb8('0x5bf')] = ![],
                            Laya[_0x219eb8('0x5ac')][_0x219eb8('0x1e6')](0x1f4, this, function () {
                                var _0x428d46 = _0x219eb8;
                                _0x4eb7c4[_0x428d46('0x5bf')] = !![],
                                    _0x4eb7c4[_0x428d46('0x1bf')](_0x4eb7c4['x'], Laya['stage']['displayHeight'] - 0x50, !![]),
                                    Laya['timer'][_0x428d46('0x1e6')](_0xd152ee[_0x428d46('0x3b6')][_0x428d46('0x4ce')][_0x428d46('0xeb')]('ShowBannerTime'), _0x1bb246, function () {
                                        var _0x4297d0 = _0x428d46;
                                        _0x126080[_0x4297d0('0x3b6')][_0x4297d0('0x574')](!![]),
                                            Laya[_0x4297d0('0x5ac')][_0x4297d0('0x1e6')](0x1f4, _0x1bb246, function () {
                                                var _0x5ead89 = _0x4297d0;
                                                _0x4eb7c4[_0x5ead89('0x1bf')](_0x4eb7c4['x'], Laya['stage'][_0x5ead89('0x15e')] - 0xdc, !![]);
                                            });
                                    });
                            });
                    }
                    ,
                    _0x5b30d9;
            }(_0x526093['ui'][_0xfbe396('0x62')][_0xfbe396('0x404')]);
        _0x2e4760[_0xfbe396('0x3b6')] = _0x33046a;
    }
        , {
        '../../Platform': 0x3,
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        '../../utils/Utils': 0x38,
        './item/AdItem': 0x31
    }],
    0x21: [function (_0x9b596b, _0xa62e65, _0x575d2e) {
        var _0x492e43 = _0x4b7fcf;
        'use strict';
        Object[_0x492e43('0x351')](_0x575d2e, _0x492e43('0xb8'), {
            'value': !![]
        });
        var _0x1f8513 = _0x9b596b('../../ui/layaMaxUI')
            , _0x44f43b = _0x9b596b(_0x492e43('0xce'))
            , _0x507615 = _0x9b596b(_0x492e43('0x20c'))
            , _0x59b6bd = _0x9b596b(_0x492e43('0x69c'))
            , _0x17a155 = _0x9b596b(_0x492e43('0x34f'))
            , _0x3f96b5 = _0x9b596b(_0x492e43('0x46'))
            , _0x1b66d1 = function (_0x1f35a8) {
                var _0x351e2f = _0x492e43;
                __extends(_0x1c6569, _0x1f35a8);
                function _0x1c6569() {
                    var _0x1c92fc = _0x5985
                        , _0x33111c = _0x1f35a8[_0x1c92fc('0x324')](this) || this;
                    return _0x33111c['randomIndex'] = 0x0,
                        _0x33111c[_0x1c92fc('0x402')] = [],
                        _0x33111c;
                }
                return _0x1c6569[_0x351e2f('0x64a')][_0x351e2f('0x4fc')] = function () {
                    var _0x367f81 = _0x351e2f;
                    this[_0x367f81('0x218')]();
                }
                    ,
                    _0x1c6569[_0x351e2f('0x64a')][_0x351e2f('0x218')] = function () {
                        var _0x554642 = _0x351e2f;
                        this[_0x554642('0x6b4')]['text'] = _0x44f43b['default'][_0x554642('0x4ce')]['getLangById'](0x14, _0x3f96b5[_0x554642('0x1d1')][_0x554642('0x64d')]),
                            this[_0x554642('0x67e')]['text'] = _0x44f43b[_0x554642('0x3b6')][_0x554642('0x4ce')][_0x554642('0x235')](0x15, _0x3f96b5['GameConst'][_0x554642('0x64d')]),
                            this[_0x554642('0x67e')]['visible'] = !![],
                            this[_0x554642('0x2')]['visible'] = ![];
                        var _0x1acf83 = _0x44f43b['default']['CfgMgr']['getItemCfg'](_0x44f43b['default'][_0x554642('0x678')][_0x554642('0x33f')]);
                        this[_0x554642('0x4dc')]['skin'] = _0x554642('0x3a7') + _0x1acf83['ResIcon'] + _0x554642('0x99'),
                            this[_0x554642('0x402')] = _0x507615[_0x554642('0x3b6')]['TransferStringToNumberArr'](_0x44f43b[_0x554642('0x3b6')]['CfgMgr'][_0x554642('0xeb')]('RandomAISkin')),
                            Laya[_0x554642('0x5ac')][_0x554642('0x2e8')](0x64, this, this[_0x554642('0x56f')]);
                    }
                    ,
                    _0x1c6569['prototype'][_0x351e2f('0x56f')] = function () {
                        var _0x2c150e = _0x351e2f;
                        this[_0x2c150e('0x25b')]++;
                        var _0x4a2939 = this[_0x2c150e('0x402')][_0x507615[_0x2c150e('0x3b6')][_0x2c150e('0x139')](0x0, this[_0x2c150e('0x402')][_0x2c150e('0x4cc')] - 0x1)]
                            , _0x133b75 = _0x44f43b['default']['CfgMgr'][_0x2c150e('0x3ef')](_0x4a2939);
                        this['imgAI'][_0x2c150e('0x3c4')] = _0x2c150e('0x3a7') + _0x133b75[_0x2c150e('0x3d9')] + _0x2c150e('0x99'),
                            this[_0x2c150e('0x25b')] > 0x14 && (Laya[_0x2c150e('0x5ac')][_0x2c150e('0x466')](this, this['randomSkin']),
                                this[_0x2c150e('0x2')][_0x2c150e('0x5bf')] = !![],
                                this[_0x2c150e('0x67e')][_0x2c150e('0x5bf')] = ![],
                                Laya[_0x2c150e('0x5ac')]['once'](0x3e8, this, this['startChallenges'], [_0x4a2939]));
                    }
                    ,
                    _0x1c6569['prototype'][_0x351e2f('0x5ce')] = function (_0x53eba6) {
                        var _0x5d6084 = _0x351e2f;
                        _0x44f43b[_0x5d6084('0x3b6')][_0x5d6084('0x5d7')][_0x5d6084('0x280')](_0x59b6bd[_0x5d6084('0x339')][_0x5d6084('0x255')]),
                            _0x44f43b['default'][_0x5d6084('0x33b')]['StartGame'](_0x507615['default'][_0x5d6084('0x139')](0x1, 0x4), _0x44f43b['default'][_0x5d6084('0x678')]['hoopSkinId'], _0x53eba6, _0x17a155[_0x5d6084('0x281')][_0x5d6084('0x4b6')][_0x5d6084('0x473')]);
                    }
                    ,
                    _0x1c6569;
            }(_0x1f8513['ui'][_0x492e43('0x62')]['DareUIUI']);
        _0x575d2e['default'] = _0x1b66d1;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37
    }],
    0x22: [function (_0x2c6c57, _0x362c26, _0x26b2f3) {
        var _0x1759e = _0x4b7fcf;
        'use strict';
        Object[_0x1759e('0x351')](_0x26b2f3, '__esModule', {
            'value': !![]
        });
        var _0x364eab = _0x2c6c57(_0x1759e('0x662'))
            , _0x3a199f = _0x2c6c57(_0x1759e('0xce'))
            , _0x3b012b = _0x2c6c57(_0x1759e('0x20c'))
            , _0x23f1a5 = _0x2c6c57(_0x1759e('0x47'))
            , _0x177e6e = _0x2c6c57('../DragListScript')
            , _0x5d82af = _0x2c6c57(_0x1759e('0x685'))
            , _0x16186d = _0x2c6c57(_0x1759e('0x61a'))
            , _0x5bf22b = _0x2c6c57('../../enum/UIEnum')
            , _0x164606 = _0x2c6c57(_0x1759e('0x34f'))
            , _0x5eb8dd = _0x2c6c57('../../enum/GameConst')
            , _0x3ccfe6 = _0x2c6c57(_0x1759e('0x1fa'))
            , _0x35ac2c = function (_0x28ffb8) {
                var _0x55c5c3 = _0x1759e;
                __extends(_0x94ee6a, _0x28ffb8);
                function _0x94ee6a(_0x17d8ab) {
                    var _0x15ad4d = _0x5985
                        , _0x404bca = _0x28ffb8[_0x15ad4d('0x324')](this) || this;
                    return _0x404bca['_curIndex'] = -0x1,
                        _0x404bca[_0x15ad4d('0x168')] = 0x0,
                        _0x404bca['_videoFlag'] = ![],
                        _0x404bca[_0x15ad4d('0x15')] = null,
                        _0x404bca[_0x15ad4d('0x65d')] = [],
                        _0x404bca[_0x15ad4d('0x43a')] = 0x0,
                        _0x404bca[_0x15ad4d('0x697')] = 0x0,
                        _0x404bca[_0x15ad4d('0x405')] = 0x0,
                        _0x404bca['_canGetTimeBox'] = ![],
                        _0x404bca['adArr'] = [],
                        _0x404bca[_0x15ad4d('0x498')] = 0x0,
                        _0x404bca[_0x15ad4d('0xdf')] = !![],
                        _0x404bca[_0x15ad4d('0x34')] = 0x0,
                        _0x17d8ab[_0x15ad4d('0x123')] = _0x3a199f['default'][_0x15ad4d('0x4ce')]['getAdCfg'](0x3),
                        _0x404bca;
                }
                return _0x94ee6a['prototype'][_0x55c5c3('0x4fc')] = function () {
                    var _0x4e47d4 = _0x55c5c3;
                    this['isStartGame'] = ![],
                        this[_0x4e47d4('0x218')](),
                        this[_0x4e47d4('0x1d5')]();
                }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x3ea')] = function (_0xf406fe) { }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x218')] = function () {
                        var _0x4ceddb = _0x55c5c3;
                        this[_0x4ceddb('0x562')][_0x4ceddb('0x5bf')] = ![],
                            this[_0x4ceddb('0x475')]['text'] = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x4ce')][_0x4ceddb('0x235')](0x5, _0x5eb8dd['GameConst'][_0x4ceddb('0x64d')]),
                            this['freeTxt'][_0x4ceddb('0x338')] = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x4ce')]['getLangById'](0x24, _0x5eb8dd[_0x4ceddb('0x1d1')]['Language']),
                            this[_0x4ceddb('0x642')]['text'] = _0x3a199f['default'][_0x4ceddb('0x4ce')][_0x4ceddb('0x235')](0x1f, _0x5eb8dd[_0x4ceddb('0x1d1')][_0x4ceddb('0x64d')]),
                            this[_0x4ceddb('0x198')][_0x4ceddb('0x338')] = _0x3a199f['default']['CfgMgr'][_0x4ceddb('0x235')](0x8, _0x5eb8dd[_0x4ceddb('0x1d1')]['Language']),
                            this[_0x4ceddb('0x58f')][_0x4ceddb('0x338')] = _0x3a199f['default'][_0x4ceddb('0x4ce')][_0x4ceddb('0x235')](0x7, _0x5eb8dd['GameConst'][_0x4ceddb('0x64d')]),
                            this[_0x4ceddb('0xa2')]['text'] = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x4ce')][_0x4ceddb('0x235')](0x4, _0x5eb8dd[_0x4ceddb('0x1d1')]['Language']),
                            this[_0x4ceddb('0x68')][_0x4ceddb('0x3c4')] = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x678')][_0x4ceddb('0x5b5')] ? _0x4ceddb('0x666') : _0x4ceddb('0x4d5'),
                            this['sound'][_0x4ceddb('0x3c4')] = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x678')][_0x4ceddb('0x2bf')] ? 'game/main_menu_sound_1.png' : _0x4ceddb('0x6a7'),
                            this[_0x4ceddb('0x16d')][_0x4ceddb('0x593')] = '',
                            this[_0x4ceddb('0x2a2')][_0x4ceddb('0x338')] = _0x3b012b[_0x4ceddb('0x3b6')][_0x4ceddb('0x456')](_0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x678')][_0x4ceddb('0xf')]);
                        var _0x1607af = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x4ce')]['getLangById'](0x2, _0x5eb8dd[_0x4ceddb('0x1d1')][_0x4ceddb('0x64d')]);
                        _0x1607af = _0x3b012b['default']['rePlaceGetNumber'](_0x1607af, _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x678')][_0x4ceddb('0x144')][_0x4ceddb('0xcc')]()),
                            this[_0x4ceddb('0x58a')][_0x4ceddb('0x338')] = _0x1607af,
                            this[_0x4ceddb('0x21')]();
                        var _0x81a736 = _0x3a199f['default'][_0x4ceddb('0x678')]['getTimBoxIndex']()
                            , _0x4ed7c4 = _0x3a199f[_0x4ceddb('0x3b6')][_0x4ceddb('0x4ce')][_0x4ceddb('0xeb')](_0x4ceddb('0x4ad'))
                            , _0x4c94a0 = _0x4ed7c4[_0x4ceddb('0x1f8')]('|');
                        if (_0x81a736 >= _0x4c94a0[_0x4ceddb('0x4cc')])
                            this[_0x4ceddb('0xaf')][_0x4ceddb('0x338')] = '已领取';
                        else {
                            var _0x3973c1 = _0x4c94a0[_0x81a736][_0x4ceddb('0x1f8')](',');
                            this[_0x4ceddb('0x405')] = Number(_0x3973c1[0x0]),
                                this['_timeBoxCointCount'] = Number(_0x3973c1[0x1]),
                                _0x3a199f['default'][_0x4ceddb('0x1ab')][_0x4ceddb('0x7e')](),
                                this[_0x4ceddb('0x4b2')](),
                                Laya[_0x4ceddb('0x5ac')]['loop'](0x3e8, this, this[_0x4ceddb('0x4b2')]);
                        }
                        _0x3b012b['default'][_0x4ceddb('0x438')](this, this[_0x4ceddb('0x84')], 0x1f4, 1.05),
                            this['moveArrowAni'](),
                            this[_0x4ceddb('0x304')]();
                        if (_0x5eb8dd[_0x4ceddb('0x1d1')][_0x4ceddb('0x400')] == _0x5eb8dd[_0x4ceddb('0x52b')][_0x4ceddb('0x540')])
                            this[_0x4ceddb('0x65f')]['visible'] = !![],
                                this[_0x4ceddb('0x12')][_0x4ceddb('0x1bf')](0x271, 0xed),
                                _0x23f1a5[_0x4ceddb('0x3b6')][_0x4ceddb('0x1fd')](this['isauthorCallback'][_0x4ceddb('0x484')](this));
                        else
                            _0x5eb8dd[_0x4ceddb('0x1d1')][_0x4ceddb('0x400')] == _0x5eb8dd[_0x4ceddb('0x52b')][_0x4ceddb('0x576')] ? this[_0x4ceddb('0x12')][_0x4ceddb('0x1bf')](0x271, 0xed) : (this['luckyBox']['pos'](562.5, 0x37b),
                                this[_0x4ceddb('0x31')]['visible'] = ![]);
                        this[_0x4ceddb('0x51f')]();
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')]['reqTmIcons'] = function () {
                        var _0x26a891 = _0x55c5c3
                            , _0x3c0d55 = this
                            , _0x41a2d0 = _0x3a199f['default'][_0x26a891('0x678')][_0x26a891('0x436')];
                        _0x5eb8dd[_0x26a891('0x1d1')][_0x26a891('0x400')] == _0x5eb8dd[_0x26a891('0x52b')][_0x26a891('0x576')] && window['wx'] && _0x41a2d0 && (this[_0x26a891('0x4da')][_0x26a891('0x5bf')] = !![],
                            this['btnRightAdView']['visible'] = !![],
                            this[_0x26a891('0x18')][_0x26a891('0x5bf')] = !![],
                            window['wx'][_0x26a891('0x33a')][_0x26a891('0x5b9')]({
                                'positionId': _0x26a891('0x31c')
                            })[_0x26a891('0x210')](function (_0x14cc65) {
                                var _0x3da6b0 = _0x26a891;
                                console['log'](_0x3da6b0('0x18a'), _0x14cc65);
                                if (!_0x14cc65)
                                    return;
                                var _0x1b2121 = _0x14cc65['creatives'];
                                for (var _0x1be7f8 = 0x0; _0x1be7f8 < _0x1b2121[_0x3da6b0('0x4cc')]; _0x1be7f8++) {
                                    var _0x3a03f5 = new _0x3ccfe6[(_0x3da6b0('0x3b6'))]();
                                    _0x3a03f5[_0x3da6b0('0x5d3')]['x'] = (_0x3a03f5['gameobject'][_0x3da6b0('0x1d2')] + 0xa) * _0x1be7f8,
                                        _0x3c0d55[_0x3da6b0('0x16d')]['addChild'](_0x3a03f5[_0x3da6b0('0x5d3')]),
                                        _0x3a03f5[_0x3da6b0('0x303')](_0x1b2121[_0x1be7f8]['creativeId'], _0x1b2121[_0x1be7f8][_0x3da6b0('0x1fe')], _0x1b2121[_0x1be7f8][_0x3da6b0('0x19e')]),
                                        _0x3c0d55[_0x3da6b0('0x1ca')][_0x3da6b0('0xff')](_0x3a03f5[_0x3da6b0('0x5d3')]);
                                }
                                _0x3c0d55[_0x3da6b0('0x16d')]['on'](Laya[_0x3da6b0('0x68f')][_0x3da6b0('0x237')], _0x3c0d55, _0x3c0d55[_0x3da6b0('0x2bd')]),
                                    Laya[_0x3da6b0('0x5ac')]['loop'](0x1, _0x3c0d55, _0x3c0d55[_0x3da6b0('0x264')]);
                            }));
                    }
                    ,
                    _0x94ee6a['prototype'][_0x55c5c3('0x2bd')] = function () {
                        var _0x3895ad = _0x55c5c3;
                        Laya[_0x3895ad('0x150')]['on'](Laya[_0x3895ad('0x68f')]['MOUSE_UP'], this, this[_0x3895ad('0x494')]),
                            this['isTurnRight'] ? Laya[_0x3895ad('0x5ac')][_0x3895ad('0x466')](this, this[_0x3895ad('0x264')]) : Laya[_0x3895ad('0x5ac')][_0x3895ad('0x466')](this, this['onLoopLeft']);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x494')] = function () {
                        var _0x38b3c8 = _0x55c5c3;
                        Laya[_0x38b3c8('0x150')]['off'](Laya[_0x38b3c8('0x68f')]['MOUSE_UP'], this, this['onSUp']),
                            this[_0x38b3c8('0x498')] = this[_0x38b3c8('0x16d')][_0x38b3c8('0x381')]['value'],
                            this[_0x38b3c8('0xdf')] ? (Laya[_0x38b3c8('0x5ac')][_0x38b3c8('0x2e8')](0x1, this, this['onloopRight']),
                                console['log'](_0x38b3c8('0xdf'))) : (Laya['timer'][_0x38b3c8('0x2e8')](0x1, this, this[_0x38b3c8('0x7c')]),
                                    console['log']('isTurnLeft'));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x264')] = function () {
                        var _0x49953e = _0x55c5c3;
                        this[_0x49953e('0x498')] >= this['adArr'][this[_0x49953e('0x1ca')][_0x49953e('0x4cc')] - 0x5]['x'] ? (this['isTurnRight'] = ![],
                            Laya[_0x49953e('0x5ac')][_0x49953e('0x466')](this, this['onloopRight']),
                            Laya[_0x49953e('0x5ac')][_0x49953e('0x2e8')](0x1, this, this[_0x49953e('0x7c')])) : (this['initAdX']++,
                                this[_0x49953e('0x16d')]['scrollTo'](this['initAdX']));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x7c')] = function () {
                        var _0x45a72a = _0x55c5c3;
                        this[_0x45a72a('0x498')] <= 0x0 && (this[_0x45a72a('0xdf')] = !![],
                            Laya['timer'][_0x45a72a('0x466')](this, this[_0x45a72a('0x7c')]),
                            Laya[_0x45a72a('0x5ac')][_0x45a72a('0x2e8')](0x1, this, this['onloopRight'])),
                            this[_0x45a72a('0x498')]--,
                            this[_0x45a72a('0x16d')][_0x45a72a('0x43b')](this['initAdX']);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x304')] = function () {
                        var _0x5945cc = _0x55c5c3
                            , _0x5a94e2 = this;
                        Laya[_0x5945cc('0x34d')]['to'](this[_0x5945cc('0x431')], {
                            'width': this[_0x5945cc('0x431')]['width'] + 0xf,
                            'x': this['btnRightAdView']['x'] - 0xf
                        }, 0x12c, null, Laya[_0x5945cc('0x49f')][_0x5945cc('0x5fb')](this, function () {
                            var _0x40f419 = _0x5945cc;
                            Laya[_0x40f419('0x34d')]['to'](_0x5a94e2[_0x40f419('0x431')], {
                                'width': _0x5a94e2[_0x40f419('0x431')][_0x40f419('0x1d2')] - 0xf,
                                'x': _0x5a94e2[_0x40f419('0x431')]['x'] + 0xf
                            }, 0x12c, null, Laya['Handler'][_0x40f419('0x5fb')](_0x5a94e2, function () {
                                var _0x2b8a58 = _0x40f419;
                                _0x5a94e2[_0x2b8a58('0x304')]();
                            }));
                        }));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x61d')] = function () {
                        var _0x42a1a9 = _0x55c5c3
                            , _0x1f38a1 = this;
                        Laya[_0x42a1a9('0x34d')]['to'](this[_0x42a1a9('0xb7')], {
                            'y': this[_0x42a1a9('0xb7')]['y'] - 0x14
                        }, 0x12c, null, Laya[_0x42a1a9('0x49f')][_0x42a1a9('0x5fb')](this, function () {
                            var _0x1b2fbb = _0x42a1a9;
                            Laya[_0x1b2fbb('0x34d')]['to'](_0x1f38a1[_0x1b2fbb('0xb7')], {
                                'y': _0x1f38a1['arrow']['y'] + 0x14
                            }, 0x12c, null, Laya[_0x1b2fbb('0x49f')][_0x1b2fbb('0x5fb')](_0x1f38a1, function () {
                                var _0x4112d5 = _0x1b2fbb;
                                _0x1f38a1[_0x4112d5('0x61d')]();
                            }));
                        }));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')]['isauthorCallback'] = function (_0x1cdfa4) {
                        var _0x3fabfb = _0x55c5c3;
                        if (_0x1cdfa4) { } else
                            this[_0x3fabfb('0x31')]['on'](Laya[_0x3fabfb('0x68f')][_0x3fabfb('0x1af')], this, this[_0x3fabfb('0x1a7')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x1a7')] = function () {
                        var _0x51c14d = _0x55c5c3;
                        _0x23f1a5[_0x51c14d('0x3b6')][_0x51c14d('0x595')](this[_0x51c14d('0x31')], this[_0x51c14d('0x2e9')]['bind'](this));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x2e9')] = function (_0x1d01c2, _0x2f506f) {
                        var _0x11df2a = _0x55c5c3;
                        _0x1d01c2 ? (console['log'](_0x11df2a('0x169')),
                            _0x3a199f[_0x11df2a('0x3b6')][_0x11df2a('0x678')][_0x11df2a('0x578')] = _0x2f506f[_0x11df2a('0x8c')],
                            _0x3a199f[_0x11df2a('0x3b6')][_0x11df2a('0x678')]['headUrl'] = _0x2f506f[_0x11df2a('0x179')]) : console[_0x11df2a('0x5df')]('授权失败!'),
                            this[_0x11df2a('0x31')]['visible'] = ![];
                    }
                    ,
                    _0x94ee6a['prototype'][_0x55c5c3('0x1d5')] = function () {
                        var _0x19e35a = _0x55c5c3;
                        this[_0x19e35a('0x51a')](this[_0x19e35a('0x328')], this[_0x19e35a('0x2c2')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x68')], this['vibrationClickHandle']),
                            this['regClick'](this[_0x19e35a('0x97')], this[_0x19e35a('0x4d1')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x12')], this['luckyBoxClickHandle']),
                            this[_0x19e35a('0x51a')](this['timeBox'], this[_0x19e35a('0x373')]),
                            this['regClick'](this[_0x19e35a('0x71')], this[_0x19e35a('0x3af')]),
                            this['regClick'](this[_0x19e35a('0x3b3')], this[_0x19e35a('0x347')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x84')], this[_0x19e35a('0x26f')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x27a')], this['recordstartHandle']),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x2de')], this[_0x19e35a('0x326')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0xca')], this[_0x19e35a('0x130')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x44b')], this[_0x19e35a('0x634')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x65f')], this[_0x19e35a('0x88')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x18')], this['moveGameClickHandle']),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x431')], this[_0x19e35a('0x5c7')]),
                            this[_0x19e35a('0x51a')](this[_0x19e35a('0x562')], this[_0x19e35a('0x503')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')]['TestHandle'] = function () {
                        var _0x285bcd = _0x55c5c3;
                        _0x3a199f[_0x285bcd('0x3b6')][_0x285bcd('0x678')][_0x285bcd('0x45')](0x3e8),
                            this['goldCount'][_0x285bcd('0x338')] = _0x3b012b['default']['ScoreToString'](_0x3a199f['default']['DataMgr'][_0x285bcd('0xf')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')]['signClickHandle'] = function () {
                        var _0x5a6ab1 = _0x55c5c3;
                        logEvent(_0x5a6ab1('0x493')),
                            _0x3a199f['default'][_0x5a6ab1('0x5d7')][_0x5a6ab1('0x280')](_0x5bf22b[_0x5a6ab1('0x339')][_0x5a6ab1('0x2bc')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x88')] = function () {
                        var _0x12d8a2 = _0x55c5c3;
                        _0x3a199f[_0x12d8a2('0x3b6')]['UIMgr']['toUI'](_0x5bf22b['UIEnum']['RankingGlobalUI']);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x5c7')] = function () {
                        var _0x5ba91e = _0x55c5c3;
                        _0x3a199f[_0x5ba91e('0x3b6')][_0x5ba91e('0x5d7')]['toUI'](_0x5bf22b['UIEnum']['MoveGameUI']);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x4b2')] = function () {
                        var _0x3e902e = _0x55c5c3;
                        this[_0x3e902e('0x43a')] = _0x3a199f[_0x3e902e('0x3b6')]['TimeMgr'][_0x3e902e('0x4a5')],
                            this[_0x3e902e('0xaf')]['text'] = _0x3b012b[_0x3e902e('0x3b6')][_0x3e902e('0x561')](this[_0x3e902e('0x43a')]),
                            this[_0x3e902e('0x43a')] <= 0x0 && (this[_0x3e902e('0x43a')] = 0x0,
                                this[_0x3e902e('0x6d')] = !![],
                                this[_0x3e902e('0xaf')][_0x3e902e('0x338')] = _0x3a199f[_0x3e902e('0x3b6')]['CfgMgr'][_0x3e902e('0x235')](0x3, _0x5eb8dd[_0x3e902e('0x1d1')][_0x3e902e('0x64d')]),
                                Laya[_0x3e902e('0x5ac')][_0x3e902e('0x466')](this, this[_0x3e902e('0x4b2')]),
                                _0x3b012b[_0x3e902e('0x3b6')][_0x3e902e('0x438')](this, this[_0x3e902e('0x27e')], 0x1f4, 1.1));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x21')] = function () {
                        var _0x4e9ac9 = _0x55c5c3;
                        this[_0x4e9ac9('0x168')] = _0x3a199f[_0x4e9ac9('0x3b6')][_0x4e9ac9('0x678')][_0x4e9ac9('0x33f')],
                            this['_hoopArr'] = _0x3a199f[_0x4e9ac9('0x3b6')][_0x4e9ac9('0x4ce')]['getItemListByType'](_0x5d82af[_0x4e9ac9('0x4cb')]['Hoop']);
                        for (var _0x41a2df = 0x0; _0x41a2df < this['_hoopArr']['length']; _0x41a2df++) {
                            var _0x193c7a = new Laya[(_0x4e9ac9('0x55c'))]('skin/' + this[_0x4e9ac9('0x674')][_0x41a2df][_0x4e9ac9('0x3d9')] + '.png');
                            _0x193c7a[_0x4e9ac9('0x552')] = 0.5,
                                _0x193c7a[_0x4e9ac9('0x60c')] = 0x1,
                                this['SkinList'][_0x4e9ac9('0x5')](_0x193c7a),
                                _0x193c7a['x'] = _0x41a2df * 0xfa + 0x32,
                                this[_0x4e9ac9('0x65d')]['push'](_0x193c7a),
                                this[_0x4e9ac9('0x674')][_0x41a2df]['Id'] == this[_0x4e9ac9('0x168')] && (this[_0x4e9ac9('0x23c')] = _0x41a2df);
                        }
                        _0x3a199f[_0x4e9ac9('0x3b6')][_0x4e9ac9('0x370')]['on'](_0x16186d[_0x4e9ac9('0x4c3')][_0x4e9ac9('0x4e7')], this, this[_0x4e9ac9('0x2a9')]),
                            this[_0x4e9ac9('0x15')] = this['SkinList'][_0x4e9ac9('0x5a3')](_0x177e6e[_0x4e9ac9('0x3b6')]),
                            this['_dragScript'][_0x4e9ac9('0x40e')]({
                                'space': 0xfa,
                                'startX': 0x50,
                                'startIndex': -0x1,
                                'len': this[_0x4e9ac9('0x674')][_0x4e9ac9('0x4cc')] - 0x1,
                                'curIndex': this[_0x4e9ac9('0x23c')] - 0x1,
                                'dragBox': this['dragBox']
                            }),
                            this[_0x4e9ac9('0x15')][_0x4e9ac9('0x26a')](),
                            this['setItemCentorByIndex'](this[_0x4e9ac9('0x23c')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x643')] = function (_0x4dc229) {
                        var _0xf206cd = _0x55c5c3;
                        this['_skinArr'][_0x4dc229][_0xf206cd('0x1b9')](1.6, 1.6),
                            _0x4dc229 - 0x1 >= 0x0 && this[_0xf206cd('0x65d')][_0x4dc229 - 0x1][_0xf206cd('0x1b9')](0x1, 0x1),
                            _0x4dc229 + 0x1 < this[_0xf206cd('0x65d')]['length'] && this['_skinArr'][_0x4dc229 + 0x1][_0xf206cd('0x1b9')](0x1, 0x1);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x2a9')] = function (_0x4cc5db, _0x5aa794) {
                        var _0x2fa38e = _0x55c5c3;
                        _0x5aa794 && (this[_0x2fa38e('0x23c')] = _0x4cc5db + 0x1,
                            this[_0x2fa38e('0x643')](this[_0x2fa38e('0x23c')]),
                            _0x3a199f[_0x2fa38e('0x3b6')][_0x2fa38e('0x678')][_0x2fa38e('0x290')](this['_hoopArr'][this[_0x2fa38e('0x23c')]]['Id']) ? (this[_0x2fa38e('0x475')][_0x2fa38e('0x5bf')] = !![],
                                this[_0x2fa38e('0x5a9')][_0x2fa38e('0x5bf')] = ![],
                                this[_0x2fa38e('0x584')] = ![],
                                this['start'][_0x2fa38e('0x4b0')] = ![]) : (this[_0x2fa38e('0x475')][_0x2fa38e('0x5bf')] = ![],
                                    this['freeuse']['visible'] = !![],
                                    this[_0x2fa38e('0x584')] = !![],
                                    this[_0x2fa38e('0x6a2')]()));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x6a2')] = function () {
                        var _0x4cf582 = _0x55c5c3;
                        if (_0x5eb8dd['GameConst']['Platform'] == _0x5eb8dd['PlatformType']['Game4399']) {
                            var _0x2f9723 = _0x3a199f['default']['DataMgr'][_0x4cf582('0x318')];
                            console[_0x4cf582('0x5df')](_0x4cf582('0x1e4'), _0x2f9723),
                                _0x2f9723 <= 0x0 && (this[_0x4cf582('0x71')][_0x4cf582('0x4b0')] = !![]);
                        }
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x26f')] = function () {
                        var _0x42664f = _0x55c5c3;
                        logEvent(_0x42664f('0x361')),
                            _0x3a199f[_0x42664f('0x3b6')][_0x42664f('0x5d7')][_0x42664f('0x280')](_0x5bf22b[_0x42664f('0x339')][_0x42664f('0x371')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x5cf')] = function () {
                        var _0x49faea = _0x55c5c3;
                        console[_0x49faea('0x5df')]('开始录制！！'),
                            console[_0x49faea('0x5df')](_0x49faea('0x5dd') + Laya['Browser'][_0x49faea('0x66d')]()),
                            _0x3a199f['default'][_0x49faea('0x678')][_0x49faea('0x4fd')] = Laya['Browser']['now'](),
                            _0x3a199f[_0x49faea('0x3b6')][_0x49faea('0x678')][_0x49faea('0x35b')](0x1),
                            this[_0x49faea('0x451')](),
                            _0x23f1a5[_0x49faea('0x3b6')][_0x49faea('0x2c9')]();
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x326')] = function () {
                        var _0x46b85d = _0x55c5c3;
                        console['log']('录制结束！！');
                        var _0x4212fd = Laya[_0x46b85d('0x2bb')]['now']()
                            , _0x1db9af = (_0x4212fd - _0x3a199f[_0x46b85d('0x3b6')]['DataMgr'][_0x46b85d('0x4fd')]) / 0x3e8;
                        console[_0x46b85d('0x5df')](_0x1db9af + _0x46b85d('0x5be')),
                            _0x1db9af <= 0x3 ? (_0x3a199f[_0x46b85d('0x3b6')][_0x46b85d('0x5d7')][_0x46b85d('0x46e')]('录制时间不足'),
                                _0x3a199f['default'][_0x46b85d('0x678')][_0x46b85d('0x35b')](0x0),
                                this[_0x46b85d('0x451')]()) : this[_0x46b85d('0xab')]();
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0xab')] = function () {
                        var _0xa29246 = _0x55c5c3;
                        _0x3a199f[_0xa29246('0x3b6')][_0xa29246('0x678')][_0xa29246('0x35b')](0x2),
                            this[_0xa29246('0x451')](),
                            _0x3a199f[_0xa29246('0x3b6')][_0xa29246('0x5d7')][_0xa29246('0x46e')]('录制成功'),
                            _0x23f1a5[_0xa29246('0x3b6')][_0xa29246('0x571')]();
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x130')] = function () {
                        var _0x7a36d1 = this;
                        setTimeout(function () {
                            var _0x36f88f = _0x5985;
                            console[_0x36f88f('0x5df')](_0x36f88f('0xe2')),
                                _0x23f1a5[_0x36f88f('0x3b6')][_0x36f88f('0x10c')](null),
                                _0x3a199f['default'][_0x36f88f('0x678')][_0x36f88f('0x35b')](0x0),
                                _0x7a36d1[_0x36f88f('0x451')]();
                        }, 0x1f4);
                    }
                    ,
                    _0x94ee6a['prototype'][_0x55c5c3('0x347')] = function () {
                        var _0x3a45de = _0x55c5c3;
                        logEvent('button_challenge'),
                            _0x3a199f[_0x3a45de('0x3b6')][_0x3a45de('0x5d7')]['toUI'](_0x5bf22b[_0x3a45de('0x339')][_0x3a45de('0x1f4')]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x3af')] = function () {
                        var _0xe73033 = _0x55c5c3;
                        this[_0xe73033('0x584')] ? (logEvent(_0xe73033('0xc0')),
                            _0x5eb8dd[_0xe73033('0x1d1')][_0xe73033('0x400')] != _0x5eb8dd[_0xe73033('0x52b')]['Game4399'] ? (_0x3b012b[_0xe73033('0x3b6')][_0xe73033('0x1e5')](_0x3a199f[_0xe73033('0x3b6')][_0xe73033('0x4ce')][_0xe73033('0x66c')](0xc), this, this[_0xe73033('0x21d')][_0xe73033('0x484')](this)),
                                console[_0xe73033('0x5df')](_0x3a199f[_0xe73033('0x3b6')][_0xe73033('0x4ce')][_0xe73033('0x66c')](0xc) + '获取视频ID' + typeof _0x3a199f['default']['CfgMgr'][_0xe73033('0x66c')](0xc))) : _0x3b012b[_0xe73033('0x3b6')][_0xe73033('0x56b')](this[_0xe73033('0x14b')][_0xe73033('0x484')](this))) : (logEvent(_0xe73033('0x48e')),
                                    this[_0xe73033('0x6ad')](),
                                    this['isStartGame'] = !![]);
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x14b')] = function (_0x53e68e) {
                        var _0x13f11a = _0x55c5c3;
                        if (!_0x53e68e)
                            return;
                        console[_0x13f11a('0x5df')]('代码:' + _0x53e68e[_0x13f11a('0x559')] + _0x13f11a('0x2f6') + _0x53e68e[_0x13f11a('0x152')]);
                        if (_0x53e68e['code'] === 0x2710)
                            console[_0x13f11a('0x5df')](_0x13f11a('0x422'));
                        else {
                            if (_0x53e68e[_0x13f11a('0x559')] === 0x2711)
                                _0x3a199f[_0x13f11a('0x3b6')]['DataMgr']['adRemainTimes'] <= 0x0 ? _0x3a199f[_0x13f11a('0x3b6')]['DataMgr']['adRemainTimes'] = 0x0 : (_0x3a199f[_0x13f11a('0x3b6')][_0x13f11a('0x678')][_0x13f11a('0x318')]--,
                                    this[_0x13f11a('0x6a2')](),
                                    this[_0x13f11a('0x6ad')]());
                            else {
                                if (_0x3a199f[_0x13f11a('0x3b6')][_0x13f11a('0x678')][_0x13f11a('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')]['watchTvCallback'] = function (_0x16cade, _0x2e3652, _0x25feeb) {
                        var _0x28208c = _0x55c5c3;
                        _0x2e3652 === void 0x0 && (_0x2e3652 = null);
                        _0x25feeb === void 0x0 && (_0x25feeb = null);
                        if (_0x2e3652) {
                            _0x3a199f[_0x28208c('0x3b6')][_0x28208c('0x5d7')][_0x28208c('0x46e')](_0x2e3652);
                            return;
                        }
                        _0x16cade ? this[_0x28208c('0x6ad')](_0x16cade) : _0x3a199f[_0x28208c('0x3b6')][_0x28208c('0x5d7')][_0x28208c('0x46e')](_0x28208c('0x301'));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x6ad')] = function (_0x3572f9) {
                        var _0x553e03 = _0x55c5c3;
                        _0x3572f9 === void 0x0 && (_0x3572f9 = ![]);
                        var _0x22589e = _0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x678')][_0x553e03('0x144')], _0x1b64f2 = _0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x4ce')][_0x553e03('0xeb')](_0x553e03('0xf6')), _0x59a897;
                        _0x3a199f['default'][_0x553e03('0x33b')][_0x553e03('0x38b')][_0x553e03('0x5d3')][_0x553e03('0x4ba')] = ![],
                            _0x3a199f[_0x553e03('0x3b6')]['GameMgr'][_0x553e03('0x631')][_0x553e03('0x5d3')]['active'] = ![],
                            _0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x33b')][_0x553e03('0x3b5')](),
                            _0x3a199f[_0x553e03('0x3b6')]['GameMgr'][_0x553e03('0x34a')] != null && (_0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x33b')][_0x553e03('0x34a')][_0x553e03('0x5d3')][_0x553e03('0x4ba')] = ![]),
                            _0x22589e % _0x1b64f2 == 0x0 ? (_0x3572f9 && (_0x59a897 = this[_0x553e03('0x674')][this[_0x553e03('0x23c')]]['Id']),
                                _0x3a199f['default'][_0x553e03('0xba')][_0x553e03('0x382')](0x5, _0x164606[_0x553e03('0x281')][_0x553e03('0x4b6')]['Special'], function () {
                                    var _0x1a4782 = _0x553e03;
                                    _0x3a199f[_0x1a4782('0x3b6')][_0x1a4782('0x5d7')][_0x1a4782('0x280')](_0x5bf22b['UIEnum']['PlayGameGemUI'], _0x59a897);
                                })) : (_0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x5d7')][_0x553e03('0x280')](_0x5bf22b[_0x553e03('0x339')][_0x553e03('0x255')]),
                                    !_0x3572f9 ? (_0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x678')][_0x553e03('0x33f')] = this[_0x553e03('0x674')][this['_curIndex']]['Id'],
                                        console['log'](_0x553e03('0x25'))) : console['log']('shipingjinqu'),
                                    _0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x33b')]['StartGame'](_0x3a199f[_0x553e03('0x3b6')][_0x553e03('0x678')][_0x553e03('0x60')], this['_hoopArr'][this[_0x553e03('0x23c')]]['Id'], this[_0x553e03('0x674')][_0x3b012b[_0x553e03('0x3b6')][_0x553e03('0x139')](0x0, this[_0x553e03('0x674')]['length'] - 0x1)]['Id'], _0x164606['GameEnum'][_0x553e03('0x4b6')][_0x553e03('0x579')]));
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x451')] = function () {
                        var _0x1547d4 = _0x55c5c3;
                        switch (_0x3a199f[_0x1547d4('0x3b6')][_0x1547d4('0x678')]['getRecordState']()) {
                            case 0x0:
                                this[_0x1547d4('0x27a')][_0x1547d4('0x5bf')] = !![],
                                    this[_0x1547d4('0x2de')][_0x1547d4('0x5bf')] = ![],
                                    this[_0x1547d4('0xca')][_0x1547d4('0x5bf')] = ![];
                                break;
                            case 0x1:
                                this[_0x1547d4('0x27a')][_0x1547d4('0x5bf')] = ![],
                                    this[_0x1547d4('0x2de')]['visible'] = !![],
                                    this[_0x1547d4('0xca')][_0x1547d4('0x5bf')] = ![];
                                break;
                            case 0x2:
                                this['recordstartBtn'][_0x1547d4('0x5bf')] = ![],
                                    this[_0x1547d4('0x2de')][_0x1547d4('0x5bf')] = ![],
                                    this[_0x1547d4('0xca')][_0x1547d4('0x5bf')] = !![];
                                break;
                        }
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x135')] = function () {
                        var _0x437f54 = _0x55c5c3;
                        logEvent(_0x437f54('0x277')),
                            _0x3a199f[_0x437f54('0x3b6')][_0x437f54('0x5d7')][_0x437f54('0x280')](_0x5bf22b[_0x437f54('0x339')][_0x437f54('0x394')]);
                    }
                    ,
                    _0x94ee6a['prototype']['timeBoxClickHandle'] = function () {
                        var _0x1a983b = _0x55c5c3;
                        logEvent(_0x1a983b('0x185'));
                        if (this['_timeBoxCointCount'] <= 0x0) {
                            _0x3a199f[_0x1a983b('0x3b6')]['UIMgr'][_0x1a983b('0x46e')]('今日已领取完，请明天领取大礼包');
                            return;
                        }
                        _0x3a199f['default'][_0x1a983b('0x5d7')]['toUI'](_0x5bf22b['UIEnum'][_0x1a983b('0x490')], {
                            'gold': this[_0x1a983b('0x697')],
                            'time': this[_0x1a983b('0x43a')],
                            'endTime': this['_timeBoxEndTime']
                        });
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x2c2')] = function () {
                        var _0x2f8287 = _0x55c5c3;
                        this['setBg'][_0x2f8287('0x5bf')] = !this['setBg'][_0x2f8287('0x5bf')];
                    }
                    ,
                    _0x94ee6a['prototype'][_0x55c5c3('0x3e7')] = function () {
                        var _0x477e65 = _0x55c5c3;
                        _0x3a199f[_0x477e65('0x3b6')]['DataMgr'][_0x477e65('0x5b5')] = !_0x3a199f[_0x477e65('0x3b6')][_0x477e65('0x678')][_0x477e65('0x5b5')],
                            this[_0x477e65('0x68')][_0x477e65('0x3c4')] = _0x3a199f[_0x477e65('0x3b6')][_0x477e65('0x678')]['bVibration'] ? 'game/main_menu_vibroon_1.png' : _0x477e65('0x4d5');
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x4d1')] = function () {
                        var _0x5cce56 = _0x55c5c3;
                        _0x3a199f[_0x5cce56('0x3b6')][_0x5cce56('0x678')]['bSound'] = !_0x3a199f[_0x5cce56('0x3b6')][_0x5cce56('0x678')][_0x5cce56('0x2bf')],
                            this[_0x5cce56('0x97')][_0x5cce56('0x3c4')] = _0x3a199f[_0x5cce56('0x3b6')][_0x5cce56('0x678')][_0x5cce56('0x2bf')] ? _0x5cce56('0x2d9') : _0x5cce56('0x6a7');
                    }
                    ,
                    _0x94ee6a[_0x55c5c3('0x64a')][_0x55c5c3('0x42')] = function () {
                        var _0x400366 = _0x55c5c3;
                        _0x3a199f[_0x400366('0x3b6')][_0x400366('0x370')][_0x400366('0x585')](_0x16186d[_0x400366('0x4c3')]['Switch_Page'], this, this['switchPageHandle']),
                            this[_0x400366('0x15')][_0x400366('0x39d')](),
                            this[_0x400366('0x15')] = null,
                            Laya[_0x400366('0x34d')]['clearAll'](this[_0x400366('0x84')]),
                            Laya[_0x400366('0x34d')][_0x400366('0x1fb')](this[_0x400366('0xb7')]),
                            _0x28ffb8[_0x400366('0x64a')][_0x400366('0x42')][_0x400366('0x324')](this);
                    }
                    ,
                    _0x94ee6a;
            }(_0x364eab['ui']['view']['GameUIUI']);
        _0x26b2f3[_0x1759e('0x3b6')] = _0x35ac2c;
    }
        , {
        '../../Platform': 0x3,
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/ResEnum': 0x12,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        '../DragListScript': 0x1e,
        './item/AdItem': 0x31
    }],
    0x23: [function (_0x2f9900, _0x3c1c17, _0x2ad548) {
        var _0x53f5b5 = _0x4b7fcf;
        'use strict';
        Object[_0x53f5b5('0x351')](_0x2ad548, _0x53f5b5('0xb8'), {
            'value': !![]
        });
        var _0x19de91 = _0x2f9900(_0x53f5b5('0x662'))
            , _0x5a6d1f = _0x2f9900(_0x53f5b5('0xce'))
            , _0x47c6fa = _0x2f9900('../../utils/Tools')
            , _0x2d323d = _0x2f9900(_0x53f5b5('0x69c'))
            , _0x50c5c0 = _0x2f9900(_0x53f5b5('0x47'))
            , _0x97562a = _0x2f9900(_0x53f5b5('0x34f'))
            , _0x4f9ba5 = _0x2f9900(_0x53f5b5('0x46'))
            , _0x46e68e = _0x2f9900(_0x53f5b5('0x1fa'))
            , _0x554142 = _0x2f9900(_0x53f5b5('0x3cf'))
            , _0x826545 = _0x2f9900(_0x53f5b5('0x61a'))
            , _0x24283d = function (_0xd19014) {
                var _0x3309ba = _0x53f5b5;
                __extends(_0x5a458b, _0xd19014);
                function _0x5a458b(_0x5dc601) {
                    var _0x3eace6 = _0x5985
                        , _0x560f47 = _0xd19014['call'](this) || this;
                    return _0x560f47['loseIcon'] = _0x3eace6('0x3eb'),
                        _0x560f47['winIcon'] = _0x3eace6('0x5ad'),
                        _0x560f47['winBG'] = 'level/level_uidi_victory.png',
                        _0x560f47[_0x3eace6('0x41b')] = _0x3eace6('0x1be'),
                        _0x560f47[_0x3eace6('0x3e9')] = 'level/level_bg2.png',
                        _0x560f47['roundWin'] = _0x3eace6('0x314'),
                        _0x560f47[_0x3eace6('0x260')] = 'level/level_bg3.png',
                        _0x560f47['finalWin'] = _0x3eace6('0x14c'),
                        _0x560f47[_0x3eace6('0x5d1')] = 'level/level_finalDi.png',
                        _0x560f47[_0x3eace6('0x57b')] = _0x3eace6('0x35e'),
                        _0x560f47[_0x3eace6('0x46c')] = _0x3eace6('0x239'),
                        _0x560f47[_0x3eace6('0x236')] = -0x1,
                        _0x560f47['itemArr'] = [],
                        _0x5dc601['adunit'] = _0x5a6d1f[_0x3eace6('0x3b6')][_0x3eace6('0x4ce')]['getAdCfg'](0x5),
                        _0x560f47;
                }
                return _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x4fc')] = function () {
                    var _0x35b376 = _0x3309ba;
                    this[_0x35b376('0x218')](),
                        this['initEvent'](),
                        Laya[_0x35b376('0x5ac')]['frameLoop'](0x1, this, this[_0x35b376('0x6a3')]);
                }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x5dc')] = function () {
                        var _0x13fdb2 = _0x3309ba;
                        Laya[_0x13fdb2('0x5ac')][_0x13fdb2('0x1fb')](this);
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x218')] = function () {
                        var _0x536d10 = _0x3309ba
                            , _0x5eb60e = !![];
                        window[_0x536d10('0x32c')] && (_0x5eb60e = typeof window[_0x536d10('0x32c')]['getVideoRecorderManager'] != _0x536d10('0x51b'));
                        console['log'](_0x5eb60e, '有没录屏!！!');
                        _0x4f9ba5['GameConst']['Platform'] == _0x4f9ba5[_0x536d10('0x52b')]['TouTAd'] ? (this['btnSharekVedio'][_0x536d10('0x4b0')] = ![],
                            this[_0x536d10('0xef')][_0x536d10('0x3b8')] = !![],
                            this['btnSharekVedio'][_0x536d10('0x5bf')] = _0x5a6d1f[_0x536d10('0x3b6')][_0x536d10('0x678')][_0x536d10('0x60')] <= 0x4,
                            this['btnNext']['x'] = 0x246) : this[_0x536d10('0x514')]['x'] = 0x16e;
                        if (this[_0x536d10('0x42d')][_0x536d10('0x5bf')] == !![])
                            _0x47c6fa[_0x536d10('0x3b6')][_0x536d10('0x72')](this, this[_0x536d10('0xe1')], Laya[_0x536d10('0x150')][_0x536d10('0x15e')] - 0x50, Laya[_0x536d10('0x150')][_0x536d10('0x15e')] - 0xdc),
                                this['doLager'](this['imgSkin']);
                        else
                            _0x5a6d1f[_0x536d10('0x3b6')][_0x536d10('0x678')][_0x536d10('0x60')] <= 0x4 && (console[_0x536d10('0x5df')](Laya[_0x536d10('0x150')][_0x536d10('0x15e')] * 0.77 + 0x20),
                                _0x47c6fa[_0x536d10('0x3b6')]['showBannerMoveBtn'](this, this[_0x536d10('0x514')], Laya[_0x536d10('0x150')][_0x536d10('0x15e')] * 0.9, Laya['stage'][_0x536d10('0x15e')] * 0.77 + 0x20));
                        _0x4f9ba5['GameConst']['Platform'] == _0x4f9ba5[_0x536d10('0x52b')]['WXAd'] && _0x5a6d1f[_0x536d10('0x3b6')][_0x536d10('0x678')][_0x536d10('0x436')] && this['reqTmAd'](),
                            _0x4f9ba5['GameConst']['Platform'] == _0x4f9ba5[_0x536d10('0x52b')]['Game4399'] && this[_0x536d10('0x6a2')]();
                    }
                    ,
                    _0x5a458b['prototype'][_0x3309ba('0x6a2')] = function () {
                        var _0x6e4cdf = _0x3309ba
                            , _0x57e50f = _0x5a6d1f[_0x6e4cdf('0x3b6')]['DataMgr'][_0x6e4cdf('0x318')];
                        console[_0x6e4cdf('0x5df')](_0x6e4cdf('0x1e4'), _0x57e50f),
                            _0x57e50f <= 0x0 && (this[_0x6e4cdf('0x5bb')][_0x6e4cdf('0x4b0')] = !![]);
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x360')] = function () {
                        var _0x33829e = _0x3309ba;
                        _0x5a6d1f[_0x33829e('0x3b6')][_0x33829e('0x33b')][_0x33829e('0x360')](_0x33829e('0x497'), this['resAdHandle'][_0x33829e('0x484')](this));
                    }
                    ,
                    _0x5a458b['prototype'][_0x3309ba('0x3c2')] = function (_0x5042a2) {
                        var _0x2c5f0e = _0x3309ba;
                        if (!_0x5042a2)
                            return;
                        this[_0x2c5f0e('0xa4')](_0x5042a2);
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')]['updateItem'] = function (_0x596b02) {
                        var _0x3577d0 = _0x3309ba;
                        this['clearItems'](),
                            this[_0x3577d0('0x3e4')] = [];
                        var _0x4c4f65 = _0x596b02[_0x3577d0('0x519')];
                        for (var _0x5d24e4 = 0x0; _0x5d24e4 < 0x4; _0x5d24e4++) {
                            if (!_0x4c4f65[_0x5d24e4])
                                return;
                            var _0x3fb24e = new _0x46e68e[(_0x3577d0('0x3b6'))]();
                            this['levelBg'][_0x3577d0('0x5')](_0x3fb24e[_0x3577d0('0x5d3')]),
                                this[_0x3577d0('0x3e4')][_0x3577d0('0xff')](_0x3fb24e[_0x3577d0('0x5d3')]),
                                _0x3fb24e[_0x3577d0('0x303')](_0x4c4f65[_0x5d24e4][_0x3577d0('0x67b')], _0x4c4f65[_0x5d24e4][_0x3577d0('0x1fe')], _0x4c4f65[_0x5d24e4][_0x3577d0('0x19e')]);
                        }
                        _0x554142['default'][_0x3577d0('0x4c7')](this['itemArr'], 0x2, 0x32, 0x2c6, 0x190, 0x14);
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0xb')] = function (_0x53a01f) {
                        var _0x17daab = _0x3309ba;
                        Laya[_0x17daab('0x34d')]['to'](_0x53a01f, {
                            'scaleX': 0x1,
                            'scaleY': 0x1
                        }, 0x2bc, null, Laya[_0x17daab('0x49f')][_0x17daab('0x5fb')](this, this['doLager'], [_0x53a01f], !![]));
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')]['doLager'] = function (_0x1c459e) {
                        var _0x528727 = _0x3309ba;
                        Laya['Tween']['to'](_0x1c459e, {
                            'scaleX': 1.5,
                            'scaleY': 1.5
                        }, 0x2bc, null, Laya[_0x528727('0x49f')][_0x528727('0x5fb')](this, this[_0x528727('0xb')], [_0x1c459e], !![]));
                    }
                    ,
                    _0x5a458b['prototype'][_0x3309ba('0x1f1')] = function () {
                        var _0xcf2a13 = _0x3309ba;
                        if (!this[_0xcf2a13('0x3e4')])
                            return;
                        this[_0xcf2a13('0x3e4')]['forEach'](function (_0xeac578) {
                            var _0x440f04 = _0xcf2a13;
                            _0xeac578[_0x440f04('0x594')]();
                        }),
                            this[_0xcf2a13('0x3e4')]['length'] = 0x0,
                            this[_0xcf2a13('0x3e4')] = null;
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')]['initEvent'] = function () {
                        var _0x36d0cd = _0x3309ba;
                        this[_0x36d0cd('0x51a')](this[_0x36d0cd('0xe1')], this['onClickBack']),
                            this['regClick'](this[_0x36d0cd('0x5bb')], this[_0x36d0cd('0x565')]),
                            this[_0x36d0cd('0x51a')](this[_0x36d0cd('0x514')], this[_0x36d0cd('0x428')]),
                            this[_0x36d0cd('0x51a')](this[_0x36d0cd('0xef')], this[_0x36d0cd('0x4bc')]),
                            _0x5a6d1f[_0x36d0cd('0x3b6')][_0x36d0cd('0x370')]['on'](_0x826545[_0x36d0cd('0x4c3')][_0x36d0cd('0x4bf')], this, this['updateItem']);
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x6a3')] = function () {
                        var _0x50da84 = _0x3309ba;
                        this[_0x50da84('0x2ae')][_0x50da84('0x4b1')] += Laya[_0x50da84('0x5ac')][_0x50da84('0x479')] / 0x64;
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x3ea')] = function (_0x5707a1) {
                        var _0x4a4a42 = _0x3309ba
                            , _0x41fc8c = this;
                        this['imgTitleLose'][_0x4a4a42('0x5bf')] = !_0x5707a1[_0x4a4a42('0x386')],
                            this[_0x4a4a42('0x4db')][_0x4a4a42('0x5bf')] = _0x5707a1[_0x4a4a42('0x386')],
                            this[_0x4a4a42('0x2cf')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x1c, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                            this['resultTxt'][_0x4a4a42('0x338')] = _0x5707a1['succes'] ? _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')]['getLangById'](0x16, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']) : _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x18, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                            this[_0x4a4a42('0x472')]['text'] = _0x5a6d1f[_0x4a4a42('0x3b6')]['CfgMgr'][_0x4a4a42('0x235')](0x19, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                            this['scheduleTxt'][_0x4a4a42('0x338')] = _0x5a6d1f['default'][_0x4a4a42('0x4ce')]['getLangById'](0x1a, _0x4f9ba5['GameConst']['Language']),
                            this[_0x4a4a42('0xb0')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x1d, _0x4f9ba5['GameConst'][_0x4a4a42('0x64d')]),
                            this['btnBack'][_0x4a4a42('0x338')] = _0x5a6d1f['default']['CfgMgr'][_0x4a4a42('0x235')](0x13, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                            this[_0x4a4a42('0x313')][_0x4a4a42('0x3c4')] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0xda')] : this[_0x4a4a42('0x41b')],
                            this[_0x4a4a42('0x32')]['skin'] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x549')] : this[_0x4a4a42('0x5d1')],
                            this[_0x4a4a42('0x628')][_0x4a4a42('0x5bf')] = !_0x5707a1[_0x4a4a42('0x386')];
                        _0x5707a1[_0x4a4a42('0x386')] ? logEvent(_0x4a4a42('0x250')) : logEvent(_0x4a4a42('0x1f2'));
                        if (_0x5707a1[_0x4a4a42('0x43e')] == 0x1)
                            this['imgLevel01'][_0x4a4a42('0x3c4')] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x29e')] : this[_0x4a4a42('0x260')],
                                this[_0x4a4a42('0x40')][_0x4a4a42('0x338')] = _0x5707a1['succes'] ? _0x5a6d1f[_0x4a4a42('0x3b6')]['CfgMgr'][_0x4a4a42('0x235')](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']) : _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x18, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']),
                                this[_0x4a4a42('0x1ac')][_0x4a4a42('0x5bf')] = !![],
                                this[_0x4a4a42('0x1ac')]['skin'] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x23a')] : this['loseIcon'],
                                this['tweenSize'](this['imgState1']),
                                this[_0x4a4a42('0x6a9')][_0x4a4a42('0x3c4')] = this['roundIdel'],
                                this[_0x4a4a42('0x5e5')][_0x4a4a42('0x338')] = _0x5a6d1f['default'][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x22, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                                this[_0x4a4a42('0x378')][_0x4a4a42('0x5bf')] = ![],
                                this[_0x4a4a42('0x690')][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x3e9')],
                                this[_0x4a4a42('0x3c5')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')]['CfgMgr'][_0x4a4a42('0x235')](0x22, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']),
                                this[_0x4a4a42('0x310')]['visible'] = ![],
                                this[_0x4a4a42('0x603')][_0x4a4a42('0x3c4')] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x57b')] : this['keyNone'],
                                this[_0x4a4a42('0x1f0')][_0x4a4a42('0x3c4')] = this['keyNone'],
                                this[_0x4a4a42('0x553')]['skin'] = this['keyNone'];
                        else {
                            if (_0x5707a1[_0x4a4a42('0x43e')] == 0x2)
                                this[_0x4a4a42('0x511')][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x29e')],
                                    this[_0x4a4a42('0x40')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')]['getLangById'](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                                    this['imgState1']['visible'] = !![],
                                    this[_0x4a4a42('0x1ac')]['skin'] = this[_0x4a4a42('0x23a')],
                                    this[_0x4a4a42('0x50')](this[_0x4a4a42('0x1ac')]),
                                    this[_0x4a4a42('0x6a9')]['skin'] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x29e')] : this[_0x4a4a42('0x260')],
                                    this[_0x4a4a42('0x5e5')][_0x4a4a42('0x338')] = _0x5707a1[_0x4a4a42('0x386')] ? _0x5a6d1f['default'][_0x4a4a42('0x4ce')]['getLangById'](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]) : _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x18, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']),
                                    this[_0x4a4a42('0x378')]['visible'] = !![],
                                    this[_0x4a4a42('0x378')][_0x4a4a42('0x3c4')] = _0x5707a1[_0x4a4a42('0x386')] ? this['winIcon'] : this[_0x4a4a42('0x599')],
                                    this['tweenSize'](this[_0x4a4a42('0x378')]),
                                    this[_0x4a4a42('0x690')]['skin'] = this[_0x4a4a42('0x3e9')],
                                    this[_0x4a4a42('0x3c5')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x22, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']),
                                    this[_0x4a4a42('0x310')][_0x4a4a42('0x5bf')] = ![],
                                    this[_0x4a4a42('0x603')]['skin'] = this[_0x4a4a42('0x57b')],
                                    this['imgKey2'][_0x4a4a42('0x3c4')] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x57b')] : this['keyNone'],
                                    this[_0x4a4a42('0x553')]['skin'] = this[_0x4a4a42('0x46c')];
                            else {
                                if (_0x5707a1['round'] == 0x3)
                                    this[_0x4a4a42('0x511')]['skin'] = this[_0x4a4a42('0x29e')],
                                        this[_0x4a4a42('0x40')]['text'] = _0x5a6d1f['default'][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x1b, _0x4f9ba5['GameConst'][_0x4a4a42('0x64d')]),
                                        this[_0x4a4a42('0x1ac')][_0x4a4a42('0x5bf')] = !![],
                                        this[_0x4a4a42('0x1ac')][_0x4a4a42('0x3c4')] = this['winIcon'],
                                        this[_0x4a4a42('0x50')](this[_0x4a4a42('0x1ac')]),
                                        this['imgLevel02'][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x29e')],
                                        this[_0x4a4a42('0x5e5')][_0x4a4a42('0x338')] = _0x5a6d1f['default'][_0x4a4a42('0x4ce')]['getLangById'](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                                        this['imgState2']['visible'] = !![],
                                        this['imgState2'][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x23a')],
                                        this[_0x4a4a42('0x50')](this[_0x4a4a42('0x378')]),
                                        this[_0x4a4a42('0x690')][_0x4a4a42('0x3c4')] = _0x5707a1['succes'] ? this[_0x4a4a42('0x29e')] : this['roundLose'],
                                        this[_0x4a4a42('0x3c5')][_0x4a4a42('0x338')] = _0x5707a1['succes'] ? _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x1b, _0x4f9ba5['GameConst'][_0x4a4a42('0x64d')]) : _0x5a6d1f['default'][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x18, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']),
                                        this[_0x4a4a42('0x310')][_0x4a4a42('0x5bf')] = !![],
                                        this[_0x4a4a42('0x310')][_0x4a4a42('0x3c4')] = _0x5707a1['succes'] ? this[_0x4a4a42('0x23a')] : this[_0x4a4a42('0x599')],
                                        this['tweenSize'](this[_0x4a4a42('0x310')]),
                                        this['imgKey1']['skin'] = this[_0x4a4a42('0x57b')],
                                        this[_0x4a4a42('0x1f0')]['skin'] = this[_0x4a4a42('0x57b')],
                                        this[_0x4a4a42('0x553')][_0x4a4a42('0x3c4')] = _0x5707a1[_0x4a4a42('0x386')] ? this[_0x4a4a42('0x57b')] : this[_0x4a4a42('0x46c')];
                                else
                                    _0x5707a1[_0x4a4a42('0x43e')] == 0x4 && (this[_0x4a4a42('0x511')][_0x4a4a42('0x3c4')] = this['roundWin'],
                                        this[_0x4a4a42('0x40')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                                        this[_0x4a4a42('0x1ac')][_0x4a4a42('0x5bf')] = !![],
                                        this['imgState1'][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x23a')],
                                        this['tweenSize'](this[_0x4a4a42('0x1ac')]),
                                        this['imgLevel02'][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x29e')],
                                        this[_0x4a4a42('0x5e5')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')]['getLangById'](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')]['Language']),
                                        this[_0x4a4a42('0x378')][_0x4a4a42('0x5bf')] = !![],
                                        this[_0x4a4a42('0x378')][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x23a')],
                                        this['tweenSize'](this[_0x4a4a42('0x378')]),
                                        this[_0x4a4a42('0x690')]['skin'] = this[_0x4a4a42('0x29e')],
                                        this[_0x4a4a42('0x3c5')][_0x4a4a42('0x338')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x235')](0x1b, _0x4f9ba5[_0x4a4a42('0x1d1')][_0x4a4a42('0x64d')]),
                                        this[_0x4a4a42('0x310')][_0x4a4a42('0x5bf')] = !![],
                                        this[_0x4a4a42('0x310')][_0x4a4a42('0x3c4')] = this['winIcon'],
                                        this['tweenSize'](this[_0x4a4a42('0x310')]),
                                        this[_0x4a4a42('0x603')][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x57b')],
                                        this[_0x4a4a42('0x1f0')][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x57b')],
                                        this[_0x4a4a42('0x553')][_0x4a4a42('0x3c4')] = this[_0x4a4a42('0x57b')]);
                            }
                        }
                        this[_0x4a4a42('0x628')][_0x4a4a42('0x5bf')] = !_0x5707a1[_0x4a4a42('0x386')],
                            this[_0x4a4a42('0x523')]['visible'] = _0x5707a1['round'] > 0x1,
                            this[_0x4a4a42('0x1b4')]['visible'] = _0x5707a1['round'] > 0x2,
                            this[_0x4a4a42('0x282')][_0x4a4a42('0x5bf')] = _0x5707a1['round'] > 0x3,
                            this['boxWin'][_0x4a4a42('0x5bf')] = _0x5707a1['succes'],
                            this[_0x4a4a42('0x42d')][_0x4a4a42('0x5bf')] = !_0x5707a1[_0x4a4a42('0x386')],
                            this[_0x4a4a42('0x208')] = _0x47c6fa[_0x4a4a42('0x3b6')]['TransferStringToNumberArr'](_0x5a6d1f['default'][_0x4a4a42('0x4ce')][_0x4a4a42('0xeb')]('TryRingList')),
                            this[_0x4a4a42('0x236')] = this[_0x4a4a42('0x208')][_0x47c6fa[_0x4a4a42('0x3b6')][_0x4a4a42('0x139')](0x0, this[_0x4a4a42('0x208')][_0x4a4a42('0x4cc')] - 0x1)];
                        var _0x441dda = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x4ce')][_0x4a4a42('0x3ef')](this[_0x4a4a42('0x236')]);
                        this[_0x4a4a42('0xbe')][_0x4a4a42('0x3c4')] = _0x4a4a42('0x3a7') + _0x441dda[_0x4a4a42('0x3d9')] + _0x4a4a42('0x99'),
                            this['txtCoin'][_0x4a4a42('0x338')] = _0x47c6fa[_0x4a4a42('0x3b6')][_0x4a4a42('0x456')](_0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x678')][_0x4a4a42('0xf')]),
                            _0x5707a1[_0x4a4a42('0x386')] ? (_0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x678')][_0x4a4a42('0x144')]++,
                                _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x678')][_0x4a4a42('0x60')]++,
                                this['btnNext'][_0x4a4a42('0x5bf')] = _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x678')][_0x4a4a42('0x60')] <= 0x4,
                                console[_0x4a4a42('0x5df')](_0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x678')][_0x4a4a42('0x60')] + _0x4a4a42('0xb9')),
                                Laya[_0x4a4a42('0x34d')]['from'](this[_0x4a4a42('0x2f5')], {
                                    'scaleX': 1.5,
                                    'scaleY': 1.5
                                }, 0x258, Laya['Ease']['elasticInOut'], Laya[_0x4a4a42('0x49f')]['create'](this, function () {
                                    var _0x4c8868 = _0x4a4a42;
                                    _0x5a6d1f[_0x4c8868('0x3b6')][_0x4c8868('0x678')][_0x4c8868('0x60')] > 0x4 && (_0x5a6d1f[_0x4c8868('0x3b6')][_0x4c8868('0x678')][_0x4c8868('0x60')] = 0x1,
                                        Laya[_0x4c8868('0x5ac')][_0x4c8868('0x1e6')](0x1f4, _0x41fc8c, function () {
                                            var _0x1e4162 = _0x4c8868;
                                            _0x5a6d1f[_0x1e4162('0x3b6')]['UIMgr']['toUI'](_0x2d323d[_0x1e4162('0x339')][_0x1e4162('0x270')]);
                                        }));
                                }))) : _0x5a6d1f[_0x4a4a42('0x3b6')][_0x4a4a42('0x678')]['curRound'] = 0x1;
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x2f9')] = function () {
                        var _0x51bff2 = _0x3309ba;
                        logEvent(_0x51bff2('0x457'));
                        var _0xbf03da = _0x47c6fa[_0x51bff2('0x3b6')][_0x51bff2('0x37f')](_0x5a6d1f[_0x51bff2('0x3b6')][_0x51bff2('0x4ce')]['getGlobalCfg'](_0x51bff2('0x524')));
                        _0xbf03da[_0x51bff2('0x1dd')](_0x5a6d1f[_0x51bff2('0x3b6')]['DataMgr'][_0x51bff2('0x144')]) >= 0x0 && _0x4f9ba5[_0x51bff2('0x1d1')][_0x51bff2('0x400')] == 'QQAd' && _0x5a6d1f[_0x51bff2('0x3b6')][_0x51bff2('0x5d7')][_0x51bff2('0x280')](_0x2d323d[_0x51bff2('0x339')][_0x51bff2('0x4d9')]);
                        _0x5a6d1f['default'][_0x51bff2('0x5d7')][_0x51bff2('0x280')](_0x2d323d[_0x51bff2('0x339')]['GameUI'], 0x1);
                        if (_0x4f9ba5[_0x51bff2('0x1d1')][_0x51bff2('0x400')] == _0x4f9ba5[_0x51bff2('0x52b')][_0x51bff2('0x5a2')] || _0x4f9ba5[_0x51bff2('0x1d1')][_0x51bff2('0x400')] == _0x4f9ba5[_0x51bff2('0x52b')][_0x51bff2('0x576')]) {
                            var _0x40c229 = _0x5a6d1f[_0x51bff2('0x3b6')][_0x51bff2('0x4ce')][_0x51bff2('0xeb')](_0x51bff2('0x122'))
                                , _0x36289b = _0x47c6fa['default'][_0x51bff2('0x139')](0x0, 0x64);
                            console['log'](_0x40c229, _0x51bff2('0x63'), _0x36289b);
                            if (_0x36289b <= _0x40c229) {
                                var _0x4b945e = _0x5a6d1f[_0x51bff2('0x3b6')][_0x51bff2('0x4ce')][_0x51bff2('0x66c')](0x19) + '';
                                _0x50c5c0[_0x51bff2('0x3b6')][_0x51bff2('0x155')](_0x4b945e);
                            }
                        }
                        if (_0x4f9ba5[_0x51bff2('0x1d1')][_0x51bff2('0x400')] == _0x4f9ba5[_0x51bff2('0x52b')][_0x51bff2('0x1e0')]) { }
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x565')] = function () {
                        var _0x41f512 = _0x3309ba
                            , _0x4476e0 = this;
                        logEvent('end_lose\x20revenge'),
                            _0x4f9ba5[_0x41f512('0x1d1')][_0x41f512('0x400')] != _0x4f9ba5['PlatformType']['Game4399'] ? _0x47c6fa[_0x41f512('0x3b6')][_0x41f512('0x1e5')](_0x5a6d1f[_0x41f512('0x3b6')][_0x41f512('0x4ce')][_0x41f512('0x66c')](0x11), this, function (_0x1375e9, _0x1d9943, _0x2bc5f2) {
                                var _0x4d03f7 = _0x41f512;
                                _0x1d9943 === void 0x0 && (_0x1d9943 = null);
                                _0x2bc5f2 === void 0x0 && (_0x2bc5f2 = null);
                                if (_0x1d9943) {
                                    _0x5a6d1f[_0x4d03f7('0x3b6')][_0x4d03f7('0x5d7')][_0x4d03f7('0x46e')](_0x1d9943);
                                    return;
                                }
                                _0x1375e9 && (_0x5a6d1f['default'][_0x4d03f7('0x5d7')][_0x4d03f7('0x280')](_0x2d323d[_0x4d03f7('0x339')][_0x4d03f7('0x255')]),
                                    _0x5a6d1f[_0x4d03f7('0x3b6')][_0x4d03f7('0x33b')][_0x4d03f7('0x4e2')](_0x5a6d1f['default']['DataMgr'][_0x4d03f7('0x60')], _0x4476e0[_0x4d03f7('0x236')], _0x4476e0[_0x4d03f7('0x208')][_0x47c6fa[_0x4d03f7('0x3b6')][_0x4d03f7('0x139')](0x0, _0x4476e0[_0x4d03f7('0x208')][_0x4d03f7('0x4cc')] - 0x1)], _0x97562a[_0x4d03f7('0x281')][_0x4d03f7('0x4b6')][_0x4d03f7('0x579')]));
                            }) : _0x47c6fa[_0x41f512('0x3b6')][_0x41f512('0x56b')](this[_0x41f512('0x14b')][_0x41f512('0x484')](this));
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x14b')] = function (_0x2f8f4c) {
                        var _0x48553d = _0x3309ba;
                        if (!_0x2f8f4c)
                            return;
                        console['log']('代码:' + _0x2f8f4c['code'] + ',消息:' + _0x2f8f4c[_0x48553d('0x152')]);
                        if (_0x2f8f4c['code'] === 0x2710)
                            console[_0x48553d('0x5df')]('开始播放');
                        else {
                            if (_0x2f8f4c[_0x48553d('0x559')] === 0x2711)
                                console[_0x48553d('0x5df')](_0x48553d('0x543')),
                                    _0x5a6d1f['default'][_0x48553d('0x678')][_0x48553d('0x318')] <= 0x0 ? _0x5a6d1f[_0x48553d('0x3b6')]['DataMgr'][_0x48553d('0x318')] = 0x0 : (_0x5a6d1f[_0x48553d('0x3b6')][_0x48553d('0x678')][_0x48553d('0x318')]--,
                                        this[_0x48553d('0x6a2')](),
                                        _0x5a6d1f[_0x48553d('0x3b6')][_0x48553d('0x5d7')]['toUI'](_0x2d323d[_0x48553d('0x339')]['PlayGameUI']),
                                        _0x5a6d1f[_0x48553d('0x3b6')][_0x48553d('0x33b')][_0x48553d('0x4e2')](_0x5a6d1f[_0x48553d('0x3b6')][_0x48553d('0x678')][_0x48553d('0x60')], this['_trySkinId'], this['_skinList'][_0x47c6fa[_0x48553d('0x3b6')][_0x48553d('0x139')](0x0, this['_skinList'][_0x48553d('0x4cc')] - 0x1)], _0x97562a['GameEnum'][_0x48553d('0x4b6')]['Normal']));
                            else {
                                if (_0x5a6d1f[_0x48553d('0x3b6')]['DataMgr'][_0x48553d('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')][_0x3309ba('0x428')] = function () {
                        var _0x3e7e10 = _0x3309ba;
                        logEvent(_0x3e7e10('0x79')),
                            this['onClickBack']();
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')]['onClikShareVedio'] = function () {
                        var _0x35b60c = this;
                        setTimeout(function () {
                            var _0x50095b = _0x5985;
                            _0x50c5c0[_0x50095b('0x3b6')][_0x50095b('0x10c')](_0x35b60c[_0x50095b('0x656')]['bind'](_0x35b60c));
                        }, 0x1f4);
                    }
                    ,
                    _0x5a458b['prototype'][_0x3309ba('0x656')] = function () {
                        var _0xee1a90 = _0x3309ba;
                        this[_0xee1a90('0xef')][_0xee1a90('0x4b0')] = !![],
                            this['btnSharekVedio']['mouseEnabled'] = ![];
                    }
                    ,
                    _0x5a458b[_0x3309ba('0x64a')]['tweenLine'] = function (_0x41ded6) {
                        var _0x1f4f31 = _0x3309ba;
                        return _0x41ded6[_0x1f4f31('0x25c')] = 0x0,
                            Laya[_0x1f4f31('0x34d')]['to'](_0x41ded6, {
                                'scaleX': 0x1
                            }, 0x1f4),
                            !![];
                    }
                    ,
                    _0x5a458b['prototype'][_0x3309ba('0x50')] = function (_0x151394) {
                        var _0x2add96 = _0x3309ba;
                        _0x151394[_0x2add96('0x25c')] = 0x0,
                            _0x151394['scaleY'] = 0x0,
                            Laya[_0x2add96('0x34d')]['to'](_0x151394, {
                                'scaleX': 0x1,
                                'scaleY': 0x1
                            }, 0x1f4, Laya[_0x2add96('0x2a3')][_0x2add96('0x156')]);
                    }
                    ,
                    _0x5a458b;
            }(_0x19de91['ui'][_0x53f5b5('0x62')][_0x53f5b5('0x316')]);
        _0x2ad548[_0x53f5b5('0x3b6')] = _0x24283d;
    }
        , {
        '../../Platform': 0x3,
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        '../../utils/Utils': 0x38,
        './item/AdItem': 0x31
    }],
    0x24: [function (_0x313730, _0x6df3cf, _0x363fc0) {
        var _0x39f25f = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x363fc0, '__esModule', {
            'value': !![]
        });
        var _0x5cdec1 = _0x313730('../../ui/layaMaxUI')
            , _0x1424cf = _0x313730('../../XGame')
            , _0x4a0ab6 = _0x313730(_0x39f25f('0x61a'))
            , _0x1fc177 = _0x313730(_0x39f25f('0x69c'))
            , _0x21c808 = _0x313730(_0x39f25f('0x46'))
            , _0x19d9fa = _0x313730(_0x39f25f('0x34f'))
            , _0x10b96d = function (_0x2fc049) {
                var _0x1cdfe7 = _0x39f25f;
                __extends(_0x36b4ef, _0x2fc049);
                function _0x36b4ef() {
                    var _0xef33ab = _0x5985
                        , _0x59da60 = _0x2fc049['call'](this) || this;
                    return _0x59da60[_0xef33ab('0x1cd')] = 0x0,
                        _0x59da60;
                }
                return _0x36b4ef['prototype']['onAwake'] = function () {
                    var _0x3f9191 = _0x5985;
                    console[_0x3f9191('0x5df')](_0x1424cf['default'][_0x3f9191('0x678')]['isTmAdOpen'], '1111'),
                        _0x21c808[_0x3f9191('0x1d1')][_0x3f9191('0x400')] == _0x21c808[_0x3f9191('0x52b')][_0x3f9191('0x576')] && window['wx'] && _0x1424cf[_0x3f9191('0x3b6')][_0x3f9191('0x678')][_0x3f9191('0x436')] && (console[_0x3f9191('0x5df')](_0x3f9191('0x5ff')),
                            window['wx']['tmSDK'][_0x3f9191('0x5ca')](_0x3f9191('0x19f'))),
                        this[_0x3f9191('0x2a0')](_0x4a0ab6[_0x3f9191('0x4c3')][_0x3f9191('0xfe')], this['updateBar']),
                        this['regEvent'](_0x4a0ab6['EventEnum'][_0x3f9191('0x19c')], this['complete']),
                        this[_0x3f9191('0x2a0')](_0x4a0ab6[_0x3f9191('0x4c3')]['Res_Load_NetFail'], this[_0x3f9191('0x24e')]),
                        _0x1424cf[_0x3f9191('0x3b6')][_0x3f9191('0x60d')]['PreloadResources']();
                }
                    ,
                    _0x36b4ef['prototype']['netFailHandle'] = function () { }
                    ,
                    _0x36b4ef[_0x1cdfe7('0x64a')][_0x1cdfe7('0x20e')] = function (_0x1e818a) {
                        var _0x3216df = _0x1cdfe7;
                        _0x1e818a === void 0x0 && (_0x1e818a = 0x0);
                        if (_0x1e818a < 0x64)
                            return;
                        _0x21c808[_0x3216df('0x1d1')][_0x3216df('0x400')] == _0x21c808['PlatformType'][_0x3216df('0x576')] && window['wx'] && _0x1424cf['default']['DataMgr']['isTmAdOpen'] && (console[_0x3216df('0x5df')](_0x3216df('0x19a')),
                            window['wx'][_0x3216df('0x33a')]['sendLoadingLog'](_0x3216df('0x2d5'))),
                            _0x21c808[_0x3216df('0x1d1')][_0x3216df('0x400')] == _0x21c808[_0x3216df('0x52b')][_0x3216df('0x32b')] && (window['hg'] && (window['hg'][_0x3216df('0x411')] && window['hg'][_0x3216df('0x411')]({
                                'code': 0x0
                            }),
                                console[_0x3216df('0x5df')]('进度条结束加载'))),
                            _0x1424cf[_0x3216df('0x3b6')][_0x3216df('0x678')]['maxLevel'] <= 0x1 && _0x21c808[_0x3216df('0x1d1')][_0x3216df('0x400')] == _0x21c808[_0x3216df('0x52b')][_0x3216df('0x576')] ? (_0x1424cf[_0x3216df('0x3b6')][_0x3216df('0x33b')][_0x3216df('0x38b')][_0x3216df('0x5d3')]['active'] = ![],
                                _0x1424cf[_0x3216df('0x3b6')]['GameMgr'][_0x3216df('0x631')][_0x3216df('0x5d3')][_0x3216df('0x4ba')] = ![],
                                _0x1424cf[_0x3216df('0x3b6')][_0x3216df('0x33b')][_0x3216df('0x3b5')](),
                                _0x1424cf[_0x3216df('0x3b6')]['GameMgr']['Ball'] != null && (_0x1424cf[_0x3216df('0x3b6')]['GameMgr'][_0x3216df('0x34a')][_0x3216df('0x5d3')][_0x3216df('0x4ba')] = ![]),
                                _0x1424cf['default'][_0x3216df('0x5d7')]['toUI'](_0x1fc177['UIEnum'][_0x3216df('0x255')]),
                                _0x1424cf['default']['GameMgr'][_0x3216df('0x4e2')](0x1, 0x7, 0xc, _0x19d9fa['GameEnum'][_0x3216df('0x4b6')][_0x3216df('0x579')], _0x1424cf['default'][_0x3216df('0x678')][_0x3216df('0x486')], !![])) : _0x1424cf['default'][_0x3216df('0x5d7')]['toUI'](_0x1fc177[_0x3216df('0x339')][_0x3216df('0x5b4')]);
                    }
                    ,
                    _0x36b4ef[_0x1cdfe7('0x64a')][_0x1cdfe7('0x28b')] = function (_0x375897) {
                        var _0x565fcb = _0x1cdfe7;
                        _0x375897 > 0x1 && (_0x375897 = 0x1),
                            this['progress'][_0x565fcb('0x52c')] = _0x375897;
                    }
                    ,
                    _0x36b4ef[_0x1cdfe7('0x64a')][_0x1cdfe7('0x151')] = function () { }
                    ,
                    _0x36b4ef[_0x1cdfe7('0x64a')][_0x1cdfe7('0x42')] = function () {
                        var _0xf30f64 = _0x1cdfe7;
                        _0x2fc049[_0xf30f64('0x64a')][_0xf30f64('0x42')]['call'](this);
                    }
                    ,
                    _0x36b4ef;
            }(_0x5cdec1['ui']['view']['LoadingUIUI']);
        _0x363fc0['default'] = _0x10b96d;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36
    }],
    0x25: [function (_0x4680a8, _0x4b6aac, _0x2edaa6) {
        var _0x2ba9ab = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x2edaa6, _0x2ba9ab('0xb8'), {
            'value': !![]
        });
        var _0x4733b9 = _0x4680a8(_0x2ba9ab('0x662'))
            , _0x3f6338 = _0x4680a8(_0x2ba9ab('0xce'))
            , _0x51fe6e = _0x4680a8(_0x2ba9ab('0x69c'))
            , _0x110c77 = function (_0x39200f) {
                var _0x20eef8 = _0x2ba9ab;
                __extends(_0x5045c1, _0x39200f);
                function _0x5045c1() {
                    var _0x440c5b = _0x5985
                        , _0x366e73 = _0x39200f[_0x440c5b('0x324')](this) || this;
                    return _0x366e73['showMaskBg'](0x0),
                        _0x366e73;
                }
                return _0x5045c1[_0x20eef8('0x64a')]['onEnable'] = function () {
                    var _0x54be67 = _0x20eef8
                        , _0x14acda = this;
                    Laya['timer'][_0x54be67('0x55')](0x1, this, this[_0x54be67('0x49')]),
                        setTimeout(function () {
                            var _0x8f9ec8 = _0x54be67;
                            _0x14acda[_0x8f9ec8('0x5af')]();
                        }, 0x3a98);
                }
                    ,
                    _0x5045c1['prototype'][_0x20eef8('0x5af')] = function () {
                        var _0x2289d7 = _0x20eef8;
                        Laya['timer'][_0x2289d7('0x1fb')](this),
                            _0x3f6338['default'][_0x2289d7('0x5d7')]['closeUI'](_0x51fe6e['UIEnum']['LoadView']);
                    }
                    ,
                    _0x5045c1[_0x20eef8('0x64a')]['loopLoadIcon'] = function () {
                        var _0x26474a = _0x20eef8;
                        this[_0x26474a('0x68a')][_0x26474a('0x4b1')]++,
                            this[_0x26474a('0x68a')][_0x26474a('0x4b1')] >= 0x2d0 && (this['loadIcon'][_0x26474a('0x4b1')] = 0x0);
                    }
                    ,
                    _0x5045c1[_0x20eef8('0x64a')][_0x20eef8('0x5dc')] = function () { }
                    ,
                    _0x5045c1;
            }(_0x4733b9['ui'][_0x2ba9ab('0x62')][_0x2ba9ab('0xc')]);
        _0x2edaa6[_0x2ba9ab('0x3b6')] = _0x110c77;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36
    }],
    0x26: [function (_0x497698, _0x4f443a, _0x1dc6d0) {
        var _0x4e7d18 = _0x4b7fcf;
        'use strict';
        Object[_0x4e7d18('0x351')](_0x1dc6d0, '__esModule', {
            'value': !![]
        });
        var _0xc5462 = _0x497698(_0x4e7d18('0x662'))
            , _0x14d939 = _0x497698(_0x4e7d18('0xce'))
            , _0x4703bc = _0x497698('../../utils/Tools')
            , _0x571e87 = _0x497698(_0x4e7d18('0x69c'))
            , _0x542db4 = _0x497698('../../enum/GameConst')
            , _0x588183 = function (_0x576887) {
                var _0x1daca4 = _0x4e7d18;
                __extends(_0x2551b6, _0x576887);
                function _0x2551b6(_0x5d909e) {
                    var _0x46a75f = _0x5985
                        , _0x3c8b4d = _0x576887[_0x46a75f('0x324')](this) || this;
                    return _0x3c8b4d[_0x46a75f('0x333')] = {},
                        _0x3c8b4d[_0x46a75f('0x2d3')] = {
                            0x0: [0xf, -0xf],
                            0x1: [-0x1e, -0x3c],
                            0x2: [-0x48, -0x6c],
                            0x3: [-0x73, -0x9b],
                            0x4: [-0xa5, -0xc8],
                            0x5: [-0xd2, -0xf5],
                            0x6: [-0xff, -0x122],
                            0x7: [-0x12c, -0x14f]
                        },
                        _0x3c8b4d[_0x46a75f('0x3fb')] = 0x0,
                        _0x3c8b4d['_flag'] = ![],
                        _0x3c8b4d[_0x46a75f('0x34e')] = -0x1,
                        _0x3c8b4d['lingqu'] = _0x46a75f('0x16f'),
                        _0x5d909e['adunit'] = _0x14d939[_0x46a75f('0x3b6')][_0x46a75f('0x4ce')]['getAdCfg'](0x1),
                        _0x3c8b4d;
                }
                return _0x2551b6[_0x1daca4('0x64a')][_0x1daca4('0x4fc')] = function () {
                    var _0x9c218 = _0x1daca4;
                    this[_0x9c218('0x218')](),
                        this[_0x9c218('0x1d5')](),
                        this[_0x9c218('0x3fb')] = Laya[_0x9c218('0x5ac')][_0x9c218('0x479')] / 0x32,
                        Laya[_0x9c218('0x5ac')][_0x9c218('0x55')](0x1, this, this[_0x9c218('0x3cc')]),
                        _0x4703bc[_0x9c218('0x3b6')]['showBannerMoveBtn'](this, this['btnBack'], Laya[_0x9c218('0x150')]['displayHeight'] - 0xb4, 0x3ee);
                }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')][_0x1daca4('0x5dc')] = function () {
                        var _0x646d24 = _0x1daca4;
                        Laya[_0x646d24('0x5ac')][_0x646d24('0x1fb')](this);
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')][_0x1daca4('0x218')] = function () {
                        var _0x474866 = _0x1daca4;
                        this[_0x474866('0x4de')][_0x474866('0x338')] = _0x14d939[_0x474866('0x3b6')][_0x474866('0x4ce')][_0x474866('0x235')](0x27, _0x542db4['GameConst'][_0x474866('0x64d')]),
                            this[_0x474866('0x6a')][_0x474866('0x338')] = _0x14d939['default'][_0x474866('0x4ce')][_0x474866('0x235')](0x23, _0x542db4[_0x474866('0x1d1')]['Language']);
                        var _0x2bbb9a = _0x14d939[_0x474866('0x3b6')]['CfgMgr'][_0x474866('0xeb')]('RateGem')[_0x474866('0x1f8')]('|')
                            , _0x522c29 = new Array();
                        for (var _0x1f7ee5 = 0x0; _0x1f7ee5 < _0x2bbb9a['length']; _0x1f7ee5++) {
                            _0x522c29 = _0x2bbb9a[_0x1f7ee5][_0x474866('0x1f8')](','),
                                this[_0x474866('0x333')][_0x1f7ee5] = [Number(_0x522c29[0x0]), Number(_0x522c29[0x1])];
                        }
                        this[_0x474866('0x650')][_0x474866('0x338')] = this[_0x474866('0x333')][0x0][0x1][_0x474866('0xcc')](),
                            this[_0x474866('0x27')]['text'] = this['_rewardArr'][0x2][0x1]['toString'](),
                            this[_0x474866('0x23e')]['text'] = this[_0x474866('0x333')][0x3][0x1]['toString'](),
                            this[_0x474866('0xf7')][_0x474866('0x338')] = this[_0x474866('0x333')][0x4][0x1][_0x474866('0xcc')](),
                            this['txtGem7'][_0x474866('0x338')] = this[_0x474866('0x333')][0x6][0x1][_0x474866('0xcc')](),
                            this['txtGem8'][_0x474866('0x338')] = this[_0x474866('0x333')][0x7][0x1][_0x474866('0xcc')](),
                            this[_0x474866('0x3b9')][_0x474866('0x5bf')] = ![],
                            this[_0x474866('0x1ae')][_0x474866('0x338')] = _0x4703bc['default'][_0x474866('0x456')](_0x14d939[_0x474866('0x3b6')][_0x474866('0x678')][_0x474866('0xf')]),
                            _0x542db4[_0x474866('0x1d1')][_0x474866('0x400')] == _0x542db4[_0x474866('0x52b')][_0x474866('0x64')] && this[_0x474866('0x6a2')](),
                            this['btnBack'][_0x474866('0x338')] = _0x14d939[_0x474866('0x3b6')][_0x474866('0x4ce')][_0x474866('0x235')](0x13, _0x542db4[_0x474866('0x1d1')][_0x474866('0x64d')]);
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')][_0x1daca4('0x1d5')] = function () {
                        var _0x34edce = _0x1daca4;
                        this[_0x34edce('0x51a')](this[_0x34edce('0xe1')], this[_0x34edce('0x2f9')]),
                            this['regClick'](this[_0x34edce('0xe8')], this[_0x34edce('0x52e')]),
                            this['regClick'](this[_0x34edce('0x3b9')], this[_0x34edce('0x597')]);
                    }
                    ,
                    _0x2551b6['prototype'][_0x1daca4('0x2f9')] = function () {
                        var _0xb724f9 = _0x1daca4;
                        logEvent(_0xb724f9('0x31d')),
                            _0x14d939[_0xb724f9('0x3b6')][_0xb724f9('0x5d7')][_0xb724f9('0x280')](_0x571e87[_0xb724f9('0x339')][_0xb724f9('0x5b4')]);
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')]['changeAdIcon'] = function () {
                        var _0x118644 = _0x1daca4
                            , _0x4704ed = _0x14d939['default']['DataMgr'][_0x118644('0x318')];
                        console[_0x118644('0x5df')]('剩余次数', _0x4704ed),
                            _0x4704ed <= 0x0 && (this[_0x118644('0xe8')][_0x118644('0x4b0')] = !![]);
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')]['onClickVideo'] = function () {
                        var _0x3b8483 = _0x1daca4;
                        logEvent(_0x3b8483('0x203')),
                            _0x542db4[_0x3b8483('0x1d1')][_0x3b8483('0x400')] != _0x542db4[_0x3b8483('0x52b')][_0x3b8483('0x64')] ? _0x4703bc[_0x3b8483('0x3b6')][_0x3b8483('0x1e5')](_0x14d939[_0x3b8483('0x3b6')][_0x3b8483('0x4ce')][_0x3b8483('0x66c')](0xa), this, this['watchTvCallback'][_0x3b8483('0x484')](this)) : _0x4703bc[_0x3b8483('0x3b6')][_0x3b8483('0x56b')](this['watch4399Callback']['bind'](this));
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')]['watch4399Callback'] = function (_0x4c9054) {
                        var _0x2977db = _0x1daca4;
                        if (!_0x4c9054)
                            return;
                        console['log'](_0x2977db('0x3e') + _0x4c9054[_0x2977db('0x559')] + _0x2977db('0x2f6') + _0x4c9054[_0x2977db('0x152')]);
                        if (_0x4c9054[_0x2977db('0x559')] === 0x2710)
                            console[_0x2977db('0x5df')]('开始播放');
                        else {
                            if (_0x4c9054[_0x2977db('0x559')] === 0x2711)
                                console['log'](_0x2977db('0x543')),
                                    _0x14d939[_0x2977db('0x3b6')][_0x2977db('0x678')][_0x2977db('0x318')] <= 0x0 ? _0x14d939[_0x2977db('0x3b6')][_0x2977db('0x678')]['adRemainTimes'] = 0x0 : (_0x14d939[_0x2977db('0x3b6')][_0x2977db('0x678')]['adRemainTimes']--,
                                        this[_0x2977db('0x6a2')](),
                                        this[_0x2977db('0x3fb')] = 0x5,
                                        this[_0x2977db('0x3b9')][_0x2977db('0x5bf')] = !![],
                                        this[_0x2977db('0xe8')][_0x2977db('0x5bf')] = ![],
                                        this[_0x2977db('0xe1')][_0x2977db('0x5bf')] = ![]);
                            else {
                                if (_0x14d939[_0x2977db('0x3b6')][_0x2977db('0x678')][_0x2977db('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')]['onClickStop'] = function () {
                        var _0x427be1 = _0x1daca4
                            , _0x61f929 = this;
                        if (this['_flag'] == !![]) {
                            var _0x59f0b5 = this[_0x427be1('0x2cb')][this['_index']][0x1]
                                , _0x51e288 = this['_rewardArr'][_0x59f0b5][0x1];
                            if (_0x59f0b5 == 0x1 || _0x59f0b5 == 0x5) { } else
                                _0x14d939[_0x427be1('0x3b6')][_0x427be1('0x678')][_0x427be1('0x45')](_0x51e288),
                                    _0x14d939[_0x427be1('0x3b6')][_0x427be1('0x5d7')][_0x427be1('0x46e')](_0x14d939[_0x427be1('0x3b6')][_0x427be1('0x4ce')]['getLangById'](0x25, _0x542db4[_0x427be1('0x1d1')]['Language']) + '+' + _0x51e288);
                            setTimeout(function () {
                                var _0x20ec90 = _0x427be1;
                                _0x14d939[_0x20ec90('0x3b6')]['UIMgr'][_0x20ec90('0x280')](_0x571e87['UIEnum'][_0x20ec90('0x5b4')]);
                            }, 0x1f4);
                        } else {
                            this['_flag'] = !![],
                                this[_0x427be1('0x3b9')]['visible'] = ![],
                                Laya[_0x427be1('0x5ac')][_0x427be1('0x466')](this, this['onUpdataRotate']),
                                this[_0x427be1('0x34e')] = this[_0x427be1('0x34b')](),
                                console[_0x427be1('0x5df')](_0x427be1('0x7b'), this[_0x427be1('0x34e')], this[_0x427be1('0x2cb')]);
                            var _0x51b943 = this[_0x427be1('0x2d3')][this[_0x427be1('0x2cb')][this[_0x427be1('0x34e')]][0x1]]
                                , _0x24736e = _0x4703bc[_0x427be1('0x3b6')][_0x427be1('0x139')](_0x51b943[0x1], _0x51b943[0x0]) + 0x168 * 0x3;
                            Laya[_0x427be1('0x34d')]['to'](this[_0x427be1('0x1d9')], {
                                'rotation': _0x24736e
                            }, 0x2710, Laya[_0x427be1('0x2a3')][_0x427be1('0x2d7')], Laya['Handler'][_0x427be1('0x5fb')](this, function () {
                                var _0x5ac7c5 = _0x427be1;
                                _0x61f929[_0x5ac7c5('0x4de')][_0x5ac7c5('0x338')] = _0x14d939[_0x5ac7c5('0x3b6')][_0x5ac7c5('0x4ce')][_0x5ac7c5('0x235')](0xa, _0x542db4[_0x5ac7c5('0x1d1')]['Language']),
                                    _0x61f929[_0x5ac7c5('0x3b9')][_0x5ac7c5('0x5bf')] = !![],
                                    _0x61f929[_0x5ac7c5('0x1d9')][_0x5ac7c5('0x4b1')] = _0x61f929[_0x5ac7c5('0x1d9')][_0x5ac7c5('0x4b1')] % 0x168;
                            }));
                        }
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')][_0x1daca4('0x3cc')] = function () {
                        var _0x74b76e = _0x1daca4;
                        this[_0x74b76e('0x1d9')]['rotation'] += this[_0x74b76e('0x3fb')];
                        var _0x3bd404 = this[_0x74b76e('0x1d9')][_0x74b76e('0x4b1')] - 0x168;
                        _0x3bd404 >= 0x0 && (this[_0x74b76e('0x1d9')][_0x74b76e('0x4b1')] = _0x3bd404);
                    }
                    ,
                    _0x2551b6['prototype'][_0x1daca4('0x21d')] = function (_0x5e8703, _0x14c6b9, _0x5c7216) {
                        var _0x38525f = _0x1daca4;
                        _0x14c6b9 === void 0x0 && (_0x14c6b9 = null);
                        _0x5c7216 === void 0x0 && (_0x5c7216 = null);
                        if (_0x14c6b9) {
                            _0x14d939[_0x38525f('0x3b6')][_0x38525f('0x5d7')][_0x38525f('0x46e')](_0x14c6b9);
                            return;
                        }
                        _0x5e8703 ? (this[_0x38525f('0x3fb')] = 0x5,
                            this[_0x38525f('0x3b9')][_0x38525f('0x5bf')] = !![],
                            this[_0x38525f('0xe8')][_0x38525f('0x5bf')] = ![],
                            this[_0x38525f('0xe1')][_0x38525f('0x5bf')] = ![]) : (_0x14d939[_0x38525f('0x3b6')][_0x38525f('0x5d7')]['showTips'](_0x38525f('0x3dc')),
                                this[_0x38525f('0xe8')]['visible'] = !![],
                                this[_0x38525f('0xe1')][_0x38525f('0x5bf')] = !![]);
                    }
                    ,
                    _0x2551b6[_0x1daca4('0x64a')]['randomReward'] = function () {
                        var _0x864eca = _0x1daca4;
                        if (this[_0x864eca('0x2cb')] == null) {
                            this['_order'] = new Array();
                            for (var _0x110160 = 0x0; _0x110160 < 0x8; _0x110160++) {
                                var _0x978c10 = this[_0x864eca('0x333')][_0x110160]
                                    , _0x462644 = this[_0x864eca('0x2d3')][_0x110160];
                                this[_0x864eca('0x2cb')][_0x864eca('0xff')]([_0x978c10[0x0], _0x110160]);
                            }
                            this[_0x864eca('0x2cb')]['sort'](function (_0x5714b4, _0x5f27fc) {
                                if (_0x5714b4[0x0] < _0x5f27fc[0x0])
                                    return -0x1;
                                else
                                    return _0x5714b4[0x0] > _0x5f27fc[0x0] ? 0x1 : 0x0;
                            }),
                                this[_0x864eca('0x5a6')] = 0x0,
                                this[_0x864eca('0x1f7')] = new Array();
                            for (var _0x110160 = 0x0; _0x110160 < this['_order'][_0x864eca('0x4cc')]; _0x110160++) {
                                var _0x252d3c = this[_0x864eca('0x2cb')][_0x110160];
                                this[_0x864eca('0x1f7')][_0x864eca('0xff')](this[_0x864eca('0x5a6')]),
                                    this['_randomTotalNum'] += _0x252d3c[0x0];
                            }
                        }
                        if (this[_0x864eca('0x5a6')] <= 0x0)
                            return 0x0;
                        var _0x17197f = _0x4703bc['default']['random'](0x1, this[_0x864eca('0x5a6')])
                            , _0x2936c5 = 0x0;
                        for (var _0x110160 = 0x0; _0x110160 < this['_randomArr'][_0x864eca('0x4cc')]; _0x110160++) {
                            this[_0x864eca('0x1f7')][_0x110160] > _0x2936c5 && this[_0x864eca('0x1f7')][_0x110160] < _0x17197f && (_0x2936c5 = this[_0x864eca('0x1f7')][_0x110160]);
                        }
                        var _0x171af1 = this[_0x864eca('0x1f7')][_0x864eca('0x1dd')](_0x2936c5);
                        return _0x171af1;
                    }
                    ,
                    _0x2551b6;
            }(_0xc5462['ui'][_0x4e7d18('0x62')][_0x4e7d18('0x5ec')]);
        _0x1dc6d0['default'] = _0x588183;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37
    }],
    0x27: [function (_0x1611c3, _0x4cfb9d, _0x19c0bf) {
        var _0x5bcffa = _0x4b7fcf;
        'use strict';
        Object[_0x5bcffa('0x351')](_0x19c0bf, _0x5bcffa('0xb8'), {
            'value': !![]
        });
        var _0x36fac2 = _0x1611c3(_0x5bcffa('0x662'))
            , _0x2fb8cd = _0x1611c3(_0x5bcffa('0xce'))
            , _0x14c6d5 = _0x1611c3(_0x5bcffa('0x69c'))
            , _0x2d6db8 = _0x1611c3(_0x5bcffa('0x46'))
            , _0x4cb5aa = _0x1611c3(_0x5bcffa('0x1fa'))
            , _0x3b9ed1 = _0x1611c3(_0x5bcffa('0x3cf'))
            , _0x25459f = _0x1611c3('../../enum/EventEnum')
            , _0x115963 = function (_0x14ecb1) {
                var _0x30a3d0 = _0x5bcffa;
                __extends(_0x461a26, _0x14ecb1);
                function _0x461a26() {
                    var _0x46098d = _0x5985;
                    return _0x14ecb1[_0x46098d('0x324')](this) || this;
                }
                return _0x461a26[_0x30a3d0('0x64a')][_0x30a3d0('0x488')] = function () {
                    var _0x1fe230 = _0x30a3d0;
                    console['log'](_0x1fe230('0x5b6')),
                        this[_0x1fe230('0x218')](),
                        this[_0x1fe230('0x1d5')]();
                }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')][_0x30a3d0('0x218')] = function () {
                        var _0x37a7d5 = _0x30a3d0
                            , _0x469acc = this;
                        _0x2d6db8[_0x37a7d5('0x1d1')]['Platform'] == _0x2d6db8[_0x37a7d5('0x52b')][_0x37a7d5('0x576')] && window['wx'] && window['wx']['tmSDK']['getFlowConfig']({
                            'positionId': _0x37a7d5('0x2b5')
                        })[_0x37a7d5('0x210')](function (_0x18e21c) {
                            var _0x3867f4 = _0x37a7d5;
                            console[_0x3867f4('0x5df')]('该广告位当前配置', _0x18e21c);
                            if (!_0x18e21c)
                                return;
                            _0x469acc[_0x3867f4('0xa4')](_0x18e21c);
                        });
                    }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')][_0x30a3d0('0xa4')] = function (_0x21af22) {
                        var _0x2dae2c = _0x30a3d0;
                        console['log']('ADLIst:>>>>>>>', _0x21af22),
                            this[_0x2dae2c('0x1f1')](),
                            this['itemArr'] = [];
                        var _0x5588b4 = _0x21af22[_0x2dae2c('0x519')];
                        for (var _0x3dfcfc = 0x0; _0x3dfcfc < 0x9; _0x3dfcfc++) {
                            if (!_0x5588b4[_0x3dfcfc])
                                return;
                            var _0x5b8d4c = new _0x4cb5aa['default']();
                            this[_0x2dae2c('0x320')][_0x2dae2c('0x5')](_0x5b8d4c[_0x2dae2c('0x5d3')]),
                                this[_0x2dae2c('0x3e4')][_0x2dae2c('0xff')](_0x5b8d4c[_0x2dae2c('0x5d3')]),
                                _0x5b8d4c[_0x2dae2c('0x303')](_0x5588b4[_0x3dfcfc][_0x2dae2c('0x67b')], _0x5588b4[_0x3dfcfc][_0x2dae2c('0x1fe')], _0x5588b4[_0x3dfcfc][_0x2dae2c('0x19e')]);
                        }
                        _0x3b9ed1[_0x2dae2c('0x3b6')][_0x2dae2c('0x4c7')](this['itemArr'], 0x3, 0x0, 0x0, 0x1e, 0xa);
                    }
                    ,
                    _0x461a26['prototype'][_0x30a3d0('0x37c')] = function (_0x4cbe3b) {
                        var _0x3c8f2c = _0x30a3d0
                            , _0x4f9d89 = [];
                        for (var _0x4f38f9 = 0x0; _0x4f38f9 < 0x9; _0x4f38f9++) {
                            var _0x910592 = Math[_0x3c8f2c('0x80')](Math['random']() * _0x4cbe3b['length']);
                            _0x4f9d89[_0x3c8f2c('0xff')](_0x4cbe3b[_0x910592]),
                                _0x4cbe3b[_0x3c8f2c('0x6ba')](_0x910592, 0x1);
                        }
                        return console[_0x3c8f2c('0x5df')](_0x3c8f2c('0x5b0'), _0x4f9d89),
                            _0x4f9d89;
                    }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')]['initEvent'] = function () {
                        var _0xfc7f97 = _0x30a3d0;
                        this[_0xfc7f97('0x51a')](this[_0xfc7f97('0x349')], this[_0xfc7f97('0x356')]),
                            _0x2fb8cd[_0xfc7f97('0x3b6')]['EventMgr']['on'](_0x25459f['EventEnum'][_0xfc7f97('0x4bf')], this, this['updateItem']);
                    }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')][_0x30a3d0('0x356')] = function () {
                        var _0x1eb757 = _0x30a3d0;
                        _0x2fb8cd['default'][_0x1eb757('0x5d7')][_0x1eb757('0x280')](_0x14c6d5[_0x1eb757('0x339')][_0x1eb757('0x5b4')]);
                    }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')][_0x30a3d0('0x1f1')] = function () {
                        var _0x836d79 = _0x30a3d0;
                        if (!this[_0x836d79('0x3e4')])
                            return;
                        this['itemArr'][_0x836d79('0x596')](function (_0x2ab5de) {
                            var _0x167ab4 = _0x836d79;
                            _0x2ab5de[_0x167ab4('0x594')]();
                        }),
                            this[_0x836d79('0x3e4')]['length'] = 0x0,
                            this['itemArr'] = null;
                    }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')]['onDisable'] = function () { }
                    ,
                    _0x461a26[_0x30a3d0('0x64a')][_0x30a3d0('0x42')] = function () {
                        var _0x4f4fc8 = _0x30a3d0;
                        _0x14ecb1[_0x4f4fc8('0x64a')][_0x4f4fc8('0x42')][_0x4f4fc8('0x324')](this);
                    }
                    ,
                    _0x461a26;
            }(_0x36fac2['ui'][_0x5bcffa('0x62')][_0x5bcffa('0x5cd')]);
        _0x19c0bf[_0x5bcffa('0x3b6')] = _0x115963;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Utils': 0x38,
        './item/AdItem': 0x31
    }],
    0x28: [function (_0x38633d, _0xe2272c, _0x34d397) {
        var _0xdddd99 = _0x4b7fcf;
        'use strict';
        Object[_0xdddd99('0x351')](_0x34d397, _0xdddd99('0xb8'), {
            'value': !![]
        });
        var _0x3b0a49 = _0x38633d(_0xdddd99('0x662'))
            , _0x19522b = _0x38633d(_0xdddd99('0xce'))
            , _0x489f7c = _0x38633d('../../utils/Tools')
            , _0x146f48 = _0x38633d(_0xdddd99('0x69c'))
            , _0x58000a = _0x38633d(_0xdddd99('0x46'))
            , _0x32e4f5 = function (_0x2f78d6) {
                var _0x249e93 = _0xdddd99;
                __extends(_0x3c5b5c, _0x2f78d6);
                function _0x3c5b5c() {
                    var _0x2d1448 = _0x5985
                        , _0x558c22 = _0x2f78d6['call'](this) || this;
                    return _0x558c22[_0x2d1448('0xac')] = 0x0,
                        _0x558c22;
                }
                return _0x3c5b5c[_0x249e93('0x64a')][_0x249e93('0x4fc')] = function () {
                    var _0x1e6273 = _0x249e93;
                    this[_0x1e6273('0x218')](),
                        this[_0x1e6273('0x1d5')]();
                }
                    ,
                    _0x3c5b5c['prototype'][_0x249e93('0x218')] = function () {
                        var _0x210461 = _0x249e93;
                        this[_0x210461('0x108')][_0x210461('0x5bf')] = ![],
                            this[_0x210461('0x39c')]['visible'] = ![];
                    }
                    ,
                    _0x3c5b5c[_0x249e93('0x64a')]['initEvent'] = function () {
                        var _0x4d98c6 = _0x249e93;
                        Laya[_0x4d98c6('0x5ac')][_0x4d98c6('0x55')](0x1, this, this[_0x4d98c6('0x54e')]),
                            this[_0x4d98c6('0x51a')](this[_0x4d98c6('0x3a5')], this['videoClickHandle']),
                            this[_0x4d98c6('0x51a')](this['receivebtn'], this['receiveClickHandle']),
                            this[_0x4d98c6('0x51a')](this['backbtn'], this[_0x4d98c6('0x336')]);
                    }
                    ,
                    _0x3c5b5c[_0x249e93('0x64a')][_0x249e93('0xbd')] = function () { }
                    ,
                    _0x3c5b5c[_0x249e93('0x64a')][_0x249e93('0x21d')] = function (_0x42d257) {
                        var _0x3b627a = _0x249e93;
                        if (_0x42d257) {
                            this[_0x3b627a('0x3a5')][_0x3b627a('0x5bf')] = ![],
                                this[_0x3b627a('0x39c')]['visible'] = !![],
                                this[_0x3b627a('0x108')][_0x3b627a('0x5bf')] = !![],
                                this['box'][_0x3b627a('0x3c4')] = 'box/chest02.png';
                            var _0x48d061 = _0x489f7c['default'][_0x3b627a('0x37f')](_0x19522b[_0x3b627a('0x3b6')]['CfgMgr'][_0x3b627a('0xeb')]('BoxGold'));
                            this['_getGold'] = _0x489f7c[_0x3b627a('0x3b6')][_0x3b627a('0x139')](_0x48d061[0x0], _0x48d061[0x1]),
                                this[_0x3b627a('0xf')]['text'] = '+' + this[_0x3b627a('0xac')];
                        } else
                            _0x19522b[_0x3b627a('0x3b6')][_0x3b627a('0x5d7')][_0x3b627a('0x46e')](_0x3b627a('0x624'));
                    }
                    ,
                    _0x3c5b5c[_0x249e93('0x64a')][_0x249e93('0x2c0')] = function () {
                        var _0x3b8cf1 = _0x249e93;
                        _0x19522b[_0x3b8cf1('0x3b6')][_0x3b8cf1('0x5d7')][_0x3b8cf1('0x46e')](_0x19522b[_0x3b8cf1('0x3b6')][_0x3b8cf1('0x4ce')][_0x3b8cf1('0x235')](0x25, _0x58000a['GameConst']['Language']) + '+' + this[_0x3b8cf1('0xac')]),
                            _0x19522b[_0x3b8cf1('0x3b6')][_0x3b8cf1('0x678')][_0x3b8cf1('0x45')](this[_0x3b8cf1('0xac')]),
                            _0x19522b[_0x3b8cf1('0x3b6')][_0x3b8cf1('0x5d7')]['toUI'](_0x146f48[_0x3b8cf1('0x339')]['GameUI']);
                    }
                    ,
                    _0x3c5b5c[_0x249e93('0x64a')][_0x249e93('0x54e')] = function () {
                        var _0x5278e4 = _0x249e93;
                        this[_0x5278e4('0x62c')][_0x5278e4('0x4b1')] += 0x1;
                    }
                    ,
                    _0x3c5b5c[_0x249e93('0x64a')][_0x249e93('0x336')] = function () {
                        var _0x3113d8 = _0x249e93;
                        _0x19522b['default'][_0x3113d8('0x5d7')][_0x3113d8('0x280')](_0x146f48['UIEnum'][_0x3113d8('0x5b4')]);
                    }
                    ,
                    _0x3c5b5c['prototype']['close'] = function () {
                        var _0x511629 = _0x249e93;
                        Laya[_0x511629('0x5ac')][_0x511629('0x466')](this, this[_0x511629('0x54e')]),
                            _0x2f78d6['prototype'][_0x511629('0x42')][_0x511629('0x324')](this);
                    }
                    ,
                    _0x3c5b5c;
            }(_0x3b0a49['ui'][_0xdddd99('0x62')]['OpenBoxUIUI']);
        _0x34d397[_0xdddd99('0x3b6')] = _0x32e4f5;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37
    }],
    0x29: [function (_0x5394aa, _0x4829de, _0xffc1c2) {
        var _0x102963 = _0x4b7fcf;
        'use strict';
        Object[_0x102963('0x351')](_0xffc1c2, _0x102963('0xb8'), {
            'value': !![]
        });
        var _0x40409d = _0x5394aa(_0x102963('0x662'))
            , _0x3d2a1b = _0x5394aa(_0x102963('0xce'))
            , _0x2875f2 = _0x5394aa(_0x102963('0x69c'))
            , _0xbc2746 = _0x5394aa(_0x102963('0x20c'))
            , _0x543207 = _0x5394aa(_0x102963('0x142'))
            , _0x17f141 = _0x5394aa(_0x102963('0x61a'))
            , _0x5bf04a = _0x5394aa('../../enum/GameConst')
            , _0x10485d = function (_0x5b948c) {
                var _0x371adc = _0x102963;
                __extends(_0x56cae0, _0x5b948c);
                function _0x56cae0(_0x7fbe27) {
                    var _0x4b7ebf = _0x5985
                        , _0x590efd = _0x5b948c[_0x4b7ebf('0x324')](this) || this;
                    return _0x590efd[_0x4b7ebf('0x4a9')] = [],
                        _0x590efd[_0x4b7ebf('0x11e')] = null,
                        _0x590efd['_openCount'] = 0x3,
                        _0x590efd[_0x4b7ebf('0x333')] = [],
                        _0x590efd[_0x4b7ebf('0x1f7')] = null,
                        _0x590efd[_0x4b7ebf('0x5a6')] = 0x0,
                        _0x590efd[_0x4b7ebf('0x14d')] = 0x0,
                        _0x590efd[_0x4b7ebf('0x3b2')] = null,
                        _0x7fbe27[_0x4b7ebf('0x123')] = _0x3d2a1b[_0x4b7ebf('0x3b6')][_0x4b7ebf('0x4ce')][_0x4b7ebf('0x66c')](0x8),
                        _0x590efd;
                }
                return _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x4fc')] = function () {
                    var _0x1f7d3a = _0x371adc;
                    this[_0x1f7d3a('0xf')][_0x1f7d3a('0x338')] = _0xbc2746[_0x1f7d3a('0x3b6')][_0x1f7d3a('0x456')](_0x3d2a1b['default'][_0x1f7d3a('0x678')]['coinCount']),
                        this[_0x1f7d3a('0x218')](),
                        this[_0x1f7d3a('0x1d5')]();
                }
                    ,
                    _0x56cae0[_0x371adc('0x64a')]['initView'] = function () {
                        var _0x4fae4b = _0x371adc;
                        this[_0x4fae4b('0x58d')][_0x4fae4b('0x338')] = _0x3d2a1b['default'][_0x4fae4b('0x4ce')][_0x4fae4b('0x235')](0x1f, _0x5bf04a[_0x4fae4b('0x1d1')]['Language']),
                            this[_0x4fae4b('0xe6')][_0x4fae4b('0x338')] = _0x3d2a1b['default']['CfgMgr'][_0x4fae4b('0x235')](0x20, _0x5bf04a[_0x4fae4b('0x1d1')][_0x4fae4b('0x64d')]),
                            this[_0x4fae4b('0x191')][_0x4fae4b('0x338')] = _0x3d2a1b[_0x4fae4b('0x3b6')][_0x4fae4b('0x4ce')][_0x4fae4b('0x235')](0x21, _0x5bf04a[_0x4fae4b('0x1d1')][_0x4fae4b('0x64d')]),
                            this[_0x4fae4b('0x3f8')][_0x4fae4b('0x338')] = _0x3d2a1b[_0x4fae4b('0x3b6')]['CfgMgr'][_0x4fae4b('0x235')](0x13, _0x5bf04a[_0x4fae4b('0x1d1')]['Language']);
                        for (var _0x4a8112 = 0x0; _0x4a8112 < 0x9; _0x4a8112++) {
                            var _0x537ae2 = new _0x543207['default'](_0x4a8112);
                            _0x537ae2[_0x4fae4b('0x5b3')](_0x4a8112 % 0x3 * 0xc8, parseInt((_0x4a8112 / 0x3)[_0x4fae4b('0xcc')]()) * 0xd0),
                                _0x537ae2[_0x4fae4b('0x53c')](this, this[_0x4fae4b('0x6a2')]),
                                this[_0x4fae4b('0x2d2')]['addChild'](_0x537ae2[_0x4fae4b('0x5d3')]),
                                this[_0x4fae4b('0x4a9')][_0x4a8112] = _0x537ae2;
                        }
                        var _0x3ebbaa = _0x3d2a1b[_0x4fae4b('0x3b6')][_0x4fae4b('0x4ce')][_0x4fae4b('0x421')]['length'];
                        for (var _0x4a8112 = 0x1; _0x4a8112 <= _0x3ebbaa; _0x4a8112++) {
                            var _0x3faea9 = _0x3d2a1b[_0x4fae4b('0x3b6')][_0x4fae4b('0x4ce')][_0x4fae4b('0x11')](_0x4a8112);
                            if (_0x3d2a1b['default'][_0x4fae4b('0x678')][_0x4fae4b('0x290')](_0x3faea9['ItemId']) == undefined) {
                                this[_0x4fae4b('0x11e')] = _0x3faea9;
                                break;
                            }
                        }
                        this[_0x4fae4b('0x11e')] && this[_0x4fae4b('0x11e')]['ItemId'] > 0x0 ? this['hoopicon'][_0x4fae4b('0x3c4')] = _0x4fae4b('0x3a7') + _0x3d2a1b['default'][_0x4fae4b('0x4ce')][_0x4fae4b('0x3ef')](this[_0x4fae4b('0x11e')]['ItemId'])[_0x4fae4b('0x3d9')] + _0x4fae4b('0x99') : this[_0x4fae4b('0x43c')][_0x4fae4b('0x5bf')] = ![],
                            this['addRewardList'](),
                            _0xbc2746[_0x4fae4b('0x3b6')]['showBannerMoveBtn'](this, this['back'], Laya[_0x4fae4b('0x150')]['displayHeight'] - 0xa0, this[_0x4fae4b('0x6aa')]['y'] + 0x6e);
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')]['initEvent'] = function () {
                        var _0x42e174 = _0x371adc;
                        this[_0x42e174('0x51a')](this['back'], this[_0x42e174('0x336')]),
                            this[_0x42e174('0x51a')](this[_0x42e174('0x6aa')], this[_0x42e174('0x68b')]),
                            _0x3d2a1b[_0x42e174('0x3b6')]['EventMgr']['on'](_0x17f141[_0x42e174('0x4c3')][_0x42e174('0x115')], this, this[_0x42e174('0x48')]),
                            _0x3d2a1b['default']['EventMgr']['on'](_0x17f141[_0x42e174('0x4c3')][_0x42e174('0x171')], this, this[_0x42e174('0x81')]);
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')]['updateData'] = function (_0x438434) {
                        var _0x3e8a7f = _0x371adc;
                        this[_0x3e8a7f('0x3b2')] = _0x438434;
                    }
                    ,
                    _0x56cae0['prototype'][_0x371adc('0x81')] = function () {
                        var _0x30d7b0 = _0x371adc;
                        this[_0x30d7b0('0xf')][_0x30d7b0('0x338')] = _0xbc2746['default'][_0x30d7b0('0x456')](_0x3d2a1b[_0x30d7b0('0x3b6')][_0x30d7b0('0x678')][_0x30d7b0('0xf')]);
                    }
                    ,
                    _0x56cae0['prototype'][_0x371adc('0x6a2')] = function () {
                        var _0x2e2e75 = _0x371adc
                            , _0x45edd4 = _0x3d2a1b[_0x2e2e75('0x3b6')][_0x2e2e75('0x678')][_0x2e2e75('0x318')];
                        console['log'](_0x2e2e75('0x1e4'), _0x45edd4);
                        if (_0x45edd4 <= 0x0) {
                            this['getchance'][_0x2e2e75('0x4b0')] = !![];
                            for (var _0x574077 = 0x0; _0x574077 < 0x9; _0x574077++) {
                                this[_0x2e2e75('0x4a9')][_0x574077][_0x2e2e75('0x318')]();
                            }
                        }
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')]['addRewardList'] = function () {
                        var _0x58ee46 = _0x371adc
                            , _0x371541 = this[_0x58ee46('0x11e')]['Reward'][_0x58ee46('0x1f8')]('|');
                        for (var _0x361000 = 0x0; _0x361000 < _0x371541[_0x58ee46('0x4cc')]; _0x361000++) {
                            var _0x2dbac8 = _0xbc2746[_0x58ee46('0x3b6')][_0x58ee46('0x37f')](_0x371541[_0x361000]);
                            this[_0x58ee46('0x333')][_0x361000] = _0x2dbac8;
                        }
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x48')] = function (_0x5d214b) {
                        var _0x27bbbf = _0x371adc;
                        console[_0x27bbbf('0x5df')](_0x5d214b, _0x27bbbf('0x5e0'));
                        var _0x51945b = this[_0x27bbbf('0x34b')]()
                            , _0xcd7e09 = this[_0x27bbbf('0x333')][_0x51945b];
                        this[_0x27bbbf('0x333')][_0x27bbbf('0x6ba')](_0x51945b, 0x1),
                            this[_0x27bbbf('0x4a9')][_0x5d214b][_0x27bbbf('0x548')](_0xcd7e09);
                        if (this['_openCount'] > 0x0) {
                            this[_0x27bbbf('0x74') + this[_0x27bbbf('0x196')]][_0x27bbbf('0x3c4')] = _0x27bbbf('0x5de'),
                                this[_0x27bbbf('0x196')]--;
                            if (this['_openCount'] == 0x0) {
                                for (var _0x3c3839 = 0x0; _0x3c3839 < 0x9; _0x3c3839++) {
                                    this['_rewardMap'][_0x3c3839][_0x27bbbf('0x24f')](!![]);
                                }
                                this['changeAdIcon'](),
                                    this[_0x27bbbf('0x25f')][_0x27bbbf('0x5bf')] = ![],
                                    this[_0x27bbbf('0x6aa')][_0x27bbbf('0x5bf')] = this[_0x27bbbf('0x14d')] < 0x1,
                                    _0xbc2746[_0x27bbbf('0x3b6')][_0x27bbbf('0x72')](this, this['back'], Laya[_0x27bbbf('0x150')][_0x27bbbf('0x15e')] - 0xa0, this['getchance']['y'] + 0x6e);
                            }
                        }
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x34b')] = function () {
                        var _0x1eb649 = _0x371adc;
                        this[_0x1eb649('0x1f7')] = [],
                            this['_randomTotalNum'] = 0x0;
                        for (var _0x5668b5 = 0x0; _0x5668b5 < this['_rewardArr'][_0x1eb649('0x4cc')]; _0x5668b5++) {
                            this['_randomArr'][_0x5668b5] = this['_randomTotalNum'],
                                this[_0x1eb649('0x5a6')] += this[_0x1eb649('0x333')][_0x5668b5][0x2];
                        }
                        var _0x558667 = _0xbc2746[_0x1eb649('0x3b6')]['random'](0x0, this[_0x1eb649('0x5a6')])
                            , _0x43be38 = 0x0;
                        for (var _0x5668b5 = 0x0; _0x5668b5 < this[_0x1eb649('0x1f7')][_0x1eb649('0x4cc')]; _0x5668b5++) {
                            this[_0x1eb649('0x1f7')][_0x5668b5] > _0x43be38 && this[_0x1eb649('0x1f7')][_0x5668b5] < _0x558667 && (_0x43be38 = this[_0x1eb649('0x1f7')][_0x5668b5]);
                        }
                        var _0x94145f = this[_0x1eb649('0x1f7')]['indexOf'](_0x43be38);
                        return _0x94145f;
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x68b')] = function () {
                        var _0x24771b = _0x371adc;
                        logEvent(_0x24771b('0x534')),
                            _0x5bf04a[_0x24771b('0x1d1')][_0x24771b('0x400')] != _0x5bf04a[_0x24771b('0x52b')][_0x24771b('0x64')] ? _0xbc2746[_0x24771b('0x3b6')][_0x24771b('0x1e5')](_0x3d2a1b[_0x24771b('0x3b6')][_0x24771b('0x4ce')][_0x24771b('0x66c')](0x14), this, this['watchTvCallback'][_0x24771b('0x484')](this)) : _0xbc2746['default']['onPlay4399Ad'](this[_0x24771b('0x14b')]['bind'](this));
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x14b')] = function (_0x12e581) {
                        var _0x4179fb = _0x371adc;
                        if (!_0x12e581)
                            return;
                        console[_0x4179fb('0x5df')](_0x4179fb('0x3e') + _0x12e581[_0x4179fb('0x559')] + _0x4179fb('0x2f6') + _0x12e581[_0x4179fb('0x152')]);
                        if (_0x12e581[_0x4179fb('0x559')] === 0x2710)
                            console['log'](_0x4179fb('0x422'));
                        else {
                            if (_0x12e581[_0x4179fb('0x559')] === 0x2711) {
                                if (_0x3d2a1b[_0x4179fb('0x3b6')][_0x4179fb('0x678')][_0x4179fb('0x318')] <= 0x0)
                                    _0x3d2a1b[_0x4179fb('0x3b6')][_0x4179fb('0x678')]['adRemainTimes'] = 0x0;
                                else {
                                    _0x3d2a1b['default']['DataMgr'][_0x4179fb('0x318')]--,
                                        this[_0x4179fb('0x6a2')](),
                                        this[_0x4179fb('0x196')] = 0x3,
                                        this[_0x4179fb('0x59')][_0x4179fb('0x3c4')] = _0x4179fb('0x1cf'),
                                        this['key2']['skin'] = _0x4179fb('0x1cf'),
                                        this['key3']['skin'] = _0x4179fb('0x1cf');
                                    for (var _0x1155be = 0x0; _0x1155be < 0x9; _0x1155be++) {
                                        this[_0x4179fb('0x4a9')][_0x1155be]['showVideobtn'](![]);
                                    }
                                    this[_0x4179fb('0x25f')][_0x4179fb('0x5bf')] = !![],
                                        this['getchance'][_0x4179fb('0x5bf')] = ![],
                                        this[_0x4179fb('0x14d')]++;
                                }
                            } else {
                                if (_0x3d2a1b[_0x4179fb('0x3b6')]['DataMgr'][_0x4179fb('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x21d')] = function (_0x4f24f2, _0x1f0744, _0x113af8) {
                        var _0x128e5d = _0x371adc;
                        _0x1f0744 === void 0x0 && (_0x1f0744 = null);
                        _0x113af8 === void 0x0 && (_0x113af8 = null);
                        if (_0x1f0744) {
                            _0x3d2a1b['default'][_0x128e5d('0x5d7')][_0x128e5d('0x46e')](_0x1f0744);
                            return;
                        }
                        if (_0x4f24f2) {
                            this['_openCount'] = 0x3,
                                this[_0x128e5d('0x59')][_0x128e5d('0x3c4')] = _0x128e5d('0x1cf'),
                                this[_0x128e5d('0x395')][_0x128e5d('0x3c4')] = _0x128e5d('0x1cf'),
                                this[_0x128e5d('0x58')][_0x128e5d('0x3c4')] = _0x128e5d('0x1cf');
                            for (var _0x5080fd = 0x0; _0x5080fd < 0x9; _0x5080fd++) {
                                this['_rewardMap'][_0x5080fd]['showVideobtn'](![]);
                            }
                            this[_0x128e5d('0x25f')][_0x128e5d('0x5bf')] = !![],
                                this[_0x128e5d('0x6aa')][_0x128e5d('0x5bf')] = ![],
                                this[_0x128e5d('0x14d')]++;
                        } else
                            _0x3d2a1b[_0x128e5d('0x3b6')][_0x128e5d('0x5d7')]['showTips'](_0x128e5d('0x301'));
                    }
                    ,
                    _0x56cae0['prototype'][_0x371adc('0x336')] = function () {
                        var _0x2e7d59 = _0x371adc;
                        logEvent('end_key\x20skip'),
                            _0x3d2a1b[_0x2e7d59('0x3b6')]['EventMgr'][_0x2e7d59('0x585')](_0x17f141[_0x2e7d59('0x4c3')][_0x2e7d59('0x115')], this, this['rewardClickHandle']),
                            _0x3d2a1b['default'][_0x2e7d59('0x370')][_0x2e7d59('0x585')](_0x17f141[_0x2e7d59('0x4c3')][_0x2e7d59('0x171')], this, this['updateGoldHandle']);
                        for (var _0x581aa4 = 0x0; _0x581aa4 < this[_0x2e7d59('0x4a9')][_0x2e7d59('0x4cc')]; _0x581aa4++) {
                            this[_0x2e7d59('0x4a9')][_0x581aa4]['destroy']();
                        }
                        _0x3d2a1b[_0x2e7d59('0x3b6')][_0x2e7d59('0x5d7')][_0x2e7d59('0x280')](_0x2875f2[_0x2e7d59('0x339')]['GameUI']);
                    }
                    ,
                    _0x56cae0[_0x371adc('0x64a')][_0x371adc('0x42')] = function () {
                        var _0x5f02d4 = _0x371adc;
                        _0x5b948c[_0x5f02d4('0x64a')][_0x5f02d4('0x42')][_0x5f02d4('0x324')](this);
                    }
                    ,
                    _0x56cae0;
            }(_0x40409d['ui'][_0x102963('0x62')]['OpenRewardUIUI']);
        _0xffc1c2[_0x102963('0x3b6')] = _0x10485d;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        './item/RewardItem': 0x33
    }],
    0x2a: [function (_0x2020d8, _0x19dc75, _0x180c5b) {
        var _0x2dea57 = _0x4b7fcf;
        'use strict';
        Object[_0x2dea57('0x351')](_0x180c5b, _0x2dea57('0xb8'), {
            'value': !![]
        });
        var _0x29fd4f = _0x2020d8(_0x2dea57('0x662'))
            , _0x5abce1 = _0x2020d8('../../XGame')
            , _0x46a073 = _0x2020d8(_0x2dea57('0x20c'))
            , _0x32efe0 = _0x2020d8(_0x2dea57('0x69c'))
            , _0x45eca2 = _0x2020d8(_0x2dea57('0x46'))
            , _0x4f2ee3 = function (_0x1e0703) {
                var _0x44eab7 = _0x2dea57;
                __extends(_0x195c78, _0x1e0703);
                function _0x195c78(_0x2d1d15) {
                    var _0x1f283c = _0x5985
                        , _0x395b7b = _0x1e0703[_0x1f283c('0x324')](this) || this;
                    return _0x395b7b[_0x1f283c('0xac')] = 0x0,
                        _0x395b7b['_time'] = 0x0,
                        _0x395b7b['_endTime'] = 0x0,
                        _0x2d1d15[_0x1f283c('0x123')] = _0x5abce1[_0x1f283c('0x3b6')][_0x1f283c('0x4ce')][_0x1f283c('0x66c')](0x2),
                        console['log'](_0x1f283c('0x380'), _0x2d1d15),
                        _0x395b7b;
                }
                return _0x195c78[_0x44eab7('0x64a')][_0x44eab7('0x4fc')] = function () {
                    var _0x2eb6e5 = _0x44eab7;
                    this[_0x2eb6e5('0x218')](),
                        this[_0x2eb6e5('0x1d5')]();
                }
                    ,
                    _0x195c78[_0x44eab7('0x64a')][_0x44eab7('0x218')] = function () {
                        var _0x2fd0ac = _0x44eab7;
                        this[_0x2fd0ac('0x108')][_0x2fd0ac('0x5bf')] = ![],
                            this[_0x2fd0ac('0x315')][_0x2fd0ac('0x338')] = _0x5abce1[_0x2fd0ac('0x3b6')]['CfgMgr']['getLangById'](0xa, _0x45eca2[_0x2fd0ac('0x1d1')][_0x2fd0ac('0x64d')]),
                            this[_0x2fd0ac('0x420')]['text'] = _0x5abce1['default']['CfgMgr'][_0x2fd0ac('0x235')](0x13, _0x45eca2[_0x2fd0ac('0x1d1')][_0x2fd0ac('0x64d')]),
                            _0x46a073[_0x2fd0ac('0x3b6')][_0x2fd0ac('0x72')](this, this[_0x2fd0ac('0x420')], Laya['stage'][_0x2fd0ac('0x33c')] * 0.9, Laya[_0x2fd0ac('0x150')]['height'] * 0.75),
                            _0x45eca2['GameConst'][_0x2fd0ac('0x400')] == _0x45eca2['PlatformType'][_0x2fd0ac('0x64')] && this[_0x2fd0ac('0x6a2')]();
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')]['initEvent'] = function () {
                        var _0x41f3e7 = _0x44eab7;
                        Laya[_0x41f3e7('0x5ac')][_0x41f3e7('0x55')](0x1, this, this[_0x41f3e7('0x54e')]),
                            this[_0x41f3e7('0x51a')](this['videobtn'], this[_0x41f3e7('0xbd')]),
                            this[_0x41f3e7('0x51a')](this[_0x41f3e7('0x420')], this[_0x41f3e7('0x336')]);
                    }
                    ,
                    _0x195c78['prototype']['changeAdIcon'] = function () {
                        var _0x2edfac = _0x44eab7
                            , _0x111861 = _0x5abce1[_0x2edfac('0x3b6')]['DataMgr'][_0x2edfac('0x318')];
                        console[_0x2edfac('0x5df')](_0x2edfac('0x1e4'), _0x111861),
                            _0x111861 <= 0x0 && (this[_0x2edfac('0x3a5')][_0x2edfac('0x4b0')] = !![]);
                    }
                    ,
                    _0x195c78['prototype'][_0x44eab7('0xbd')] = function () {
                        var _0x2ad88b = _0x44eab7;
                        logEvent(_0x2ad88b('0x38f')),
                            _0x45eca2[_0x2ad88b('0x1d1')][_0x2ad88b('0x400')] != _0x45eca2[_0x2ad88b('0x52b')][_0x2ad88b('0x64')] ? _0x46a073[_0x2ad88b('0x3b6')]['onClickWatchTV'](_0x5abce1[_0x2ad88b('0x3b6')][_0x2ad88b('0x4ce')]['getAdCfg'](0xb), this, this['watchTvCallback']['bind'](this)) : _0x46a073[_0x2ad88b('0x3b6')]['onPlay4399Ad'](this[_0x2ad88b('0x14b')]['bind'](this));
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')]['watch4399Callback'] = function (_0x23b2d0) {
                        var _0x22e96b = _0x44eab7;
                        if (!_0x23b2d0)
                            return;
                        console['log'](_0x22e96b('0x3e') + _0x23b2d0['code'] + ',消息:' + _0x23b2d0[_0x22e96b('0x152')]);
                        if (_0x23b2d0[_0x22e96b('0x559')] === 0x2710)
                            console[_0x22e96b('0x5df')](_0x22e96b('0x422'));
                        else {
                            if (_0x23b2d0[_0x22e96b('0x559')] === 0x2711)
                                console['log'](_0x22e96b('0x543')),
                                    _0x5abce1[_0x22e96b('0x3b6')]['DataMgr'][_0x22e96b('0x318')] <= 0x0 ? _0x5abce1['default'][_0x22e96b('0x678')][_0x22e96b('0x318')] = 0x0 : (_0x5abce1['default'][_0x22e96b('0x678')][_0x22e96b('0x318')]--,
                                        this['changeAdIcon'](),
                                        this['gem']['visible'] = !![],
                                        this['box']['skin'] = _0x22e96b('0x32f'),
                                        this[_0x22e96b('0xf')]['text'] = '+' + this[_0x22e96b('0xac')],
                                        _0x5abce1['default'][_0x22e96b('0x5d7')][_0x22e96b('0x46e')](_0x5abce1['default']['CfgMgr'][_0x22e96b('0x235')](0x25, _0x45eca2[_0x22e96b('0x1d1')]['Language']) + '+' + this[_0x22e96b('0xac')]),
                                        _0x5abce1[_0x22e96b('0x3b6')][_0x22e96b('0x678')][_0x22e96b('0x45')](this['_getGold']),
                                        this[_0x22e96b('0x3a5')]['disabled'] = !![],
                                        this[_0x22e96b('0x420')]['visible'] = ![],
                                        _0x5abce1['default'][_0x22e96b('0x678')][_0x22e96b('0x63e')](),
                                        Laya[_0x22e96b('0x5ac')]['once'](0x1f4, this, function () {
                                            var _0x268d18 = _0x22e96b;
                                            _0x5abce1[_0x268d18('0x3b6')][_0x268d18('0x5d7')][_0x268d18('0x280')](_0x32efe0[_0x268d18('0x339')][_0x268d18('0x5b4')]);
                                        }));
                            else {
                                if (_0x5abce1[_0x22e96b('0x3b6')][_0x22e96b('0x678')][_0x22e96b('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')]['updateData'] = function (_0x448a5b) {
                        var _0x59a6fa = _0x44eab7;
                        this[_0x59a6fa('0xac')] = _0x448a5b['gold'],
                            this['_time'] = _0x448a5b[_0x59a6fa('0x244')],
                            this[_0x59a6fa('0x299')] = _0x448a5b[_0x59a6fa('0x340')],
                            this['_time'] > 0x0 ? (this[_0x59a6fa('0x3a5')][_0x59a6fa('0x5bf')] = ![],
                                Laya[_0x59a6fa('0x5ac')][_0x59a6fa('0x2e8')](0x3e8, this, this[_0x59a6fa('0x4b2')]),
                                this[_0x59a6fa('0x4b2')]()) : (this[_0x59a6fa('0x3a5')][_0x59a6fa('0x5bf')] = !![],
                                    this['countdown'][_0x59a6fa('0x338')] = '');
                    }
                    ,
                    _0x195c78['prototype']['updateTimeBox'] = function () {
                        var _0x206c77 = _0x44eab7;
                        _0x5abce1[_0x206c77('0x3b6')][_0x206c77('0x678')][_0x206c77('0x21f')](Math[_0x206c77('0xc6')](this[_0x206c77('0x1eb')] - this[_0x206c77('0x299')])),
                            this[_0x206c77('0x5cc')][_0x206c77('0x338')] = _0x46a073[_0x206c77('0x3b6')][_0x206c77('0x561')](this['_time']),
                            this[_0x206c77('0x1eb')] <= 0x0 && (this['_time'] = 0x0,
                                Laya[_0x206c77('0x5ac')][_0x206c77('0x466')](this, this[_0x206c77('0x4b2')])),
                            this[_0x206c77('0x1eb')]--;
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')][_0x44eab7('0x21d')] = function (_0x307327, _0x2b84c2, _0x3f7af2) {
                        var _0x1390ff = _0x44eab7;
                        _0x2b84c2 === void 0x0 && (_0x2b84c2 = null);
                        _0x3f7af2 === void 0x0 && (_0x3f7af2 = null);
                        if (_0x2b84c2) {
                            _0x5abce1[_0x1390ff('0x3b6')][_0x1390ff('0x5d7')][_0x1390ff('0x46e')](_0x2b84c2);
                            return;
                        }
                        _0x307327 ? (this[_0x1390ff('0x108')]['visible'] = !![],
                            this[_0x1390ff('0x31')][_0x1390ff('0x3c4')] = _0x1390ff('0x32f'),
                            this[_0x1390ff('0xf')][_0x1390ff('0x338')] = '+' + this[_0x1390ff('0xac')],
                            _0x5abce1[_0x1390ff('0x3b6')][_0x1390ff('0x5d7')][_0x1390ff('0x46e')](_0x5abce1['default']['CfgMgr'][_0x1390ff('0x235')](0x25, _0x45eca2[_0x1390ff('0x1d1')][_0x1390ff('0x64d')]) + '+' + this[_0x1390ff('0xac')]),
                            _0x5abce1[_0x1390ff('0x3b6')][_0x1390ff('0x678')][_0x1390ff('0x45')](this['_getGold']),
                            this[_0x1390ff('0x3a5')][_0x1390ff('0x61c')] = !![],
                            this[_0x1390ff('0x420')]['visible'] = ![],
                            _0x5abce1['default']['DataMgr'][_0x1390ff('0x63e')](),
                            Laya[_0x1390ff('0x5ac')][_0x1390ff('0x1e6')](0x1f4, this, function () {
                                var _0x3f6aa9 = _0x1390ff;
                                _0x5abce1[_0x3f6aa9('0x3b6')][_0x3f6aa9('0x5d7')][_0x3f6aa9('0x280')](_0x32efe0[_0x3f6aa9('0x339')][_0x3f6aa9('0x5b4')]);
                            })) : _0x5abce1[_0x1390ff('0x3b6')][_0x1390ff('0x5d7')][_0x1390ff('0x46e')]('看完视频后即可领取奖励！');
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')][_0x44eab7('0x54e')] = function () {
                        var _0x422949 = _0x44eab7;
                        this[_0x422949('0x62c')][_0x422949('0x4b1')] += 0x1;
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')][_0x44eab7('0x336')] = function () {
                        var _0x29f3a6 = _0x44eab7;
                        logEvent('button_chest\x20skip'),
                            _0x5abce1[_0x29f3a6('0x3b6')]['UIMgr']['toUI'](_0x32efe0[_0x29f3a6('0x339')][_0x29f3a6('0x5b4')]);
                    }
                    ,
                    _0x195c78[_0x44eab7('0x64a')][_0x44eab7('0x42')] = function () {
                        var _0x43910e = _0x44eab7;
                        Laya[_0x43910e('0x5ac')]['clear'](this, this[_0x43910e('0x54e')]),
                            Laya['timer']['clear'](this, this[_0x43910e('0x4b2')]),
                            _0x1e0703['prototype']['close'][_0x43910e('0x324')](this);
                    }
                    ,
                    _0x195c78;
            }(_0x29fd4f['ui'][_0x2dea57('0x62')][_0x2dea57('0x184')]);
        _0x180c5b[_0x2dea57('0x3b6')] = _0x4f2ee3;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37
    }],
    0x2b: [function (_0x39b6cb, _0x539dc6, _0x32d634) {
        var _0x497a3d = _0x4b7fcf;
        'use strict';
        Object[_0x497a3d('0x351')](_0x32d634, '__esModule', {
            'value': !![]
        });
        var _0x4b0c46 = _0x39b6cb('../../ui/layaMaxUI')
            , _0x384962 = _0x39b6cb(_0x497a3d('0xce'))
            , _0x31eba6 = _0x39b6cb(_0x497a3d('0x69c'))
            , _0x35e68e = _0x39b6cb('../../utils/Tools')
            , _0xf54201 = _0x39b6cb('../../Platform')
            , _0xde0fd7 = _0x39b6cb(_0x497a3d('0x61a'))
            , _0x185bdd = _0x39b6cb(_0x497a3d('0x34f'))
            , _0x3c75b1 = _0x39b6cb(_0x497a3d('0x46'))
            , _0x5505a4 = _0x39b6cb(_0x497a3d('0x1fa'))
            , _0x52f537 = _0x39b6cb('../../utils/Utils')
            , _0x270df5 = function (_0x253861) {
                var _0x5a96dc = _0x497a3d;
                __extends(_0x525f2c, _0x253861);
                function _0x525f2c(_0x53ef6f) {
                    var _0x1c9acc = _0x5985
                        , _0x128166 = _0x253861['call'](this) || this;
                    return _0x128166[_0x1c9acc('0x273')] = 0x0,
                        _0x128166[_0x1c9acc('0x3e4')] = [],
                        _0x53ef6f[_0x1c9acc('0x123')] = _0x384962[_0x1c9acc('0x3b6')][_0x1c9acc('0x4ce')][_0x1c9acc('0x66c')](0x1d),
                        _0x128166;
                }
                return _0x525f2c['prototype'][_0x5a96dc('0x4fc')] = function () {
                    var _0x4cad17 = _0x5a96dc;
                    this[_0x4cad17('0x218')](),
                        this[_0x4cad17('0x1d5')](),
                        Laya['timer'][_0x4cad17('0x55')](0x1, this, this[_0x4cad17('0x6a3')]);
                }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x3ea')] = function (_0xa6df17) {
                        var _0x2a37b6 = _0x5a96dc;
                        this[_0x2a37b6('0x211')] = _0xa6df17,
                            console[_0x2a37b6('0x5df')](_0x2a37b6('0x15d'), _0xa6df17);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x218')] = function () {
                        var _0x1c185b = _0x5a96dc;
                        this['btnBack'][_0x1c185b('0x338')] = _0x384962['default'][_0x1c185b('0x4ce')]['getLangById'](0x13, _0x3c75b1['GameConst']['Language']),
                            this[_0x1c185b('0x472')][_0x1c185b('0x338')] = _0x384962['default'][_0x1c185b('0x4ce')][_0x1c185b('0x235')](0x17, _0x3c75b1['GameConst'][_0x1c185b('0x64d')]),
                            this[_0x1c185b('0x2a5')][_0x1c185b('0x338')] = _0x384962[_0x1c185b('0x3b6')][_0x1c185b('0x4ce')][_0x1c185b('0x235')](0x28, _0x3c75b1['GameConst'][_0x1c185b('0x64d')]),
                            this['resultTxt'][_0x1c185b('0x338')] = _0x384962[_0x1c185b('0x3b6')][_0x1c185b('0x4ce')][_0x1c185b('0x235')](0x2a, _0x3c75b1['GameConst'][_0x1c185b('0x64d')]),
                            this[_0x1c185b('0x86')]['text'] = _0x384962[_0x1c185b('0x3b6')][_0x1c185b('0x4ce')][_0x1c185b('0x235')](0x29, _0x3c75b1['GameConst']['Language']),
                            this[_0x1c185b('0x1ae')][_0x1c185b('0x338')] = _0x35e68e[_0x1c185b('0x3b6')][_0x1c185b('0x456')](_0x384962[_0x1c185b('0x3b6')][_0x1c185b('0x678')][_0x1c185b('0xf')]),
                            this[_0x1c185b('0x42b')][_0x1c185b('0x5bf')] = ![],
                            this['imgTitle'][_0x1c185b('0x5bf')] = !![],
                            this[_0x1c185b('0x1c2')][_0x1c185b('0x5bf')] = ![];
                        var _0x738e03 = !![];
                        window[_0x1c185b('0x32c')] && (_0x738e03 = typeof window['swan']['getVideoRecorderManager'] != _0x1c185b('0x51b')),
                            console['log'](_0x738e03, _0x1c185b('0x3ff')),
                            _0x3c75b1[_0x1c185b('0x1d1')][_0x1c185b('0x400')] == _0x3c75b1[_0x1c185b('0x52b')][_0x1c185b('0xd1')] ? (this[_0x1c185b('0xef')][_0x1c185b('0x4b0')] = ![],
                                this[_0x1c185b('0xef')][_0x1c185b('0x3b8')] = !![],
                                this[_0x1c185b('0xef')]['visible'] = !![],
                                this[_0x1c185b('0x2af')]['x'] = 0x142) : this[_0x1c185b('0x2af')]['x'] = 0x8a,
                            Laya['Tween'][_0x1c185b('0x3fa')](this[_0x1c185b('0x2a5')], {
                                'scaleX': 0x2,
                                'scaleY': 0x2,
                                'alpha': 0x0
                            }, 0x12c),
                            _0x35e68e[_0x1c185b('0x3b6')][_0x1c185b('0x438')](this, this[_0x1c185b('0x86')], 0x1f4, 1.2),
                            _0x3c75b1[_0x1c185b('0x1d1')]['Platform'] == _0x3c75b1[_0x1c185b('0x52b')][_0x1c185b('0x64')] && this['changeAdIcon']();
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x6a2')] = function () {
                        var _0x35ec8d = _0x5a96dc
                            , _0x8d5c5f = _0x384962[_0x35ec8d('0x3b6')][_0x35ec8d('0x678')][_0x35ec8d('0x318')];
                        console[_0x35ec8d('0x5df')](_0x35ec8d('0x1e4'), _0x8d5c5f),
                            _0x8d5c5f <= 0x0 && (this[_0x35ec8d('0x2af')][_0x35ec8d('0x4b0')] = !![]);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x1d5')] = function () {
                        var _0x3b3fad = _0x5a96dc;
                        this['regClick'](this[_0x3b3fad('0xe1')], this[_0x3b3fad('0x2f9')]),
                            this[_0x3b3fad('0x51a')](this[_0x3b3fad('0x2af')], this[_0x3b3fad('0x127')]),
                            this['regClick'](this[_0x3b3fad('0x86')], this[_0x3b3fad('0x1df')]),
                            _0x384962[_0x3b3fad('0x3b6')][_0x3b3fad('0x370')]['on'](_0xde0fd7['EventEnum'][_0x3b3fad('0x5f2')], this, this[_0x3b3fad('0x618')]),
                            _0x384962[_0x3b3fad('0x3b6')][_0x3b3fad('0x370')]['on'](_0xde0fd7[_0x3b3fad('0x4c3')][_0x3b3fad('0x515')], this, this['GameStart']),
                            _0x384962['default']['EventMgr']['on'](_0xde0fd7['EventEnum'][_0x3b3fad('0x46f')], this, this['GameEnd']),
                            _0x384962[_0x3b3fad('0x3b6')][_0x3b3fad('0x370')]['on'](_0xde0fd7['EventEnum']['Update_Items'], this, this[_0x3b3fad('0xa4')]),
                            this[_0x3b3fad('0x51a')](this['btnSharekVedio'], this['onClikShareVedio']);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x33e')] = function () {
                        var _0x4c287a = _0x5a96dc
                            , _0x4f661c = _0x384962['default'][_0x4c287a('0x33b')]['getRemainTime']();
                        _0x4f661c >= 0x0 ? this[_0x4c287a('0x8e')]['text'] = _0x35e68e[_0x4c287a('0x3b6')]['transferSecondToMS'](_0x4f661c) : Laya[_0x4c287a('0x5ac')][_0x4c287a('0x466')](this, this[_0x4c287a('0x33e')]);
                    }
                    ,
                    _0x525f2c['prototype'][_0x5a96dc('0x618')] = function (_0x162c33) {
                        var _0x2d83f2 = _0x5a96dc
                            , _0x2e0cf8 = _0x384962[_0x2d83f2('0x3b6')]['GameMgr'][_0x2d83f2('0x49d')]();
                        if (_0x2e0cf8 >= 0x0) {
                            var _0x190eca = _0x384962[_0x2d83f2('0x3b6')][_0x2d83f2('0x4ce')]['getGlobalCfg'](_0x2d83f2('0x5a7'));
                            this[_0x2d83f2('0x273')] = _0x162c33 * _0x190eca,
                                this[_0x2d83f2('0x60a')][_0x2d83f2('0x52c')] = this[_0x2d83f2('0x273')]['toString']();
                        }
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x515')] = function () {
                        var _0x11beb7 = _0x5a96dc;
                        Laya[_0x11beb7('0x5ac')][_0x11beb7('0x2e8')](0x3e8, this, this[_0x11beb7('0x33e')]);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')]['GameEnd'] = function () {
                        var _0x4df434 = _0x5a96dc;
                        console[_0x4df434('0x5df')](_0x4df434('0x217')),
                            this[_0x4df434('0x616')][_0x4df434('0x5bf')] = !![],
                            this['imgTimer'][_0x4df434('0x5bf')] = ![],
                            this['imgOver'][_0x4df434('0x5bf')] = !![],
                            _0x3c75b1[_0x4df434('0x1d1')]['Platform'] == _0x3c75b1['PlatformType'][_0x4df434('0x576')] && _0x384962[_0x4df434('0x3b6')][_0x4df434('0x678')][_0x4df434('0x436')] && (this[_0x4df434('0x54c')][_0x4df434('0x5bf')] = !![],
                                this['reqTmAd']()),
                            this[_0x4df434('0x2ca')](this['_addCoin']);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x360')] = function () {
                        var _0x2220a9 = _0x5a96dc;
                        _0x384962[_0x2220a9('0x3b6')][_0x2220a9('0x33b')][_0x2220a9('0x360')](_0x2220a9('0x417'), this[_0x2220a9('0x3c2')][_0x2220a9('0x484')](this));
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x3c2')] = function (_0x334c2b) {
                        var _0x4c8a62 = _0x5a96dc;
                        if (!_0x334c2b)
                            return;
                        this[_0x4c8a62('0xa4')](_0x334c2b);
                    }
                    ,
                    _0x525f2c['prototype'][_0x5a96dc('0xa4')] = function (_0x197cd6) {
                        var _0x10e537 = _0x5a96dc;
                        this['clearItems'](),
                            this[_0x10e537('0x3e4')] = [];
                        var _0x3e47e3 = _0x197cd6[_0x10e537('0x519')];
                        for (var _0x345908 = 0x0; _0x345908 < 0x4; _0x345908++) {
                            if (!_0x3e47e3[_0x345908])
                                return;
                            var _0x38188f = new _0x5505a4[(_0x10e537('0x3b6'))]();
                            this[_0x10e537('0x42b')]['addChild'](_0x38188f[_0x10e537('0x5d3')]),
                                this[_0x10e537('0x3e4')][_0x10e537('0xff')](_0x38188f[_0x10e537('0x5d3')]),
                                _0x38188f[_0x10e537('0x303')](_0x3e47e3[_0x345908][_0x10e537('0x67b')], _0x3e47e3[_0x345908][_0x10e537('0x1fe')], _0x3e47e3[_0x345908][_0x10e537('0x19e')]);
                        }
                        _0x52f537[_0x10e537('0x3b6')][_0x10e537('0x4c7')](this[_0x10e537('0x3e4')], 0x2, -58.5, 0xb7, 0x1c2, 0x14);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')]['clearItems'] = function () {
                        var _0x77f228 = _0x5a96dc;
                        if (!this['itemArr'])
                            return;
                        this[_0x77f228('0x3e4')][_0x77f228('0x596')](function (_0x3000b2) {
                            var _0xc0149a = _0x77f228;
                            _0x3000b2[_0xc0149a('0x594')]();
                        }),
                            this[_0x77f228('0x3e4')][_0x77f228('0x4cc')] = 0x0,
                            this[_0x77f228('0x3e4')] = null;
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x4bc')] = function () {
                        var _0x2d539f = this;
                        setTimeout(function () {
                            var _0x3dadd4 = _0x5985;
                            _0xf54201[_0x3dadd4('0x3b6')]['clipVideo'](_0x2d539f[_0x3dadd4('0x656')][_0x3dadd4('0x484')](_0x2d539f));
                        }, 0x1f4);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x656')] = function () {
                        var _0x49d658 = _0x5a96dc;
                        this[_0x49d658('0xef')][_0x49d658('0x4b0')] = !![],
                            this[_0x49d658('0xef')]['mouseEnabled'] = ![];
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x6a3')] = function () {
                        var _0x589a87 = _0x5a96dc;
                        this['imgLight'][_0x589a87('0x4b1')] += Laya[_0x589a87('0x5ac')][_0x589a87('0x479')] / 0x32;
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x2ca')] = function (_0x40369a) {
                        var _0x39df39 = _0x5a96dc;
                        console['log'](_0x39df39('0xf1')),
                            _0x384962[_0x39df39('0x3b6')]['DataMgr']['maxLevel']++,
                            this[_0x39df39('0x42b')]['visible'] = !![];
                        try {
                            this[_0x39df39('0x3d')][_0x39df39('0x338')] = '+' + _0x40369a[_0x39df39('0xcc')]();
                        } catch (_0x83e6ae) {
                            console[_0x39df39('0x5df')](_0x83e6ae);
                        }
                        this[_0x39df39('0x273')] = _0x40369a,
                            _0x384962[_0x39df39('0x3b6')][_0x39df39('0x678')][_0x39df39('0x45')](this[_0x39df39('0x273')]),
                            _0x35e68e['default']['showBannerMoveBtn'](this, this['btnBack'], Laya[_0x39df39('0x150')][_0x39df39('0x33c')] * 0.77, Laya[_0x39df39('0x150')][_0x39df39('0x33c')] * 0.65);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x1df')] = function () {
                        var _0x14109e = _0x5a96dc, _0x323e57 = this, _0x1edc9c;
                        this['skinId'] ? _0x1edc9c = this[_0x14109e('0x211')] : _0x1edc9c = _0x384962[_0x14109e('0x3b6')][_0x14109e('0x678')][_0x14109e('0x33f')],
                            this[_0x14109e('0x86')][_0x14109e('0x5bf')] = ![],
                            this['imgGem'][_0x14109e('0x5bf')] = ![],
                            this['imgBG'][_0x14109e('0x5bf')] = ![],
                            Laya[_0x14109e('0x34d')][_0x14109e('0x1fb')](this[_0x14109e('0x86')]),
                            Laya[_0x14109e('0x34d')]['to'](this[_0x14109e('0x2a5')], {
                                'scaleX': 0x2,
                                'scaleY': 0x2,
                                'alpha': 0x0
                            }, 0x12c, null, Laya[_0x14109e('0x49f')]['create'](this, function () {
                                var _0x35997f = _0x14109e;
                                _0x323e57[_0x35997f('0x2a5')][_0x35997f('0x5bf')] = ![],
                                    _0x384962[_0x35997f('0x3b6')]['GameMgr']['StartGame'](0x5, _0x1edc9c, 0x1, _0x185bdd[_0x35997f('0x281')]['GameType'][_0x35997f('0x6a6')]),
                                    _0x323e57[_0x35997f('0x33e')](),
                                    _0x323e57['imgTimer']['visible'] = !![];
                            }));
                    }
                    ,
                    _0x525f2c['prototype'][_0x5a96dc('0x2f9')] = function () {
                        var _0x48e100 = _0x5a96dc;
                        _0x384962[_0x48e100('0x3b6')][_0x48e100('0x5d7')][_0x48e100('0x280')](_0x31eba6[_0x48e100('0x339')][_0x48e100('0x5b4')]);
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')][_0x5a96dc('0x127')] = function () {
                        var _0x2db760 = _0x5a96dc
                            , _0x36c774 = this;
                        _0x3c75b1[_0x2db760('0x1d1')][_0x2db760('0x400')] != _0x3c75b1[_0x2db760('0x52b')][_0x2db760('0x64')] ? _0x35e68e[_0x2db760('0x3b6')][_0x2db760('0x1e5')](_0x384962['default'][_0x2db760('0x4ce')][_0x2db760('0x66c')](0x12), this, function (_0x17af68, _0xe91f1f, _0x5d2a59) {
                            var _0xa5c1e5 = _0x2db760;
                            _0xe91f1f === void 0x0 && (_0xe91f1f = null);
                            _0x5d2a59 === void 0x0 && (_0x5d2a59 = null);
                            if (_0xe91f1f) {
                                _0x384962[_0xa5c1e5('0x3b6')]['UIMgr']['showTips'](_0xe91f1f);
                                return;
                            }
                            _0x17af68 ? (_0x36c774[_0xa5c1e5('0x2af')]['visible'] = ![],
                                _0x36c774[_0xa5c1e5('0xe1')][_0xa5c1e5('0x5bf')] = ![],
                                Laya[_0xa5c1e5('0x34d')]['to'](_0x36c774, {
                                    '_addCoin': _0x36c774[_0xa5c1e5('0x273')] * 0x2,
                                    'update': new Laya[(_0xa5c1e5('0x49f'))](_0x36c774, function () {
                                        var _0x521a10 = _0xa5c1e5;
                                        _0x36c774[_0x521a10('0x3d')][_0x521a10('0x338')] = '+' + Math[_0x521a10('0x80')](_0x36c774[_0x521a10('0x273')])[_0x521a10('0xcc')]();
                                    }
                                    )
                                }, 0x3e8, Laya['Ease']['quadOut'], Laya[_0xa5c1e5('0x49f')][_0xa5c1e5('0x5fb')](_0x36c774, function () {
                                    var _0x1c82ad = _0xa5c1e5;
                                    _0x384962[_0x1c82ad('0x3b6')][_0x1c82ad('0x678')][_0x1c82ad('0x45')](_0x36c774[_0x1c82ad('0x273')] / 0x2),
                                        _0x36c774['onClickBack']();
                                }))) : _0x384962[_0xa5c1e5('0x3b6')][_0xa5c1e5('0x5d7')][_0xa5c1e5('0x46e')](_0xa5c1e5('0x3dd'));
                        }) : _0x35e68e[_0x2db760('0x3b6')]['onPlay4399Ad'](this['watch4399Callback'][_0x2db760('0x484')](this));
                    }
                    ,
                    _0x525f2c[_0x5a96dc('0x64a')]['watch4399Callback'] = function (_0x2b8840) {
                        var _0x580b5a = _0x5a96dc
                            , _0x50bcb2 = this;
                        if (!_0x2b8840)
                            return;
                        console[_0x580b5a('0x5df')]('代码:' + _0x2b8840[_0x580b5a('0x559')] + _0x580b5a('0x2f6') + _0x2b8840[_0x580b5a('0x152')]);
                        if (_0x2b8840[_0x580b5a('0x559')] === 0x2710)
                            console['log'](_0x580b5a('0x422'));
                        else {
                            if (_0x2b8840['code'] === 0x2711)
                                console[_0x580b5a('0x5df')]('播放结束'),
                                    _0x384962['default'][_0x580b5a('0x678')][_0x580b5a('0x318')] <= 0x0 ? _0x384962['default'][_0x580b5a('0x678')][_0x580b5a('0x318')] = 0x0 : (_0x384962[_0x580b5a('0x3b6')]['DataMgr'][_0x580b5a('0x318')]--,
                                        this[_0x580b5a('0x6a2')](),
                                        this[_0x580b5a('0x2af')]['visible'] = ![],
                                        this[_0x580b5a('0xe1')][_0x580b5a('0x5bf')] = ![],
                                        Laya[_0x580b5a('0x34d')]['to'](this, {
                                            '_addCoin': this[_0x580b5a('0x273')] * 0x2,
                                            'update': new Laya[(_0x580b5a('0x49f'))](this, function () {
                                                var _0x5ed97a = _0x580b5a;
                                                _0x50bcb2[_0x5ed97a('0x3d')]['text'] = '+' + Math[_0x5ed97a('0x80')](_0x50bcb2[_0x5ed97a('0x273')])[_0x5ed97a('0xcc')]();
                                            }
                                            )
                                        }, 0x3e8, Laya[_0x580b5a('0x2a3')][_0x580b5a('0x3e3')], Laya[_0x580b5a('0x49f')][_0x580b5a('0x5fb')](this, function () {
                                            var _0x1395d3 = _0x580b5a;
                                            _0x384962[_0x1395d3('0x3b6')]['DataMgr']['addCoinCount'](_0x50bcb2[_0x1395d3('0x273')] / 0x2),
                                                _0x50bcb2[_0x1395d3('0x2f9')]();
                                        })));
                            else {
                                if (_0x384962['default'][_0x580b5a('0x678')]['adRemainTimes'] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x525f2c;
            }(_0x4b0c46['ui']['view'][_0x497a3d('0x105')]);
        _0x32d634[_0x497a3d('0x3b6')] = _0x270df5;
    }
        , {
        '../../Platform': 0x3,
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        '../../utils/Utils': 0x38,
        './item/AdItem': 0x31
    }],
    0x2c: [function (_0x4ca686, _0x3877cd, _0x3a58fc) {
        var _0x428a35 = _0x4b7fcf;
        'use strict';
        Object[_0x428a35('0x351')](_0x3a58fc, '__esModule', {
            'value': !![]
        });
        var _0x13afcb = _0x4ca686(_0x428a35('0x662'))
            , _0x697f1c = _0x4ca686('../../XGame')
            , _0x3b3e57 = _0x4ca686(_0x428a35('0x20c'))
            , _0x36f003 = _0x4ca686(_0x428a35('0x61a'))
            , _0x305cd9 = _0x4ca686(_0x428a35('0x46'))
            , _0x284cc8 = function (_0x2ad816) {
                var _0xe8b700 = _0x428a35;
                __extends(_0x3c0eb7, _0x2ad816);
                function _0x3c0eb7(_0x17619c) {
                    var _0x5f2de5 = _0x5985
                        , _0x1e4e09 = _0x2ad816[_0x5f2de5('0x324')](this) || this;
                    return _0x1e4e09[_0x5f2de5('0x13d')] = [_0x5f2de5('0x434'), _0x5f2de5('0x293'), _0x5f2de5('0x5e4'), _0x5f2de5('0x1e2'), _0x5f2de5('0x194'), 'playGame/ColorText_TERRIFIC.png', _0x5f2de5('0x449'), _0x5f2de5('0x220')],
                        _0x17619c[_0x5f2de5('0x123')] = _0x697f1c[_0x5f2de5('0x3b6')][_0x5f2de5('0x4ce')][_0x5f2de5('0x66c')](0x1c),
                        _0x1e4e09;
                }
                return _0x3c0eb7[_0xe8b700('0x64a')][_0xe8b700('0x4fc')] = function () {
                    var _0x765c86 = _0xe8b700;
                    this[_0x765c86('0x218')](),
                        this[_0x765c86('0x1d5')]();
                }
                    ,
                    _0x3c0eb7[_0xe8b700('0x64a')][_0xe8b700('0x218')] = function () {
                        var _0x3e594c = _0xe8b700;
                        this[_0x3e594c('0x32e')][_0x3e594c('0x5bf')] = ![],
                            _0x305cd9[_0x3e594c('0x1d1')][_0x3e594c('0x400')] == _0x305cd9[_0x3e594c('0x52b')]['WXAd'] && _0x697f1c[_0x3e594c('0x3b6')][_0x3e594c('0x678')][_0x3e594c('0x144')] <= 0x1 && (this[_0x3e594c('0x42a')][_0x3e594c('0x5bf')] = !![],
                                this[_0x3e594c('0x28e')]['visible'] = !![]);
                    }
                    ,
                    _0x3c0eb7['prototype']['initEvent'] = function () {
                        var _0x5f59cc = _0xe8b700;
                        _0x697f1c['default'][_0x5f59cc('0x370')]['on'](_0x36f003[_0x5f59cc('0x4c3')][_0x5f59cc('0x5f2')], this, this['AddScoreHandle']),
                            _0x697f1c[_0x5f59cc('0x3b6')][_0x5f59cc('0x370')]['on'](_0x36f003[_0x5f59cc('0x4c3')][_0x5f59cc('0x515')], this, this[_0x5f59cc('0x515')]),
                            _0x697f1c['default'][_0x5f59cc('0x370')]['on'](_0x36f003[_0x5f59cc('0x4c3')][_0x5f59cc('0x1a1')], this, this[_0x5f59cc('0x15c')]),
                            this[_0x5f59cc('0x51a')](this[_0x5f59cc('0x28e')], this[_0x5f59cc('0x136')]),
                            this['regClick'](this[_0x5f59cc('0x42a')], this['guideRightHandle']);
                    }
                    ,
                    _0x3c0eb7['prototype'][_0xe8b700('0x136')] = function () {
                        var _0x34abab = _0xe8b700;
                        _0x3b3e57[_0x34abab('0x3b6')][_0x34abab('0x2d0')](this[_0x34abab('0x28e')]);
                    }
                    ,
                    _0x3c0eb7[_0xe8b700('0x64a')][_0xe8b700('0x214')] = function () {
                        var _0x2b6c66 = _0xe8b700;
                        _0x3b3e57[_0x2b6c66('0x3b6')]['guideLeftHandleSmall'](this[_0x2b6c66('0x42a')]);
                    }
                    ,
                    _0x3c0eb7[_0xe8b700('0x64a')][_0xe8b700('0x515')] = function () {
                        var _0x540b8a = _0xe8b700
                            , _0x5b0349 = this;
                        this['remainTime'][_0x540b8a('0x5bf')] = !![],
                            Laya[_0x540b8a('0x5ac')][_0x540b8a('0x1e6')](0x5dc, this, function () {
                                var _0x5effd = _0x540b8a;
                                Laya['Tween']['to'](_0x5b0349['go'], {
                                    'scaleX': 0x0,
                                    'scaleY': 0x0,
                                    'alpha': 0x0
                                }, 0x12c, Laya[_0x5effd('0x2a3')][_0x5effd('0x2aa')]);
                            }),
                            Laya[_0x540b8a('0x5ac')]['loop'](0x3e8, this, this[_0x540b8a('0x33e')]);
                    }
                    ,
                    _0x3c0eb7['prototype'][_0xe8b700('0x15c')] = function (_0x47856a) {
                        var _0x373d11 = _0xe8b700
                            , _0x26c7e3 = this;
                        this[_0x373d11('0x1ba')][_0x373d11('0x3c4')] = _0x373d11('0x577') + _0x47856a + '.png',
                            Laya[_0x373d11('0x34d')]['to'](this['feeling'], {
                                'scaleX': 0x1,
                                'scaleY': 0x1
                            }, 0x64, null, Laya[_0x373d11('0x49f')][_0x373d11('0x5fb')](this, function () {
                                var _0x4d9408 = _0x373d11;
                                Laya[_0x4d9408('0x5ac')][_0x4d9408('0x1e6')](0x1f4, _0x26c7e3, function () {
                                    var _0x278755 = _0x4d9408;
                                    Laya[_0x278755('0x34d')]['to'](_0x26c7e3[_0x278755('0x1ba')], {
                                        'scaleX': 0x0,
                                        'scaleY': 0x0
                                    }, 0xc8);
                                });
                            }));
                    }
                    ,
                    _0x3c0eb7[_0xe8b700('0x64a')][_0xe8b700('0x618')] = function (_0x3181ba) {
                        var _0x314a24 = _0xe8b700
                            , _0x45fbb8 = this;
                        _0x3181ba > 0x0 && (this[_0x314a24('0x682')]['skin'] = this[_0x314a24('0x13d')][_0x3b3e57[_0x314a24('0x3b6')]['random'](0x0, this[_0x314a24('0x13d')][_0x314a24('0x4cc')])],
                            Laya[_0x314a24('0x34d')]['to'](this[_0x314a24('0x544')], {
                                'scaleX': 0x1,
                                'scaleY': 0x1,
                                'alpha': 0x1
                            }, 0x12c, null, Laya[_0x314a24('0x49f')][_0x314a24('0x5fb')](this, function () {
                                var _0x1b9c4c = _0x314a24;
                                Laya[_0x1b9c4c('0x5ac')][_0x1b9c4c('0x1e6')](0x3e8, _0x45fbb8, function () {
                                    var _0x3d7d55 = _0x1b9c4c;
                                    Laya[_0x3d7d55('0x34d')]['to'](_0x45fbb8['tips'], {
                                        'scaleX': 0x0,
                                        'scaleY': 0x0,
                                        'alpha': 0x0
                                    }, 0xc8);
                                });
                            })));
                    }
                    ,
                    _0x3c0eb7[_0xe8b700('0x64a')]['countDownHandle'] = function () {
                        var _0x17bc3e = _0xe8b700
                            , _0x2fe9d8 = _0x697f1c[_0x17bc3e('0x3b6')][_0x17bc3e('0x33b')]['getRemainTime']();
                        _0x2fe9d8 >= 0x0 ? this['remainTime'][_0x17bc3e('0x338')] = _0x3b3e57[_0x17bc3e('0x3b6')][_0x17bc3e('0x561')](_0x2fe9d8) : Laya[_0x17bc3e('0x5ac')][_0x17bc3e('0x466')](this, this[_0x17bc3e('0x33e')]);
                    }
                    ,
                    _0x3c0eb7[_0xe8b700('0x64a')]['close'] = function () {
                        var _0x5219b4 = _0xe8b700;
                        _0x697f1c[_0x5219b4('0x3b6')][_0x5219b4('0x370')][_0x5219b4('0x585')](_0x36f003[_0x5219b4('0x4c3')][_0x5219b4('0x5f2')], this, this[_0x5219b4('0x618')]),
                            _0x697f1c[_0x5219b4('0x3b6')][_0x5219b4('0x370')]['off'](_0x36f003[_0x5219b4('0x4c3')][_0x5219b4('0x515')], this, this[_0x5219b4('0x515')]),
                            _0x697f1c['default'][_0x5219b4('0x370')][_0x5219b4('0x585')](_0x36f003['EventEnum'][_0x5219b4('0x1a1')], this, this['updateFeeling']),
                            _0x2ad816[_0x5219b4('0x64a')][_0x5219b4('0x42')][_0x5219b4('0x324')](this);
                    }
                    ,
                    _0x3c0eb7;
            }(_0x13afcb['ui'][_0x428a35('0x62')][_0x428a35('0x53')]);
        _0x3a58fc['default'] = _0x284cc8;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37
    }],
    0x2d: [function (_0x135b26, _0x31ebc1, _0x314f91) {
        var _0x4a9f8f = _0x4b7fcf;
        'use strict';
        Object[_0x4a9f8f('0x351')](_0x314f91, _0x4a9f8f('0xb8'), {
            'value': !![]
        });
        var _0x48dab4 = _0x135b26(_0x4a9f8f('0x662'))
            , _0x2b634d = _0x135b26('../../XGame')
            , _0x16984f = _0x135b26(_0x4a9f8f('0x69c'))
            , _0x55cf51 = _0x135b26(_0x4a9f8f('0x4dd'))
            , _0x1e11d2 = _0x135b26('../../enum/GameConst')
            , _0x32e9a1 = _0x135b26('./item/RankItem')
            , _0x168e1c = _0x135b26(_0x4a9f8f('0x20c'))
            , _0x6fef34 = function (_0x2f7019) {
                var _0x5d52dc = _0x4a9f8f;
                __extends(_0x54d9dc, _0x2f7019);
                function _0x54d9dc() {
                    var _0x4de1d0 = _0x5985
                        , _0x231547 = _0x2f7019[_0x4de1d0('0x324')](this) || this;
                    return _0x231547[_0x4de1d0('0x442')] = 0x1,
                        _0x231547[_0x4de1d0('0x5d5')] = 0x1,
                        _0x231547[_0x4de1d0('0x49b')] = 0x1,
                        _0x231547[_0x4de1d0('0x1b0')] = [],
                        _0x231547[_0x4de1d0('0x664')] = [],
                        _0x231547;
                }
                return _0x54d9dc['prototype']['onAwake'] = function () {
                    var _0x240991 = _0x5985;
                    _0x2b634d[_0x240991('0x3b6')][_0x240991('0x4ce')][_0x240991('0xeb')]('RankOpen') == 0x0 && this[_0x240991('0x3d2')](),
                        this[_0x240991('0x218')](),
                        this[_0x240991('0x1d5')]();
                }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x3d2')] = function () {
                        var _0x792523 = _0x5d52dc
                            , _0x55a409 = _0x2b634d['default']['CfgMgr'][_0x792523('0x506')]
                            , _0x172c6f = 0x0
                            , _0x269a81 = ![];
                        this[_0x792523('0x442')] = 0x14;
                        while (_0x172c6f < this[_0x792523('0x442')]) {
                            var _0x43ce24 = _0x55a409[_0x168e1c[_0x792523('0x3b6')][_0x792523('0x139')](0x0, _0x55a409['length'] - 0x1) + 0x2711];
                            !_0x269a81 && _0x2b634d[_0x792523('0x3b6')][_0x792523('0x678')][_0x792523('0x144')] > _0x43ce24[_0x792523('0x246')] && (_0x269a81 = !![],
                                this[_0x792523('0x664')][_0x792523('0xff')]({
                                    'Id': 0x1,
                                    '_headUrl': _0x2b634d[_0x792523('0x3b6')]['DataMgr']['headUrl'],
                                    '_nickName': _0x2b634d['default'][_0x792523('0x678')][_0x792523('0x578')],
                                    '_maxScore': _0x2b634d[_0x792523('0x3b6')][_0x792523('0x678')][_0x792523('0x144')]
                                }),
                                _0x172c6f++),
                                this[_0x792523('0x664')][_0x792523('0xff')](_0x43ce24),
                                _0x172c6f++;
                        }
                        this[_0x792523('0x664')][_0x792523('0x33')](function (_0x1a79b4, _0x57bf1f) {
                            var _0x4ea564 = _0x792523;
                            return _0x1a79b4['_maxScore'] > _0x57bf1f[_0x4ea564('0x246')] ? -0x1 : 0x1;
                        });
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x218')] = function () {
                        var _0x1d05c5 = _0x5d52dc;
                        for (var _0x17abc6 = 0x0; _0x17abc6 < 0x5; _0x17abc6++) {
                            var _0x1cff8b = new _0x32e9a1[(_0x1d05c5('0x3b6'))]();
                            _0x1cff8b[_0x1d05c5('0x35c')](![]),
                                this['_itemArr'][_0x1d05c5('0xff')](_0x1cff8b),
                                this[_0x1d05c5('0x34c')][_0x1d05c5('0x5')](_0x1cff8b[_0x1d05c5('0x5d3')]);
                        }
                        this['_ownItem'] = new _0x32e9a1[(_0x1d05c5('0x3b6'))](),
                            this[_0x1d05c5('0x323')][_0x1d05c5('0x35c')](![]),
                            this['myRank'][_0x1d05c5('0x5')](this[_0x1d05c5('0x323')][_0x1d05c5('0x5d3')]);
                        if (_0x2b634d[_0x1d05c5('0x3b6')][_0x1d05c5('0x4ce')][_0x1d05c5('0xeb')]('RankOpen') == 0x0) {
                            this['_ownRank'] = -0x1;
                            for (var _0x17abc6 = 0x0; _0x17abc6 < this[_0x1d05c5('0x664')][_0x1d05c5('0x4cc')]; _0x17abc6++) {
                                if (this[_0x1d05c5('0x664')][_0x17abc6]['Id'] == 0x1) {
                                    this[_0x1d05c5('0x463')] = _0x17abc6 + 0x1;
                                    break;
                                }
                            }
                        }
                        this[_0x1d05c5('0x5a0')]();
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x6a0')] = function (_0x1f9ef9) {
                        var _0x2752d2 = _0x5d52dc
                            , _0x21bc55 = _0x1f9ef9;
                        typeof _0x1f9ef9 == _0x2752d2('0x47d') && (_0x21bc55 = JSON[_0x2752d2('0x66f')](_0x1f9ef9));
                        console[_0x2752d2('0x5df')](_0x2752d2('0x17d'), _0x21bc55);
                        if (_0x21bc55[_0x2752d2('0x4f1')] == 0x1) {
                            this[_0x2752d2('0x442')] = _0x21bc55['data'][_0x2752d2('0x49c')];
                            var _0x5ba45a = _0x21bc55['data'][_0x2752d2('0x66a')];
                            _0x5ba45a[_0x2752d2('0x33')](function (_0x381a40, _0x3fe966) {
                                var _0xf55e57 = _0x2752d2;
                                return _0x381a40[_0xf55e57('0x246')] > _0x3fe966[_0xf55e57('0x246')] ? -0x1 : 0x1;
                            }),
                                this['createItems'](_0x5ba45a, _0x21bc55[_0x2752d2('0x555')][_0x2752d2('0x52')]);
                        }
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x677')] = function (_0x22e0a4, _0xdb20f2) {
                        var _0x387f4c = _0x5d52dc;
                        for (var _0x4504ea = 0x0; _0x4504ea < this[_0x387f4c('0x1b0')][_0x387f4c('0x4cc')]; _0x4504ea++) {
                            var _0x419a76 = this[_0x387f4c('0x1b0')][_0x4504ea];
                            _0x4504ea < _0x22e0a4[_0x387f4c('0x4cc')] ? (_0x419a76[_0x387f4c('0x35c')](!![]),
                                _0x419a76[_0x387f4c('0x53a')]({
                                    'own': ![],
                                    'level': (this[_0x387f4c('0x5d5')] - 0x1) * 0x5 + _0x4504ea + 0x1,
                                    'headUrl': _0x22e0a4[_0x4504ea]['_headUrl'],
                                    'nickName': _0x22e0a4[_0x4504ea]['_nickName'],
                                    'score': _0x22e0a4[_0x4504ea]['_maxScore']
                                })) : _0x419a76[_0x387f4c('0x35c')](![]);
                        }
                        this[_0x387f4c('0x323')]['showItem'](!![]),
                            this[_0x387f4c('0x323')][_0x387f4c('0x53a')]({
                                'own': !![],
                                'level': _0xdb20f2,
                                'headUrl': _0x2b634d[_0x387f4c('0x3b6')][_0x387f4c('0x678')]['headUrl'],
                                'nickName': _0x2b634d['default']['DataMgr']['nickName'],
                                'score': _0x2b634d['default'][_0x387f4c('0x678')][_0x387f4c('0x144')]
                            });
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x1d5')] = function () {
                        var _0x5efcc2 = _0x5d52dc;
                        this[_0x5efcc2('0x51a')](this[_0x5efcc2('0x420')], this[_0x5efcc2('0x356')]),
                            this[_0x5efcc2('0x51a')](this['prepage'], this[_0x5efcc2('0x262')]),
                            this['regClick'](this[_0x5efcc2('0x54a')], this[_0x5efcc2('0x7')]);
                    }
                    ,
                    _0x54d9dc['prototype'][_0x5d52dc('0x262')] = function () {
                        var _0x4848cc = _0x5d52dc;
                        this['_curPage']--,
                            this[_0x4848cc('0x5d5')] = Math[_0x4848cc('0x43d')](0x1, this[_0x4848cc('0x5d5')]),
                            this[_0x4848cc('0x5d5')] != this['_oldPage'] && (this['_oldPage'] = this[_0x4848cc('0x5d5')],
                                this[_0x4848cc('0x5a0')]());
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x7')] = function () {
                        var _0xc3efe8 = _0x5d52dc;
                        this[_0xc3efe8('0x5d5')]++,
                            this['_curPage'] = Math[_0xc3efe8('0x201')](this['_maxRank'] / 0x5, this['_curPage']),
                            this[_0xc3efe8('0x5d5')] != this[_0xc3efe8('0x49b')] && (this['_oldPage'] = this['_curPage'],
                                this[_0xc3efe8('0x5a0')]());
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x5a0')] = function () {
                        var _0x3e622a = _0x5d52dc
                            , _0x5069a7 = (this[_0x3e622a('0x5d5')] - 0x1) * 0x5 + 0x1;
                        _0x5069a7 <= this['_maxRank'] && (_0x2b634d[_0x3e622a('0x3b6')][_0x3e622a('0x4ce')][_0x3e622a('0xeb')](_0x3e622a('0x7a')) == 0x0 ? this['createItems'](this['_robotList']['slice'](_0x5069a7 - 0x1, _0x5069a7 - 0x1 + 0x5), this['_ownRank']) : _0x55cf51[_0x3e622a('0x3b6')][_0x3e622a('0x249')](_0x1e11d2['GameConst']['HttpServer'], 0x3, {
                            'index': _0x5069a7,
                            'count': 0x5,
                            'platform': _0x1e11d2[_0x3e622a('0x1d1')][_0x3e622a('0x400')],
                            'appid': _0x1e11d2[_0x3e622a('0x1d1')][_0x3e622a('0x295')],
                            'openid': _0x2b634d[_0x3e622a('0x3b6')][_0x3e622a('0x678')][_0x3e622a('0x4ea')]
                        }, this['updateView'][_0x3e622a('0x484')](this), !![]));
                    }
                    ,
                    _0x54d9dc['prototype'][_0x5d52dc('0x356')] = function () {
                        var _0x4fdc8b = _0x5d52dc;
                        _0x2b634d[_0x4fdc8b('0x3b6')][_0x4fdc8b('0x5d7')][_0x4fdc8b('0x280')](_0x16984f['UIEnum'][_0x4fdc8b('0x5b4')]);
                    }
                    ,
                    _0x54d9dc[_0x5d52dc('0x64a')][_0x5d52dc('0x42')] = function () {
                        var _0x58f28e = _0x5d52dc;
                        _0x2f7019[_0x58f28e('0x64a')][_0x58f28e('0x42')][_0x58f28e('0x324')](this);
                    }
                    ,
                    _0x54d9dc;
            }(_0x48dab4['ui']['view'][_0x4a9f8f('0x589')]);
        _0x314f91['default'] = _0x6fef34;
    }
        , {
        '../../XGame': 0x4,
        '../../core/Http': 0x7,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        './item/RankItem': 0x32
    }],
    0x2e: [function (_0x396d19, _0x2cc0b9, _0x366cb8) {
        var _0x935de9 = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x366cb8, _0x935de9('0xb8'), {
            'value': !![]
        });
        var _0x46c9c5 = _0x396d19(_0x935de9('0x662'))
            , _0x4358c7 = _0x396d19(_0x935de9('0x69c'))
            , _0x5b3761 = _0x396d19(_0x935de9('0xce'))
            , _0xb5f54f = _0x396d19('../../enum/GameConst')
            , _0x2ca1b7 = _0x396d19(_0x935de9('0x20c'))
            , _0x3bd9dd = _0x396d19(_0x935de9('0x11b'))
            , _0x21cbc4 = _0x396d19('../../Platform')
            , _0x33ccac = function (_0x341ae1) {
                var _0x2dc29d = _0x935de9;
                __extends(_0x2a3eea, _0x341ae1);
                function _0x2a3eea() {
                    var _0x536fab = _0x5985
                        , _0x2d8609 = _0x341ae1[_0x536fab('0x324')](this) || this;
                    return _0x2d8609[_0x536fab('0x6b6')] = [],
                        _0x2d8609['day7Knife'] = 0x0,
                        _0x2d8609[_0x536fab('0xee')] = 0x0,
                        _0x2d8609[_0x536fab('0x228')] = [],
                        _0x2d8609;
                }
                return _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x4fc')] = function () {
                    var _0x438844 = _0x2dc29d;
                    this[_0x438844('0x218')](),
                        this[_0x438844('0x1d5')](),
                        this[_0x438844('0x6a0')]();
                }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')]['initView'] = function () {
                        var _0x33b82d = _0x2dc29d;
                        this[_0x33b82d('0x315')][_0x33b82d('0x338')] = _0x5b3761['default'][_0x33b82d('0x4ce')][_0x33b82d('0x235')](0xa, _0xb5f54f[_0x33b82d('0x1d1')][_0x33b82d('0x64d')]),
                            this['checkedTxt']['text'] = _0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x4ce')][_0x33b82d('0x235')](0x2c, _0xb5f54f['GameConst'][_0x33b82d('0x64d')]),
                            this[_0x33b82d('0x17e')][_0x33b82d('0x338')] = _0x5b3761[_0x33b82d('0x3b6')]['CfgMgr'][_0x33b82d('0x235')](0xb, _0xb5f54f['GameConst'][_0x33b82d('0x64d')]),
                            this[_0x33b82d('0xa2')][_0x33b82d('0x338')] = _0x5b3761[_0x33b82d('0x3b6')]['CfgMgr']['getLangById'](0x4, _0xb5f54f[_0x33b82d('0x1d1')]['Language']);
                        var _0x5829a2 = _0x5b3761['default'][_0x33b82d('0x4ce')][_0x33b82d('0x235')](0x9, _0xb5f54f[_0x33b82d('0x1d1')][_0x33b82d('0x64d')]);
                        _0x5829a2 = _0x2ca1b7[_0x33b82d('0x3b6')][_0x33b82d('0xb4')](_0x5829a2, '7'),
                            this['day7Txt']['text'] = _0x5829a2;
                        var _0x5f0af7 = _0x33b82d('0x606');
                        (_0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x678')][_0x33b82d('0x38d')] > 0x7 || _0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x678')][_0x33b82d('0x38d')] == 0x7 && _0x5b3761['default'][_0x33b82d('0x678')][_0x33b82d('0x629')] != _0x2ca1b7[_0x33b82d('0x3b6')][_0x33b82d('0x366')]()) && (_0x5f0af7 = _0x33b82d('0xd4'),
                            _0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x678')]['signTotalCount'] % 0x7 == 0x0 && (_0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x678')][_0x33b82d('0x2e5')] = 0x0));
                        var _0x504aaf = _0x2ca1b7['default'][_0x33b82d('0x4c9')](_0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x4ce')][_0x33b82d('0xeb')](_0x5f0af7), '|');
                        for (var _0x940edb = 0x0; _0x940edb < _0x504aaf[_0x33b82d('0x4cc')]; _0x940edb++) {
                            if (_0x940edb == _0x504aaf[_0x33b82d('0x4cc')] - 0x1) {
                                var _0x54b951 = _0x2ca1b7['default'][_0x33b82d('0x4c9')](_0x504aaf[_0x940edb], '_');
                                this[_0x33b82d('0x192')] = _0x2ca1b7[_0x33b82d('0x3b6')][_0x33b82d('0x37f')](_0x54b951[0x0])[0x1],
                                    this['day7Gold'] = _0x2ca1b7[_0x33b82d('0x3b6')][_0x33b82d('0x37f')](_0x54b951[0x1])[0x1];
                            } else
                                this[_0x33b82d('0x6b6')]['push'](_0x2ca1b7[_0x33b82d('0x3b6')][_0x33b82d('0x37f')](_0x504aaf[_0x940edb]));
                        }
                        for (var _0x940edb = 0x0; _0x940edb < this[_0x33b82d('0x6b6')][_0x33b82d('0x4cc')]; _0x940edb++) {
                            var _0x114f30 = new _0x3bd9dd[(_0x33b82d('0x3b6'))](_0x940edb);
                            _0x114f30['setPos'](_0x940edb % 0x3 * 0xaa, parseInt((_0x940edb / 0x3)[_0x33b82d('0xcc')]()) * 0xaa),
                                _0x114f30[_0x33b82d('0x548')](this[_0x33b82d('0x6b6')][_0x940edb]),
                                this[_0x33b82d('0x670')][_0x33b82d('0x5')](_0x114f30[_0x33b82d('0x5d3')]),
                                this[_0x33b82d('0x228')][_0x33b82d('0xff')](_0x114f30);
                        }
                        if (_0x5b3761['default'][_0x33b82d('0x678')][_0x33b82d('0x38d')] > 0x7)
                            this['knifeIcon'][_0x33b82d('0x5bf')] = ![],
                                this['goldCount'][_0x33b82d('0x338')] = 'X' + this[_0x33b82d('0xee')],
                                this[_0x33b82d('0x1ea')]['x'] = 0xd2;
                        else
                            _0x5b3761['default'][_0x33b82d('0x678')]['signTotalCount'] == 0x7 ? _0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x678')][_0x33b82d('0x629')] == _0x2ca1b7[_0x33b82d('0x3b6')][_0x33b82d('0x366')]() ? (this[_0x33b82d('0x346')][_0x33b82d('0x3c4')] = _0x33b82d('0x3a7') + _0x5b3761['default'][_0x33b82d('0x4ce')][_0x33b82d('0x3ef')](this['day7Knife'])[_0x33b82d('0x3d9')] + _0x33b82d('0x99'),
                                this[_0x33b82d('0x2a2')]['text'] = 'X' + this['day7Gold']) : (this[_0x33b82d('0x346')][_0x33b82d('0x5bf')] = ![],
                                    this[_0x33b82d('0x2a2')][_0x33b82d('0x338')] = 'X' + this['day7Gold'],
                                    this['gold']['x'] = 0xd2) : (this['knifeIcon'][_0x33b82d('0x3c4')] = _0x33b82d('0x3a7') + _0x5b3761[_0x33b82d('0x3b6')][_0x33b82d('0x4ce')][_0x33b82d('0x3ef')](this[_0x33b82d('0x192')])[_0x33b82d('0x3d9')] + '.png',
                                        this[_0x33b82d('0x2a2')][_0x33b82d('0x338')] = 'X' + this[_0x33b82d('0xee')]);
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x6a2')] = function () {
                        var _0x4e5ba1 = _0x2dc29d
                            , _0x316fd3 = _0x5b3761[_0x4e5ba1('0x3b6')][_0x4e5ba1('0x678')][_0x4e5ba1('0x318')];
                        console[_0x4e5ba1('0x5df')](_0x4e5ba1('0x1e4'), _0x316fd3),
                            _0x316fd3 <= 0x0 && (this[_0x4e5ba1('0x415')][_0x4e5ba1('0x4b0')] = !![]);
                    }
                    ,
                    _0x2a3eea['prototype'][_0x2dc29d('0x6a0')] = function () {
                        var _0x11e728 = _0x2dc29d;
                        for (var _0x9cbf36 = 0x0; _0x9cbf36 < this[_0x11e728('0x228')][_0x11e728('0x4cc')]; _0x9cbf36++) {
                            _0x9cbf36 < _0x5b3761['default']['DataMgr'][_0x11e728('0x2e5')] && this[_0x11e728('0x228')][_0x9cbf36][_0x11e728('0x53a')]();
                        }
                        _0x5b3761['default']['DataMgr']['signDate'] != _0x2ca1b7['default']['getCurrentDate']() ? (this[_0x11e728('0x39c')]['gray'] = ![],
                            this['doublebtn']['gray'] = ![],
                            this[_0x11e728('0x39c')]['mouseEnabled'] = !![],
                            this[_0x11e728('0x415')][_0x11e728('0x3b8')] = !![],
                            this[_0x11e728('0x675')][_0x11e728('0x5bf')] = ![]) : (this[_0x11e728('0x39c')][_0x11e728('0x4b0')] = !![],
                                this[_0x11e728('0x415')][_0x11e728('0x4b0')] = !![],
                                this[_0x11e728('0x39c')]['mouseEnabled'] = ![],
                                this[_0x11e728('0x415')][_0x11e728('0x3b8')] = ![],
                                this['receiveobj'][_0x11e728('0x5bf')] = _0x5b3761['default'][_0x11e728('0x678')]['signCount'] == 0x7),
                            _0xb5f54f[_0x11e728('0x1d1')]['Platform'] == _0xb5f54f['PlatformType'][_0x11e728('0x64')] && this[_0x11e728('0x6a2')]();
                    }
                    ,
                    _0x2a3eea['prototype'][_0x2dc29d('0x1d5')] = function () {
                        var _0x514a35 = _0x2dc29d;
                        this['regClick'](this[_0x514a35('0x39c')], this[_0x514a35('0x2c0')]),
                            this[_0x514a35('0x51a')](this[_0x514a35('0x415')], this[_0x514a35('0x623')]),
                            this['regClick'](this[_0x514a35('0x500')], this[_0x514a35('0x336')]);
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x623')] = function () {
                        var _0x2f183e = _0x2dc29d;
                        logEvent(_0x2f183e('0x158'));
                        if (_0xb5f54f[_0x2f183e('0x1d1')][_0x2f183e('0x400')] != _0xb5f54f['PlatformType'][_0x2f183e('0x64')])
                            _0x21cbc4['default']['createRewardedVideoAd'](_0x5b3761['default'][_0x2f183e('0x4ce')]['getAdCfg'](0x14), this[_0x2f183e('0x21d')][_0x2f183e('0x484')](this), ![]);
                        else {
                            if (_0xb5f54f[_0x2f183e('0x1d1')][_0x2f183e('0x400')] == _0xb5f54f[_0x2f183e('0x52b')]['Game4399']) {
                                _0x2ca1b7[_0x2f183e('0x3b6')]['onPlay4399Ad'](this[_0x2f183e('0x14b')]['bind'](this));
                                return;
                            }
                            this[_0x2f183e('0x21d')](!![]);
                        }
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x14b')] = function (_0x3d3d14) {
                        var _0xa4ba1d = _0x2dc29d;
                        if (!_0x3d3d14)
                            return;
                        console[_0xa4ba1d('0x5df')]('代码:' + _0x3d3d14[_0xa4ba1d('0x559')] + _0xa4ba1d('0x2f6') + _0x3d3d14['message']);
                        if (_0x3d3d14[_0xa4ba1d('0x559')] === 0x2710)
                            console['log'](_0xa4ba1d('0x422'));
                        else {
                            if (_0x3d3d14[_0xa4ba1d('0x559')] === 0x2711)
                                console['log'](_0xa4ba1d('0x543')),
                                    _0x5b3761[_0xa4ba1d('0x3b6')]['DataMgr'][_0xa4ba1d('0x318')] <= 0x0 ? _0x5b3761[_0xa4ba1d('0x3b6')]['DataMgr'][_0xa4ba1d('0x318')] = 0x0 : (_0x5b3761['default'][_0xa4ba1d('0x678')]['adRemainTimes']--,
                                        this[_0xa4ba1d('0x6a2')](),
                                        this[_0xa4ba1d('0x160')](0x2));
                            else {
                                if (_0x5b3761[_0xa4ba1d('0x3b6')]['DataMgr'][_0xa4ba1d('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x21d')] = function (_0x38c6f8, _0x1959a0, _0x21f414) {
                        var _0x16a7a5 = _0x2dc29d;
                        _0x1959a0 === void 0x0 && (_0x1959a0 = null);
                        _0x21f414 === void 0x0 && (_0x21f414 = null);
                        if (_0x1959a0) {
                            _0x5b3761[_0x16a7a5('0x3b6')][_0x16a7a5('0x5d7')][_0x16a7a5('0x46e')](_0x1959a0);
                            return;
                        }
                        _0x38c6f8 ? this['getSignReward'](0x2) : _0x5b3761['default'][_0x16a7a5('0x5d7')]['showTips']('看完视频才能获得奖励！');
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x2c0')] = function () {
                        var _0x59b0d1 = _0x2dc29d;
                        logEvent(_0x59b0d1('0x6a4')),
                            this[_0x59b0d1('0x160')](0x1);
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x160')] = function (_0x5c1bb5) {
                        var _0x692235 = _0x2dc29d;
                        _0x5b3761['default'][_0x692235('0x678')]['signCount'] + 0x1 < 0x7 ? this[_0x692235('0x228')][_0x5b3761[_0x692235('0x3b6')][_0x692235('0x678')]['signCount']][_0x692235('0x12b')](_0x5c1bb5) : (_0x5b3761['default']['DataMgr'][_0x692235('0x45')](this[_0x692235('0xee')] * _0x5c1bb5),
                            this['receiveobj'][_0x692235('0x5bf')] = !![],
                            _0x5b3761[_0x692235('0x3b6')]['DataMgr'][_0x692235('0x45c')](this['day7Knife']),
                            _0x5b3761[_0x692235('0x3b6')][_0x692235('0x5d7')][_0x692235('0x46e')](_0x5b3761[_0x692235('0x3b6')][_0x692235('0x4ce')][_0x692235('0x235')](0x26, _0xb5f54f['GameConst']['Language']))),
                            _0x5b3761[_0x692235('0x3b6')][_0x692235('0x678')][_0x692235('0x2e5')]++,
                            _0x5b3761[_0x692235('0x3b6')][_0x692235('0x678')][_0x692235('0x38d')]++,
                            _0x5b3761['default'][_0x692235('0x678')]['signDate'] = _0x2ca1b7[_0x692235('0x3b6')]['getCurrentDate'](),
                            this[_0x692235('0x6a0')]();
                    }
                    ,
                    _0x2a3eea['prototype'][_0x2dc29d('0x336')] = function () {
                        var _0x3aa08d = _0x2dc29d;
                        for (var _0x3ad233 = 0x0; _0x3ad233 < this[_0x3aa08d('0x228')][_0x3aa08d('0x4cc')]; _0x3ad233++) {
                            this[_0x3aa08d('0x228')][_0x3ad233][_0x3aa08d('0x392')]();
                        }
                        this[_0x3aa08d('0x228')]['length'] = 0x0,
                            _0x5b3761['default'][_0x3aa08d('0x5d7')][_0x3aa08d('0x280')](_0x4358c7[_0x3aa08d('0x339')][_0x3aa08d('0x5b4')]);
                    }
                    ,
                    _0x2a3eea[_0x2dc29d('0x64a')][_0x2dc29d('0x42')] = function () {
                        var _0x35740a = _0x2dc29d;
                        _0x341ae1[_0x35740a('0x64a')]['close'][_0x35740a('0x324')](this);
                    }
                    ,
                    _0x2a3eea;
            }(_0x46c9c5['ui']['view'][_0x935de9('0x269')]);
        _0x366cb8[_0x935de9('0x3b6')] = _0x33ccac;
    }
        , {
        '../../Platform': 0x3,
        '../../XGame': 0x4,
        '../../enum/GameConst': 0xf,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        './item/SignItem': 0x34
    }],
    0x2f: [function (_0x24e076, _0xd1f62, _0xc93f4e) {
        var _0x2717f7 = _0x4b7fcf;
        'use strict';
        Object[_0x2717f7('0x351')](_0xc93f4e, _0x2717f7('0xb8'), {
            'value': !![]
        });
        var _0x4271e6 = _0x24e076('../../ui/layaMaxUI')
            , _0x15592c = _0x24e076(_0x2717f7('0xce'))
            , _0x534cc5 = _0x24e076(_0x2717f7('0x20c'))
            , _0x5b4a9f = _0x24e076(_0x2717f7('0x69c'))
            , _0x327446 = _0x24e076(_0x2717f7('0x685'))
            , _0x4832b0 = _0x24e076(_0x2717f7('0x4c'))
            , _0x5bb67c = _0x24e076('../DragListScript')
            , _0x23fda2 = _0x24e076(_0x2717f7('0x61a'))
            , _0x2602ca = _0x24e076(_0x2717f7('0x34f'))
            , _0x5e5812 = _0x24e076(_0x2717f7('0x322'))
            , _0x1ccc0d = _0x24e076(_0x2717f7('0x46'))
            , _0xc0c44e = function (_0x529109) {
                var _0x4f67dd = _0x2717f7;
                __extends(_0x324370, _0x529109);
                function _0x324370(_0x22cbc2) {
                    var _0x2324b5 = _0x5985
                        , _0x50599e = _0x529109['call'](this) || this;
                    return _0x50599e[_0x2324b5('0x40b')] = 0x0,
                        _0x50599e[_0x2324b5('0x35a')] = null,
                        _0x50599e[_0x2324b5('0x38')] = [],
                        _0x50599e[_0x2324b5('0x57c')] = [],
                        _0x50599e['_hoopPageArr'] = [],
                        _0x50599e[_0x2324b5('0x2ec')] = null,
                        _0x50599e[_0x2324b5('0x57a')] = [],
                        _0x50599e['_ballMap'] = {},
                        _0x50599e[_0x2324b5('0x376')] = [],
                        _0x50599e['hooArr'] = [],
                        _0x22cbc2['adunit'] = _0x15592c[_0x2324b5('0x3b6')][_0x2324b5('0x4ce')]['getAdCfg'](0x4),
                        _0x50599e;
                }
                return _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x4fc')] = function () {
                    var _0x43ad19 = _0x4f67dd;
                    this[_0x43ad19('0x218')](),
                        this['initEvent'](),
                        window['h5Platform']['interstitialShow']();
                }
                    ,
                    _0x324370['prototype'][_0x4f67dd('0x218')] = function () {
                        var _0x4b7a5e = _0x4f67dd;
                        this[_0x4b7a5e('0x52a')][_0x4b7a5e('0x338')] = _0x15592c['default'][_0x4b7a5e('0x4ce')][_0x4b7a5e('0x235')](0xe, _0x1ccc0d[_0x4b7a5e('0x1d1')]['Language']),
                            this['BallTxt'][_0x4b7a5e('0x338')] = _0x15592c[_0x4b7a5e('0x3b6')]['CfgMgr'][_0x4b7a5e('0x235')](0xf, _0x1ccc0d['GameConst'][_0x4b7a5e('0x64d')]),
                            this[_0x4b7a5e('0x5ed')][_0x4b7a5e('0x338')] = _0x15592c['default'][_0x4b7a5e('0x4ce')]['getLangById'](0x10, _0x1ccc0d['GameConst'][_0x4b7a5e('0x64d')]),
                            this[_0x4b7a5e('0x54f')][_0x4b7a5e('0x338')] = _0x15592c[_0x4b7a5e('0x3b6')][_0x4b7a5e('0x4ce')][_0x4b7a5e('0x235')](0x11, _0x1ccc0d[_0x4b7a5e('0x1d1')]['Language']),
                            this['useTxt'][_0x4b7a5e('0x338')] = _0x15592c[_0x4b7a5e('0x3b6')][_0x4b7a5e('0x4ce')][_0x4b7a5e('0x235')](0x12, _0x1ccc0d[_0x4b7a5e('0x1d1')][_0x4b7a5e('0x64d')]),
                            this['_skinScene'] = Laya[_0x4b7a5e('0x150')][_0x4b7a5e('0x5')](Laya[_0x4b7a5e('0x5e')][_0x4b7a5e('0xcb')](_0x327446['Scenes'][_0x4b7a5e('0x21b')])),
                            this[_0x4b7a5e('0x363')]['ambientColor'] = new Laya[(_0x4b7a5e('0x592'))](0.85, 0.85, 0.85),
                            Laya[_0x4b7a5e('0x150')][_0x4b7a5e('0x5')](this[_0x4b7a5e('0x363')]),
                            this[_0x4b7a5e('0xf')][_0x4b7a5e('0x338')] = _0x534cc5[_0x4b7a5e('0x3b6')][_0x4b7a5e('0x456')](_0x15592c['default']['DataMgr']['coinCount']),
                            this[_0x4b7a5e('0x35a')] = this['addItemInfo'](_0x327446[_0x4b7a5e('0x4cb')][_0x4b7a5e('0x331')], this[_0x4b7a5e('0x330')], this[_0x4b7a5e('0x57c')], this[_0x4b7a5e('0x13e')]),
                            this['_ballDrag'] = this[_0x4b7a5e('0x418')](_0x327446[_0x4b7a5e('0x4cb')][_0x4b7a5e('0x34a')], this[_0x4b7a5e('0x1ad')], this[_0x4b7a5e('0x4f9')], this[_0x4b7a5e('0x376')]),
                            this['_hoopInfoArr'] = _0x15592c[_0x4b7a5e('0x3b6')]['CfgMgr'][_0x4b7a5e('0x430')](_0x327446['ItemType'][_0x4b7a5e('0x331')]),
                            this['_ballInfoArr'] = _0x15592c[_0x4b7a5e('0x3b6')]['CfgMgr'][_0x4b7a5e('0x430')](_0x327446[_0x4b7a5e('0x4cb')][_0x4b7a5e('0x34a')]),
                            this[_0x4b7a5e('0x533')](),
                            this[_0x4b7a5e('0x2d4')]();
                        if (_0x1ccc0d[_0x4b7a5e('0x1d1')]['Platform'] == _0x1ccc0d['PlatformType'][_0x4b7a5e('0xd1')] || _0x1ccc0d[_0x4b7a5e('0x1d1')][_0x4b7a5e('0x400')] == _0x1ccc0d['PlatformType']['OPPOAd'] || _0x1ccc0d[_0x4b7a5e('0x1d1')][_0x4b7a5e('0x400')] == _0x1ccc0d[_0x4b7a5e('0x52b')][_0x4b7a5e('0x691')] || _0x1ccc0d[_0x4b7a5e('0x1d1')][_0x4b7a5e('0x400')] == _0x1ccc0d[_0x4b7a5e('0x52b')][_0x4b7a5e('0x369')] || _0x1ccc0d['GameConst'][_0x4b7a5e('0x400')] == _0x1ccc0d['PlatformType'][_0x4b7a5e('0x64')] || _0x1ccc0d[_0x4b7a5e('0x1d1')][_0x4b7a5e('0x400')] == _0x1ccc0d[_0x4b7a5e('0x52b')][_0x4b7a5e('0x32b')] || _0x1ccc0d['GameConst'][_0x4b7a5e('0x400')] == _0x1ccc0d[_0x4b7a5e('0x52b')][_0x4b7a5e('0x1e0')] || _0x1ccc0d['GameConst'][_0x4b7a5e('0x400')] == _0x1ccc0d['PlatformType'][_0x4b7a5e('0x576')])
                            this[_0x4b7a5e('0x388')]['visible'] = !![],
                                this[_0x4b7a5e('0x267')]['visible'] = ![],
                                this[_0x4b7a5e('0x42e')][_0x4b7a5e('0x5bf')] = ![];
                        else
                            _0x1ccc0d[_0x4b7a5e('0x1d1')][_0x4b7a5e('0x400')] == _0x1ccc0d['PlatformType'][_0x4b7a5e('0x576')] && !_0x15592c[_0x4b7a5e('0x3b6')]['DataMgr'][_0x4b7a5e('0x436')] && (console[_0x4b7a5e('0x5df')](!_0x15592c[_0x4b7a5e('0x3b6')][_0x4b7a5e('0x678')][_0x4b7a5e('0x436')]),
                                this[_0x4b7a5e('0x388')][_0x4b7a5e('0x5bf')] = !![],
                                this[_0x4b7a5e('0x267')][_0x4b7a5e('0x5bf')] = ![],
                                this[_0x4b7a5e('0x42e')][_0x4b7a5e('0x5bf')] = ![]);
                        Laya['timer'][_0x4b7a5e('0x55')](0x1, this, this['showHoopTurnHandle']),
                            _0x534cc5[_0x4b7a5e('0x3b6')][_0x4b7a5e('0x72')](this, this['usebtn'], Laya['stage']['displayHeight'] - 0x78, 0x438),
                            _0x1ccc0d['GameConst'][_0x4b7a5e('0x400')] == _0x1ccc0d[_0x4b7a5e('0x52b')]['Game4399'] && this[_0x4b7a5e('0x6a2')]();
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x6a2')] = function () {
                        var _0x2ae6f5 = _0x4f67dd
                            , _0x550fc5 = _0x15592c[_0x2ae6f5('0x3b6')][_0x2ae6f5('0x678')][_0x2ae6f5('0x318')];
                        console[_0x2ae6f5('0x5df')](_0x2ae6f5('0x1e4'), _0x550fc5);
                        if (_0x550fc5 <= 0x0) {
                            this[_0x2ae6f5('0x388')]['gray'] = !![];
                            for (var _0x5ab304 = 0x0; _0x5ab304 < this[_0x2ae6f5('0x6b5')][_0x2ae6f5('0x4cc')]; _0x5ab304++) {
                                this[_0x2ae6f5('0x6b5')][_0x5ab304]['adRemainTimes'](_0x15592c[_0x2ae6f5('0x3b6')][_0x2ae6f5('0x678')][_0x2ae6f5('0x318')]);
                            }
                        }
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x391')] = function () {
                        var _0x1ef769 = _0x4f67dd;
                        _0x15592c[_0x1ef769('0x3b6')][_0x1ef769('0x678')][_0x1ef769('0x1a2')] >= 0x1 && (this['sharebtn']['visible'] = ![],
                            this[_0x1ef769('0x388')]['visible'] = !![]);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x1d5')] = function () {
                        var _0x2694a6 = _0x4f67dd;
                        this['regClick'](this[_0x2694a6('0x328')], this[_0x2694a6('0x2c2')]),
                            this[_0x2694a6('0x51a')](this[_0x2694a6('0x68')], this[_0x2694a6('0x3e7')]),
                            this[_0x2694a6('0x51a')](this[_0x2694a6('0x97')], this[_0x2694a6('0x4d1')]),
                            this[_0x2694a6('0x51a')](this[_0x2694a6('0x500')], this[_0x2694a6('0x87')]),
                            this['regClick'](this['hoopbtn'], this['hoopClickHandle']),
                            this[_0x2694a6('0x51a')](this[_0x2694a6('0x6a5')], this[_0x2694a6('0x57d')]),
                            this['regClick'](this['gembtn'], this['freeGemHandle']),
                            this[_0x2694a6('0x51a')](this['sharebtn'], this[_0x2694a6('0x3ec')]),
                            this[_0x2694a6('0x51a')](this['unlockbtn'], this['unlockClickHandle']),
                            this[_0x2694a6('0x51a')](this[_0x2694a6('0x42e')], this[_0x2694a6('0x2db')]),
                            _0x15592c[_0x2694a6('0x3b6')][_0x2694a6('0x370')]['on'](_0x23fda2[_0x2694a6('0x4c3')][_0x2694a6('0x4e7')], this, this[_0x2694a6('0x2a9')]),
                            _0x15592c[_0x2694a6('0x3b6')][_0x2694a6('0x370')]['on'](_0x23fda2[_0x2694a6('0x4c3')][_0x2694a6('0x117')], this, this[_0x2694a6('0x54b')]);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['showShareBtn'] = function () {
                        var _0x58e960 = _0x4f67dd;
                        _0x15592c[_0x58e960('0x3b6')][_0x58e960('0x678')][_0x58e960('0x1a2')] <= 0x0 ? (this['gembtn'][_0x58e960('0x5bf')] = ![],
                            this[_0x58e960('0x267')][_0x58e960('0x5bf')] = !![]) : (this[_0x58e960('0x388')][_0x58e960('0x5bf')] = !![],
                                this[_0x58e960('0x267')][_0x58e960('0x5bf')] = ![]);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x435')] = function () {
                        var _0x554d45 = _0x4f67dd;
                        logEvent('button_free\x20gem_ad'),
                            _0x1ccc0d[_0x554d45('0x1d1')][_0x554d45('0x400')] != _0x1ccc0d[_0x554d45('0x52b')][_0x554d45('0x64')] ? this['_selectHoopFlag'] ? _0x534cc5[_0x554d45('0x3b6')][_0x554d45('0x1e5')](_0x15592c[_0x554d45('0x3b6')]['CfgMgr'][_0x554d45('0x66c')](0xf), this, this['onWatchTvCallback'][_0x554d45('0x484')](this)) : _0x534cc5['default'][_0x554d45('0x1e5')](_0x15592c[_0x554d45('0x3b6')]['CfgMgr']['getAdCfg'](0x18), this, this[_0x554d45('0x9e')][_0x554d45('0x484')](this)) : _0x534cc5['default'][_0x554d45('0x56b')](this[_0x554d45('0x14b')][_0x554d45('0x484')](this));
                    }
                    ,
                    _0x324370['prototype'][_0x4f67dd('0x14b')] = function (_0x26ef62) {
                        var _0x26254b = _0x4f67dd;
                        if (!_0x26ef62)
                            return;
                        console[_0x26254b('0x5df')](_0x26254b('0x3e') + _0x26ef62['code'] + _0x26254b('0x2f6') + _0x26ef62['message']);
                        if (_0x26ef62[_0x26254b('0x559')] === 0x2710)
                            console[_0x26254b('0x5df')](_0x26254b('0x422'));
                        else {
                            if (_0x26ef62['code'] === 0x2711) {
                                console['log']('播放结束');
                                if (_0x15592c[_0x26254b('0x3b6')]['DataMgr'][_0x26254b('0x318')] <= 0x0)
                                    _0x15592c[_0x26254b('0x3b6')][_0x26254b('0x678')][_0x26254b('0x318')] = 0x0;
                                else {
                                    _0x15592c[_0x26254b('0x3b6')][_0x26254b('0x678')][_0x26254b('0x318')]--,
                                        this[_0x26254b('0x6a2')]();
                                    var _0x5ac11b = _0x534cc5[_0x26254b('0x3b6')][_0x26254b('0x37f')](_0x15592c[_0x26254b('0x3b6')][_0x26254b('0x4ce')]['getGlobalCfg'](_0x26254b('0x15f')))
                                        , _0x3bebc3 = _0x534cc5[_0x26254b('0x3b6')][_0x26254b('0x139')](_0x5ac11b[0x0], _0x5ac11b[0x1]);
                                    _0x15592c[_0x26254b('0x3b6')][_0x26254b('0x5d7')][_0x26254b('0x46e')](_0x15592c[_0x26254b('0x3b6')]['CfgMgr'][_0x26254b('0x235')](0x25, _0x1ccc0d['GameConst']['Language']) + '+' + _0x3bebc3),
                                        _0x15592c['default'][_0x26254b('0x678')][_0x26254b('0x45')](_0x3bebc3),
                                        this[_0x26254b('0xf')]['text'] = _0x534cc5[_0x26254b('0x3b6')]['ScoreToString'](_0x15592c[_0x26254b('0x3b6')][_0x26254b('0x678')][_0x26254b('0xf')]);
                                }
                            } else {
                                if (_0x15592c['default'][_0x26254b('0x678')][_0x26254b('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['onWatchTvCallback'] = function (_0x3a68c7, _0x482b33, _0x3e7d46) {
                        var _0x452f28 = _0x4f67dd;
                        _0x482b33 === void 0x0 && (_0x482b33 = null);
                        _0x3e7d46 === void 0x0 && (_0x3e7d46 = null);
                        if (_0x482b33) {
                            _0x15592c[_0x452f28('0x3b6')]['UIMgr'][_0x452f28('0x46e')](_0x482b33);
                            return;
                        }
                        if (_0x3a68c7) {
                            var _0x36e55a = _0x534cc5[_0x452f28('0x3b6')]['TransferStringToNumberArr'](_0x15592c[_0x452f28('0x3b6')][_0x452f28('0x4ce')][_0x452f28('0xeb')](_0x452f28('0x15f')))
                                , _0x5ec912 = _0x534cc5['default'][_0x452f28('0x139')](_0x36e55a[0x0], _0x36e55a[0x1]);
                            _0x15592c[_0x452f28('0x3b6')][_0x452f28('0x5d7')]['showTips'](_0x15592c['default'][_0x452f28('0x4ce')][_0x452f28('0x235')](0x25, _0x1ccc0d[_0x452f28('0x1d1')][_0x452f28('0x64d')]) + '+' + _0x5ec912),
                                _0x15592c[_0x452f28('0x3b6')]['DataMgr'][_0x452f28('0x45')](_0x5ec912),
                                this[_0x452f28('0xf')][_0x452f28('0x338')] = _0x534cc5[_0x452f28('0x3b6')][_0x452f28('0x456')](_0x15592c[_0x452f28('0x3b6')]['DataMgr'][_0x452f28('0xf')]);
                        } else
                            _0x15592c[_0x452f28('0x3b6')][_0x452f28('0x5d7')][_0x452f28('0x46e')](_0x452f28('0x1c3'));
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x3ec')] = function () {
                        var _0xb43b3f = _0x4f67dd;
                        _0x5e5812[_0xb43b3f('0x3b6')][_0xb43b3f('0x3a2')][_0xb43b3f('0x4d6')](Laya['Handler'][_0xb43b3f('0x5fb')](this, this[_0xb43b3f('0x680')]));
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x680')] = function (_0x10a701) {
                        var _0x4ef88b = _0x4f67dd;
                        _0x10a701 ? (_0x15592c['default'][_0x4ef88b('0x5d7')][_0x4ef88b('0x46e')](_0x4ef88b('0x2dc')),
                            _0x15592c[_0x4ef88b('0x3b6')]['DataMgr'][_0x4ef88b('0x45')](0x3c),
                            this['coinCount']['text'] = _0x534cc5[_0x4ef88b('0x3b6')][_0x4ef88b('0x456')](_0x15592c[_0x4ef88b('0x3b6')][_0x4ef88b('0x678')][_0x4ef88b('0xf')]),
                            _0x15592c[_0x4ef88b('0x3b6')][_0x4ef88b('0x678')][_0x4ef88b('0x1a2')]++,
                            this['showShareBtn']()) : _0x15592c[_0x4ef88b('0x3b6')][_0x4ef88b('0x5d7')][_0x4ef88b('0x46e')](_0x4ef88b('0x1e9'));
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['unlockClickHandle'] = function () {
                        var _0x47be45 = _0x4f67dd;
                        if (_0x15592c[_0x47be45('0x3b6')][_0x47be45('0x678')]['coinCount'] < parseInt(this['unlockCoin'][_0x47be45('0x338')]))
                            _0x15592c['default']['UIMgr'][_0x47be45('0x46e')](_0x15592c[_0x47be45('0x3b6')][_0x47be45('0x4ce')][_0x47be45('0x235')](0x2b, _0x1ccc0d[_0x47be45('0x1d1')][_0x47be45('0x64d')]));
                        else {
                            this[_0x47be45('0x240')]['mouseEnabled'] = ![],
                                this['hoopbtn'][_0x47be45('0x3b8')] = ![],
                                this[_0x47be45('0x6a5')][_0x47be45('0x3b8')] = ![],
                                this['closebtn'][_0x47be45('0x3b8')] = ![],
                                _0x15592c[_0x47be45('0x3b6')][_0x47be45('0x678')][_0x47be45('0x45')](-parseInt(this[_0x47be45('0x375')][_0x47be45('0x338')])),
                                this[_0x47be45('0xf')][_0x47be45('0x338')] = _0x534cc5['default'][_0x47be45('0x456')](_0x15592c[_0x47be45('0x3b6')][_0x47be45('0x678')][_0x47be45('0xf')]);
                            var _0x51117a = this[_0x47be45('0x357')]();
                            this[_0x47be45('0x35a')]['removeEvent'](),
                                this[_0x47be45('0x2ec')][_0x47be45('0x39d')](),
                                Laya[_0x47be45('0x5ac')][_0x47be45('0x2e8')](0xc8, this, this[_0x47be45('0x37c')], [_0x51117a]),
                                _0x51117a['length'] > 0x1 ? Laya[_0x47be45('0x5ac')][_0x47be45('0x1e6')](0xbb8, this, this[_0x47be45('0x684')], [_0x51117a]) : Laya[_0x47be45('0x5ac')]['once'](0x12c, this, this[_0x47be45('0x684')], [_0x51117a]);
                        }
                    }
                    ,
                    _0x324370['prototype'][_0x4f67dd('0x37c')] = function (_0x47178e) {
                        var _0x454301 = _0x4f67dd;
                        this[_0x454301('0x40b')]++;
                        this[_0x454301('0x40b')] >= _0x47178e[_0x454301('0x4cc')] && (this['_randomId'] = 0x0);
                        var _0x24ef7f = _0x47178e[this[_0x454301('0x40b')]] % 0x6 - 0x1;
                        _0x47178e[this[_0x454301('0x40b')]] % 0x6 == 0x0 && (_0x24ef7f = 0x6 - 0x1),
                            this[_0x454301('0x230')](_0x24ef7f);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['stopRandomTimer'] = function (_0x528c7b) {
                        var _0x5f1f15 = _0x4f67dd;
                        Laya['timer'][_0x5f1f15('0x466')](this, this[_0x5f1f15('0x37c')]),
                            Laya[_0x5f1f15('0x5ac')]['clear'](this, this[_0x5f1f15('0x684')]);
                        var _0x9a7f16 = _0x528c7b[_0x534cc5[_0x5f1f15('0x3b6')]['random'](0x0, _0x528c7b[_0x5f1f15('0x4cc')] - 0x1)];
                        this[_0x5f1f15('0x4b7')] ? (_0x15592c['default'][_0x5f1f15('0x678')][_0x5f1f15('0x45c')](_0x9a7f16),
                            this[_0x5f1f15('0x57c')][_0x9a7f16]['updateData'](_0x9a7f16),
                            this['_hoopDrag'][_0x5f1f15('0x26a')](![])) : (_0x15592c['default'][_0x5f1f15('0x678')]['addunlockBall'](_0x9a7f16),
                                this[_0x5f1f15('0x4f9')][_0x9a7f16][_0x5f1f15('0x3ea')](_0x9a7f16),
                                this[_0x5f1f15('0x2ec')][_0x5f1f15('0x26a')](![])),
                            this[_0x5f1f15('0x240')][_0x5f1f15('0x3b8')] = !![],
                            this[_0x5f1f15('0x3db')][_0x5f1f15('0x3b8')] = !![],
                            this['ballbtn'][_0x5f1f15('0x3b8')] = !![],
                            this['closebtn']['mouseEnabled'] = !![],
                            this[_0x5f1f15('0x2a1')][_0x5f1f15('0x5bf')] = ![],
                            this[_0x5f1f15('0x2a9')](this[_0x5f1f15('0x5d5')], ![]);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['setSelectIconPos'] = function (_0x294eb1) {
                        var _0x238100 = _0x4f67dd
                            , _0x1181f7 = _0x294eb1 % 0x3
                            , _0x46f1a8 = parseInt((_0x294eb1 / 0x3)[_0x238100('0xcc')]());
                        this[_0x238100('0x2a1')][_0x238100('0x1bf')](_0x1181f7 * 0xdc + 0x4b, _0x46f1a8 * 0xc3 + 0x2a),
                            this[_0x238100('0x2a1')][_0x238100('0x5bf')] = !![];
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['getUnlockIndex'] = function () {
                        var _0x35a020 = _0x4f67dd
                            , _0x5d7e23 = []
                            , _0x2de829 = this['_curPage'] * 0x6 + 0x1
                            , _0x2700df = (this['_curPage'] + 0x1) * 0x6
                            , _0x1d3ed6 = this[_0x35a020('0x4b7')] ? this['_hoopInfoArr'] : this[_0x35a020('0x57a')]
                            , _0x19b723 = this['_selectHoopFlag'] ? this[_0x35a020('0x57c')] : this[_0x35a020('0x4f9')];
                        for (var _0x20c7d6 = _0x2de829; _0x20c7d6 <= _0x2700df; _0x20c7d6++) {
                            !_0x19b723[_0x1d3ed6[_0x20c7d6 - 0x1]['Id']][_0x35a020('0x459')] && _0x5d7e23[_0x35a020('0xff')](_0x1d3ed6[_0x20c7d6 - 0x1]['Id']);
                        }
                        return _0x5d7e23;
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x251')] = function () {
                        var _0xaec411 = _0x4f67dd;
                        this['_itemObj'] != null && (this[_0xaec411('0x36a')][_0xaec411('0xb6')][_0xaec411('0x35d')] += 0x1,
                            this[_0xaec411('0x36a')]['transform'][_0xaec411('0x2f0')] += 0x1);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x54b')] = function (_0x101912, _0x3f205b) {
                        var _0x406c0e = _0x4f67dd
                            , _0x3054e9 = this;
                        if (_0x3f205b) {
                            this[_0x406c0e('0x4b7')] ? (this[_0x406c0e('0x57c')][this['_preSelectId']][_0x406c0e('0x143')](![]),
                                this['_hoopMap'][_0x101912['Id']][_0x406c0e('0x143')](!![]),
                                logEvent(_0x406c0e('0x3bd') + _0x101912['Id'])) : (this['_ballMap'][this[_0x406c0e('0x5ea')]][_0x406c0e('0x143')](![]),
                                    this[_0x406c0e('0x4f9')][_0x101912['Id']][_0x406c0e('0x143')](!![]),
                                    logEvent('button_ball\x20' + _0x101912['Id']));
                            this['_preSelectId'] = _0x101912['Id'];
                            if (_0x1ccc0d[_0x406c0e('0x1d1')][_0x406c0e('0x400')] == _0x1ccc0d[_0x406c0e('0x52b')][_0x406c0e('0x691')] || _0x1ccc0d[_0x406c0e('0x1d1')][_0x406c0e('0x400')] == _0x1ccc0d[_0x406c0e('0x52b')][_0x406c0e('0x5a2')] || _0x1ccc0d[_0x406c0e('0x1d1')]['Platform'] == _0x1ccc0d[_0x406c0e('0x52b')][_0x406c0e('0x369')] || _0x1ccc0d['GameConst'][_0x406c0e('0x400')] == _0x1ccc0d[_0x406c0e('0x52b')][_0x406c0e('0x576')] || _0x1ccc0d[_0x406c0e('0x1d1')]['Platform'] == _0x1ccc0d['PlatformType'][_0x406c0e('0x32b')] || _0x1ccc0d[_0x406c0e('0x1d1')][_0x406c0e('0x400')] == _0x1ccc0d['PlatformType'][_0x406c0e('0x1e0')] || _0x1ccc0d[_0x406c0e('0x1d1')][_0x406c0e('0x400')] == _0x1ccc0d['PlatformType'][_0x406c0e('0x576')]) {
                                this[_0x406c0e('0x542')](_0x101912[_0x406c0e('0x29d')]);
                                return;
                            }
                            this[_0x406c0e('0x542')](_0x101912[_0x406c0e('0x29d')]),
                                _0x534cc5[_0x406c0e('0x3b6')][_0x406c0e('0x72')](this, this[_0x406c0e('0x42e')], Laya[_0x406c0e('0x150')]['displayHeight'] - 0x78, 0x438);
                        } else {
                            if (_0x1ccc0d[_0x406c0e('0x1d1')][_0x406c0e('0x400')] != _0x1ccc0d['PlatformType'][_0x406c0e('0x64')]) {
                                var _0x3ae2d6 = _0x15592c[_0x406c0e('0x3b6')]['CfgMgr']['getGlobalCfg']('GemLevel');
                                !this[_0x406c0e('0x165')] && (this[_0x406c0e('0x4b7')] ? _0x534cc5[_0x406c0e('0x3b6')][_0x406c0e('0x1e5')](_0x15592c[_0x406c0e('0x3b6')][_0x406c0e('0x4ce')][_0x406c0e('0x66c')](0xd), this, function (_0xb7f2d3, _0xff6a9, _0x1cd8f3) {
                                    var _0x13d131 = _0x406c0e;
                                    _0xff6a9 === void 0x0 && (_0xff6a9 = null);
                                    _0x1cd8f3 === void 0x0 && (_0x1cd8f3 = null);
                                    if (_0xff6a9) {
                                        _0x15592c[_0x13d131('0x3b6')][_0x13d131('0x5d7')][_0x13d131('0x46e')](_0xff6a9);
                                        return;
                                    }
                                    if (_0xb7f2d3) {
                                        logEvent(_0x13d131('0x6ac') + _0x101912['Id']),
                                            console[_0x13d131('0x5df')](_0xb7f2d3, 'skinUI.....');
                                        var _0x41cf76 = _0x15592c[_0x13d131('0x3b6')][_0x13d131('0x678')]['maxLevel']
                                            , _0x59bc6b = _0x41cf76 % _0x15592c[_0x13d131('0x3b6')][_0x13d131('0x4ce')][_0x13d131('0xeb')](_0x13d131('0xf6')) == 0x0 ? _0x2602ca[_0x13d131('0x281')][_0x13d131('0x4b6')][_0x13d131('0x6a6')] : _0x2602ca['GameEnum'][_0x13d131('0x4b6')]['Normal']
                                            , _0x30c08a = _0x534cc5[_0x13d131('0x3b6')][_0x13d131('0x139')](0x1, 0x12);
                                        _0x41cf76 % _0x3ae2d6 == 0x0 ? _0x15592c[_0x13d131('0x3b6')][_0x13d131('0xba')][_0x13d131('0x382')](0x5, _0x2602ca[_0x13d131('0x281')][_0x13d131('0x4b6')][_0x13d131('0x6a6')], function () {
                                            var _0x14a054 = _0x13d131;
                                            _0x15592c['default'][_0x14a054('0x5d7')][_0x14a054('0x280')](_0x5b4a9f['UIEnum'][_0x14a054('0x28f')], _0x101912['Id']);
                                        }) : (_0x15592c[_0x13d131('0x3b6')]['UIMgr']['toUI'](_0x5b4a9f[_0x13d131('0x339')][_0x13d131('0x255')]),
                                            _0x15592c[_0x13d131('0x3b6')][_0x13d131('0x33b')][_0x13d131('0x4e2')](_0x15592c['default'][_0x13d131('0x678')]['curRound'], _0x101912['Id'], _0x30c08a, _0x59bc6b));
                                    } else
                                        _0x15592c[_0x13d131('0x3b6')][_0x13d131('0x5d7')][_0x13d131('0x46e')](_0x13d131('0x132'));
                                }) : _0x534cc5[_0x406c0e('0x3b6')][_0x406c0e('0x1e5')](_0x15592c['default']['CfgMgr'][_0x406c0e('0x66c')](0x10), this, function (_0x3457bf, _0x5a4781, _0x8432e2) {
                                    var _0x1931aa = _0x406c0e;
                                    _0x5a4781 === void 0x0 && (_0x5a4781 = null);
                                    _0x8432e2 === void 0x0 && (_0x8432e2 = null);
                                    if (_0x5a4781) {
                                        _0x15592c['default'][_0x1931aa('0x5d7')][_0x1931aa('0x46e')](_0x5a4781);
                                        return;
                                    }
                                    if (_0x3457bf) {
                                        logEvent('button_ball\x20unlock\x20' + _0x101912['Id']),
                                            _0x15592c[_0x1931aa('0x3b6')][_0x1931aa('0x5d7')][_0x1931aa('0x280')](_0x5b4a9f['UIEnum'][_0x1931aa('0x255')]);
                                        var _0x3a17f6 = _0x15592c[_0x1931aa('0x3b6')][_0x1931aa('0x678')]['maxLevel']
                                            , _0x8f094f = _0x3a17f6 % _0x15592c['default'][_0x1931aa('0x4ce')]['getGlobalCfg']('GemLevel') == 0x0 ? _0x2602ca[_0x1931aa('0x281')][_0x1931aa('0x4b6')][_0x1931aa('0x6a6')] : _0x2602ca[_0x1931aa('0x281')][_0x1931aa('0x4b6')]['Normal']
                                            , _0x2f7ba8 = _0x534cc5[_0x1931aa('0x3b6')]['random'](0x1, 0x12);
                                        _0x3a17f6 % _0x3ae2d6 == 0x0 ? _0x15592c[_0x1931aa('0x3b6')][_0x1931aa('0xba')][_0x1931aa('0x382')](0x5, _0x2602ca[_0x1931aa('0x281')]['GameType']['Special'], function () {
                                            var _0x11523a = _0x1931aa;
                                            _0x15592c[_0x11523a('0x3b6')][_0x11523a('0x5d7')][_0x11523a('0x280')](_0x5b4a9f[_0x11523a('0x339')][_0x11523a('0x28f')]);
                                        }) : (_0x15592c[_0x1931aa('0x3b6')]['UIMgr'][_0x1931aa('0x280')](_0x5b4a9f[_0x1931aa('0x339')][_0x1931aa('0x255')]),
                                            _0x15592c[_0x1931aa('0x3b6')][_0x1931aa('0x33b')][_0x1931aa('0x4e2')](_0x15592c[_0x1931aa('0x3b6')][_0x1931aa('0x678')][_0x1931aa('0x60')], _0x15592c['default']['DataMgr'][_0x1931aa('0x33f')], _0x2f7ba8, _0x8f094f, _0x101912['Id']));
                                    } else
                                        _0x15592c['default'][_0x1931aa('0x5d7')][_0x1931aa('0x46e')](_0x1931aa('0x132'));
                                }));
                            } else
                                !this['_dragFlag'] && (this[_0x406c0e('0x4b7')] ? _0x534cc5[_0x406c0e('0x3b6')][_0x406c0e('0x56b')](function (_0x6ad110) {
                                    var _0x5d40ed = _0x406c0e;
                                    if (!_0x6ad110)
                                        return;
                                    console[_0x5d40ed('0x5df')]('代码:' + _0x6ad110[_0x5d40ed('0x559')] + _0x5d40ed('0x2f6') + _0x6ad110[_0x5d40ed('0x152')]);
                                    if (_0x6ad110['code'] === 0x2710)
                                        console[_0x5d40ed('0x5df')](_0x5d40ed('0x422'));
                                    else {
                                        if (_0x6ad110[_0x5d40ed('0x559')] === 0x2711) {
                                            if (_0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x678')][_0x5d40ed('0x318')] <= 0x0)
                                                _0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x678')]['adRemainTimes'] = 0x0;
                                            else {
                                                console[_0x5d40ed('0x5df')](_0x5d40ed('0x437')),
                                                    _0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x678')][_0x5d40ed('0x318')]--,
                                                    _0x3054e9[_0x5d40ed('0x6a2')](),
                                                    _0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x5d7')][_0x5d40ed('0x280')](_0x5b4a9f[_0x5d40ed('0x339')][_0x5d40ed('0x255')]);
                                                var _0x269875 = _0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x678')]['maxLevel']
                                                    , _0x7855f1 = _0x269875 % _0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x4ce')][_0x5d40ed('0xeb')]('GemLevel') == 0x0 ? _0x2602ca[_0x5d40ed('0x281')]['GameType']['Special'] : _0x2602ca['GameEnum'][_0x5d40ed('0x4b6')]['Normal']
                                                    , _0x22189b = _0x534cc5[_0x5d40ed('0x3b6')]['random'](0x1, 0x12);
                                                _0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x33b')][_0x5d40ed('0x4e2')](_0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x678')][_0x5d40ed('0x60')], _0x101912['Id'], _0x22189b, _0x7855f1);
                                            }
                                        } else {
                                            if (_0x15592c[_0x5d40ed('0x3b6')][_0x5d40ed('0x678')][_0x5d40ed('0x318')] <= 0x0) { }
                                        }
                                    }
                                }) : _0x534cc5['default'][_0x406c0e('0x56b')](function (_0x4aee1f) {
                                    var _0x32a344 = _0x406c0e;
                                    if (!_0x4aee1f)
                                        return;
                                    console[_0x32a344('0x5df')](_0x32a344('0x3e') + _0x4aee1f[_0x32a344('0x559')] + ',消息:' + _0x4aee1f['message']);
                                    if (_0x4aee1f[_0x32a344('0x559')] === 0x2710)
                                        console[_0x32a344('0x5df')](_0x32a344('0x422'));
                                    else {
                                        if (_0x4aee1f['code'] === 0x2711) {
                                            if (_0x15592c[_0x32a344('0x3b6')][_0x32a344('0x678')][_0x32a344('0x318')] <= 0x0)
                                                _0x15592c['default'][_0x32a344('0x678')][_0x32a344('0x318')] = 0x0;
                                            else {
                                                _0x15592c[_0x32a344('0x3b6')]['DataMgr'][_0x32a344('0x318')]--,
                                                    _0x3054e9[_0x32a344('0x6a2')](),
                                                    _0x15592c[_0x32a344('0x3b6')][_0x32a344('0x5d7')][_0x32a344('0x280')](_0x5b4a9f[_0x32a344('0x339')]['PlayGameUI']);
                                                var _0xfb6378 = _0x15592c[_0x32a344('0x3b6')]['DataMgr'][_0x32a344('0x144')]
                                                    , _0x356f6c = _0xfb6378 % _0x15592c['default'][_0x32a344('0x4ce')][_0x32a344('0xeb')](_0x32a344('0xf6')) == 0x0 ? _0x2602ca[_0x32a344('0x281')][_0x32a344('0x4b6')][_0x32a344('0x6a6')] : _0x2602ca[_0x32a344('0x281')]['GameType']['Normal']
                                                    , _0x1ae460 = _0x534cc5[_0x32a344('0x3b6')][_0x32a344('0x139')](0x1, 0x12);
                                                _0x15592c['default'][_0x32a344('0x33b')][_0x32a344('0x4e2')](_0x15592c[_0x32a344('0x3b6')][_0x32a344('0x678')]['curRound'], _0x15592c[_0x32a344('0x3b6')][_0x32a344('0x678')][_0x32a344('0x33f')], _0x1ae460, _0x356f6c, _0x101912['Id']);
                                            }
                                        } else {
                                            if (_0x15592c[_0x32a344('0x3b6')][_0x32a344('0x678')][_0x32a344('0x318')] <= 0x0) { }
                                        }
                                    }
                                }));
                        }
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x2db')] = function () {
                        var _0x5bdf49 = _0x4f67dd;
                        this[_0x5bdf49('0x4b7')] ? _0x15592c[_0x5bdf49('0x3b6')][_0x5bdf49('0x678')][_0x5bdf49('0x33f')] = this['_preSelectId'] : _0x15592c[_0x5bdf49('0x3b6')][_0x5bdf49('0x678')][_0x5bdf49('0x486')] = this[_0x5bdf49('0x5ea')],
                            _0x15592c[_0x5bdf49('0x3b6')][_0x5bdf49('0x5d7')][_0x5bdf49('0x280')](_0x5b4a9f[_0x5bdf49('0x339')]['GameUI']);
                    }
                    ,
                    _0x324370['prototype']['showItemOnStage'] = function (_0x332d21) {
                        var _0x48247d = _0x4f67dd
                            , _0x77290b = _0x15592c['default']['ResMgr'][_0x48247d('0xec')](_0x332d21);
                        this['removeItemObj'](),
                            this['_itemObj'] = Laya[_0x48247d('0x55a')][_0x48247d('0x3c')](_0x77290b, this[_0x48247d('0x363')]);
                        var _0x2f8145 = this[_0x48247d('0x36a')][_0x48247d('0x612')](Laya[_0x48247d('0x78')]);
                        _0x2f8145[_0x48247d('0x3cd')] = ![],
                            this['_itemObj'][_0x48247d('0xb6')][_0x48247d('0x13')] = new Laya['Vector3'](0x0, 1.95, -1.5);
                    }
                    ,
                    _0x324370['prototype'][_0x4f67dd('0x418')] = function (_0x4c6b4f, _0xd112ad, _0xcfee34, _0x55d7c1) {
                        var _0x1e60d1 = _0x4f67dd
                            , _0x3f32e7 = _0x15592c[_0x1e60d1('0x3b6')][_0x1e60d1('0x4ce')][_0x1e60d1('0x430')](_0x4c6b4f)
                            , _0x5e2f33 = _0x3f32e7[_0x1e60d1('0x4cc')] / 0x6
                            , _0x6857cb = 0x0;
                        for (var _0x4be7d0 = 0x0; _0x4be7d0 < _0x5e2f33; _0x4be7d0++) {
                            var _0x5b8a89 = new Laya[(_0x1e60d1('0x4a0'))]();
                            _0xd112ad[_0x1e60d1('0x5')](_0x5b8a89),
                                _0x5b8a89['pos'](0x2bc * _0x4be7d0, 0x0, !![]);
                            for (var _0x29ff86 = 0x0; _0x29ff86 < 0x2; _0x29ff86++) {
                                for (var _0xd0ab90 = 0x0; _0xd0ab90 < 0x3; _0xd0ab90++) {
                                    var _0x5f54e0 = new _0x4832b0[(_0x1e60d1('0x3b6'))](_0x3f32e7[_0x6857cb]);
                                    _0x5f54e0[_0x1e60d1('0x5b3')](_0xd0ab90 * 0xdc, _0x29ff86 * 0xbe),
                                        _0x5b8a89[_0x1e60d1('0x5')](_0x5f54e0['gameobject']),
                                        _0xcfee34[_0x3f32e7[_0x6857cb]['Id']] = _0x5f54e0,
                                        this[_0x1e60d1('0x6b5')]['push'](_0x5f54e0),
                                        _0x6857cb++;
                                }
                            }
                        }
                        for (var _0x29ff86 = 0x0; _0x29ff86 < _0x5e2f33; _0x29ff86++) {
                            var _0x58fac4 = new Laya['Image'](_0x29ff86 == 0x0 ? _0x1e60d1('0x354') : _0x1e60d1('0x23d'));
                            _0x55d7c1[_0x1e60d1('0xff')](_0x58fac4);
                        }
                        var _0x556d14 = _0xd112ad['addComponent'](_0x5bb67c[_0x1e60d1('0x3b6')]);
                        return _0x556d14[_0x1e60d1('0x40e')]({
                            'len': _0x5e2f33,
                            'space': 0x2bc,
                            'startX': _0xd112ad['x'],
                            'startIndex': 0x0,
                            'curIndex': 0x0,
                            'dragSkinBox': this[_0x1e60d1('0x70')]
                        }),
                            _0x556d14;
                    }
                    ,
                    _0x324370['prototype']['switchPageHandle'] = function (_0x416873, _0x1dda51) {
                        var _0x21a9d2 = _0x4f67dd;
                        this['_curPage'] = _0x416873,
                            this[_0x21a9d2('0x165')] = _0x1dda51;
                        for (var _0x1a120e = 0x0; _0x1a120e < this[_0x21a9d2('0x56e')][_0x21a9d2('0x4cc')]; _0x1a120e++) {
                            this[_0x21a9d2('0x56e')][_0x1a120e][_0x21a9d2('0x3c4')] = _0x1a120e == _0x416873 ? _0x21a9d2('0x354') : _0x21a9d2('0x23d');
                        }
                        var _0x13faca = this[_0x21a9d2('0x357')]();
                        if (_0x13faca[_0x21a9d2('0x4cc')] > 0x0) {
                            this['gembtn']['x'] = 0x3a,
                                this['sharebtn']['x'] = 0x3a,
                                this['unlockbtn']['visible'] = !![];
                            if (this[_0x21a9d2('0x4b7')]) {
                                var _0x4b41a8 = this[_0x21a9d2('0x38')][(_0x416873 + 0x1) * 0x6 - 0x1][_0x21a9d2('0x9d')];
                                this[_0x21a9d2('0x375')][_0x21a9d2('0x338')] = _0x4b41a8;
                            } else {
                                var _0x4b41a8 = this[_0x21a9d2('0x57a')][(_0x416873 + 0x1) * 0x6 - 0x1]['GemUnlock'];
                                this[_0x21a9d2('0x375')][_0x21a9d2('0x338')] = _0x4b41a8;
                            }
                        } else
                            this['gembtn']['x'] = 0xf0,
                                this[_0x21a9d2('0x267')]['x'] = 0xf0,
                                this[_0x21a9d2('0x240')][_0x21a9d2('0x5bf')] = ![];
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['switchTabView'] = function () {
                        var _0x3fd63b = _0x4f67dd;
                        this['pageObj'][_0x3fd63b('0x4a1')](0x0, this['pageObj']['numChildren'] - 0x1);
                        this[_0x3fd63b('0x4b7')] ? (this[_0x3fd63b('0x3db')][_0x3fd63b('0x3c4')] = _0x3fd63b('0xd9'),
                            this[_0x3fd63b('0x6a5')][_0x3fd63b('0x3c4')] = _0x3fd63b('0x176'),
                            this['_pageArr'] = this[_0x3fd63b('0x13e')],
                            this[_0x3fd63b('0x2ec')][_0x3fd63b('0x39d')](),
                            this['_hoopDrag'][_0x3fd63b('0x26a')](![]),
                            this[_0x3fd63b('0x5ea')] = _0x15592c[_0x3fd63b('0x3b6')][_0x3fd63b('0x678')]['hoopSkinId'],
                            this[_0x3fd63b('0x542')](_0x15592c[_0x3fd63b('0x3b6')][_0x3fd63b('0x4ce')]['getItemCfg'](this[_0x3fd63b('0x5ea')])[_0x3fd63b('0x29d')]),
                            this[_0x3fd63b('0x57c')][this[_0x3fd63b('0x5ea')]][_0x3fd63b('0x143')](!![])) : (this['hoopbtn']['skin'] = 'skin/skin_Tap_UnSelect.png',
                                this[_0x3fd63b('0x6a5')][_0x3fd63b('0x3c4')] = 'skin/skin_Tap_Select.png',
                                this[_0x3fd63b('0x56e')] = this['_ballPageArr'],
                                this[_0x3fd63b('0x2ec')]['addEvent'](![]),
                                this[_0x3fd63b('0x35a')][_0x3fd63b('0x39d')](),
                                this[_0x3fd63b('0x5ea')] = _0x15592c['default'][_0x3fd63b('0x678')][_0x3fd63b('0x486')],
                                this[_0x3fd63b('0x542')](_0x15592c['default'][_0x3fd63b('0x4ce')]['getItemCfg'](this[_0x3fd63b('0x5ea')])[_0x3fd63b('0x29d')]),
                                this[_0x3fd63b('0x4f9')][this['_preSelectId']][_0x3fd63b('0x143')](!![]));
                        for (var _0x3d0e92 = 0x0; _0x3d0e92 < this[_0x3fd63b('0x56e')][_0x3fd63b('0x4cc')]; _0x3d0e92++) {
                            this[_0x3fd63b('0x495')]['addChild'](this['_pageArr'][_0x3d0e92]);
                        }
                        this[_0x3fd63b('0x330')][_0x3fd63b('0x5bf')] = this[_0x3fd63b('0x4b7')],
                            this[_0x3fd63b('0x1ad')]['visible'] = !this[_0x3fd63b('0x4b7')],
                            this[_0x3fd63b('0x2a9')](0x0, ![]);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x533')] = function () {
                        var _0x12999b = _0x4f67dd;
                        this[_0x12999b('0x4b7')] = !![],
                            this[_0x12999b('0x1')]();
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['ballClickHandle'] = function () {
                        var _0x5e0864 = _0x4f67dd;
                        this[_0x5e0864('0x4b7')] = ![],
                            this['switchTabView']();
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x87')] = function () {
                        var _0x2f2ea8 = _0x4f67dd;
                        this[_0x2f2ea8('0x2db')]();
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x2c2')] = function () {
                        var _0x23a283 = _0x4f67dd;
                        this[_0x23a283('0x12c')]['visible'] = !this[_0x23a283('0x12c')][_0x23a283('0x5bf')];
                    }
                    ,
                    _0x324370['prototype'][_0x4f67dd('0x3e7')] = function () {
                        var _0x408515 = _0x4f67dd;
                        _0x15592c[_0x408515('0x3b6')][_0x408515('0x678')][_0x408515('0x5b5')] = !_0x15592c[_0x408515('0x3b6')][_0x408515('0x678')][_0x408515('0x5b5')],
                            this['vibration']['skin'] = _0x15592c[_0x408515('0x3b6')][_0x408515('0x678')][_0x408515('0x5b5')] ? 'game/main_menu_vibroon_1.png' : 'game/main_menu_vibroon_2.png';
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')]['soundClickHandle'] = function () {
                        var _0xf5e604 = _0x4f67dd;
                        _0x15592c[_0xf5e604('0x3b6')][_0xf5e604('0x678')][_0xf5e604('0x2bf')] = !_0x15592c[_0xf5e604('0x3b6')][_0xf5e604('0x678')][_0xf5e604('0x2bf')],
                            this[_0xf5e604('0x97')][_0xf5e604('0x3c4')] = _0x15592c[_0xf5e604('0x3b6')][_0xf5e604('0x678')][_0xf5e604('0x2bf')] ? _0xf5e604('0x2d9') : _0xf5e604('0x6a7');
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0xd7')] = function () {
                        var _0xf78208 = _0x4f67dd;
                        this[_0xf78208('0x36a')] != null && (this[_0xf78208('0x36a')][_0xf78208('0x594')](),
                            this[_0xf78208('0x36a')]['destroy'](),
                            this[_0xf78208('0x36a')] = null);
                    }
                    ,
                    _0x324370[_0x4f67dd('0x64a')][_0x4f67dd('0x39d')] = function () {
                        var _0x5b03ee = _0x4f67dd;
                        _0x15592c['default'][_0x5b03ee('0x370')][_0x5b03ee('0x585')](_0x23fda2[_0x5b03ee('0x4c3')][_0x5b03ee('0x4e7')], this, this[_0x5b03ee('0x2a9')]),
                            _0x15592c['default']['EventMgr'][_0x5b03ee('0x585')](_0x23fda2[_0x5b03ee('0x4c3')][_0x5b03ee('0x117')], this, this[_0x5b03ee('0x54b')]),
                            Laya[_0x5b03ee('0x5ac')][_0x5b03ee('0x466')](this, this[_0x5b03ee('0x251')]);
                    }
                    ,
                    _0x324370['prototype']['close'] = function () {
                        var _0x3aa2fc = _0x4f67dd;
                        this[_0x3aa2fc('0xd7')](),
                            this[_0x3aa2fc('0x39d')](),
                            this['_skinScene'] != null && (Laya['stage'][_0x3aa2fc('0x26c')](this[_0x3aa2fc('0x363')]),
                                this[_0x3aa2fc('0x363')] = null),
                            _0x529109[_0x3aa2fc('0x64a')][_0x3aa2fc('0x42')][_0x3aa2fc('0x324')](this);
                    }
                    ,
                    _0x324370;
            }(_0x4271e6['ui'][_0x2717f7('0x62')][_0x2717f7('0x501')]);
        _0xc93f4e[_0x2717f7('0x3b6')] = _0xc0c44e;
    }
        , {
        '../../XGame': 0x4,
        '../../core/ServerAgency': 0x8,
        '../../enum/EventEnum': 0xe,
        '../../enum/GameConst': 0xf,
        '../../enum/GameEnum': 0x10,
        '../../enum/ResEnum': 0x12,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36,
        '../../utils/Tools': 0x37,
        '../DragListScript': 0x1e,
        './item/SkinItem': 0x35
    }],
    0x30: [function (_0x167b05, _0x202969, _0x1450f0) {
        var _0x55ec9e = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x1450f0, _0x55ec9e('0xb8'), {
            'value': !![]
        });
        var _0x3d9975 = _0x167b05('../../ui/layaMaxUI')
            , _0x55aba6 = _0x167b05(_0x55ec9e('0x69c'))
            , _0x9e33f = _0x167b05(_0x55ec9e('0xce'))
            , _0x5c8e41 = function (_0x4eee47) {
                var _0x2ef0fa = _0x55ec9e;
                __extends(_0x13eee3, _0x4eee47);
                function _0x13eee3() {
                    var _0x36ff5f = _0x5985;
                    return _0x4eee47[_0x36ff5f('0x324')](this) || this;
                }
                return _0x13eee3[_0x2ef0fa('0x64a')]['onAwake'] = function () {
                    var _0x8bf6f5 = _0x2ef0fa;
                    this[_0x8bf6f5('0x218')](),
                        this[_0x8bf6f5('0x1d5')]();
                }
                    ,
                    _0x13eee3['prototype']['initView'] = function () { }
                    ,
                    _0x13eee3[_0x2ef0fa('0x64a')][_0x2ef0fa('0x1d5')] = function () {
                        var _0x341f91 = _0x2ef0fa;
                        this['regClick'](this[_0x341f91('0x500')], this[_0x341f91('0x336')]);
                    }
                    ,
                    _0x13eee3[_0x2ef0fa('0x64a')][_0x2ef0fa('0x336')] = function () {
                        var _0x503b62 = _0x2ef0fa;
                        _0x9e33f[_0x503b62('0x3b6')][_0x503b62('0x5d7')][_0x503b62('0x280')](_0x55aba6['UIEnum']['GameUI']);
                    }
                    ,
                    _0x13eee3['prototype'][_0x2ef0fa('0x42')] = function () {
                        var _0xe5def9 = _0x2ef0fa;
                        _0x4eee47[_0xe5def9('0x64a')][_0xe5def9('0x42')][_0xe5def9('0x324')](this);
                    }
                    ,
                    _0x13eee3;
            }(_0x3d9975['ui'][_0x55ec9e('0x62')][_0x55ec9e('0x1e1')]);
        _0x1450f0[_0x55ec9e('0x3b6')] = _0x5c8e41;
    }
        , {
        '../../XGame': 0x4,
        '../../enum/UIEnum': 0x13,
        '../../ui/layaMaxUI': 0x36
    }],
    0x31: [function (_0x174d45, _0x4a361f, _0x3d08d7) {
        var _0x239ec2 = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x3d08d7, _0x239ec2('0xb8'), {
            'value': !![]
        });
        var _0x4c2834 = _0x174d45(_0x239ec2('0x14'))
            , _0x12bfd1 = _0x174d45('../../../XGame')
            , _0xcb8cf4 = _0x174d45(_0x239ec2('0x26b'))
            , _0x123639 = function () {
                var _0x214e3c = _0x239ec2;
                function _0x285c20() {
                    var _0x381f7f = _0x5985;
                    this['gameobject'] = null,
                        this[_0x381f7f('0x37d')] = null,
                        this[_0x381f7f('0x24c')] = null;
                    var _0x5def5f = _0x12bfd1[_0x381f7f('0x3b6')]['ResMgr'][_0x381f7f('0x1b8')](_0x4c2834[_0x381f7f('0x29')][_0x381f7f('0x126')]);
                    this[_0x381f7f('0x5d3')] = _0x5def5f[_0x381f7f('0x5fb')](),
                        this[_0x381f7f('0x37d')] = this[_0x381f7f('0x5d3')][_0x381f7f('0x3aa')](_0x381f7f('0x613')),
                        this[_0x381f7f('0x24c')] = this[_0x381f7f('0x5d3')][_0x381f7f('0x3aa')]('iconName'),
                        this[_0x381f7f('0x5d3')]['on'](Laya[_0x381f7f('0x68f')][_0x381f7f('0x1af')], this, this[_0x381f7f('0x31f')]);
                }
                return _0x285c20[_0x214e3c('0x64a')][_0x214e3c('0x303')] = function (_0x298ed5, _0x175272, _0xab5d4c) {
                    var _0x33871a = _0x214e3c;
                    this['icon']['skin'] = _0xab5d4c[_0x33871a('0x605')],
                        this['labName'][_0x33871a('0x338')] = _0xab5d4c[_0x33871a('0x396')],
                        this[_0x33871a('0x10b')] = _0x298ed5,
                        this['posId'] = _0x175272;
                }
                    ,
                    _0x285c20[_0x214e3c('0x64a')][_0x214e3c('0x31f')] = function () {
                        var _0x1873b1 = _0x214e3c;
                        window['wx'] && window['wx'][_0x1873b1('0x33a')][_0x1873b1('0x590')]({
                            'positionId': this[_0x1873b1('0x17b')],
                            'creativeId': this[_0x1873b1('0x10b')]
                        })[_0x1873b1('0x210')](function (_0x188e90) {
                            var _0x24d41f = _0x1873b1;
                            console[_0x24d41f('0x5df')]('跳转成功'),
                                console[_0x24d41f('0x5df')](_0x24d41f('0x177'), _0x188e90),
                                _0x12bfd1[_0x24d41f('0x3b6')][_0x24d41f('0x370')]['event'](_0xcb8cf4[_0x24d41f('0x4c3')][_0x24d41f('0x4bf')], [_0x188e90]);
                        })[_0x1873b1('0xed')](function (_0x12065a) {
                            var _0x5cc216 = _0x1873b1;
                            console[_0x5cc216('0x5df')](_0x5cc216('0x2b1'), _0x12065a);
                        });
                    }
                    ,
                    _0x285c20[_0x214e3c('0x64a')][_0x214e3c('0x488')] = function () { }
                    ,
                    _0x285c20[_0x214e3c('0x64a')]['onDisable'] = function () { }
                    ,
                    _0x285c20;
            }();
        _0x3d08d7[_0x239ec2('0x3b6')] = _0x123639;
    }
        , {
        '../../../XGame': 0x4,
        '../../../enum/EventEnum': 0xe,
        '../../../enum/ResEnum': 0x12
    }],
    0x32: [function (_0x1ea531, _0x204fee, _0x1216ec) {
        var _0x24e901 = _0x4b7fcf;
        'use strict';
        Object[_0x24e901('0x351')](_0x1216ec, '__esModule', {
            'value': !![]
        });
        var _0x3f5b17 = _0x1ea531(_0x24e901('0x1ff'))
            , _0x21a809 = _0x1ea531(_0x24e901('0x14'))
            , _0x537dcc = function () {
                var _0x6cfd46 = _0x24e901;
                function _0x455b2e() {
                    var _0x386114 = _0x5985;
                    this[_0x386114('0x5d3')] = null,
                        this[_0x386114('0xb2')] = null,
                        this[_0x386114('0x60b')] = null,
                        this[_0x386114('0x532')] = null,
                        this[_0x386114('0x452')] = null,
                        this['_name'] = null,
                        this[_0x386114('0x440')] = null;
                    var _0x5b8cd6 = _0x3f5b17[_0x386114('0x3b6')][_0x386114('0x60d')][_0x386114('0x1b8')](_0x21a809[_0x386114('0x29')]['RankItem']);
                    this['gameobject'] = _0x5b8cd6[_0x386114('0x5fb')](),
                        this[_0x386114('0xb2')] = this['gameobject'][_0x386114('0x3aa')]('bg'),
                        this[_0x386114('0x60b')] = this[_0x386114('0x5d3')][_0x386114('0x3aa')](_0x386114('0x545')),
                        this[_0x386114('0x532')] = this[_0x386114('0x5d3')][_0x386114('0x3aa')](_0x386114('0x93')),
                        this['_rankNum'] = this[_0x386114('0x5d3')][_0x386114('0x3aa')](_0x386114('0x2f7')),
                        this[_0x386114('0x52d')] = this[_0x386114('0x5d3')][_0x386114('0x3aa')](_0x386114('0x8c')),
                        this['_score'] = this[_0x386114('0x5d3')][_0x386114('0x3aa')](_0x386114('0x668'));
                }
                return _0x455b2e[_0x6cfd46('0x64a')]['showItem'] = function (_0x13cfd6) {
                    var _0x4a7706 = _0x6cfd46;
                    this[_0x4a7706('0x5d3')]['visible'] = _0x13cfd6;
                }
                    ,
                    _0x455b2e[_0x6cfd46('0x64a')][_0x6cfd46('0x53a')] = function (_0x3d5cd6) {
                        var _0x234958 = _0x6cfd46;
                        this[_0x234958('0x60b')][_0x234958('0x5bf')] = !![];
                        if (_0x3d5cd6['own'])
                            this[_0x234958('0xb2')][_0x234958('0x3c4')] = _0x234958('0x630'),
                                this['_rankbg'][_0x234958('0x5bf')] = ![],
                                this[_0x234958('0x452')][_0x234958('0x338')] = _0x3d5cd6[_0x234958('0x58a')],
                                (_0x3d5cd6[_0x234958('0x58a')] < 0x0 || _0x3d5cd6['level'] > 0x64) && (this['_rankNum']['text'] = _0x234958('0x401'));
                        else {
                            if (_0x3d5cd6[_0x234958('0x58a')] == 0x1)
                                this[_0x234958('0xb2')]['skin'] = 'ranking/rank_di_1.png',
                                    this[_0x234958('0x60b')][_0x234958('0x3c4')] = _0x234958('0x52f'),
                                    this[_0x234958('0x452')][_0x234958('0x338')] = '';
                            else {
                                if (_0x3d5cd6[_0x234958('0x58a')] == 0x2)
                                    this[_0x234958('0xb2')][_0x234958('0x3c4')] = 'ranking/rank_di_2.png',
                                        this[_0x234958('0x60b')][_0x234958('0x3c4')] = _0x234958('0x5c0'),
                                        this[_0x234958('0x452')][_0x234958('0x338')] = '';
                                else
                                    _0x3d5cd6[_0x234958('0x58a')] == 0x3 ? (this[_0x234958('0xb2')]['skin'] = 'ranking/rank_di_3.png',
                                        this['_rankbg']['skin'] = _0x234958('0x37e'),
                                        this[_0x234958('0x452')][_0x234958('0x338')] = '') : (this['_bg']['skin'] = _0x234958('0x335'),
                                            this[_0x234958('0x452')][_0x234958('0x338')] = _0x3d5cd6[_0x234958('0x58a')],
                                            this[_0x234958('0x60b')][_0x234958('0x5bf')] = ![]);
                            }
                        }
                        this[_0x234958('0x532')]['skin'] = _0x3d5cd6[_0x234958('0x2b3')],
                            this['_score']['text'] = '第' + _0x3d5cd6[_0x234958('0x668')] + '关',
                            this[_0x234958('0x4a4')](_0x3d5cd6[_0x234958('0x578')]);
                    }
                    ,
                    _0x455b2e['prototype'][_0x6cfd46('0x4a4')] = function (_0xdc11ac) {
                        var _0x224aff = _0x6cfd46;
                        _0xdc11ac[_0x224aff('0x4cc')] > 0xa && (_0xdc11ac = _0xdc11ac[_0x224aff('0x18c')](0x0, 0xa) + _0x224aff('0xe9')),
                            this['_name'][_0x224aff('0x338')] = _0xdc11ac;
                    }
                    ,
                    _0x455b2e[_0x6cfd46('0x64a')][_0x6cfd46('0x392')] = function () {
                        var _0x26516c = _0x6cfd46;
                        this[_0x26516c('0x5d3')][_0x26516c('0x594')]();
                    }
                    ,
                    _0x455b2e;
            }();
        _0x1216ec[_0x24e901('0x3b6')] = _0x537dcc;
    }
        , {
        '../../../XGame': 0x4,
        '../../../enum/ResEnum': 0x12
    }],
    0x33: [function (_0xc90426, _0x16cdf9, _0x5aa210) {
        var _0x4c474b = _0x4b7fcf;
        'use strict';
        Object[_0x4c474b('0x351')](_0x5aa210, _0x4c474b('0xb8'), {
            'value': !![]
        });
        var _0x455d40 = _0xc90426(_0x4c474b('0x1ff'))
            , _0x3a854b = _0xc90426('../../../enum/EventEnum')
            , _0x558b00 = _0xc90426('../../../enum/ResEnum')
            , _0x509066 = _0xc90426('../../../utils/Tools')
            , _0x3eed18 = _0xc90426('../../../enum/GameConst')
            , _0x4bd92c = function () {
                var _0x411a3 = _0x4c474b;
                function _0x461668(_0x115fe1) {
                    var _0x5270e6 = _0x5985;
                    this[_0x5270e6('0x5d3')] = null,
                        this[_0x5270e6('0x11c')] = null,
                        this[_0x5270e6('0x615')] = null,
                        this['_isOpen'] = ![],
                        this[_0x5270e6('0x34e')] = -0x1,
                        this[_0x5270e6('0x521')] = null,
                        this[_0x5270e6('0xe')] = null,
                        this[_0x5270e6('0x427')] = null,
                        this[_0x5270e6('0x439')] = null,
                        this[_0x5270e6('0x34e')] = _0x115fe1;
                    var _0x5bb272 = _0x455d40[_0x5270e6('0x3b6')][_0x5270e6('0x60d')][_0x5270e6('0x1b8')](_0x558b00[_0x5270e6('0x29')][_0x5270e6('0x22')]);
                    this[_0x5270e6('0x5d3')] = _0x5bb272[_0x5270e6('0x5fb')](),
                        this[_0x5270e6('0x11c')] = this['gameobject']['getChildByName'](_0x5270e6('0x108')),
                        this[_0x5270e6('0x615')] = this[_0x5270e6('0x5d3')][_0x5270e6('0x3aa')](_0x5270e6('0x3df')),
                        this[_0x5270e6('0x521')] = this[_0x5270e6('0x5d3')][_0x5270e6('0x3aa')](_0x5270e6('0x2cd')),
                        this[_0x5270e6('0xe')] = this['gameobject'][_0x5270e6('0x3aa')](_0x5270e6('0x1ea')),
                        this[_0x5270e6('0x427')] = this[_0x5270e6('0xe')][_0x5270e6('0x3aa')](_0x5270e6('0x2a2')),
                        this['_videobtn'] = this[_0x5270e6('0x5d3')]['getChildByName'](_0x5270e6('0x188')),
                        this[_0x5270e6('0xe')][_0x5270e6('0x5bf')] = ![],
                        this[_0x5270e6('0x5d3')]['on'](Laya['Event'][_0x5270e6('0x1af')], this, this[_0x5270e6('0x3e8')]);
                }
                return _0x461668[_0x411a3('0x64a')]['setPos'] = function (_0x366a85, _0x14ba77) {
                    var _0x3240c9 = _0x411a3;
                    this['gameobject'][_0x3240c9('0x1bf')](_0x366a85, _0x14ba77, !![]);
                }
                    ,
                    _0x461668[_0x411a3('0x64a')][_0x411a3('0x318')] = function (_0x133ce9) {
                        var _0x3f0744 = _0x411a3;
                        _0x133ce9 > 0x0 ? this[_0x3f0744('0x439')][_0x3f0744('0x46a')] = Laya[_0x3f0744('0x5e')]['getRes'](_0x3f0744('0x689')) : this[_0x3f0744('0x439')]['texture'] = Laya[_0x3f0744('0x5e')]['getRes']('game/mask.png');
                    }
                    ,
                    _0x461668[_0x411a3('0x64a')][_0x411a3('0x53c')] = function (_0xe8de81, _0x4f519e) {
                        var _0x3e2217 = _0x411a3;
                        this[_0x3e2217('0x109')] = _0xe8de81,
                            this[_0x3e2217('0x5c1')] = _0x4f519e;
                    }
                    ,
                    _0x461668['prototype']['onClickHandle'] = function () {
                        var _0x365f87 = _0x411a3;
                        this[_0x365f87('0x439')][_0x365f87('0x5bf')] ? _0x3eed18['GameConst'][_0x365f87('0x400')] != _0x3eed18['PlatformType'][_0x365f87('0x64')] ? _0x509066['default'][_0x365f87('0x1e5')](_0x455d40[_0x365f87('0x3b6')][_0x365f87('0x4ce')][_0x365f87('0x66c')](0x13), this, this['watchTvCallback'][_0x365f87('0x484')](this)) : _0x509066[_0x365f87('0x3b6')][_0x365f87('0x56b')](this[_0x365f87('0x14b')][_0x365f87('0x484')](this)) : !this[_0x365f87('0xf9')] && (this[_0x365f87('0xf9')] = !![],
                            _0x455d40[_0x365f87('0x3b6')][_0x365f87('0x370')]['event'](_0x3a854b[_0x365f87('0x4c3')][_0x365f87('0x115')], [this[_0x365f87('0x34e')]]));
                    }
                    ,
                    _0x461668['prototype'][_0x411a3('0x14b')] = function (_0x52a779) {
                        var _0x2a1b8f = _0x411a3;
                        if (!_0x52a779)
                            return;
                        console['log'](_0x2a1b8f('0x3e') + _0x52a779['code'] + _0x2a1b8f('0x2f6') + _0x52a779['message']);
                        if (_0x52a779[_0x2a1b8f('0x559')] === 0x2710)
                            console[_0x2a1b8f('0x5df')](_0x2a1b8f('0x422'));
                        else {
                            if (_0x52a779[_0x2a1b8f('0x559')] === 0x2711)
                                _0x455d40[_0x2a1b8f('0x3b6')]['DataMgr'][_0x2a1b8f('0x318')] <= 0x0 ? _0x455d40['default']['DataMgr'][_0x2a1b8f('0x318')] = 0x0 : (_0x455d40[_0x2a1b8f('0x3b6')]['DataMgr'][_0x2a1b8f('0x318')]--,
                                    this['_videobtn']['visible'] = ![],
                                    this['onClickHandle'](),
                                    this[_0x2a1b8f('0x409')]());
                            else {
                                if (_0x455d40[_0x2a1b8f('0x3b6')]['DataMgr'][_0x2a1b8f('0x318')] <= 0x0) { }
                            }
                        }
                    }
                    ,
                    _0x461668[_0x411a3('0x64a')][_0x411a3('0x409')] = function () {
                        var _0x13d009 = _0x411a3;
                        _0x455d40[_0x13d009('0x3b6')][_0x13d009('0x678')][_0x13d009('0x318')] <= 0x0 && this[_0x13d009('0x5c1')]['call'](this[_0x13d009('0x109')]);
                    }
                    ,
                    _0x461668[_0x411a3('0x64a')][_0x411a3('0x21d')] = function (_0x57fb82, _0x32ea9b, _0x5c7373) {
                        var _0x2803f6 = _0x411a3;
                        _0x32ea9b === void 0x0 && (_0x32ea9b = null);
                        _0x5c7373 === void 0x0 && (_0x5c7373 = null);
                        if (_0x32ea9b) {
                            _0x455d40[_0x2803f6('0x3b6')][_0x2803f6('0x5d7')][_0x2803f6('0x46e')](_0x32ea9b);
                            return;
                        }
                        _0x57fb82 ? (this[_0x2803f6('0x439')][_0x2803f6('0x5bf')] = ![],
                            this[_0x2803f6('0x3e8')]()) : _0x455d40[_0x2803f6('0x3b6')][_0x2803f6('0x5d7')][_0x2803f6('0x46e')](_0x2803f6('0x301'));
                    }
                    ,
                    _0x461668['prototype'][_0x411a3('0x548')] = function (_0x3f9fda) {
                        var _0x43c4b9 = _0x411a3;
                        this[_0x43c4b9('0x615')][_0x43c4b9('0x5bf')] = ![],
                            _0x3f9fda[0x0] == -0x5 ? (this[_0x43c4b9('0x11c')]['visible'] = !![],
                                this[_0x43c4b9('0xe')][_0x43c4b9('0x5bf')] = !![],
                                this[_0x43c4b9('0x427')][_0x43c4b9('0x338')] = _0x3f9fda[0x1][_0x43c4b9('0xcc')](),
                                _0x455d40[_0x43c4b9('0x3b6')][_0x43c4b9('0x678')][_0x43c4b9('0x45')](_0x3f9fda[0x1]),
                                _0x455d40[_0x43c4b9('0x3b6')][_0x43c4b9('0x370')][_0x43c4b9('0x393')](_0x3a854b[_0x43c4b9('0x4c3')]['Reward_UpdateInfo'])) : (this['_hoopicon'][_0x43c4b9('0x5bf')] = !![],
                                    this[_0x43c4b9('0x521')][_0x43c4b9('0x3c4')] = _0x43c4b9('0x3a7') + _0x455d40[_0x43c4b9('0x3b6')][_0x43c4b9('0x4ce')][_0x43c4b9('0x3ef')](_0x3f9fda[0x0])[_0x43c4b9('0x3d9')] + '.png',
                                    _0x455d40['default'][_0x43c4b9('0x678')][_0x43c4b9('0x45c')](_0x3f9fda[0x0]));
                    }
                    ,
                    _0x461668[_0x411a3('0x64a')][_0x411a3('0x24f')] = function (_0x3ead21) {
                        var _0x4bf602 = _0x411a3;
                        this[_0x4bf602('0xf9')] ? this[_0x4bf602('0x439')]['visible'] = ![] : this[_0x4bf602('0x439')]['visible'] = _0x3ead21;
                    }
                    ,
                    _0x461668[_0x411a3('0x64a')][_0x411a3('0x392')] = function () {
                        var _0x4a35e5 = _0x411a3;
                        this[_0x4a35e5('0x5d3')][_0x4a35e5('0x585')](Laya[_0x4a35e5('0x68f')][_0x4a35e5('0x1af')], this, this[_0x4a35e5('0x3e8')]),
                            this[_0x4a35e5('0x5d3')][_0x4a35e5('0x594')]();
                    }
                    ,
                    _0x461668;
            }();
        _0x5aa210[_0x4c474b('0x3b6')] = _0x4bd92c;
    }
        , {
        '../../../XGame': 0x4,
        '../../../enum/EventEnum': 0xe,
        '../../../enum/GameConst': 0xf,
        '../../../enum/ResEnum': 0x12,
        '../../../utils/Tools': 0x37
    }],
    0x34: [function (_0x2331e4, _0x4752c6, _0x178b1e) {
        var _0x570abe = _0x4b7fcf;
        'use strict';
        Object[_0x570abe('0x351')](_0x178b1e, _0x570abe('0xb8'), {
            'value': !![]
        });
        var _0xdf791f = _0x2331e4(_0x570abe('0x1ff'))
            , _0x32f266 = _0x2331e4(_0x570abe('0x14'))
            , _0x4aa951 = _0x2331e4(_0x570abe('0x625'))
            , _0x50f993 = _0x2331e4(_0x570abe('0x20'))
            , _0x5a1095 = function () {
                var _0x35257c = _0x570abe;
                function _0x22d075(_0x4e7c88) {
                    var _0x3dccd2 = _0x5985;
                    this[_0x3dccd2('0x5d3')] = null,
                        this[_0x3dccd2('0x537')] = null,
                        this[_0x3dccd2('0x4d')] = null,
                        this[_0x3dccd2('0xe')] = null,
                        this['_goldCount'] = null,
                        this[_0x3dccd2('0x24b')] = null,
                        this['_checkedTxt'] = null,
                        this['_index'] = -0x1,
                        this[_0x3dccd2('0x3b2')] = null,
                        this[_0x3dccd2('0x34e')] = _0x4e7c88;
                    var _0x593516 = _0xdf791f[_0x3dccd2('0x3b6')][_0x3dccd2('0x60d')][_0x3dccd2('0x1b8')](_0x32f266[_0x3dccd2('0x29')][_0x3dccd2('0x1e7')]);
                    this[_0x3dccd2('0x5d3')] = _0x593516['create'](),
                        this[_0x3dccd2('0x537')] = this['gameobject']['getChildByName'](_0x3dccd2('0x396')),
                        this[_0x3dccd2('0xe')] = this[_0x3dccd2('0x5d3')][_0x3dccd2('0x3aa')](_0x3dccd2('0x1ea')),
                        this['_goldCount'] = this[_0x3dccd2('0xe')][_0x3dccd2('0x3aa')]('goldCount'),
                        this[_0x3dccd2('0x4d')] = this['gameobject']['getChildByName'](_0x3dccd2('0x346')),
                        this[_0x3dccd2('0x24b')] = this[_0x3dccd2('0x5d3')][_0x3dccd2('0x3aa')](_0x3dccd2('0x4f5')),
                        this[_0x3dccd2('0xaa')] = this[_0x3dccd2('0x24b')][_0x3dccd2('0x3aa')]('checkedTxt'),
                        this[_0x3dccd2('0x24b')][_0x3dccd2('0x5bf')] = ![];
                }
                return _0x22d075[_0x35257c('0x64a')]['setPos'] = function (_0x549f5c, _0x5667a2) {
                    var _0x28d4c8 = _0x35257c;
                    this['gameobject'][_0x28d4c8('0x1bf')](_0x549f5c, _0x5667a2, !![]);
                }
                    ,
                    _0x22d075[_0x35257c('0x64a')][_0x35257c('0x548')] = function (_0x6d3f4c) {
                        var _0x492d6b = _0x35257c;
                        this[_0x492d6b('0x3b2')] = _0x6d3f4c;
                        var _0x8fb0d = _0xdf791f[_0x492d6b('0x3b6')]['CfgMgr'][_0x492d6b('0x235')](0x9, _0x50f993[_0x492d6b('0x1d1')][_0x492d6b('0x64d')]);
                        _0x8fb0d = _0x4aa951[_0x492d6b('0x3b6')]['rePlaceGetNumber'](_0x8fb0d, (this[_0x492d6b('0x34e')] + 0x1)[_0x492d6b('0xcc')]()),
                            this[_0x492d6b('0x537')][_0x492d6b('0x338')] = _0x8fb0d;
                        if (_0x6d3f4c[0x0] == 0x1)
                            this[_0x492d6b('0x4d')][_0x492d6b('0x5bf')] = ![],
                                this[_0x492d6b('0x427')][_0x492d6b('0x338')] = _0x6d3f4c[0x1];
                        else
                            _0x6d3f4c[0x0] == 0x2 && (this['_gold'][_0x492d6b('0x5bf')] = ![],
                                this[_0x492d6b('0x4d')][_0x492d6b('0x3c4')] = _0x492d6b('0x3a7') + _0xdf791f[_0x492d6b('0x3b6')][_0x492d6b('0x4ce')][_0x492d6b('0x3ef')](_0x6d3f4c[0x1])['ResIcon'] + _0x492d6b('0x99'));
                    }
                    ,
                    _0x22d075[_0x35257c('0x64a')][_0x35257c('0x53a')] = function () {
                        var _0x181b1f = _0x35257c;
                        this[_0x181b1f('0xaa')][_0x181b1f('0x338')] = _0xdf791f[_0x181b1f('0x3b6')][_0x181b1f('0x4ce')][_0x181b1f('0x235')](0x2c, _0x50f993[_0x181b1f('0x1d1')][_0x181b1f('0x64d')]),
                            this['_received'][_0x181b1f('0x5bf')] = !![];
                    }
                    ,
                    _0x22d075[_0x35257c('0x64a')]['GetReward'] = function (_0x375560) {
                        var _0x2daf95 = _0x35257c;
                        if (this[_0x2daf95('0x3b2')][0x0] == 0x1)
                            _0xdf791f[_0x2daf95('0x3b6')][_0x2daf95('0x678')][_0x2daf95('0x45')](this[_0x2daf95('0x3b2')][0x1] * _0x375560),
                                _0xdf791f['default'][_0x2daf95('0x5d7')][_0x2daf95('0x46e')](_0xdf791f[_0x2daf95('0x3b6')][_0x2daf95('0x4ce')]['getLangById'](0xa, _0x50f993[_0x2daf95('0x1d1')][_0x2daf95('0x64d')]) + 'x' + this[_0x2daf95('0x3b2')][0x1] * _0x375560);
                        else
                            this['_info'][0x0] == 0x2 && (this['_gold'][_0x2daf95('0x5bf')] = ![],
                                _0xdf791f[_0x2daf95('0x3b6')][_0x2daf95('0x678')][_0x2daf95('0x45c')](this[_0x2daf95('0x3b2')][0x1]),
                                _0xdf791f[_0x2daf95('0x3b6')]['UIMgr'][_0x2daf95('0x46e')](_0xdf791f[_0x2daf95('0x3b6')][_0x2daf95('0x4ce')][_0x2daf95('0x235')](0x26, _0x50f993[_0x2daf95('0x1d1')]['Language'])));
                    }
                    ,
                    _0x22d075[_0x35257c('0x64a')][_0x35257c('0x392')] = function () {
                        var _0x3b7743 = _0x35257c;
                        this['gameobject'][_0x3b7743('0x594')]();
                    }
                    ,
                    _0x22d075;
            }();
        _0x178b1e['default'] = _0x5a1095;
    }
        , {
        '../../../XGame': 0x4,
        '../../../enum/GameConst': 0xf,
        '../../../enum/ResEnum': 0x12,
        '../../../utils/Tools': 0x37
    }],
    0x35: [function (_0x39bd38, _0x44103f, _0x2a7ce7) {
        var _0x12ea3a = _0x4b7fcf;
        'use strict';
        Object['defineProperty'](_0x2a7ce7, _0x12ea3a('0xb8'), {
            'value': !![]
        });
        var _0x1b8692 = _0x39bd38(_0x12ea3a('0x1ff'))
            , _0x2ab686 = _0x39bd38(_0x12ea3a('0x26b'))
            , _0x593d73 = _0x39bd38(_0x12ea3a('0x14'))
            , _0x3d1ee3 = function () {
                var _0x1f8280 = _0x12ea3a;
                function _0x584b8d(_0xba7b4c) {
                    var _0x42cfff = _0x5985;
                    this[_0x42cfff('0x5d3')] = null,
                        this[_0x42cfff('0x459')] = ![],
                        this['_info'] = null,
                        this[_0x42cfff('0x5a8')] = null,
                        this['_icon'] = null,
                        this['_mask'] = null,
                        this[_0x42cfff('0x3b2')] = _0xba7b4c;
                    var _0x256e91 = _0x1b8692[_0x42cfff('0x3b6')]['ResMgr'][_0x42cfff('0x1b8')](_0x593d73[_0x42cfff('0x29')][_0x42cfff('0x67')]);
                    this['gameobject'] = _0x256e91[_0x42cfff('0x5fb')](),
                        this[_0x42cfff('0x5a8')] = this[_0x42cfff('0x5d3')][_0x42cfff('0x3aa')]('Selected'),
                        this[_0x42cfff('0x3ba')] = this['gameobject'][_0x42cfff('0x3aa')]('icon'),
                        this[_0x42cfff('0x38a')] = this['gameobject'][_0x42cfff('0x3aa')](_0x42cfff('0x426')),
                        this[_0x42cfff('0x3ba')][_0x42cfff('0x3c4')] = _0x42cfff('0x3a7') + _0xba7b4c[_0x42cfff('0x3d9')] + _0x42cfff('0x99'),
                        this['gameobject']['on'](Laya['Event'][_0x42cfff('0x1af')], this, this[_0x42cfff('0x3e8')]),
                        this[_0x42cfff('0x3ea')](_0xba7b4c['Id']);
                }
                return _0x584b8d[_0x1f8280('0x64a')][_0x1f8280('0x5b3')] = function (_0xb4ddc7, _0x21e9d5) {
                    var _0x538b64 = _0x1f8280;
                    this[_0x538b64('0x5d3')][_0x538b64('0x1bf')](_0xb4ddc7, _0x21e9d5, !![]);
                }
                    ,
                    _0x584b8d[_0x1f8280('0x64a')][_0x1f8280('0x318')] = function (_0x43aeea) {
                        var _0x402362 = _0x1f8280;
                        _0x43aeea > 0x0 ? this[_0x402362('0x38a')][_0x402362('0x46a')] = Laya['loader'][_0x402362('0xcb')](_0x402362('0x689')) : this[_0x402362('0x38a')][_0x402362('0x46a')] = Laya[_0x402362('0x5e')][_0x402362('0xcb')](_0x402362('0x564'));
                    }
                    ,
                    _0x584b8d[_0x1f8280('0x64a')]['onClickHandle'] = function () {
                        var _0x756222 = _0x1f8280;
                        _0x1b8692[_0x756222('0x3b6')][_0x756222('0x370')]['event'](_0x2ab686['EventEnum'][_0x756222('0x117')], [this[_0x756222('0x3b2')], this['isUnlock']]);
                    }
                    ,
                    _0x584b8d[_0x1f8280('0x64a')][_0x1f8280('0x3ea')] = function (_0x281e1a) {
                        var _0x323eb5 = _0x1f8280
                            , _0x564bcc = _0x1b8692[_0x323eb5('0x3b6')][_0x323eb5('0x4ce')]['getItemCfg'](_0x281e1a);
                        _0x564bcc[_0x323eb5('0x47c')] == _0x593d73[_0x323eb5('0x4cb')][_0x323eb5('0x331')] ? this[_0x323eb5('0x459')] = _0x1b8692[_0x323eb5('0x3b6')]['DataMgr'][_0x323eb5('0x290')](_0x564bcc['Id']) != null : this[_0x323eb5('0x459')] = _0x1b8692['default']['DataMgr'][_0x323eb5('0x202')](_0x564bcc['Id']) != null,
                            this[_0x323eb5('0x459')] ? this[_0x323eb5('0x38a')][_0x323eb5('0x5bf')] = ![] : this[_0x323eb5('0x38a')]['visible'] = !![];
                    }
                    ,
                    _0x584b8d[_0x1f8280('0x64a')]['showSelected'] = function (_0x3c490e) {
                        var _0x2460e7 = _0x1f8280;
                        this[_0x2460e7('0x5a8')][_0x2460e7('0x5bf')] = _0x3c490e;
                    }
                    ,
                    _0x584b8d[_0x1f8280('0x64a')]['destroy'] = function () {
                        var _0x333a9d = _0x1f8280;
                        this[_0x333a9d('0x5d3')][_0x333a9d('0x585')](Laya['Event'][_0x333a9d('0x1af')], this, this[_0x333a9d('0x3e8')]),
                            this['gameobject'][_0x333a9d('0x594')]();
                    }
                    ,
                    _0x584b8d;
            }();
        _0x2a7ce7[_0x12ea3a('0x3b6')] = _0x3d1ee3;
    }
        , {
        '../../../XGame': 0x4,
        '../../../enum/EventEnum': 0xe,
        '../../../enum/ResEnum': 0x12
    }],
    0x36: [function (_0x2918b6, _0x2b342a, _0x128d2b) {
        var _0x2e6b7e = _0x4b7fcf;
        'use strict';
        Object[_0x2e6b7e('0x351')](_0x128d2b, _0x2e6b7e('0xb8'), {
            'value': !![]
        });
        var _0x43b9b1 = Laya[_0x2e6b7e('0x59d')]['regClass'], _0x9224eb;
        (function (_0x57008c) {
            var _0x129804;
            (function (_0x27a9bf) {
                var _0xc67ffd = _0x5985
                    , _0x11a8dd = function (_0x1c333c) {
                        var _0x20057c = _0x5985;
                        __extends(_0x4951fd, _0x1c333c);
                        function _0x4951fd() {
                            var _0x49266b = _0x5985;
                            return _0x1c333c[_0x49266b('0x324')](this) || this;
                        }
                        return _0x4951fd[_0x20057c('0x64a')][_0x20057c('0x292')] = function () {
                            var _0x36fc37 = _0x20057c;
                            _0x1c333c['prototype'][_0x36fc37('0x292')][_0x36fc37('0x324')](this),
                                this[_0x36fc37('0x39e')](_0x4951fd['uiView']);
                        }
                            ,
                            _0x4951fd[_0x20057c('0x31e')] = {
                                'type': _0x20057c('0x646'),
                                'props': {
                                    'width': 0x2ee,
                                    'top': 0x0,
                                    'runtime': _0x20057c('0x3a6'),
                                    'right': 0x0,
                                    'left': 0x0,
                                    'height': 0x536,
                                    'bottom': 0x0
                                },
                                'compId': 0x2,
                                'child': [{
                                    'type': 'Image',
                                    'props': {
                                        'top': 0x0,
                                        'skin': _0x20057c('0x5b8'),
                                        'sizeGrid': '10,10,10,10',
                                        'right': 0x0,
                                        'name': _0x20057c('0x1ec'),
                                        'left': 0x0,
                                        'bottom': 0x0
                                    },
                                    'compId': 0x5,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0xb3,
                                            'x': 0x2d,
                                            'width': 0x294,
                                            'skin': _0x20057c('0x2c6'),
                                            'name': 'title',
                                            'height': 0x7c
                                        },
                                        'compId': 0x6
                                    }, {
                                        'type': _0x20057c('0x55c'),
                                        'props': {
                                            'y': 0x25e,
                                            'x': 0x176,
                                            'width': 0x201,
                                            'var': _0x20057c('0x65e'),
                                            'skin': _0x20057c('0x6f'),
                                            'pivotY': 0xff,
                                            'pivotX': 256.5,
                                            'height': 0x1fe
                                        },
                                        'compId': 0x7
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x26f,
                                            'x': 0x177,
                                            'width': 0x100,
                                            'var': 'cup',
                                            'skin': _0x20057c('0x3d7'),
                                            'pivotY': 0xdc,
                                            'pivotX': 0x80,
                                            'height': 0x1b8
                                        },
                                        'compId': 0x8
                                    }, {
                                        'type': _0x20057c('0x55c'),
                                        'props': {
                                            'y': 0x366,
                                            'x': 0xcf,
                                            'width': 0x14f,
                                            'var': 'keybtn',
                                            'skin': _0x20057c('0x47b'),
                                            'height': 0xdb
                                        },
                                        'compId': 0x9
                                    }, {
                                        'type': _0x20057c('0x141'),
                                        'props': {
                                            'y': 0xce,
                                            'x': 0x2,
                                            'width': 0x2ea,
                                            'var': _0x20057c('0x56c'),
                                            'text': '签到',
                                            'strokeColor': _0x20057c('0x2b2'),
                                            'stroke': 0x3,
                                            'height': 0x48,
                                            'fontSize': 0x50,
                                            'font': _0x20057c('0xa3'),
                                            'color': _0x20057c('0x207'),
                                            'bold': !![],
                                            'align': _0x20057c('0x59f'),
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0xb
                                    }, {
                                        'type': _0x20057c('0x141'),
                                        'props': {
                                            'y': 0x372,
                                            'x': 0xe0,
                                            'width': 0x12b,
                                            'var': _0x20057c('0x1c8'),
                                            'valign': 'middle',
                                            'text': '领取',
                                            'height': 0x28,
                                            'fontSize': 0x21,
                                            'font': 'Microsoft\x20YaHei',
                                            'color': _0x20057c('0x554'),
                                            'bold': !![],
                                            'align': _0x20057c('0x59f'),
                                            'runtime': _0x20057c('0x63f')
                                        },
                                        'compId': 0xc
                                    }]
                                }],
                                'loadList': [_0x20057c('0x5b8'), _0x20057c('0x2c6'), _0x20057c('0x6f'), 'level/reward_cup.png', _0x20057c('0x47b')],
                                'loadList3D': []
                            },
                            _0x4951fd;
                    }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf['CupUIUI'] = _0x11a8dd,
                    _0x43b9b1(_0xc67ffd('0x6b3'), _0x11a8dd);
                var _0x2ebb33 = function (_0x5eb6f7) {
                    var _0x480cb0 = _0xc67ffd;
                    __extends(_0xe89d57, _0x5eb6f7);
                    function _0xe89d57() {
                        var _0x578c7a = _0x5985;
                        return _0x5eb6f7[_0x578c7a('0x324')](this) || this;
                    }
                    return _0xe89d57[_0x480cb0('0x64a')][_0x480cb0('0x292')] = function () {
                        var _0x3a4fe0 = _0x480cb0;
                        _0x5eb6f7['prototype'][_0x3a4fe0('0x292')][_0x3a4fe0('0x324')](this),
                            this[_0x3a4fe0('0x39e')](_0xe89d57[_0x3a4fe0('0x31e')]);
                    }
                        ,
                        _0xe89d57['uiView'] = {
                            'type': 'BaseView',
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': 'script/view/DareLoseUI.ts',
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': 'Image',
                                'props': {
                                    'width': 0x2ee,
                                    'var': 'levelBg',
                                    'top': 0x0,
                                    'skin': _0x480cb0('0x5b8'),
                                    'sizeGrid': '10,10,10,10',
                                    'right': 0x0,
                                    'pivotY': 0x29b,
                                    'pivotX': 0x177,
                                    'name': _0x480cb0('0x215'),
                                    'left': 0x0,
                                    'height': 0x536,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 0x3c,
                                        'x': 0x113,
                                        'width': 0xe7,
                                        'skin': _0x480cb0('0xde'),
                                        'sizeGrid': _0x480cb0('0x582'),
                                        'name': 'gem',
                                        'height': 0x2c
                                    },
                                    'compId': 0x6,
                                    'child': [{
                                        'type': _0x480cb0('0x55c'),
                                        'props': {
                                            'y': -0x5,
                                            'x': -0x18,
                                            'width': 0x3a,
                                            'skin': _0x480cb0('0x20d'),
                                            'name': _0x480cb0('0x605'),
                                            'height': 0x3b
                                        },
                                        'compId': 0x7
                                    }, {
                                        'type': _0x480cb0('0x141'),
                                        'props': {
                                            'y': 0x0,
                                            'x': 0x2c,
                                            'width': 0xae,
                                            'var': _0x480cb0('0x199'),
                                            'valign': 'top',
                                            'text': _0x480cb0('0x21c'),
                                            'height': 0x1d,
                                            'fontSize': 0x28,
                                            'font': _0x480cb0('0xa3'),
                                            'color': _0x480cb0('0x36f'),
                                            'bold': !![],
                                            'align': _0x480cb0('0x59f'),
                                            'runtime': _0x480cb0('0x63f')
                                        },
                                        'compId': 0x8
                                    }]
                                }, {
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 0xcb,
                                        'x': 0x2d,
                                        'var': _0x480cb0('0x2a5'),
                                        'skin': 'level/levelTitle_fail.png',
                                        'name': _0x480cb0('0x2a5')
                                    },
                                    'compId': 0x9,
                                    'child': [{
                                        'type': 'Text',
                                        'props': {
                                            'y': -0x1,
                                            'x': -0x2b,
                                            'width': 0x2ea,
                                            'var': _0x480cb0('0x181'),
                                            'valign': 'middle',
                                            'text': '签到',
                                            'strokeColor': '#0b41ee',
                                            'stroke': 0x3,
                                            'height': 0x83,
                                            'fontSize': 0x50,
                                            'font': 'Microsoft\x20YaHei',
                                            'color': _0x480cb0('0x207'),
                                            'bold': !![],
                                            'align': _0x480cb0('0x59f'),
                                            'runtime': _0x480cb0('0x63f')
                                        },
                                        'compId': 0x50
                                    }]
                                }, {
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 0x268,
                                        'x': 0x179,
                                        'width': 0x1b8,
                                        'var': _0x480cb0('0x187'),
                                        'skin': _0x480cb0('0x6f'),
                                        'pivotY': 0xe5,
                                        'pivotX': 0xdc,
                                        'name': 'randomSkin',
                                        'height': 0x1c9
                                    },
                                    'compId': 0x3a
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x20b,
                                        'x': 0x114,
                                        'width': 0xca,
                                        'var': _0x480cb0('0xbe'),
                                        'skin': _0x480cb0('0x572'),
                                        'name': _0x480cb0('0x3c4'),
                                        'height': 0xd1
                                    },
                                    'compId': 0x3b
                                }, {
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 0x378,
                                        'x': 0xdd,
                                        'width': 0x134,
                                        'var': _0x480cb0('0x5bb'),
                                        'skin': _0x480cb0('0x2c'),
                                        'name': _0x480cb0('0x62b'),
                                        'height': 0x70
                                    },
                                    'compId': 0x36,
                                    'child': [{
                                        'type': _0x480cb0('0x55c'),
                                        'props': {
                                            'y': 0x1f,
                                            'x': 0x21,
                                            'width': 0x3b,
                                            'visible': !![],
                                            'skin': _0x480cb0('0x3b4'),
                                            'height': 0x32
                                        },
                                        'compId': 0x37
                                    }, {
                                        'type': 'Text',
                                        'props': {
                                            'y': 0xd,
                                            'x': 0x5c,
                                            'wordWrap': !![],
                                            'width': 0xcb,
                                            'var': _0x480cb0('0x472'),
                                            'valign': _0x480cb0('0x46b'),
                                            'text': _0x480cb0('0x424'),
                                            'height': 0x54,
                                            'fontSize': 0x1c,
                                            'font': _0x480cb0('0xa3'),
                                            'color': '#ffffff',
                                            'bold': !![],
                                            'align': _0x480cb0('0x59f'),
                                            'runtime': _0x480cb0('0x63f')
                                        },
                                        'compId': 0x51
                                    }]
                                }, {
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 586.5,
                                        'x': 0x122,
                                        'var': _0x480cb0('0x1da'),
                                        'skin': 'game/icon_diamond.png',
                                        'name': 'imgGem'
                                    },
                                    'compId': 0x3c,
                                    'child': [{
                                        'type': _0x480cb0('0x141'),
                                        'props': {
                                            'y': 0x0,
                                            'x': 0x3a,
                                            'width': 0xaa,
                                            'var': 'txtAddGem',
                                            'valign': _0x480cb0('0x46b'),
                                            'text': _0x480cb0('0x13f'),
                                            'height': 0x3b,
                                            'fontSize': 0x28,
                                            'font': _0x480cb0('0xa3'),
                                            'color': _0x480cb0('0x554'),
                                            'bold': !![],
                                            'align': _0x480cb0('0x2dd'),
                                            'runtime': _0x480cb0('0x63f')
                                        },
                                        'compId': 0x3d
                                    }]
                                }, {
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 0x388,
                                        'x': 0x2d,
                                        'width': 0x134,
                                        'visible': ![],
                                        'var': 'btnSharekVedio',
                                        'stateNum': 0x1,
                                        'skin': _0x480cb0('0x4f2'),
                                        'label': _0x480cb0('0x55b'),
                                        'height': 0x70
                                    },
                                    'compId': 0x3e,
                                    'child': [{
                                        'type': _0x480cb0('0x4a0'),
                                        'props': {
                                            'y': 0x1d,
                                            'x': 0x3a,
                                            'texture': _0x480cb0('0x56')
                                        },
                                        'compId': 0x3f
                                    }, {
                                        'type': _0x480cb0('0x4a0'),
                                        'props': {
                                            'y': 0x26,
                                            'x': 0x7a,
                                            'texture': _0x480cb0('0x367')
                                        },
                                        'compId': 0x40
                                    }]
                                }, {
                                    'type': _0x480cb0('0x55c'),
                                    'props': {
                                        'y': 0x159,
                                        'x': 0x37,
                                        'width': 0x27f,
                                        'visible': ![],
                                        'var': _0x480cb0('0x5b7'),
                                        'skin': _0x480cb0('0x133'),
                                        'sizeGrid': '67,30,24,27',
                                        'height': 0xe0
                                    },
                                    'compId': 0x41,
                                    'child': [{
                                        'type': _0x480cb0('0x6ae'),
                                        'props': {
                                            'y': 0x3b,
                                            'x': 0x22,
                                            'width': 0x80,
                                            'var': _0x480cb0('0x320')
                                        },
                                        'compId': 0x42
                                    }, {
                                        'type': _0x480cb0('0x4a0'),
                                        'props': {
                                            'y': 0x7,
                                            'x': 0xfb,
                                            'texture': _0x480cb0('0x113')
                                        },
                                        'compId': 0x44
                                    }]
                                }, {
                                    'type': _0x480cb0('0x6ae'),
                                    'props': {
                                        'y': 0x16d,
                                        'x': 0x0,
                                        'visible': ![],
                                        'var': 'loseAd'
                                    },
                                    'compId': 0x4f,
                                    'child': [{
                                        'type': _0x480cb0('0x55c'),
                                        'props': {
                                            'width': 0xa9,
                                            'visible': !![],
                                            'skin': _0x480cb0('0x133'),
                                            'sizeGrid': _0x480cb0('0x69'),
                                            'height': 0x232
                                        },
                                        'compId': 0x4a
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'x': 0x245,
                                            'width': 0xa9,
                                            'visible': !![],
                                            'skin': _0x480cb0('0x133'),
                                            'sizeGrid': _0x480cb0('0x69'),
                                            'height': 0x232
                                        },
                                        'compId': 0x4c
                                    }]
                                }, {
                                    'type': 'Text',
                                    'props': {
                                        'y': 0x3e8,
                                        'x': 0xef,
                                        'width': 0x10b,
                                        'var': _0x480cb0('0xe1'),
                                        'valign': 'middle',
                                        'text': _0x480cb0('0x3c4'),
                                        'height': 0x4e,
                                        'fontSize': 0x28,
                                        'font': _0x480cb0('0xa3'),
                                        'color': _0x480cb0('0xc5'),
                                        'bold': !![],
                                        'align': _0x480cb0('0x59f'),
                                        'runtime': _0x480cb0('0x63f')
                                    },
                                    'compId': 0x52
                                }]
                            }],
                            'loadList': ['level/BG_Black.png', _0x480cb0('0xde'), _0x480cb0('0x20d'), 'level/levelTitle_fail.png', 'level/result_key_fx.png', 'skin/Hoop_Donut_01_icon.png', _0x480cb0('0x2c'), _0x480cb0('0x3b4'), 'game/btn_red.png', _0x480cb0('0x56'), _0x480cb0('0x367'), _0x480cb0('0x133'), _0x480cb0('0x113')],
                            'loadList3D': []
                        },
                        _0xe89d57;
                }(Laya['BaseView']);
                _0x27a9bf[_0xc67ffd('0x404')] = _0x2ebb33,
                    _0x43b9b1(_0xc67ffd('0x92'), _0x2ebb33);
                var _0x22a4da = function (_0x165c2c) {
                    var _0x8727aa = _0xc67ffd;
                    __extends(_0xe7ae89, _0x165c2c);
                    function _0xe7ae89() {
                        var _0xe5ac75 = _0x5985;
                        return _0x165c2c[_0xe5ac75('0x324')](this) || this;
                    }
                    return _0xe7ae89[_0x8727aa('0x64a')][_0x8727aa('0x292')] = function () {
                        var _0x3026cd = _0x8727aa;
                        _0x165c2c[_0x3026cd('0x64a')]['createChildren'][_0x3026cd('0x324')](this),
                            this[_0x3026cd('0x39e')](_0xe7ae89['uiView']);
                    }
                        ,
                        _0xe7ae89[_0x8727aa('0x31e')] = {
                            'type': _0x8727aa('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x8727aa('0x1ef'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x8727aa('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': _0x8727aa('0x5b8'),
                                    'sizeGrid': _0x8727aa('0x4ec'),
                                    'right': 0x0,
                                    'name': 'dareBg',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0xa,
                                'child': [{
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x20e,
                                        'x': 0x0,
                                        'width': 0x2ee,
                                        'skin': 'dare/vs_di.png',
                                        'name': _0x8727aa('0x600'),
                                        'height': 0xe5
                                    },
                                    'compId': 0xb,
                                    'child': [{
                                        'type': _0x8727aa('0x55c'),
                                        'props': {
                                            'y': 39.5,
                                            'x': 0x2e,
                                            'width': 0x93,
                                            'skin': _0x8727aa('0x4e9'),
                                            'name': 'player01',
                                            'height': 0x96
                                        },
                                        'compId': 0xd,
                                        'child': [{
                                            'type': _0x8727aa('0x55c'),
                                            'props': {
                                                'y': 11.5,
                                                'x': 0xb,
                                                'width': 0x7d,
                                                'var': _0x8727aa('0x4dc'),
                                                'skin': _0x8727aa('0x572'),
                                                'name': _0x8727aa('0x4dc'),
                                                'height': 0x7d
                                            },
                                            'compId': 0xe
                                        }]
                                    }, {
                                        'type': _0x8727aa('0x141'),
                                        'props': {
                                            'y': 0x57,
                                            'x': 0x2,
                                            'width': 0x2ea,
                                            'var': _0x8727aa('0x67e'),
                                            'valign': _0x8727aa('0x46b'),
                                            'text': '签到',
                                            'strokeColor': _0x8727aa('0x2b2'),
                                            'stroke': 0x3,
                                            'height': 0x47,
                                            'fontSize': 0x32,
                                            'font': _0x8727aa('0xa3'),
                                            'color': _0x8727aa('0x207'),
                                            'bold': !![],
                                            'align': _0x8727aa('0x59f'),
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0x18
                                    }, {
                                        'type': _0x8727aa('0x55c'),
                                        'props': {
                                            'y': 0x36,
                                            'x': 299.5,
                                            'width': 0x98,
                                            'var': 'imgVS',
                                            'skin': _0x8727aa('0x96'),
                                            'name': _0x8727aa('0x2'),
                                            'height': 0x79
                                        },
                                        'compId': 0x12
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 39.5,
                                            'x': 0x230,
                                            'width': 0x93,
                                            'skin': _0x8727aa('0x4e9'),
                                            'name': _0x8727aa('0x387'),
                                            'height': 0x96
                                        },
                                        'compId': 0x10,
                                        'child': [{
                                            'type': 'Image',
                                            'props': {
                                                'y': 11.5,
                                                'x': 0xb,
                                                'width': 0x7d,
                                                'var': _0x8727aa('0x412'),
                                                'skin': _0x8727aa('0x572'),
                                                'name': _0x8727aa('0x412'),
                                                'height': 0x7d
                                            },
                                            'compId': 0x11
                                        }]
                                    }]
                                }, {
                                    'type': _0x8727aa('0x141'),
                                    'props': {
                                        'y': 0x16a,
                                        'x': 0x1,
                                        'width': 0x2ea,
                                        'var': _0x8727aa('0x6b4'),
                                        'text': '签到',
                                        'strokeColor': '#0b41ee',
                                        'stroke': 0x3,
                                        'height': 0x48,
                                        'fontSize': 0x50,
                                        'font': _0x8727aa('0xa3'),
                                        'color': '#fffdfd',
                                        'bold': !![],
                                        'align': 'center',
                                        'runtime': _0x8727aa('0x63f')
                                    },
                                    'compId': 0x17
                                }]
                            }],
                            'loadList': [_0x8727aa('0x5b8'), _0x8727aa('0x1bb'), _0x8727aa('0x4e9'), _0x8727aa('0x572'), _0x8727aa('0x96')],
                            'loadList3D': []
                        },
                        _0xe7ae89;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf['DareUIUI'] = _0x22a4da,
                    _0x43b9b1('ui.view.DareUIUI', _0x22a4da);
                var _0x593d0d = function (_0x33d84f) {
                    var _0xbff985 = _0xc67ffd;
                    __extends(_0x15c0db, _0x33d84f);
                    function _0x15c0db() {
                        var _0x7f0bce = _0x5985;
                        return _0x33d84f[_0x7f0bce('0x324')](this) || this;
                    }
                    return _0x15c0db['prototype'][_0xbff985('0x292')] = function () {
                        var _0x30469d = _0xbff985;
                        _0x33d84f[_0x30469d('0x64a')]['createChildren'][_0x30469d('0x324')](this),
                            this[_0x30469d('0x39e')](_0x15c0db['uiView']);
                    }
                        ,
                        _0x15c0db[_0xbff985('0x31e')] = {
                            'type': _0xbff985('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': 'script/view/GameUI.ts',
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0xbff985('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': _0xbff985('0x614'),
                                    'right': 0x0,
                                    'name': _0xbff985('0x56d'),
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x1c,
                                        'x': 0x15,
                                        'width': 0x6a,
                                        'visible': ![],
                                        'var': _0xbff985('0x12c'),
                                        'skin': _0xbff985('0x1c9'),
                                        'sizeGrid': '45,0,44,0',
                                        'height': 0x16b
                                    },
                                    'compId': 0x6,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x8a,
                                            'x': 0xd,
                                            'width': 0x4f,
                                            'var': _0xbff985('0x68'),
                                            'skin': 'game/main_menu_vibroon_1.png',
                                            'height': 0x51
                                        },
                                        'compId': 0x9
                                    }, {
                                        'type': _0xbff985('0x55c'),
                                        'props': {
                                            'y': 0xfe,
                                            'x': 0xd,
                                            'width': 0x4f,
                                            'var': _0xbff985('0x97'),
                                            'skin': _0xbff985('0x2d9'),
                                            'height': 0x51
                                        },
                                        'compId': 0xa
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x1c,
                                        'x': 0x15,
                                        'width': 0x6a,
                                        'visible': ![],
                                        'var': _0xbff985('0x328'),
                                        'skin': 'game/setting1.png',
                                        'height': 0x6c
                                    },
                                    'compId': 0x7
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x3e,
                                        'x': 0x113,
                                        'width': 0xe7,
                                        'skin': _0xbff985('0xde'),
                                        'sizeGrid': _0xbff985('0x582'),
                                        'name': _0xbff985('0x108'),
                                        'height': 0x2c
                                    },
                                    'compId': 0xe,
                                    'child': [{
                                        'type': _0xbff985('0x55c'),
                                        'props': {
                                            'y': -0x5,
                                            'x': -0x18,
                                            'width': 0x3a,
                                            'skin': 'game/icon_diamond.png',
                                            'name': _0xbff985('0x605'),
                                            'height': 0x3b
                                        },
                                        'compId': 0xd
                                    }, {
                                        'type': 'Text',
                                        'props': {
                                            'y': 0x0,
                                            'x': 0x2a,
                                            'width': 0xae,
                                            'var': _0xbff985('0x2a2'),
                                            'valign': _0xbff985('0x10d'),
                                            'text': _0xbff985('0x362'),
                                            'height': 0xc,
                                            'fontSize': 0x28,
                                            'font': 'Microsoft\x20YaHei',
                                            'color': _0xbff985('0x36f'),
                                            'bold': !![],
                                            'align': 'center',
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0xf
                                    }]
                                }, {
                                    'type': _0xbff985('0x141'),
                                    'props': {
                                        'y': 0x92,
                                        'x': 0x71,
                                        'width': 0x20b,
                                        'var': _0xbff985('0x58a'),
                                        'text': '第六关',
                                        'height': 0x31,
                                        'fontSize': 0x32,
                                        'font': _0xbff985('0xa3'),
                                        'color': '#fdfbfb',
                                        'bold': !![],
                                        'align': 'center',
                                        'runtime': 'laya.display.Text'
                                    },
                                    'compId': 0x10
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0xef,
                                        'x': 149.5,
                                        'width': 0x1a3,
                                        'skin': _0xbff985('0x226'),
                                        'name': _0xbff985('0x106'),
                                        'height': 0x11a
                                    },
                                    'compId': 0x11
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0xee,
                                        'x': 0x271,
                                        'width': 0x7d,
                                        'visible': !![],
                                        'var': _0xbff985('0x12'),
                                        'skin': _0xbff985('0x58e'),
                                        'height': 0x81
                                    },
                                    'compId': 0x1b,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0xe,
                                            'x': 26.5,
                                            'width': 0x48,
                                            'skin': 'game/btn_luckypan.png',
                                            'height': 0x48
                                        },
                                        'compId': 0x1c
                                    }, {
                                        'type': _0xbff985('0x141'),
                                        'props': {
                                            'y': 0x58,
                                            'x': 0x3,
                                            'wordWrap': !![],
                                            'width': 0x77,
                                            'var': _0xbff985('0x642'),
                                            'valign': _0xbff985('0x46b'),
                                            'text': _0xbff985('0x23b'),
                                            'height': 0x22,
                                            'fontSize': 0xe,
                                            'font': _0xbff985('0xa3'),
                                            'color': _0xbff985('0x207'),
                                            'bold': !![],
                                            'align': _0xbff985('0x59f'),
                                            'runtime': _0xbff985('0x63f')
                                        },
                                        'compId': 0x1d
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x1c1,
                                        'x': 0x2ee,
                                        'width': 0x7d,
                                        'var': _0xbff985('0x27e'),
                                        'skin': 'game/btn_Purpledi.png',
                                        'pivotY': 0x41,
                                        'pivotX': 0x7d,
                                        'height': 0x81
                                    },
                                    'compId': 0x1e,
                                    'child': [{
                                        'type': _0xbff985('0x55c'),
                                        'props': {
                                            'y': 0x10,
                                            'x': 26.5,
                                            'width': 0x48,
                                            'skin': _0xbff985('0x48c'),
                                            'height': 0x48
                                        },
                                        'compId': 0x1f
                                    }, {
                                        'type': _0xbff985('0x141'),
                                        'props': {
                                            'y': 0x6a,
                                            'x': 0x2f,
                                            'width': 0x70,
                                            'var': _0xbff985('0xaf'),
                                            'valign': _0xbff985('0x46b'),
                                            'pivotY': 0x10,
                                            'pivotX': 0x28,
                                            'height': 0x1f,
                                            'fontSize': 0x14,
                                            'font': 'Microsoft\x20YaHei',
                                            'color': _0xbff985('0x207'),
                                            'bold': !![],
                                            'align': _0xbff985('0x59f'),
                                            'runtime': _0xbff985('0x63f')
                                        },
                                        'compId': 0x20
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x37c,
                                        'x': 0xdd,
                                        'width': 0x134,
                                        'var': _0xbff985('0x71'),
                                        'skin': _0xbff985('0x4f2'),
                                        'height': 0x82
                                    },
                                    'compId': 0x22,
                                    'child': [{
                                        'type': _0xbff985('0x55c'),
                                        'props': {
                                            'y': 0x26,
                                            'x': 0x1d,
                                            'width': 0x3b,
                                            'visible': ![],
                                            'var': _0xbff985('0x5a9'),
                                            'skin': _0xbff985('0x14a'),
                                            'height': 0x32
                                        },
                                        'compId': 0x25,
                                        'child': [{
                                            'type': _0xbff985('0x141'),
                                            'props': {
                                                'y': -0x19,
                                                'x': 0x3c,
                                                'wordWrap': !![],
                                                'width': 0xd0,
                                                'var': _0xbff985('0x6a'),
                                                'valign': _0xbff985('0x46b'),
                                                'text': '免费使用',
                                                'height': 0x65,
                                                'fontSize': 0x1e,
                                                'font': _0xbff985('0xa3'),
                                                'color': '#fffdfd',
                                                'bold': !![],
                                                'align': _0xbff985('0x59f'),
                                                'runtime': _0xbff985('0x63f')
                                            },
                                            'compId': 0x6e
                                        }]
                                    }, {
                                        'type': 'Text',
                                        'props': {
                                            'y': 0x2e,
                                            'x': 58.5,
                                            'width': 0xb8,
                                            'var': _0xbff985('0x475'),
                                            'text': '游戏',
                                            'height': 0x28,
                                            'fontSize': 0x28,
                                            'font': _0xbff985('0xa3'),
                                            'color': _0xbff985('0x207'),
                                            'bold': !![],
                                            'align': _0xbff985('0x59f'),
                                            'runtime': _0xbff985('0x63f')
                                        },
                                        'compId': 0x6d
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x3ff,
                                        'x': 0x25,
                                        'width': 0x122,
                                        'var': _0xbff985('0x3b3'),
                                        'skin': _0xbff985('0x61e'),
                                        'height': 0x86
                                    },
                                    'compId': 0x16,
                                    'child': [{
                                        'type': _0xbff985('0x141'),
                                        'props': {
                                            'y': 0x1e,
                                            'x': 0x31,
                                            'wordWrap': !![],
                                            'width': 0xc0,
                                            'var': _0xbff985('0x58f'),
                                            'valign': _0xbff985('0x46b'),
                                            'text': '挑战',
                                            'height': 0x62,
                                            'fontSize': 0x23,
                                            'font': _0xbff985('0xa3'),
                                            'color': _0xbff985('0x207'),
                                            'bold': !![],
                                            'align': _0xbff985('0x59f'),
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0x6f
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x442,
                                        'x': 0x228,
                                        'width': 0x122,
                                        'var': _0xbff985('0x84'),
                                        'skin': _0xbff985('0x103'),
                                        'pivotY': 0x43,
                                        'pivotX': 0x91,
                                        'height': 0x86
                                    },
                                    'compId': 0x17,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x0,
                                            'x': 0xfa,
                                            'width': 0x32,
                                            'skin': _0xbff985('0x483'),
                                            'height': 0x33
                                        },
                                        'compId': 0x21
                                    }, {
                                        'type': _0xbff985('0x141'),
                                        'props': {
                                            'y': 0x3b,
                                            'x': 0x17,
                                            'width': 0xfc,
                                            'var': 'skinTxt',
                                            'text': '游戏',
                                            'height': 0x28,
                                            'fontSize': 0x23,
                                            'font': _0xbff985('0xa3'),
                                            'color': _0xbff985('0x207'),
                                            'bold': !![],
                                            'align': _0xbff985('0x59f'),
                                            'runtime': _0xbff985('0x63f')
                                        },
                                        'compId': 0x70
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x200,
                                        'x': 0x154,
                                        'width': 0x46,
                                        'var': 'arrow',
                                        'skin': 'game/PlayerMark.png',
                                        'height': 0x3c
                                    },
                                    'compId': 0x32
                                }, {
                                    'type': _0xbff985('0x6ae'),
                                    'props': {
                                        'y': 0x341,
                                        'x': 0x15c,
                                        'var': _0xbff985('0x146')
                                    },
                                    'compId': 0x35
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x1a8,
                                        'x': 0x1d,
                                        'visible': ![],
                                        'var': _0xbff985('0x2de'),
                                        'skin': _0xbff985('0x4f')
                                    },
                                    'compId': 0x42,
                                    'child': [{
                                        'type': _0xbff985('0x4a0'),
                                        'props': {
                                            'y': 0x18,
                                            'x': 25.5,
                                            'texture': 'game/record_stop.png'
                                        },
                                        'compId': 0x43
                                    }, {
                                        'type': _0xbff985('0x4a0'),
                                        'props': {
                                            'y': 0x5b,
                                            'x': 0xe,
                                            'texture': _0xbff985('0x18b')
                                        },
                                        'compId': 0x49
                                    }]
                                }, {
                                    'type': _0xbff985('0x55c'),
                                    'props': {
                                        'y': 0x1a8,
                                        'x': 0x1d,
                                        'visible': ![],
                                        'var': _0xbff985('0x27a'),
                                        'skin': _0xbff985('0x4f')
                                    },
                                    'compId': 0x3c,
                                    'child': [{
                                        'type': _0xbff985('0x4a0'),
                                        'props': {
                                            'y': 0x12,
                                            'x': 0x13,
                                            'texture': _0xbff985('0x687')
                                        },
                                        'compId': 0x3b
                                    }, {
                                        'type': _0xbff985('0x4a0'),
                                        'props': {
                                            'y': 0x5b,
                                            'x': 0x19,
                                            'texture': 'game/record_startText.png'
                                        },
                                        'compId': 0x3d
                                    }]
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x1a8,
                                        'x': 0x1d,
                                        'visible': ![],
                                        'var': _0xbff985('0xca'),
                                        'skin': _0xbff985('0x4f')
                                    },
                                    'compId': 0x54,
                                    'child': [{
                                        'type': _0xbff985('0x4a0'),
                                        'props': {
                                            'y': 0xf,
                                            'x': 0x13,
                                            'texture': _0xbff985('0x5d0')
                                        },
                                        'compId': 0x55
                                    }, {
                                        'type': _0xbff985('0x4a0'),
                                        'props': {
                                            'y': 0x5b,
                                            'x': 0x2,
                                            'texture': _0xbff985('0x671')
                                        },
                                        'compId': 0x57
                                    }]
                                }, {
                                    'type': _0xbff985('0x4a0'),
                                    'props': {
                                        'y': 0x37b,
                                        'x': 64.5,
                                        'var': 'signbtn',
                                        'texture': _0xbff985('0x5a5')
                                    },
                                    'compId': 0x5c,
                                    'child': [{
                                        'type': _0xbff985('0x141'),
                                        'props': {
                                            'y': 0x57,
                                            'x': 0x7,
                                            'wordWrap': !![],
                                            'width': 0x6d,
                                            'var': 'signTxt',
                                            'valign': _0xbff985('0x46b'),
                                            'text': _0xbff985('0x15b'),
                                            'leading': -0x3,
                                            'height': 0x21,
                                            'fontSize': 0x14,
                                            'font': _0xbff985('0xa3'),
                                            'color': _0xbff985('0x207'),
                                            'bold': !![],
                                            'align': _0xbff985('0x59f'),
                                            'runtime': _0xbff985('0x63f')
                                        },
                                        'compId': 0x71
                                    }]
                                }, {
                                    'type': _0xbff985('0x4a0'),
                                    'props': {
                                        'y': 0x37b,
                                        'x': 562.5,
                                        'visible': ![],
                                        'var': 'rankbtn',
                                        'texture': _0xbff985('0x39')
                                    },
                                    'compId': 0x5a
                                }, {
                                    'type': _0xbff985('0x4a0'),
                                    'props': {
                                        'y': 0x37b,
                                        'x': 562.5,
                                        'visible': ![],
                                        'var': 'btnMoreGame',
                                        'texture': _0xbff985('0x75')
                                    },
                                    'compId': 0x69
                                }, {
                                    'type': _0xbff985('0x4a0'),
                                    'props': {
                                        'y': 0x222,
                                        'x': 0x266,
                                        'width': 0x88,
                                        'visible': ![],
                                        'var': _0xbff985('0x431'),
                                        'texture': _0xbff985('0x311')
                                    },
                                    'compId': 0x6a
                                }, {
                                    'type': _0xbff985('0x53b'),
                                    'props': {
                                        'y': 0x208,
                                        'x': 0x1f7,
                                        'width': 0xf9,
                                        'visible': ![],
                                        'var': 'testBtn',
                                        'stateNum': 0x1,
                                        'skin': _0xbff985('0x4f2'),
                                        'labelSize': 0x1e,
                                        'labelColors': _0xbff985('0x554'),
                                        'labelBold': !![],
                                        'label': '加宝石按钮',
                                        'height': 0x72
                                    },
                                    'compId': 0x72
                                }, {
                                    'type': _0xbff985('0x6ae'),
                                    'props': {
                                        'y': 0x27e,
                                        'x': 0x0,
                                        'width': 0x2ee,
                                        'var': _0xbff985('0x6e'),
                                        'height': 0x101
                                    },
                                    'compId': 0x73
                                }]
                            }, {
                                'type': _0xbff985('0x6ae'),
                                'props': {
                                    'var': 'box',
                                    'top': 0x0,
                                    'right': 0x0,
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x59
                            }, {
                                'type': 'Image',
                                'props': {
                                    'visible': ![],
                                    'var': _0xbff985('0x4da'),
                                    'skin': 'game/toulike.png',
                                    'sizeGrid': _0xbff985('0x7d'),
                                    'right': 0x0,
                                    'left': 0x0,
                                    'height': 0xad,
                                    'bottom': 0x0
                                },
                                'compId': 0x68,
                                'child': [{
                                    'type': _0xbff985('0x3ed'),
                                    'props': {
                                        'y': 0x10,
                                        'x': 0x51,
                                        'width': 0x293,
                                        'var': _0xbff985('0x16d'),
                                        'height': 0x96
                                    },
                                    'compId': 0x5f
                                }]
                            }],
                            'loadList': [_0xbff985('0x614'), _0xbff985('0x1c9'), _0xbff985('0x666'), 'game/main_menu_sound_1.png', _0xbff985('0x1f5'), _0xbff985('0xde'), _0xbff985('0x20d'), _0xbff985('0x226'), _0xbff985('0x58e'), _0xbff985('0x225'), _0xbff985('0x48c'), 'game/btn_red.png', 'reward/rewarded_video_button.png', 'game/BTN_challenge.png', _0xbff985('0x103'), _0xbff985('0x483'), _0xbff985('0xb1'), _0xbff985('0x4f'), 'game/record_stop.png', _0xbff985('0x18b'), _0xbff985('0x687'), _0xbff985('0x178'), _0xbff985('0x5d0'), _0xbff985('0x671'), _0xbff985('0x5a5'), _0xbff985('0x39'), 'game/moregame.png', _0xbff985('0x311'), 'game/toulike.png'],
                            'loadList3D': []
                        },
                        _0x15c0db;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x4f4')] = _0x593d0d,
                    _0x43b9b1(_0xc67ffd('0x446'), _0x593d0d);
                var _0xfb1658 = function (_0xadb0b2) {
                    var _0x28503c = _0xc67ffd;
                    __extends(_0x2a6ea8, _0xadb0b2);
                    function _0x2a6ea8() {
                        var _0x29a4b2 = _0x5985;
                        return _0xadb0b2[_0x29a4b2('0x324')](this) || this;
                    }
                    return _0x2a6ea8[_0x28503c('0x64a')][_0x28503c('0x292')] = function () {
                        var _0x54b586 = _0x28503c;
                        _0xadb0b2['prototype'][_0x54b586('0x292')][_0x54b586('0x324')](this),
                            this['createView'](_0x2a6ea8['uiView']);
                    }
                        ,
                        _0x2a6ea8[_0x28503c('0x31e')] = {
                            'type': _0x28503c('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x28503c('0x157'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x28503c('0x55c'),
                                'props': {
                                    'var': _0x28503c('0x215'),
                                    'top': 0x0,
                                    'skin': _0x28503c('0x5b8'),
                                    'sizeGrid': _0x28503c('0x4ec'),
                                    'right': 0x0,
                                    'name': _0x28503c('0x215'),
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': _0x28503c('0x55c'),
                                    'props': {
                                        'y': 0x3c,
                                        'x': 0x113,
                                        'width': 0xe7,
                                        'skin': 'game/iocn_diamondBG.png',
                                        'sizeGrid': _0x28503c('0x582'),
                                        'name': 'gem',
                                        'height': 0x2c
                                    },
                                    'compId': 0x6,
                                    'child': [{
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': -0x5,
                                            'x': -0x18,
                                            'width': 0x3a,
                                            'skin': _0x28503c('0x20d'),
                                            'name': _0x28503c('0x605'),
                                            'height': 0x3b
                                        },
                                        'compId': 0x7
                                    }, {
                                        'type': _0x28503c('0x141'),
                                        'props': {
                                            'y': 0x0,
                                            'x': 0x2b,
                                            'width': 0xae,
                                            'var': _0x28503c('0x1ae'),
                                            'valign': 'top',
                                            'text': _0x28503c('0x362'),
                                            'height': 0x1d,
                                            'fontSize': 0x28,
                                            'font': _0x28503c('0xa3'),
                                            'color': _0x28503c('0x36f'),
                                            'bold': !![],
                                            'align': _0x28503c('0x59f'),
                                            'runtime': _0x28503c('0x63f')
                                        },
                                        'compId': 0x8
                                    }]
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0xca,
                                        'x': 0x2d,
                                        'width': 0x294,
                                        'var': _0x28503c('0x4db'),
                                        'skin': 'level/title_Victory.png',
                                        'name': _0x28503c('0x4db'),
                                        'height': 0x7c
                                    },
                                    'compId': 0x9
                                }, {
                                    'type': _0x28503c('0x55c'),
                                    'props': {
                                        'y': 0xca,
                                        'x': 0x2d,
                                        'width': 0x294,
                                        'var': _0x28503c('0x410'),
                                        'skin': _0x28503c('0x512'),
                                        'name': _0x28503c('0x410'),
                                        'height': 0x7c
                                    },
                                    'compId': 0x3c
                                }, {
                                    'type': _0x28503c('0x55c'),
                                    'props': {
                                        'width': 0x275,
                                        'var': _0x28503c('0x313'),
                                        'top': 0x16b,
                                        'skin': _0x28503c('0x5a4'),
                                        'pivotY': 0x95,
                                        'pivotX': 0x13b,
                                        'name': 'imgSchedule',
                                        'left': 0x3c,
                                        'height': 0x129
                                    },
                                    'compId': 0xa,
                                    'child': [{
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x8f,
                                            'x': 0x6a,
                                            'width': 0x18b,
                                            'skin': _0x28503c('0x271'),
                                            'name': _0x28503c('0x492'),
                                            'height': 0x12
                                        },
                                        'compId': 0x13
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x98,
                                            'x': 0x74,
                                            'width': 0x3e,
                                            'var': _0x28503c('0x523'),
                                            'skin': 'level/level_bar1.png',
                                            'sizeGrid': '0,11,0,14',
                                            'pivotY': 0x9,
                                            'name': _0x28503c('0x37a'),
                                            'height': 0x12
                                        },
                                        'compId': 0x12
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x98,
                                            'x': 272.5,
                                            'width': 0x3e,
                                            'var': 'imgLine2',
                                            'skin': _0x28503c('0x104'),
                                            'sizeGrid': _0x28503c('0x2e7'),
                                            'pivotY': 0x9,
                                            'name': _0x28503c('0x1de'),
                                            'height': 0x12
                                        },
                                        'compId': 0x14
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x98,
                                            'x': 0x1a4,
                                            'width': 0x3e,
                                            'var': _0x28503c('0x282'),
                                            'skin': _0x28503c('0x104'),
                                            'sizeGrid': _0x28503c('0x2e7'),
                                            'pivotY': 0x9,
                                            'name': 'imgLine03',
                                            'height': 0x12
                                        },
                                        'compId': 0x16
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x61,
                                            'x': 0x11,
                                            'width': 0x6c,
                                            'var': 'imgLevel01',
                                            'skin': _0x28503c('0x314'),
                                            'name': _0x28503c('0x511'),
                                            'height': 0x6e
                                        },
                                        'compId': 0xc,
                                        'child': [{
                                            'type': 'Image',
                                            'props': {
                                                'y': 0x5c,
                                                'x': 0x66,
                                                'width': 0x2f,
                                                'var': _0x28503c('0x1ac'),
                                                'skin': 'level/level_complete.png',
                                                'pivotY': 0x19,
                                                'pivotX': 0x18,
                                                'name': 'imgState1',
                                                'height': 0x32
                                            },
                                            'compId': 0xd
                                        }, {
                                            'type': _0x28503c('0x141'),
                                            'props': {
                                                'y': 0x84,
                                                'x': -0x9,
                                                'width': 0x78,
                                                'var': _0x28503c('0x40'),
                                                'valign': _0x28503c('0x46b'),
                                                'name': 'txtState1',
                                                'height': 0x14,
                                                'fontSize': 0x19,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': '#fbf6f6',
                                                'bold': !![],
                                                'align': _0x28503c('0x59f'),
                                                'runtime': _0x28503c('0x63f')
                                            },
                                            'compId': 0x1a
                                        }]
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x61,
                                            'x': 0xaa,
                                            'width': 0x6c,
                                            'var': 'imgLevel02',
                                            'skin': _0x28503c('0x28c'),
                                            'name': 'imgLevel02',
                                            'height': 0x6e
                                        },
                                        'compId': 0x40,
                                        'child': [{
                                            'type': _0x28503c('0x55c'),
                                            'props': {
                                                'y': 0x5c,
                                                'x': 0x66,
                                                'width': 0x2f,
                                                'var': 'imgState2',
                                                'skin': 'level/level_failed.png',
                                                'pivotY': 0x19,
                                                'pivotX': 0x18,
                                                'name': _0x28503c('0x378'),
                                                'height': 0x32
                                            },
                                            'compId': 0x41
                                        }, {
                                            'type': _0x28503c('0x141'),
                                            'props': {
                                                'y': 0x84,
                                                'x': -0x6,
                                                'width': 0x78,
                                                'var': _0x28503c('0x5e5'),
                                                'text': '待定',
                                                'name': _0x28503c('0x5e5'),
                                                'height': 0x14,
                                                'fontSize': 0x19,
                                                'font': _0x28503c('0xa3'),
                                                'color': _0x28503c('0x397'),
                                                'bold': !![],
                                                'align': 'center',
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x42
                                        }]
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x61,
                                            'x': 0x141,
                                            'width': 0x6c,
                                            'var': _0x28503c('0x690'),
                                            'skin': _0x28503c('0x48a'),
                                            'name': _0x28503c('0x690'),
                                            'height': 0x6e
                                        },
                                        'compId': 0x46,
                                        'child': [{
                                            'type': _0x28503c('0x55c'),
                                            'props': {
                                                'y': 0x5c,
                                                'x': 0x66,
                                                'width': 0x2f,
                                                'var': _0x28503c('0x310'),
                                                'skin': 'level/level_failed.png',
                                                'pivotY': 0x19,
                                                'pivotX': 0x18,
                                                'name': 'imgState3',
                                                'height': 0x32
                                            },
                                            'compId': 0x47
                                        }, {
                                            'type': _0x28503c('0x141'),
                                            'props': {
                                                'y': 0x84,
                                                'x': -0x1,
                                                'width': 0x78,
                                                'var': _0x28503c('0x3c5'),
                                                'text': '待定',
                                                'name': _0x28503c('0x3c5'),
                                                'height': 0x14,
                                                'fontSize': 0x19,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x28503c('0x397'),
                                                'bold': !![],
                                                'align': _0x28503c('0x59f'),
                                                'runtime': _0x28503c('0x63f')
                                            },
                                            'compId': 0x48
                                        }]
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 77.5,
                                            'x': 0x1d8,
                                            'width': 0x8d,
                                            'var': _0x28503c('0x32'),
                                            'skin': _0x28503c('0x14c'),
                                            'name': _0x28503c('0x32'),
                                            'height': 0x97
                                        },
                                        'compId': 0x18,
                                        'child': [{
                                            'type': _0x28503c('0x55c'),
                                            'props': {
                                                'y': 0x12,
                                                'x': 0x25,
                                                'width': 0x44,
                                                'var': 'imgLose',
                                                'skin': 'level/fail-xxx.png',
                                                'name': _0x28503c('0x628'),
                                                'height': 0x44
                                            },
                                            'compId': 0x39
                                        }, {
                                            'type': 'Image',
                                            'props': {
                                                'y': 0x6a,
                                                'x': 0x1f,
                                                'width': 0x11,
                                                'var': _0x28503c('0x603'),
                                                'skin': 'level/result_key_small2.png',
                                                'name': _0x28503c('0x603'),
                                                'height': 0x1f
                                            },
                                            'compId': 0x25
                                        }, {
                                            'type': 'Image',
                                            'props': {
                                                'y': 0x6a,
                                                'x': 0x40,
                                                'width': 0x11,
                                                'var': _0x28503c('0x1f0'),
                                                'skin': _0x28503c('0x35e'),
                                                'name': _0x28503c('0x1f0'),
                                                'height': 0x1f
                                            },
                                            'compId': 0x27
                                        }, {
                                            'type': _0x28503c('0x55c'),
                                            'props': {
                                                'y': 0x6a,
                                                'x': 0x61,
                                                'width': 0x11,
                                                'var': _0x28503c('0x553'),
                                                'skin': _0x28503c('0x239'),
                                                'name': _0x28503c('0x553'),
                                                'height': 0x1f
                                            },
                                            'compId': 0x29
                                        }, {
                                            'type': _0x28503c('0x141'),
                                            'props': {
                                                'y': 0xa2,
                                                'x': 15.5,
                                                'width': 0x78,
                                                'var': 'finalsTxt',
                                                'text': '决赛',
                                                'name': _0x28503c('0x640'),
                                                'height': 0x14,
                                                'fontSize': 0x19,
                                                'font': _0x28503c('0xa3'),
                                                'color': '#f9ed69',
                                                'bold': !![],
                                                'align': 'center',
                                                'runtime': _0x28503c('0x63f')
                                            },
                                            'compId': 0x23
                                        }]
                                    }, {
                                        'type': _0x28503c('0x141'),
                                        'props': {
                                            'y': 0xf,
                                            'x': 0x1,
                                            'width': 0x272,
                                            'var': _0x28503c('0x140'),
                                            'valign': _0x28503c('0x46b'),
                                            'text': '领取',
                                            'height': 0x28,
                                            'fontSize': 0x28,
                                            'font': _0x28503c('0xa3'),
                                            'color': '#ffffff',
                                            'bold': !![],
                                            'align': 'center',
                                            'runtime': _0x28503c('0x63f')
                                        },
                                        'compId': 0x63
                                    }]
                                }, {
                                    'type': _0x28503c('0x6ae'),
                                    'props': {
                                        'y': 0x33a,
                                        'x': 0xf1,
                                        'width': 0x2ee,
                                        'right': 0x0,
                                        'pivotY': 0xa2,
                                        'pivotX': 0xf1,
                                        'name': _0x28503c('0x31'),
                                        'left': 0x0,
                                        'height': 0x29e
                                    },
                                    'compId': 0x52,
                                    'child': [{
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0xa2,
                                            'x': 0x177,
                                            'var': 'imgLight',
                                            'skin': _0x28503c('0x6f'),
                                            'pivotY': 0xa2,
                                            'pivotX': 0xa3,
                                            'name': _0x28503c('0x2ae')
                                        },
                                        'compId': 0x2d
                                    }]
                                }, {
                                    'type': _0x28503c('0x6ae'),
                                    'props': {
                                        'var': _0x28503c('0x174'),
                                        'name': 'boxWin'
                                    },
                                    'compId': 0x4a,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x343,
                                            'x': 0x177,
                                            'width': 0x59,
                                            'var': 'imgKey',
                                            'skin': _0x28503c('0x344'),
                                            'pivotY': 0x4d,
                                            'pivotX': 0x2d,
                                            'name': _0x28503c('0x2f5'),
                                            'height': 0x99
                                        },
                                        'compId': 0x2e
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x3f6,
                                            'x': 0x16e,
                                            'width': 0x125,
                                            'var': _0x28503c('0x514'),
                                            'skin': _0x28503c('0x6b7'),
                                            'pivotY': 0x38,
                                            'pivotX': 0x93,
                                            'name': _0x28503c('0x514'),
                                            'height': 0x70
                                        },
                                        'compId': 0x30,
                                        'child': [{
                                            'type': _0x28503c('0x141'),
                                            'props': {
                                                'y': 0x1c,
                                                'x': 0xc,
                                                'wordWrap': !![],
                                                'width': 0x10d,
                                                'var': 'nextTxt',
                                                'valign': _0x28503c('0x46b'),
                                                'text': _0x28503c('0x22a'),
                                                'height': 0x38,
                                                'fontSize': 0x1e,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x28503c('0x554'),
                                                'bold': !![],
                                                'align': _0x28503c('0x59f'),
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x66
                                        }]
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x409,
                                            'x': 0xaf,
                                            'width': 0x134,
                                            'visible': ![],
                                            'var': _0x28503c('0xef'),
                                            'stateNum': 0x1,
                                            'skin': _0x28503c('0x4f2'),
                                            'pivotY': 0x38,
                                            'pivotX': 0x93,
                                            'label': _0x28503c('0x55b'),
                                            'height': 0x70
                                        },
                                        'compId': 0x58,
                                        'child': [{
                                            'type': _0x28503c('0x4a0'),
                                            'props': {
                                                'y': 0x1d,
                                                'x': 0x3a,
                                                'texture': _0x28503c('0x56')
                                            },
                                            'compId': 0x59
                                        }, {
                                            'type': _0x28503c('0x4a0'),
                                            'props': {
                                                'y': 0x26,
                                                'x': 0x7a,
                                                'texture': _0x28503c('0x367')
                                            },
                                            'compId': 0x5a
                                        }]
                                    }]
                                }, {
                                    'type': _0x28503c('0x6ae'),
                                    'props': {
                                        'var': _0x28503c('0x42d'),
                                        'name': 'boxLose'
                                    },
                                    'compId': 0x4c,
                                    'child': [{
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x347,
                                            'x': 0x167,
                                            'var': 'imgSkin',
                                            'skin': _0x28503c('0x4c5'),
                                            'pivotY': 0x4d,
                                            'pivotX': 0x2d,
                                            'name': 'imgSkin'
                                        },
                                        'compId': 0x51
                                    }, {
                                        'type': _0x28503c('0x55c'),
                                        'props': {
                                            'y': 0x3d1,
                                            'x': 0xe6,
                                            'width': 0x134,
                                            'var': 'btnRevival',
                                            'skin': _0x28503c('0x2c'),
                                            'name': _0x28503c('0x5bb'),
                                            'height': 0x70
                                        },
                                        'compId': 0x36,
                                        'child': [{
                                            'type': _0x28503c('0x55c'),
                                            'props': {
                                                'y': 0x1e,
                                                'x': 0x21,
                                                'width': 0x3b,
                                                'visible': !![],
                                                'skin': _0x28503c('0x3b4'),
                                                'height': 0x32
                                            },
                                            'compId': 0x37
                                        }, {
                                            'type': _0x28503c('0x141'),
                                            'props': {
                                                'y': 0xd,
                                                'x': 0x5d,
                                                'wordWrap': !![],
                                                'width': 0xcb,
                                                'var': _0x28503c('0x472'),
                                                'valign': _0x28503c('0x46b'),
                                                'text': _0x28503c('0x4b9'),
                                                'height': 0x52,
                                                'fontSize': 0x1c,
                                                'font': _0x28503c('0xa3'),
                                                'color': _0x28503c('0x554'),
                                                'bold': !![],
                                                'align': _0x28503c('0x59f'),
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x64
                                        }]
                                    }, {
                                        'type': _0x28503c('0x141'),
                                        'props': {
                                            'y': 0x460,
                                            'x': 0xc3,
                                            'width': 0x180,
                                            'var': 'btnBack',
                                            'valign': _0x28503c('0x46b'),
                                            'text': '领取',
                                            'height': 0x24,
                                            'fontSize': 0x1e,
                                            'font': _0x28503c('0xa3'),
                                            'color': _0x28503c('0xc5'),
                                            'bold': !![],
                                            'align': _0x28503c('0x59f'),
                                            'runtime': _0x28503c('0x63f')
                                        },
                                        'compId': 0x67
                                    }]
                                }, {
                                    'type': _0x28503c('0x141'),
                                    'props': {
                                        'y': 0xca,
                                        'x': 0x2,
                                        'width': 0x2ea,
                                        'var': _0x28503c('0x181'),
                                        'valign': _0x28503c('0x46b'),
                                        'text': '签到',
                                        'strokeColor': _0x28503c('0x2b2'),
                                        'stroke': 0x3,
                                        'height': 0x80,
                                        'fontSize': 0x50,
                                        'font': _0x28503c('0xa3'),
                                        'color': _0x28503c('0x207'),
                                        'bold': !![],
                                        'align': _0x28503c('0x59f'),
                                        'runtime': _0x28503c('0x63f')
                                    },
                                    'compId': 0x68
                                }]
                            }],
                            'loadList': [_0x28503c('0x5b8'), _0x28503c('0xde'), _0x28503c('0x20d'), _0x28503c('0x2c6'), _0x28503c('0x512'), _0x28503c('0x5a4'), _0x28503c('0x271'), _0x28503c('0x104'), 'level/level_bg1.png', _0x28503c('0x5ad'), 'level/level_bg3.png', _0x28503c('0x3eb'), 'level/level_bg2.png', _0x28503c('0x14c'), _0x28503c('0xc2'), _0x28503c('0x239'), _0x28503c('0x35e'), _0x28503c('0x6f'), _0x28503c('0x344'), 'level/btn_green.png', _0x28503c('0x4f2'), _0x28503c('0x56'), _0x28503c('0x367'), 'skin/Hoop_Minecraft_icon.png', _0x28503c('0x2c'), _0x28503c('0x3b4')],
                            'loadList3D': []
                        },
                        _0x2a6ea8;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x316')] = _0xfb1658,
                    _0x43b9b1(_0xc67ffd('0x172'), _0xfb1658);
                var _0x2f9ad1 = function (_0x256af2) {
                    var _0x20141b = _0xc67ffd;
                    __extends(_0x4c8de9, _0x256af2);
                    function _0x4c8de9() {
                        var _0x3e818c = _0x5985;
                        return _0x256af2[_0x3e818c('0x324')](this) || this;
                    }
                    return _0x4c8de9['prototype'][_0x20141b('0x292')] = function () {
                        var _0x10934f = _0x20141b;
                        _0x256af2[_0x10934f('0x64a')]['createChildren']['call'](this),
                            this[_0x10934f('0x39e')](_0x4c8de9['uiView']);
                    }
                        ,
                        _0x4c8de9['uiView'] = {
                            'type': _0x20141b('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x20141b('0x77'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x20141b('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': _0x20141b('0x2e3'),
                                    'right': 0x0,
                                    'name': 'imgBG',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5
                            }, {
                                'type': _0x20141b('0x6ae'),
                                'props': {
                                    'top': 0x0,
                                    'right': 0x0,
                                    'left': 0x0
                                },
                                'compId': 0xd,
                                'child': [{
                                    'type': _0x20141b('0x55c'),
                                    'props': {
                                        'y': 0x110,
                                        'x': 0x86,
                                        'width': 0x1e2,
                                        'skin': _0x20141b('0x226'),
                                        'name': _0x20141b('0x2a5'),
                                        'height': 0x146
                                    },
                                    'compId': 0x6
                                }, {
                                    'type': _0x20141b('0x13b'),
                                    'props': {
                                        'y': 0x36b,
                                        'x': 0x94,
                                        'width': 0x1d4,
                                        'var': _0x20141b('0x85'),
                                        'value': 0x0,
                                        'skin': _0x20141b('0x5c5'),
                                        'sizeGrid': '0,31,0,31',
                                        'height': 0x4b
                                    },
                                    'compId': 0xc
                                }]
                            }],
                            'loadList': ['loading/LoadingBg.jpg', 'loading/Logo.png', _0x20141b('0x5c5')],
                            'loadList3D': []
                        },
                        _0x4c8de9;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x622')] = _0x2f9ad1,
                    _0x43b9b1(_0xc67ffd('0x5b1'), _0x2f9ad1);
                var _0x4c30d4 = function (_0x405cf5) {
                    var _0x4c11f1 = _0xc67ffd;
                    __extends(_0x2d26bd, _0x405cf5);
                    function _0x2d26bd() {
                        var _0x57dc76 = _0x5985;
                        return _0x405cf5[_0x57dc76('0x324')](this) || this;
                    }
                    return _0x2d26bd[_0x4c11f1('0x64a')]['createChildren'] = function () {
                        var _0x2c4b0c = _0x4c11f1;
                        _0x405cf5[_0x2c4b0c('0x64a')]['createChildren'][_0x2c4b0c('0x324')](this),
                            this['createView'](_0x2d26bd[_0x2c4b0c('0x31e')]);
                    }
                        ,
                        _0x2d26bd['uiView'] = {
                            'type': _0x4c11f1('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x4c11f1('0x252'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x4c11f1('0x4a0'),
                                'props': {
                                    'y': 0x29b,
                                    'x': 0x177,
                                    'var': _0x4c11f1('0x68a'),
                                    'texture': _0x4c11f1('0x3e2'),
                                    'rotation': 0x0,
                                    'pivotY': 0x40,
                                    'pivotX': 0x40
                                },
                                'compId': 0x4
                            }],
                            'loadList': [_0x4c11f1('0x3e2')],
                            'loadList3D': []
                        },
                        _0x2d26bd;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0xc')] = _0x4c30d4,
                    _0x43b9b1(_0xc67ffd('0x3fc'), _0x4c30d4);
                var _0xc3a84 = function (_0x276b18) {
                    var _0x339bf2 = _0xc67ffd;
                    __extends(_0x4a76c1, _0x276b18);
                    function _0x4a76c1() {
                        var _0x51c115 = _0x5985;
                        return _0x276b18[_0x51c115('0x324')](this) || this;
                    }
                    return _0x4a76c1[_0x339bf2('0x64a')][_0x339bf2('0x292')] = function () {
                        var _0x367b07 = _0x339bf2;
                        _0x276b18[_0x367b07('0x64a')][_0x367b07('0x292')][_0x367b07('0x324')](this),
                            this[_0x367b07('0x39e')](_0x4a76c1[_0x367b07('0x31e')]);
                    }
                        ,
                        _0x4a76c1[_0x339bf2('0x31e')] = {
                            'type': _0x339bf2('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x339bf2('0x10e'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': 'Image',
                                'props': {
                                    'top': 0x0,
                                    'skin': _0x339bf2('0x14e'),
                                    'right': 0x0,
                                    'name': 'bg',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x3c,
                                        'x': 0x113,
                                        'width': 0xe7,
                                        'skin': 'game/iocn_diamondBG.png',
                                        'sizeGrid': _0x339bf2('0x582'),
                                        'name': _0x339bf2('0x108'),
                                        'height': 0x2c
                                    },
                                    'compId': 0x6,
                                    'child': [{
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': -0x5,
                                            'x': -0x18,
                                            'width': 0x3a,
                                            'skin': _0x339bf2('0x20d'),
                                            'name': _0x339bf2('0x605'),
                                            'height': 0x3b
                                        },
                                        'compId': 0x7
                                    }, {
                                        'type': _0x339bf2('0x141'),
                                        'props': {
                                            'y': 0x0,
                                            'x': 0x2b,
                                            'width': 0xae,
                                            'var': _0x339bf2('0x1ae'),
                                            'valign': _0x339bf2('0x10d'),
                                            'text': _0x339bf2('0x362'),
                                            'height': 0x1d,
                                            'fontSize': 0x28,
                                            'font': 'Microsoft\x20YaHei',
                                            'color': '#f9f8f8',
                                            'bold': !![],
                                            'align': _0x339bf2('0x59f'),
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0x8
                                    }]
                                }, {
                                    'type': _0x339bf2('0x654'),
                                    'props': {
                                        'y': 0x216,
                                        'x': 0x177,
                                        'source': _0x339bf2('0x30b'),
                                        'autoPlay': !![]
                                    },
                                    'compId': 0x25
                                }, {
                                    'type': _0x339bf2('0x55c'),
                                    'props': {
                                        'y': 0x217,
                                        'x': 0x177,
                                        'width': 0x1fb,
                                        'var': _0x339bf2('0x1d9'),
                                        'skin': _0x339bf2('0xe5'),
                                        'rotation': 0xc6,
                                        'pivotY': 0xfe,
                                        'pivotX': 0xfe,
                                        'name': _0x339bf2('0x1d9'),
                                        'height': 0x1fb
                                    },
                                    'compId': 0x1e,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x56,
                                            'x': 0xe6,
                                            'width': 0x2f,
                                            'var': _0x339bf2('0x166'),
                                            'skin': _0x339bf2('0x20d'),
                                            'rotation': 0x0,
                                            'name': _0x339bf2('0x166'),
                                            'height': 0x2e
                                        },
                                        'compId': 0x2a,
                                        'child': [{
                                            'type': _0x339bf2('0x141'),
                                            'props': {
                                                'y': -0x26,
                                                'x': 0x4,
                                                'var': _0x339bf2('0x650'),
                                                'text': '66',
                                                'name': _0x339bf2('0x650'),
                                                'fontSize': 0x1e,
                                                'font': _0x339bf2('0xa3'),
                                                'color': '#fbf9f9',
                                                'bold': !![],
                                                'runtime': _0x339bf2('0x63f')
                                            },
                                            'compId': 0x30
                                        }]
                                    }, {
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0x5c,
                                            'x': 0x142,
                                            'width': 0x5a,
                                            'var': _0x339bf2('0x18f'),
                                            'skin': _0x339bf2('0x566'),
                                            'name': 'imgGem2',
                                            'height': 0x5a
                                        },
                                        'compId': 0x27
                                    }, {
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0xe6,
                                            'x': 0x1a5,
                                            'width': 0x2f,
                                            'var': _0x339bf2('0x58b'),
                                            'skin': 'game/icon_diamond.png',
                                            'rotation': 0x5c,
                                            'name': _0x339bf2('0x58b'),
                                            'height': 0x2e
                                        },
                                        'compId': 0x2b,
                                        'child': [{
                                            'type': _0x339bf2('0x141'),
                                            'props': {
                                                'y': -0x2b,
                                                'x': -0x5,
                                                'var': 'txtGem3',
                                                'text': _0x339bf2('0x471'),
                                                'name': _0x339bf2('0x27'),
                                                'fontSize': 0x1e,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x339bf2('0x325'),
                                                'bold': !![],
                                                'runtime': _0x339bf2('0x63f')
                                            },
                                            'compId': 0x31
                                        }]
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x15d,
                                            'x': 0x182,
                                            'width': 0x2f,
                                            'var': _0x339bf2('0x317'),
                                            'skin': 'game/icon_diamond.png',
                                            'rotation': 0x89,
                                            'name': _0x339bf2('0x317'),
                                            'height': 0x2e
                                        },
                                        'compId': 0x2c,
                                        'child': [{
                                            'type': 'Text',
                                            'props': {
                                                'y': -0x2b,
                                                'x': -0x5,
                                                'var': 'txtGem4',
                                                'text': _0x339bf2('0x471'),
                                                'name': _0x339bf2('0x23e'),
                                                'fontSize': 0x1e,
                                                'font': _0x339bf2('0xa3'),
                                                'color': _0x339bf2('0x325'),
                                                'bold': !![],
                                                'runtime': _0x339bf2('0x63f')
                                            },
                                            'compId': 0x32
                                        }]
                                    }, {
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0x199,
                                            'x': 0x113,
                                            'width': 0x2f,
                                            'var': _0x339bf2('0x51c'),
                                            'skin': 'game/icon_diamond.png',
                                            'rotation': 0xb5,
                                            'name': 'imgGem5',
                                            'height': 0x2e
                                        },
                                        'compId': 0x2d,
                                        'child': [{
                                            'type': _0x339bf2('0x141'),
                                            'props': {
                                                'y': -0x2b,
                                                'x': -0x5,
                                                'var': _0x339bf2('0xf7'),
                                                'text': _0x339bf2('0x471'),
                                                'name': 'txtGem5',
                                                'fontSize': 0x1e,
                                                'font': _0x339bf2('0xa3'),
                                                'color': _0x339bf2('0x325'),
                                                'bold': !![],
                                                'runtime': _0x339bf2('0x63f')
                                            },
                                            'compId': 0x33
                                        }]
                                    }, {
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0x13d,
                                            'x': 0x5c,
                                            'width': 0x60,
                                            'var': _0x339bf2('0x36e'),
                                            'skin': _0x339bf2('0xfa'),
                                            'name': 'imgGem6',
                                            'height': 0x5f
                                        },
                                        'compId': 0x26
                                    }, {
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0x114,
                                            'x': 0x5b,
                                            'width': 0x2f,
                                            'var': _0x339bf2('0x359'),
                                            'skin': _0x339bf2('0x20d'),
                                            'rotation': -0x5b,
                                            'name': _0x339bf2('0x359'),
                                            'height': 0x2e
                                        },
                                        'compId': 0x28,
                                        'child': [{
                                            'type': _0x339bf2('0x141'),
                                            'props': {
                                                'y': -0x2b,
                                                'x': -5.25146484375,
                                                'var': _0x339bf2('0x57'),
                                                'text': _0x339bf2('0x471'),
                                                'name': _0x339bf2('0x57'),
                                                'fontSize': 0x1e,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x339bf2('0x325'),
                                                'bold': !![],
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x2e
                                        }]
                                    }, {
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0x99,
                                            'x': 0x77,
                                            'width': 0x2f,
                                            'var': _0x339bf2('0x601'),
                                            'skin': _0x339bf2('0x20d'),
                                            'rotation': -0x2e,
                                            'name': _0x339bf2('0x601'),
                                            'height': 0x2e
                                        },
                                        'compId': 0x29,
                                        'child': [{
                                            'type': 'Text',
                                            'props': {
                                                'y': -0x2c,
                                                'x': 0x0,
                                                'var': 'txtGem8',
                                                'text': '88',
                                                'name': _0x339bf2('0x64e'),
                                                'fontSize': 0x1e,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x339bf2('0x325'),
                                                'bold': !![],
                                                'runtime': _0x339bf2('0x63f')
                                            },
                                            'compId': 0x2f
                                        }]
                                    }]
                                }, {
                                    'type': _0x339bf2('0x55c'),
                                    'props': {
                                        'y': 0x1a1,
                                        'x': 0x152,
                                        'width': 0x49,
                                        'skin': _0x339bf2('0x3f3'),
                                        'name': 'arrow',
                                        'height': 0xea
                                    },
                                    'compId': 0x24
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x377,
                                        'x': 0xdd,
                                        'width': 0x134,
                                        'var': _0x339bf2('0xe8'),
                                        'skin': _0x339bf2('0x329'),
                                        'name': _0x339bf2('0xe8'),
                                        'height': 0x70
                                    },
                                    'compId': 0x1f,
                                    'child': [{
                                        'type': _0x339bf2('0x55c'),
                                        'props': {
                                            'y': 0x1f,
                                            'x': 0x26,
                                            'width': 0x3b,
                                            'skin': _0x339bf2('0x3b4'),
                                            'height': 0x32
                                        },
                                        'compId': 0x20
                                    }, {
                                        'type': _0x339bf2('0x141'),
                                        'props': {
                                            'y': 0xd,
                                            'x': 0x61,
                                            'wordWrap': !![],
                                            'width': 0xc7,
                                            'var': 'freeTxt',
                                            'valign': _0x339bf2('0x46b'),
                                            'text': _0x339bf2('0x673'),
                                            'height': 0x53,
                                            'fontSize': 0x1e,
                                            'font': _0x339bf2('0xa3'),
                                            'color': _0x339bf2('0x207'),
                                            'bold': !![],
                                            'align': 'center',
                                            'runtime': _0x339bf2('0x63f')
                                        },
                                        'compId': 0x3b
                                    }]
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x377,
                                        'x': 228.5,
                                        'width': 0x125,
                                        'var': _0x339bf2('0x3b9'),
                                        'skin': 'game/btn_green.png',
                                        'name': _0x339bf2('0x3b9'),
                                        'height': 0x70
                                    },
                                    'compId': 0x22,
                                    'child': [{
                                        'type': _0x339bf2('0x141'),
                                        'props': {
                                            'y': 0xd,
                                            'x': 0x8,
                                            'width': 0x112,
                                            'var': _0x339bf2('0x4de'),
                                            'valign': _0x339bf2('0x46b'),
                                            'text': '游戏',
                                            'height': 0x57,
                                            'fontSize': 0x28,
                                            'font': _0x339bf2('0xa3'),
                                            'color': _0x339bf2('0x207'),
                                            'bold': !![],
                                            'align': _0x339bf2('0x59f'),
                                            'runtime': _0x339bf2('0x63f')
                                        },
                                        'compId': 0x3c
                                    }]
                                }, {
                                    'type': _0x339bf2('0x141'),
                                    'props': {
                                        'y': 0x3f6,
                                        'x': 0x111,
                                        'width': 0xcb,
                                        'var': _0x339bf2('0xe1'),
                                        'valign': _0x339bf2('0x46b'),
                                        'text': _0x339bf2('0x1b3'),
                                        'height': 0x38,
                                        'fontSize': 0x28,
                                        'font': _0x339bf2('0xa3'),
                                        'color': _0x339bf2('0xc5'),
                                        'bold': !![],
                                        'align': _0x339bf2('0x59f'),
                                        'runtime': 'laya.display.Text'
                                    },
                                    'compId': 0x3a
                                }]
                            }],
                            'animations': [{
                                'nodes': [{
                                    'target': 0x25,
                                    'keyframes': {
                                        'autoPlay': [{
                                            'value': !![],
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': ![],
                                            'target': 0x25,
                                            'key': _0x339bf2('0x364'),
                                            'index': 0x0
                                        }]
                                    }
                                }, {
                                    'target': 0x1e,
                                    'keyframes': {
                                        'y': [{
                                            'value': 0x217,
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': !![],
                                            'target': 0x1e,
                                            'key': 'y',
                                            'index': 0x0
                                        }],
                                        'x': [{
                                            'value': 0x177,
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': !![],
                                            'target': 0x1e,
                                            'key': 'x',
                                            'index': 0x0
                                        }],
                                        'var': [{
                                            'value': _0x339bf2('0x1d9'),
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': ![],
                                            'target': 0x1e,
                                            'key': _0x339bf2('0x499'),
                                            'index': 0x0
                                        }],
                                        'rotation': [{
                                            'value': 0x0,
                                            'tweenMethod': 'linearNone',
                                            'tween': !![],
                                            'target': 0x1e,
                                            'key': 'rotation',
                                            'index': 0x0
                                        }],
                                        'pivotY': [{
                                            'value': 0xfe,
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': !![],
                                            'target': 0x1e,
                                            'key': 'pivotY',
                                            'index': 0x0
                                        }],
                                        'pivotX': [{
                                            'value': 0xfe,
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': !![],
                                            'target': 0x1e,
                                            'key': _0x339bf2('0x530'),
                                            'index': 0x0
                                        }],
                                        'name': [{
                                            'value': _0x339bf2('0x1d9'),
                                            'tweenMethod': _0x339bf2('0x609'),
                                            'tween': ![],
                                            'target': 0x1e,
                                            'key': _0x339bf2('0x8c'),
                                            'index': 0x0
                                        }]
                                    }
                                }, {
                                    'target': 0x1f,
                                    'keyframes': {
                                        'var': [{
                                            'value': 'btnVideo',
                                            'tweenMethod': 'linearNone',
                                            'tween': ![],
                                            'target': 0x1f,
                                            'key': _0x339bf2('0x499'),
                                            'index': 0x0
                                        }]
                                    }
                                }],
                                'name': _0x339bf2('0x2b8'),
                                'id': 0x1,
                                'frameRate': 0x18,
                                'action': 0x0
                            }],
                            'loadList': [_0x339bf2('0x14e'), _0x339bf2('0xde'), 'game/icon_diamond.png', _0x339bf2('0x30b'), 'luckyBox/LuckPan_2.png', _0x339bf2('0x566'), 'skin/Hoop_Duck_icon.png', 'luckyBox/LuckPan_1.png', _0x339bf2('0x329'), _0x339bf2('0x3b4'), _0x339bf2('0x4c4')],
                            'loadList3D': []
                        },
                        _0x4a76c1;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf['LucktBoxUIUI'] = _0xc3a84,
                    _0x43b9b1('ui.view.LucktBoxUIUI', _0xc3a84);
                var _0x233fb7 = function (_0x5b6269) {
                    var _0x571781 = _0xc67ffd;
                    __extends(_0x290458, _0x5b6269);
                    function _0x290458() {
                        var _0xa0d23e = _0x5985;
                        return _0x5b6269[_0xa0d23e('0x324')](this) || this;
                    }
                    return _0x290458['prototype'][_0x571781('0x292')] = function () {
                        var _0x3d94af = _0x571781;
                        _0x5b6269[_0x3d94af('0x64a')][_0x3d94af('0x292')][_0x3d94af('0x324')](this),
                            this[_0x3d94af('0x39e')](_0x290458[_0x3d94af('0x31e')]);
                    }
                        ,
                        _0x290458[_0x571781('0x31e')] = {
                            'type': 'BaseView',
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x571781('0x510'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x571781('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': 'box/BG_Black.png',
                                    'sizeGrid': _0x571781('0x39a'),
                                    'right': 0x0,
                                    'name': 'bg',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x3,
                                'child': [{
                                    'type': _0x571781('0x55c'),
                                    'props': {
                                        'y': 0x153,
                                        'x': 0x65,
                                        'width': 0x224,
                                        'skin': _0x571781('0x4c1'),
                                        'sizeGrid': '128,38,37,28',
                                        'height': 0x290
                                    },
                                    'compId': 0x17
                                }, {
                                    'type': _0x571781('0x4a0'),
                                    'props': {
                                        'y': 0x163,
                                        'x': 0x240,
                                        'var': _0x571781('0x349'),
                                        'texture': _0x571781('0x3c9')
                                    },
                                    'compId': 0x18
                                }, {
                                    'type': _0x571781('0x4a0'),
                                    'props': {
                                        'y': 0x16d,
                                        'x': 0xfa,
                                        'texture': _0x571781('0x509')
                                    },
                                    'compId': 0x19
                                }, {
                                    'type': _0x571781('0x55c'),
                                    'props': {
                                        'y': 0x1e3,
                                        'x': 0x87,
                                        'width': 0x1df,
                                        'skin': _0x571781('0x59e'),
                                        'sizeGrid': _0x571781('0x6b0'),
                                        'height': 0x1df
                                    },
                                    'compId': 0x1a
                                }, {
                                    'type': _0x571781('0x6ae'),
                                    'props': {
                                        'y': 0x1eb,
                                        'x': 0x9a,
                                        'var': _0x571781('0x320')
                                    },
                                    'compId': 0x1b
                                }]
                            }],
                            'loadList': [_0x571781('0x3c8'), _0x571781('0x4c1'), _0x571781('0x3c9'), _0x571781('0x509'), _0x571781('0x59e')],
                            'loadList3D': []
                        },
                        _0x290458;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x5cd')] = _0x233fb7,
                    _0x43b9b1(_0xc67ffd('0x633'), _0x233fb7);
                var _0x262ef2 = function (_0x4722b0) {
                    var _0xf123eb = _0xc67ffd;
                    __extends(_0x51d048, _0x4722b0);
                    function _0x51d048() {
                        var _0x2d54b3 = _0x5985;
                        return _0x4722b0[_0x2d54b3('0x324')](this) || this;
                    }
                    return _0x51d048['prototype'][_0xf123eb('0x292')] = function () {
                        var _0x5cdf4e = _0xf123eb;
                        _0x4722b0[_0x5cdf4e('0x64a')]['createChildren'][_0x5cdf4e('0x324')](this),
                            this[_0x5cdf4e('0x39e')](_0x51d048[_0x5cdf4e('0x31e')]);
                    }
                        ,
                        _0x51d048[_0xf123eb('0x31e')] = {
                            'type': 'BaseView',
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': 'script/view/OpenBoxUI.ts',
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': 'Image',
                                'props': {
                                    'top': 0x0,
                                    'skin': 'box/BG_Black.png',
                                    'sizeGrid': _0xf123eb('0x14f'),
                                    'right': 0x0,
                                    'name': _0xf123eb('0x2b6'),
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': _0xf123eb('0x55c'),
                                    'props': {
                                        'y': 0x245,
                                        'x': 0x177,
                                        'width': 0x26e,
                                        'var': 'light',
                                        'skin': _0xf123eb('0x5cb'),
                                        'pivotY': 0x136,
                                        'pivotX': 0x137,
                                        'height': 0x26b
                                    },
                                    'compId': 0x6
                                }, {
                                    'type': _0xf123eb('0x55c'),
                                    'props': {
                                        'y': 406.5,
                                        'x': 199.5,
                                        'width': 0x15f,
                                        'var': _0xf123eb('0x31'),
                                        'skin': 'box/chest01.png',
                                        'height': 0x15a
                                    },
                                    'compId': 0x8
                                }, {
                                    'type': _0xf123eb('0x55c'),
                                    'props': {
                                        'y': 0x30c,
                                        'x': 0x129,
                                        'var': _0xf123eb('0x108'),
                                        'skin': _0xf123eb('0x20d')
                                    },
                                    'compId': 0x11,
                                    'child': [{
                                        'type': _0xf123eb('0x141'),
                                        'props': {
                                            'y': 0xc,
                                            'x': 0x58,
                                            'width': 0x65,
                                            'var': _0xf123eb('0xf'),
                                            'text': _0xf123eb('0x1cb'),
                                            'height': 0x23,
                                            'fontSize': 0x28,
                                            'font': _0xf123eb('0xa3'),
                                            'color': '#fffdfd',
                                            'bold': !![],
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0x12
                                    }]
                                }, {
                                    'type': _0xf123eb('0x55c'),
                                    'props': {
                                        'y': 0x363,
                                        'x': 230.5,
                                        'width': 0x134,
                                        'var': _0xf123eb('0x3a5'),
                                        'skin': _0xf123eb('0x2c'),
                                        'height': 0x70
                                    },
                                    'compId': 0xa,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x1f,
                                            'x': 0x24,
                                            'width': 0x3b,
                                            'skin': 'box/rewarded_video.png',
                                            'name': _0xf123eb('0x37d'),
                                            'height': 0x32
                                        },
                                        'compId': 0xb
                                    }, {
                                        'type': _0xf123eb('0x55c'),
                                        'props': {
                                            'y': 0x24,
                                            'x': 0x76,
                                            'width': 0x98,
                                            'skin': _0xf123eb('0x403'),
                                            'name': 'text',
                                            'height': 0x28
                                        },
                                        'compId': 0xc
                                    }]
                                }, {
                                    'type': _0xf123eb('0x55c'),
                                    'props': {
                                        'y': 0x2d7,
                                        'x': 0x1ad,
                                        'width': 0x125,
                                        'var': 'receivebtn',
                                        'skin': _0xf123eb('0x4c4'),
                                        'height': 0x70
                                    },
                                    'compId': 0xf,
                                    'child': [{
                                        'type': _0xf123eb('0x55c'),
                                        'props': {
                                            'y': 0x21,
                                            'x': 99.5,
                                            'width': 0x5e,
                                            'skin': _0xf123eb('0x43'),
                                            'name': _0xf123eb('0x338'),
                                            'height': 0x2e
                                        },
                                        'compId': 0x10
                                    }]
                                }, {
                                    'type': _0xf123eb('0x141'),
                                    'props': {
                                        'y': 0x3fb,
                                        'x': 0x117,
                                        'width': 0xcb,
                                        'var': _0xf123eb('0x420'),
                                        'valign': 'middle',
                                        'text': '领取',
                                        'height': 0x28,
                                        'fontSize': 0x21,
                                        'font': _0xf123eb('0xa3'),
                                        'color': _0xf123eb('0xc5'),
                                        'bold': !![],
                                        'align': _0xf123eb('0x59f'),
                                        'runtime': _0xf123eb('0x63f')
                                    },
                                    'compId': 0x13
                                }]
                            }],
                            'loadList': [_0xf123eb('0x3c8'), 'box/chesLight.png', _0xf123eb('0x4bd'), _0xf123eb('0x20d'), _0xf123eb('0x2c'), _0xf123eb('0x3b4'), _0xf123eb('0x403'), _0xf123eb('0x4c4'), _0xf123eb('0x43')],
                            'loadList3D': []
                        },
                        _0x51d048;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x120')] = _0x262ef2,
                    _0x43b9b1(_0xc67ffd('0x658'), _0x262ef2);
                var _0x335a38 = function (_0x3c4813) {
                    var _0x35187c = _0xc67ffd;
                    __extends(_0x6c1812, _0x3c4813);
                    function _0x6c1812() {
                        var _0x487b1d = _0x5985;
                        return _0x3c4813[_0x487b1d('0x324')](this) || this;
                    }
                    return _0x6c1812[_0x35187c('0x64a')][_0x35187c('0x292')] = function () {
                        var _0x13d784 = _0x35187c;
                        _0x3c4813[_0x13d784('0x64a')][_0x13d784('0x292')][_0x13d784('0x324')](this),
                            this['createView'](_0x6c1812[_0x13d784('0x31e')]);
                    }
                        ,
                        _0x6c1812[_0x35187c('0x31e')] = {
                            'type': _0x35187c('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x35187c('0x2f3'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': 'Image',
                                'props': {
                                    'top': 0x0,
                                    'skin': _0x35187c('0x14e'),
                                    'right': 0x0,
                                    'name': 'bg',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': _0x35187c('0x55c'),
                                    'props': {
                                        'y': 0x2c,
                                        'x': 0x113,
                                        'width': 0xe7,
                                        'skin': _0x35187c('0xde'),
                                        'sizeGrid': _0x35187c('0x582'),
                                        'name': _0x35187c('0x108'),
                                        'height': 0x2c
                                    },
                                    'compId': 0x6,
                                    'child': [{
                                        'type': _0x35187c('0x55c'),
                                        'props': {
                                            'y': -0x5,
                                            'x': -0x18,
                                            'width': 0x3a,
                                            'skin': 'game/icon_diamond.png',
                                            'name': _0x35187c('0x605'),
                                            'height': 0x3b
                                        },
                                        'compId': 0x7
                                    }, {
                                        'type': 'Text',
                                        'props': {
                                            'y': 0x0,
                                            'x': 0x22,
                                            'width': 0xae,
                                            'var': _0x35187c('0xf'),
                                            'valign': _0x35187c('0x10d'),
                                            'text': _0x35187c('0x362'),
                                            'height': 0x1d,
                                            'fontSize': 0x28,
                                            'font': 'Microsoft\x20YaHei',
                                            'color': _0x35187c('0x36f'),
                                            'bold': !![],
                                            'align': _0x35187c('0x59f'),
                                            'runtime': _0x35187c('0x63f')
                                        },
                                        'compId': 0x8
                                    }]
                                }, {
                                    'type': _0x35187c('0x55c'),
                                    'props': {
                                        'y': 0x72,
                                        'x': 0x61,
                                        'width': 0x22d,
                                        'skin': _0x35187c('0x9c'),
                                        'name': 'title',
                                        'height': 0x66
                                    },
                                    'compId': 0x9
                                }, {
                                    'type': _0x35187c('0x55c'),
                                    'props': {
                                        'y': 0xb6,
                                        'x': 0x19f,
                                        'width': 0x9a,
                                        'var': 'bestReward',
                                        'skin': _0x35187c('0x27f'),
                                        'height': 0x99
                                    },
                                    'compId': 0xb,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0xe,
                                            'x': 14.5,
                                            'width': 0x7d,
                                            'var': _0x35187c('0x2cd'),
                                            'skin': _0x35187c('0x572'),
                                            'height': 0x7d
                                        },
                                        'compId': 0xc
                                    }]
                                }, {
                                    'type': 'Box',
                                    'props': {
                                        'y': 0x130,
                                        'x': 0x55,
                                        'width': 0xa6,
                                        'var': 'rewardObj',
                                        'styleSkin': _0x35187c('0x5a1'),
                                        'height': 0xa8
                                    },
                                    'compId': 0xd
                                }, {
                                    'type': _0x35187c('0x6ae'),
                                    'props': {
                                        'y': 892.5,
                                        'x': 0xc4,
                                        'var': _0x35187c('0x25f')
                                    },
                                    'compId': 0x1e,
                                    'child': [{
                                        'type': _0x35187c('0x55c'),
                                        'props': {
                                            'width': 0x3d,
                                            'var': _0x35187c('0x59'),
                                            'skin': _0x35187c('0x1cf'),
                                            'height': 0x6b
                                        },
                                        'compId': 0x14
                                    }, {
                                        'type': _0x35187c('0x55c'),
                                        'props': {
                                            'x': 0x85,
                                            'width': 0x3d,
                                            'var': _0x35187c('0x395'),
                                            'skin': _0x35187c('0x1cf'),
                                            'height': 0x6b
                                        },
                                        'compId': 0x16
                                    }, {
                                        'type': _0x35187c('0x55c'),
                                        'props': {
                                            'x': 0x109,
                                            'width': 0x3d,
                                            'var': 'key3',
                                            'skin': _0x35187c('0x1cf'),
                                            'height': 0x6b
                                        },
                                        'compId': 0x18
                                    }]
                                }, {
                                    'type': _0x35187c('0x55c'),
                                    'props': {
                                        'y': 0x37a,
                                        'x': 205.5,
                                        'width': 0x134,
                                        'visible': ![],
                                        'var': _0x35187c('0x6aa'),
                                        'skin': _0x35187c('0x2c'),
                                        'height': 0x70
                                    },
                                    'compId': 0x1a,
                                    'child': [{
                                        'type': _0x35187c('0x55c'),
                                        'props': {
                                            'y': 0x1f,
                                            'x': 0x29,
                                            'width': 0x3b,
                                            'visible': !![],
                                            'skin': _0x35187c('0x14a'),
                                            'height': 0x32
                                        },
                                        'compId': 0x1b
                                    }, {
                                        'type': _0x35187c('0x141'),
                                        'props': {
                                            'y': 0x2d,
                                            'x': 0x67,
                                            'width': 0xc1,
                                            'var': _0x35187c('0x191'),
                                            'valign': 'middle',
                                            'text': _0x35187c('0x4e0'),
                                            'height': 0x16,
                                            'fontSize': 0x19,
                                            'font': _0x35187c('0xa3'),
                                            'color': '#ffffff',
                                            'bold': !![],
                                            'align': 'center',
                                            'runtime': _0x35187c('0x63f')
                                        },
                                        'compId': 0x24
                                    }]
                                }, {
                                    'type': _0x35187c('0x141'),
                                    'props': {
                                        'y': 0x88,
                                        'x': 0x7a,
                                        'width': 0x1fa,
                                        'var': _0x35187c('0x58d'),
                                        'valign': 'middle',
                                        'text': '签到',
                                        'strokeColor': _0x35187c('0x2b2'),
                                        'stroke': 0x3,
                                        'height': 0x3c,
                                        'fontSize': 0x32,
                                        'font': _0x35187c('0xa3'),
                                        'color': _0x35187c('0x207'),
                                        'bold': !![],
                                        'align': 'center',
                                        'runtime': _0x35187c('0x63f')
                                    },
                                    'compId': 0x20
                                }, {
                                    'type': _0x35187c('0x141'),
                                    'props': {
                                        'y': 0xe8,
                                        'x': 0x4,
                                        'width': 0x193,
                                        'var': _0x35187c('0xe6'),
                                        'text': '签到',
                                        'height': 0x48,
                                        'fontSize': 0x23,
                                        'font': 'Microsoft\x20YaHei',
                                        'color': '#fbeb78',
                                        'bold': !![],
                                        'align': _0x35187c('0x59f'),
                                        'runtime': _0x35187c('0x63f')
                                    },
                                    'compId': 0x23
                                }, {
                                    'type': _0x35187c('0x141'),
                                    'props': {
                                        'y': 0x3fc,
                                        'x': 0x113,
                                        'width': 0xcb,
                                        'var': _0x35187c('0x3f8'),
                                        'valign': _0x35187c('0x46b'),
                                        'text': '领取',
                                        'height': 0x37,
                                        'fontSize': 0x28,
                                        'font': 'Microsoft\x20YaHei',
                                        'color': _0x35187c('0xc5'),
                                        'bold': !![],
                                        'align': _0x35187c('0x59f'),
                                        'runtime': _0x35187c('0x63f')
                                    },
                                    'compId': 0x25
                                }]
                            }],
                            'loadList': [_0x35187c('0x14e'), 'game/iocn_diamondBG.png', 'game/icon_diamond.png', _0x35187c('0x9c'), _0x35187c('0x27f'), _0x35187c('0x572'), _0x35187c('0x5a1'), _0x35187c('0x1cf'), _0x35187c('0x2c'), _0x35187c('0x14a')],
                            'loadList3D': []
                        },
                        _0x6c1812;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x4b3')] = _0x335a38,
                    _0x43b9b1(_0xc67ffd('0x44'), _0x335a38);
                var _0x179b9b = function (_0x19a257) {
                    var _0x4a7822 = _0xc67ffd;
                    __extends(_0x178e2a, _0x19a257);
                    function _0x178e2a() {
                        return _0x19a257['call'](this) || this;
                    }
                    return _0x178e2a[_0x4a7822('0x64a')][_0x4a7822('0x292')] = function () {
                        var _0x235a55 = _0x4a7822;
                        _0x19a257[_0x235a55('0x64a')][_0x235a55('0x292')]['call'](this),
                            this[_0x235a55('0x39e')](_0x178e2a[_0x235a55('0x31e')]);
                    }
                        ,
                        _0x178e2a[_0x4a7822('0x31e')] = {
                            'type': _0x4a7822('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x4a7822('0x3f4'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x4a7822('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': 'box/BG_Black.png',
                                    'sizeGrid': _0x4a7822('0x14f'),
                                    'right': 0x0,
                                    'name': _0x4a7822('0x2b6'),
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x5,
                                'child': [{
                                    'type': _0x4a7822('0x55c'),
                                    'props': {
                                        'y': 0x245,
                                        'x': 0x177,
                                        'width': 0x26e,
                                        'var': _0x4a7822('0x62c'),
                                        'skin': _0x4a7822('0x5cb'),
                                        'pivotY': 0x136,
                                        'pivotX': 0x137,
                                        'height': 0x26b
                                    },
                                    'compId': 0x6
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x18d,
                                        'x': 199.5,
                                        'width': 0x15f,
                                        'var': _0x4a7822('0x31'),
                                        'skin': _0x4a7822('0x4bd'),
                                        'height': 0x15a
                                    },
                                    'compId': 0xf
                                }, {
                                    'type': _0x4a7822('0x55c'),
                                    'props': {
                                        'y': 0x363,
                                        'x': 230.5,
                                        'width': 0x134,
                                        'var': _0x4a7822('0x3a5'),
                                        'skin': _0x4a7822('0x2c'),
                                        'height': 0x70
                                    },
                                    'compId': 0xa,
                                    'child': [{
                                        'type': _0x4a7822('0x55c'),
                                        'props': {
                                            'y': 0x1f,
                                            'x': 0x2b,
                                            'width': 0x3b,
                                            'skin': _0x4a7822('0x3b4'),
                                            'name': _0x4a7822('0x37d'),
                                            'height': 0x32
                                        },
                                        'compId': 0xb
                                    }, {
                                        'type': _0x4a7822('0x141'),
                                        'props': {
                                            'y': 0x28,
                                            'x': 0x66,
                                            'width': 0xbd,
                                            'var': 'getTxt',
                                            'text': '签到',
                                            'height': 0x2d,
                                            'fontSize': 0x23,
                                            'font': _0x4a7822('0xa3'),
                                            'color': _0x4a7822('0x554'),
                                            'bold': !![],
                                            'align': _0x4a7822('0x59f'),
                                            'runtime': _0x4a7822('0x63f')
                                        },
                                        'compId': 0x15
                                    }]
                                }, {
                                    'type': _0x4a7822('0x55c'),
                                    'props': {
                                        'y': 0x30c,
                                        'x': 0x129,
                                        'width': 0x3a,
                                        'var': _0x4a7822('0x108'),
                                        'skin': 'game/icon_diamond.png',
                                        'height': 0x3b
                                    },
                                    'compId': 0x10,
                                    'child': [{
                                        'type': 'Text',
                                        'props': {
                                            'y': 0xc,
                                            'x': 0x58,
                                            'width': 0x65,
                                            'var': _0x4a7822('0xf'),
                                            'text': _0x4a7822('0x1cb'),
                                            'height': 0x23,
                                            'fontSize': 0x28,
                                            'font': _0x4a7822('0xa3'),
                                            'color': _0x4a7822('0x207'),
                                            'bold': !![],
                                            'runtime': _0x4a7822('0x63f')
                                        },
                                        'compId': 0x11
                                    }]
                                }, {
                                    'type': _0x4a7822('0x141'),
                                    'props': {
                                        'y': 0x382,
                                        'x': 315.68896484375,
                                        'var': _0x4a7822('0x5cc'),
                                        'valign': _0x4a7822('0x10d'),
                                        'fontSize': 0x32,
                                        'font': _0x4a7822('0xa3'),
                                        'color': _0x4a7822('0x554'),
                                        'bold': !![],
                                        'align': _0x4a7822('0x59f'),
                                        'runtime': _0x4a7822('0x63f')
                                    },
                                    'compId': 0x12
                                }, {
                                    'type': _0x4a7822('0x141'),
                                    'props': {
                                        'y': 0x3d3,
                                        'x': 266.5,
                                        'width': 0xdd,
                                        'var': _0x4a7822('0x420'),
                                        'valign': _0x4a7822('0x46b'),
                                        'text': _0x4a7822('0x1b3'),
                                        'height': 0x67,
                                        'fontSize': 0x28,
                                        'font': _0x4a7822('0xa3'),
                                        'color': _0x4a7822('0xc5'),
                                        'bold': !![],
                                        'align': _0x4a7822('0x59f'),
                                        'runtime': _0x4a7822('0x63f')
                                    },
                                    'compId': 0x14
                                }]
                            }],
                            'loadList': ['box/BG_Black.png', _0x4a7822('0x5cb'), 'box/chest01.png', _0x4a7822('0x2c'), _0x4a7822('0x3b4'), 'game/icon_diamond.png'],
                            'loadList3D': []
                        },
                        _0x178e2a;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x184')] = _0x179b9b,
                    _0x43b9b1(_0xc67ffd('0x1a5'), _0x179b9b);
                var _0x51ae51 = function (_0x10f98a) {
                    var _0x22d8f3 = _0xc67ffd;
                    __extends(_0x550ffb, _0x10f98a);
                    function _0x550ffb() {
                        return _0x10f98a['call'](this) || this;
                    }
                    return _0x550ffb[_0x22d8f3('0x64a')][_0x22d8f3('0x292')] = function () {
                        var _0x1f5336 = _0x22d8f3;
                        _0x10f98a['prototype'][_0x1f5336('0x292')][_0x1f5336('0x324')](this),
                            this['createView'](_0x550ffb[_0x1f5336('0x31e')]);
                    }
                        ,
                        _0x550ffb[_0x22d8f3('0x31e')] = {
                            'type': _0x22d8f3('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x22d8f3('0x229'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x22d8f3('0x55c'),
                                'props': {
                                    'var': _0x22d8f3('0x616'),
                                    'top': 0x0,
                                    'skin': 'level/BG_Black.png',
                                    'sizeGrid': _0x22d8f3('0x4ec'),
                                    'right': 0x0,
                                    'name': 'BG',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x26
                            }, {
                                'type': 'Image',
                                'props': {
                                    'y': 0x3c,
                                    'x': 0x113,
                                    'width': 0xe7,
                                    'var': _0x22d8f3('0x1da'),
                                    'skin': _0x22d8f3('0xde'),
                                    'sizeGrid': _0x22d8f3('0x582'),
                                    'name': _0x22d8f3('0x1da'),
                                    'height': 0x2c
                                },
                                'compId': 0x11,
                                'child': [{
                                    'type': _0x22d8f3('0x55c'),
                                    'props': {
                                        'y': -0x5,
                                        'x': -0x18,
                                        'width': 0x3a,
                                        'skin': _0x22d8f3('0x20d'),
                                        'name': _0x22d8f3('0x605'),
                                        'height': 0x3b
                                    },
                                    'compId': 0x17
                                }, {
                                    'type': _0x22d8f3('0x141'),
                                    'props': {
                                        'y': 0x7,
                                        'x': 0x28,
                                        'width': 0xae,
                                        'var': _0x22d8f3('0x1ae'),
                                        'text': _0x22d8f3('0x362'),
                                        'name': _0x22d8f3('0x1ae'),
                                        'height': 0x1d,
                                        'fontSize': 0x28,
                                        'font': _0x22d8f3('0xa3'),
                                        'color': _0x22d8f3('0x36f'),
                                        'bold': !![],
                                        'runtime': 'laya.display.Text'
                                    },
                                    'compId': 0x18
                                }]
                            }, {
                                'type': 'Text',
                                'props': {
                                    'y': 0x343,
                                    'x': 0x177,
                                    'wordWrap': !![],
                                    'width': 0x2ee,
                                    'var': _0x22d8f3('0x86'),
                                    'valign': 'middle',
                                    'text': 'Double\x20Gem',
                                    'strokeColor': '#be22c5',
                                    'stroke': 0x8,
                                    'pivotY': 0x2a,
                                    'pivotX': 0x177,
                                    'height': 0x54,
                                    'fontSize': 0x32,
                                    'font': _0x22d8f3('0xa3'),
                                    'color': _0x22d8f3('0x554'),
                                    'bold': !![],
                                    'align': _0x22d8f3('0x59f'),
                                    'runtime': 'laya.display.Text'
                                },
                                'compId': 0x43
                            }, {
                                'type': _0x22d8f3('0x55c'),
                                'props': {
                                    'y': 0xd1,
                                    'x': 0x53,
                                    'width': 0x248,
                                    'var': _0x22d8f3('0x42b'),
                                    'skin': 'level/gem_completeTitle.png',
                                    'name': _0x22d8f3('0x42b'),
                                    'height': 0x56
                                },
                                'compId': 0x1b,
                                'child': [{
                                    'type': _0x22d8f3('0x55c'),
                                    'props': {
                                        'y': 0x190,
                                        'x': 0x124,
                                        'width': 0x1a9,
                                        'var': 'imgLight',
                                        'skin': 'level/gem_FX.png',
                                        'rotation': 0x0,
                                        'pivotY': 0xd3,
                                        'pivotX': 0xd5,
                                        'name': 'imgLight',
                                        'height': 0x1a6
                                    },
                                    'compId': 0x1c
                                }, {
                                    'type': _0x22d8f3('0x55c'),
                                    'props': {
                                        'y': 361.5,
                                        'x': 0xb1,
                                        'width': 0x4d,
                                        'var': _0x22d8f3('0x2c7'),
                                        'skin': _0x22d8f3('0x20d'),
                                        'name': _0x22d8f3('0x2c7'),
                                        'height': 0x4d
                                    },
                                    'compId': 0x1d
                                }, {
                                    'type': _0x22d8f3('0x141'),
                                    'props': {
                                        'y': 0x174,
                                        'x': 0xfe,
                                        'width': 0x9d,
                                        'var': _0x22d8f3('0x3d'),
                                        'text': '11',
                                        'name': _0x22d8f3('0x3d'),
                                        'height': 0x39,
                                        'fontSize': 0x3c,
                                        'font': 'Microsoft\x20YaHei',
                                        'color': _0x22d8f3('0x554'),
                                        'bold': !![],
                                        'runtime': _0x22d8f3('0x63f')
                                    },
                                    'compId': 0x1e
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x2e5,
                                        'x': 0x8a,
                                        'width': 0x134,
                                        'var': 'btnVedio',
                                        'skin': _0x22d8f3('0x2c'),
                                        'name': 'btnVedio',
                                        'height': 0x70
                                    },
                                    'compId': 0x1f,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x1f,
                                            'x': 0x29,
                                            'width': 0x3b,
                                            'visible': !![],
                                            'skin': _0x22d8f3('0x14a'),
                                            'height': 0x32
                                        },
                                        'compId': 0x21
                                    }, {
                                        'type': 'Text',
                                        'props': {
                                            'y': 0xb,
                                            'x': 0x65,
                                            'wordWrap': !![],
                                            'width': 0xc3,
                                            'var': _0x22d8f3('0x472'),
                                            'valign': _0x22d8f3('0x46b'),
                                            'text': 'Double\x20Gem',
                                            'height': 0x54,
                                            'fontSize': 0x1c,
                                            'font': _0x22d8f3('0xa3'),
                                            'color': _0x22d8f3('0x554'),
                                            'bold': !![],
                                            'align': 'center',
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0x41
                                    }]
                                }, {
                                    'type': _0x22d8f3('0x55c'),
                                    'props': {
                                        'y': 0x2e5,
                                        'x': -0x2f,
                                        'width': 0x134,
                                        'visible': ![],
                                        'var': _0x22d8f3('0xef'),
                                        'stateNum': 0x1,
                                        'skin': 'game/btn_red.png',
                                        'label': _0x22d8f3('0x55b'),
                                        'height': 0x70
                                    },
                                    'compId': 0x2e,
                                    'child': [{
                                        'type': _0x22d8f3('0x4a0'),
                                        'props': {
                                            'y': 0x1d,
                                            'x': 0x3a,
                                            'texture': 'game/share_icon.png'
                                        },
                                        'compId': 0x2f
                                    }, {
                                        'type': _0x22d8f3('0x4a0'),
                                        'props': {
                                            'y': 0x26,
                                            'x': 0x7a,
                                            'texture': _0x22d8f3('0x367')
                                        },
                                        'compId': 0x30
                                    }]
                                }, {
                                    'type': _0x22d8f3('0x6ae'),
                                    'props': {
                                        'y': 0x7d,
                                        'x': -0x4e,
                                        'visible': ![],
                                        'var': _0x22d8f3('0x54c')
                                    },
                                    'compId': 0x40,
                                    'child': [{
                                        'type': _0x22d8f3('0x55c'),
                                        'props': {
                                            'width': 0xa9,
                                            'skin': _0x22d8f3('0x133'),
                                            'sizeGrid': _0x22d8f3('0x69'),
                                            'height': 0x179
                                        },
                                        'compId': 0x33
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'x': 0x241,
                                            'width': 0xa9,
                                            'skin': _0x22d8f3('0x133'),
                                            'sizeGrid': _0x22d8f3('0x69'),
                                            'height': 0x179
                                        },
                                        'compId': 0x35
                                    }, {
                                        'type': _0x22d8f3('0x4a0'),
                                        'props': {
                                            'y': 0x6,
                                            'x': 0xe,
                                            'texture': _0x22d8f3('0x113')
                                        },
                                        'compId': 0x37
                                    }, {
                                        'type': _0x22d8f3('0x4a0'),
                                        'props': {
                                            'y': 0x8,
                                            'x': 0x251,
                                            'texture': _0x22d8f3('0x113')
                                        },
                                        'compId': 0x38
                                    }]
                                }, {
                                    'type': _0x22d8f3('0x141'),
                                    'props': {
                                        'y': 0x36b,
                                        'x': 193.5,
                                        'width': 0xcb,
                                        'var': 'btnBack',
                                        'valign': _0x22d8f3('0x46b'),
                                        'text': '领取',
                                        'height': 0x38,
                                        'fontSize': 0x28,
                                        'font': 'Microsoft\x20YaHei',
                                        'color': '#898585',
                                        'bold': !![],
                                        'align': _0x22d8f3('0x59f'),
                                        'runtime': _0x22d8f3('0x63f')
                                    },
                                    'compId': 0x42
                                }, {
                                    'type': 'Text',
                                    'props': {
                                        'y': -0x11,
                                        'x': 0x2a,
                                        'width': 0x1f3,
                                        'var': 'resultTxt',
                                        'valign': _0x22d8f3('0x46b'),
                                        'text': _0x22d8f3('0x3c6'),
                                        'strokeColor': _0x22d8f3('0x5f3'),
                                        'stroke': 0x8,
                                        'height': 0x83,
                                        'fontSize': 0x28,
                                        'font': 'Microsoft\x20YaHei',
                                        'color': _0x22d8f3('0x207'),
                                        'bold': !![],
                                        'align': _0x22d8f3('0x59f'),
                                        'runtime': 'laya.display.Text'
                                    },
                                    'compId': 0x44
                                }]
                            }, {
                                'type': _0x22d8f3('0x55c'),
                                'props': {
                                    'y': 0x34,
                                    'x': 0x114,
                                    'var': _0x22d8f3('0x1c2'),
                                    'skin': _0x22d8f3('0x444')
                                },
                                'compId': 0x24,
                                'child': [{
                                    'type': _0x22d8f3('0x141'),
                                    'props': {
                                        'y': -0xd,
                                        'x': 0x14,
                                        'width': 0xbf,
                                        'var': 'txtTimer',
                                        'valign': _0x22d8f3('0x5c3'),
                                        'text': _0x22d8f3('0x42c'),
                                        'height': 0x40,
                                        'fontSize': 0x23,
                                        'font': _0x22d8f3('0xa3'),
                                        'color': '#ffffff',
                                        'bold': !![],
                                        'align': 'center',
                                        'runtime': _0x22d8f3('0x63f')
                                    },
                                    'compId': 0x25
                                }]
                            }, {
                                'type': 'FontClip',
                                'props': {
                                    'y': 0x45,
                                    'x': 0x2a,
                                    'width': 0xa9,
                                    'var': _0x22d8f3('0x60a'),
                                    'skin': _0x22d8f3('0x413'),
                                    'sheet': _0x22d8f3('0x26d'),
                                    'name': 'txtScore',
                                    'height': 0x65,
                                    'align': _0x22d8f3('0x59f')
                                },
                                'compId': 0x28
                            }, {
                                'type': _0x22d8f3('0x141'),
                                'props': {
                                    'y': 0x15b,
                                    'x': 0xb8,
                                    'wordWrap': !![],
                                    'width': 0x17e,
                                    'var': _0x22d8f3('0x2a5'),
                                    'valign': _0x22d8f3('0x46b'),
                                    'text': 'Tantangan\x20batu\x20permata',
                                    'strokeColor': _0x22d8f3('0x554'),
                                    'stroke': 0x3,
                                    'leading': 0x14,
                                    'height': 0x172,
                                    'fontSize': 0x46,
                                    'font': _0x22d8f3('0xa3'),
                                    'color': _0x22d8f3('0x3fd'),
                                    'bold': !![],
                                    'align': 'center',
                                    'runtime': _0x22d8f3('0x63f')
                                },
                                'compId': 0x45
                            }],
                            'loadList': ['level/BG_Black.png', _0x22d8f3('0xde'), 'game/icon_diamond.png', _0x22d8f3('0x213'), 'level/gem_FX.png', _0x22d8f3('0x2c'), _0x22d8f3('0x14a'), _0x22d8f3('0x4f2'), _0x22d8f3('0x56'), _0x22d8f3('0x367'), _0x22d8f3('0x133'), _0x22d8f3('0x113'), _0x22d8f3('0x444'), _0x22d8f3('0x413')],
                            'loadList3D': []
                        },
                        _0x550ffb;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf['PlayGameGemUIUI'] = _0x51ae51,
                    _0x43b9b1(_0xc67ffd('0x502'), _0x51ae51);
                var _0x624da5 = function (_0x581fda) {
                    var _0x2cc12a = _0xc67ffd;
                    __extends(_0x1d6676, _0x581fda);
                    function _0x1d6676() {
                        var _0xd5accc = _0x5985;
                        return _0x581fda[_0xd5accc('0x324')](this) || this;
                    }
                    return _0x1d6676['prototype'][_0x2cc12a('0x292')] = function () {
                        var _0x22bed2 = _0x2cc12a;
                        _0x581fda['prototype'][_0x22bed2('0x292')][_0x22bed2('0x324')](this),
                            this[_0x22bed2('0x39e')](_0x1d6676['uiView']);
                    }
                        ,
                        _0x1d6676['uiView'] = {
                            'type': _0x2cc12a('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': 'script/view/PlayGameUI.ts',
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': 'Box',
                                'props': {
                                    'top': 0x0,
                                    'right': 0x0,
                                    'left': 0x0
                                },
                                'compId': 0x10,
                                'child': [{
                                    'type': _0x2cc12a('0x55c'),
                                    'props': {
                                        'y': 0xf0,
                                        'x': 0x177,
                                        'width': 0x279,
                                        'var': _0x2cc12a('0x544'),
                                        'skin': 'playGame/colorbg.png',
                                        'scaleY': 0x0,
                                        'scaleX': 0x0,
                                        'pivotY': 0x27,
                                        'pivotX': 0x13d,
                                        'height': 0x4e,
                                        'alpha': 0x0
                                    },
                                    'compId': 0x5,
                                    'child': [{
                                        'type': _0x2cc12a('0x55c'),
                                        'props': {
                                            'y': 16.5,
                                            'x': 185.5,
                                            'width': 0x106,
                                            'var': _0x2cc12a('0x682'),
                                            'skin': 'playGame/ColorText_AMAZING.png',
                                            'height': 0x2f
                                        },
                                        'compId': 0x6
                                    }]
                                }, {
                                    'type': _0x2cc12a('0x55c'),
                                    'props': {
                                        'y': 0x2a0,
                                        'x': 0x177,
                                        'width': 0xd5,
                                        'var': 'go',
                                        'skin': _0x2cc12a('0x66e'),
                                        'pivotY': 0x4e,
                                        'pivotX': 0x6b,
                                        'height': 0x9c
                                    },
                                    'compId': 0xe
                                }, {
                                    'type': _0x2cc12a('0x4a0'),
                                    'props': {
                                        'y': 0x43,
                                        'x': 0x114,
                                        'texture': _0x2cc12a('0x444')
                                    },
                                    'compId': 0xf,
                                    'child': [{
                                        'type': _0x2cc12a('0x141'),
                                        'props': {
                                            'y': 0xd,
                                            'x': 0x41,
                                            'width': 0x6b,
                                            'var': 'remainTime',
                                            'valign': _0x2cc12a('0x46b'),
                                            'text': _0x2cc12a('0x4df'),
                                            'height': 0x24,
                                            'fontSize': 0x23,
                                            'font': _0x2cc12a('0xa3'),
                                            'color': _0x2cc12a('0x554'),
                                            'bold': !![],
                                            'align': _0x2cc12a('0x59f'),
                                            'runtime': _0x2cc12a('0x63f')
                                        },
                                        'compId': 0x11
                                    }]
                                }, {
                                    'type': _0x2cc12a('0x55c'),
                                    'props': {
                                        'y': 0x1a8,
                                        'x': 0x130,
                                        'var': _0x2cc12a('0x1ba'),
                                        'skin': _0x2cc12a('0x254'),
                                        'scaleY': 0x0,
                                        'scaleX': 0x0,
                                        'anchorY': 0.5,
                                        'anchorX': 0.5
                                    },
                                    'compId': 0x13
                                }]
                            }, {
                                'type': _0x2cc12a('0x55c'),
                                'props': {
                                    'x': 0x22f,
                                    'width': 0x10c,
                                    'visible': ![],
                                    'var': _0x2cc12a('0x42a'),
                                    'skin': _0x2cc12a('0x212'),
                                    'pivotY': 0x90,
                                    'pivotX': 0x86,
                                    'height': 0x120,
                                    'bottom': 0x50
                                },
                                'compId': 0x15
                            }, {
                                'type': 'Image',
                                'props': {
                                    'x': 0xc5,
                                    'width': 0x10c,
                                    'visible': ![],
                                    'var': _0x2cc12a('0x28e'),
                                    'skin': _0x2cc12a('0x1e'),
                                    'pivotY': 0x90,
                                    'pivotX': 0x86,
                                    'height': 0x120,
                                    'bottom': 0x50
                                },
                                'compId': 0x14
                            }],
                            'loadList': [_0x2cc12a('0x4f3'), _0x2cc12a('0x434'), _0x2cc12a('0x66e'), 'playGame/fightTime_bg.png', _0x2cc12a('0x254'), 'game/guideRight.png', _0x2cc12a('0x1e')],
                            'loadList3D': []
                        },
                        _0x1d6676;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x53')] = _0x624da5,
                    _0x43b9b1('ui.view.PlayGameUIUI', _0x624da5);
                var _0x1f5789 = function (_0x47db4c) {
                    var _0x17b681 = _0xc67ffd;
                    __extends(_0x1af40b, _0x47db4c);
                    function _0x1af40b() {
                        var _0x33765f = _0x5985;
                        return _0x47db4c[_0x33765f('0x324')](this) || this;
                    }
                    return _0x1af40b[_0x17b681('0x64a')]['createChildren'] = function () {
                        var _0x53862b = _0x17b681;
                        _0x47db4c[_0x53862b('0x64a')]['createChildren'][_0x53862b('0x324')](this),
                            this['createView'](_0x1af40b[_0x53862b('0x31e')]);
                    }
                        ,
                        _0x1af40b['uiView'] = {
                            'type': 'BaseView',
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x17b681('0x3c7'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x17b681('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': _0x17b681('0x3c8'),
                                    'sizeGrid': _0x17b681('0x2b'),
                                    'right': 0x0,
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x8,
                                'child': [{
                                    'type': _0x17b681('0x4a0'),
                                    'props': {
                                        'y': 0x25,
                                        'x': 0x24,
                                        'var': 'backbtn',
                                        'texture': _0x17b681('0x1aa')
                                    },
                                    'compId': 0x9
                                }, {
                                    'type': _0x17b681('0x55c'),
                                    'props': {
                                        'y': 0x83,
                                        'x': 0x6d,
                                        'width': 0x214,
                                        'skin': _0x17b681('0x5aa'),
                                        'sizeGrid': _0x17b681('0x332'),
                                        'height': 0x375
                                    },
                                    'compId': 0x7,
                                    'child': [{
                                        'type': 'Sprite',
                                        'props': {
                                            'y': 0x22,
                                            'x': 146.5,
                                            'texture': _0x17b681('0x688')
                                        },
                                        'compId': 0xa
                                    }]
                                }, {
                                    'type': _0x17b681('0x4a0'),
                                    'props': {
                                        'y': 0x3fd,
                                        'x': 0x7f,
                                        'width': 0xe6,
                                        'var': _0x17b681('0x302'),
                                        'texture': _0x17b681('0x55e'),
                                        'height': 0x46
                                    },
                                    'compId': 0xb,
                                    'child': [{
                                        'type': 'Sprite',
                                        'props': {
                                            'y': 0x13,
                                            'x': 0x45,
                                            'texture': _0x17b681('0x693')
                                        },
                                        'compId': 0xd
                                    }]
                                }, {
                                    'type': _0x17b681('0x4a0'),
                                    'props': {
                                        'y': 0x3fd,
                                        'x': 0x191,
                                        'width': 0xe6,
                                        'var': _0x17b681('0x54a'),
                                        'texture': _0x17b681('0x55e'),
                                        'height': 0x46
                                    },
                                    'compId': 0xe,
                                    'child': [{
                                        'type': _0x17b681('0x4a0'),
                                        'props': {
                                            'y': 19.5,
                                            'x': 0x45,
                                            'texture': _0x17b681('0x665')
                                        },
                                        'compId': 0xf
                                    }]
                                }, {
                                    'type': 'VBox',
                                    'props': {
                                        'y': 0x103,
                                        'x': 127.5,
                                        'var': _0x17b681('0x34c'),
                                        'space': 0x78,
                                        'align': _0x17b681('0x2dd')
                                    },
                                    'compId': 0x10
                                }, {
                                    'type': _0x17b681('0x4a0'),
                                    'props': {
                                        'y': 0x37a,
                                        'x': 0x7f,
                                        'var': 'myRank'
                                    },
                                    'compId': 0x4b
                                }]
                            }],
                            'loadList': [_0x17b681('0x3c8'), _0x17b681('0x1aa'), 'ranking/rank_bgDI.png', 'ranking/Rank_title.png', _0x17b681('0x55e'), _0x17b681('0x693'), _0x17b681('0x665')],
                            'loadList3D': []
                        },
                        _0x1af40b;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x589')] = _0x1f5789,
                    _0x43b9b1('ui.view.RankingGlobalUIUI', _0x1f5789);
                var _0x33278a = function (_0x394534) {
                    var _0x550748 = _0xc67ffd;
                    __extends(_0x5530c4, _0x394534);
                    function _0x5530c4() {
                        var _0x3aac1f = _0x5985;
                        return _0x394534[_0x3aac1f('0x324')](this) || this;
                    }
                    return _0x5530c4[_0x550748('0x64a')][_0x550748('0x292')] = function () {
                        var _0x123b69 = _0x550748;
                        _0x394534[_0x123b69('0x64a')][_0x123b69('0x292')][_0x123b69('0x324')](this),
                            this[_0x123b69('0x39e')](_0x5530c4[_0x123b69('0x31e')]);
                    }
                        ,
                        _0x5530c4[_0x550748('0x31e')] = {
                            'type': _0x550748('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x550748('0x63b'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x550748('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': _0x550748('0x3c8'),
                                    'sizeGrid': _0x550748('0x39a'),
                                    'right': 0x0,
                                    'name': 'bg',
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x36,
                                'child': [{
                                    'type': _0x550748('0x55c'),
                                    'props': {
                                        'y': 0xb4,
                                        'x': 0x10,
                                        'width': 0x49,
                                        'var': _0x550748('0x500'),
                                        'skin': _0x550748('0xa9'),
                                        'height': 0x49
                                    },
                                    'compId': 0x37
                                }, {
                                    'type': _0x550748('0x55c'),
                                    'props': {
                                        'y': 0x132,
                                        'x': 0x6d,
                                        'width': 0x214,
                                        'skin': 'sign/sign_bg.png',
                                        'sizeGrid': _0x550748('0x31b'),
                                        'name': _0x550748('0x1cc'),
                                        'height': 0x31b
                                    },
                                    'compId': 0x38,
                                    'child': [{
                                        'type': _0x550748('0x6ae'),
                                        'props': {
                                            'y': 0x91,
                                            'x': 0x17,
                                            'var': 'signObj',
                                            'space': 0xaa,
                                            'align': _0x550748('0x10d')
                                        },
                                        'compId': 0x63
                                    }, {
                                        'type': _0x550748('0x55c'),
                                        'props': {
                                            'y': 0x1ed,
                                            'x': 0x17,
                                            'width': 0x1ea,
                                            'skin': _0x550748('0x1c4'),
                                            'sizeGrid': _0x550748('0x5d'),
                                            'name': 'day7',
                                            'height': 0x98
                                        },
                                        'compId': 0x40,
                                        'child': [{
                                            'type': _0x550748('0x141'),
                                            'props': {
                                                'y': 0x8,
                                                'x': 0x1e,
                                                'width': 0x1ae,
                                                'var': _0x550748('0x1c5'),
                                                'text': _0x550748('0x580'),
                                                'height': 0x14,
                                                'fontSize': 0x19,
                                                'font': _0x550748('0xa3'),
                                                'color': _0x550748('0x3a9'),
                                                'bold': !![],
                                                'align': _0x550748('0x59f'),
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x47
                                        }, {
                                            'type': _0x550748('0x55c'),
                                            'props': {
                                                'y': 0x20,
                                                'x': 0x73,
                                                'width': 0x66,
                                                'var': _0x550748('0x346'),
                                                'skin': _0x550748('0x5a'),
                                                'height': 0x67
                                            },
                                            'compId': 0x53
                                        }, {
                                            'type': 'Image',
                                            'props': {
                                                'y': 0x43,
                                                'x': 0x110,
                                                'width': 0x35,
                                                'var': _0x550748('0x1ea'),
                                                'skin': _0x550748('0x20d'),
                                                'height': 0x38
                                            },
                                            'compId': 0x54,
                                            'child': [{
                                                'type': 'Text',
                                                'props': {
                                                    'y': 0x2e,
                                                    'x': 0x39,
                                                    'width': 0x4e,
                                                    'var': _0x550748('0x2a2'),
                                                    'valign': _0x550748('0x46b'),
                                                    'text': 'X3000',
                                                    'height': 0x14,
                                                    'fontSize': 0x19,
                                                    'font': 'Microsoft\x20YaHei',
                                                    'color': _0x550748('0x59a'),
                                                    'bold': !![],
                                                    'align': _0x550748('0x59f'),
                                                    'runtime': 'laya.display.Text'
                                                },
                                                'compId': 0x55
                                            }]
                                        }, {
                                            'type': _0x550748('0x55c'),
                                            'props': {
                                                'y': 0x0,
                                                'x': 0x0,
                                                'width': 0x1ea,
                                                'var': _0x550748('0x675'),
                                                'skin': _0x550748('0x134'),
                                                'sizeGrid': _0x550748('0x107'),
                                                'height': 0x96
                                            },
                                            'compId': 0x67,
                                            'child': [{
                                                'type': _0x550748('0x55c'),
                                                'props': {
                                                    'y': 0x25,
                                                    'x': 0xd8,
                                                    'skin': _0x550748('0x6b8')
                                                },
                                                'compId': 0x68
                                            }, {
                                                'type': 'Text',
                                                'props': {
                                                    'y': 0x55,
                                                    'x': 0xaf,
                                                    'wordWrap': !![],
                                                    'width': 0x8b,
                                                    'var': 'checkedTxt',
                                                    'valign': _0x550748('0x46b'),
                                                    'text': _0x550748('0x49a'),
                                                    'strokeColor': _0x550748('0x27c'),
                                                    'stroke': 0x3,
                                                    'presetID': 0x9,
                                                    'height': 0x2f,
                                                    'fontSize': 0x16,
                                                    'font': _0x550748('0xa3'),
                                                    'color': _0x550748('0x554'),
                                                    'bold': !![],
                                                    'align': _0x550748('0x59f'),
                                                    'name': 'checkedTxt',
                                                    'runtime': 'laya.display.Text'
                                                },
                                                'compId': 0x6e
                                            }]
                                        }]
                                    }, {
                                        'type': _0x550748('0x55c'),
                                        'props': {
                                            'y': 0x29a,
                                            'x': 24.5,
                                            'width': 0xb9,
                                            'var': _0x550748('0x39c'),
                                            'skin': _0x550748('0x329'),
                                            'sizeGrid': '0,78,0,75',
                                            'height': 0x6d
                                        },
                                        'compId': 0x59,
                                        'child': [{
                                            'type': _0x550748('0x141'),
                                            'props': {
                                                'y': 37.5,
                                                'x': 11.5,
                                                'width': 0xa0,
                                                'var': 'getTxt',
                                                'text': '领取',
                                                'height': 0x28,
                                                'fontSize': 0x21,
                                                'font': _0x550748('0xa3'),
                                                'color': _0x550748('0x207'),
                                                'bold': !![],
                                                'align': _0x550748('0x59f'),
                                                'runtime': _0x550748('0x63f')
                                            },
                                            'compId': 0x6a
                                        }]
                                    }, {
                                        'type': _0x550748('0x55c'),
                                        'props': {
                                            'y': 0x29a,
                                            'x': 0xe6,
                                            'width': 0x109,
                                            'var': _0x550748('0x415'),
                                            'skin': 'game/btn_orange.png',
                                            'sizeGrid': _0x550748('0x1d'),
                                            'height': 0x6d
                                        },
                                        'compId': 0x5a,
                                        'child': [{
                                            'type': _0x550748('0x55c'),
                                            'props': {
                                                'y': 0x1b,
                                                'x': 0x1d,
                                                'skin': _0x550748('0x3b4')
                                            },
                                            'compId': 0x5d
                                        }, {
                                            'type': _0x550748('0x141'),
                                            'props': {
                                                'y': 0x24,
                                                'x': 0x58,
                                                'width': 0xa6,
                                                'var': _0x550748('0x17e'),
                                                'text': _0x550748('0x698'),
                                                'height': 0x28,
                                                'fontSize': 0x21,
                                                'font': _0x550748('0xa3'),
                                                'color': _0x550748('0x207'),
                                                'bold': !![],
                                                'align': _0x550748('0x59f'),
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x6b
                                        }]
                                    }, {
                                        'type': 'Text',
                                        'props': {
                                            'y': 0x17,
                                            'x': 0x1,
                                            'width': 0x212,
                                            'var': _0x550748('0xa2'),
                                            'valign': _0x550748('0x46b'),
                                            'text': '签到',
                                            'height': 0x4b,
                                            'fontSize': 0x32,
                                            'font': _0x550748('0xa3'),
                                            'color': _0x550748('0x207'),
                                            'bold': !![],
                                            'align': _0x550748('0x59f'),
                                            'runtime': _0x550748('0x63f')
                                        },
                                        'compId': 0x6c
                                    }]
                                }]
                            }],
                            'loadList': [_0x550748('0x3c8'), 'game/backBTN.png', _0x550748('0x569'), _0x550748('0x1c4'), _0x550748('0x5a'), _0x550748('0x20d'), _0x550748('0x134'), _0x550748('0x6b8'), _0x550748('0x12f'), _0x550748('0x329'), _0x550748('0x3b4')],
                            'loadList3D': []
                        },
                        _0x5530c4;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x269')] = _0x33278a,
                    _0x43b9b1('ui.view.SignUIUI', _0x33278a);
                var _0x535aed = function (_0x40803c) {
                    var _0x67b651 = _0xc67ffd;
                    __extends(_0x1b7fa6, _0x40803c);
                    function _0x1b7fa6() {
                        var _0x33be5d = _0x5985;
                        return _0x40803c[_0x33be5d('0x324')](this) || this;
                    }
                    return _0x1b7fa6['prototype'][_0x67b651('0x292')] = function () {
                        var _0xc24228 = _0x67b651;
                        _0x40803c[_0xc24228('0x64a')][_0xc24228('0x292')][_0xc24228('0x324')](this),
                            this[_0xc24228('0x39e')](_0x1b7fa6[_0xc24228('0x31e')]);
                    }
                        ,
                        _0x1b7fa6['uiView'] = {
                            'type': _0x67b651('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': 'script/view/SkinUI.ts',
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x67b651('0x6ae'),
                                'props': {
                                    'top': 0x0,
                                    'right': 0x0,
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x3a,
                                'child': [{
                                    'type': _0x67b651('0x55c'),
                                    'props': {
                                        'y': 0x0,
                                        'x': 0x0,
                                        'width': 0x2ee,
                                        'sizeGrid': '0',
                                        'name': _0x67b651('0x607'),
                                        'height': 0x208
                                    },
                                    'compId': 0xf,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x1c,
                                            'x': 0x15,
                                            'width': 0x6a,
                                            'visible': ![],
                                            'var': _0x67b651('0x12c'),
                                            'skin': _0x67b651('0x1c9'),
                                            'sizeGrid': _0x67b651('0x9'),
                                            'height': 0x16b
                                        },
                                        'compId': 0x6,
                                        'child': [{
                                            'type': _0x67b651('0x55c'),
                                            'props': {
                                                'y': 0x8a,
                                                'x': 13.5,
                                                'width': 0x4f,
                                                'var': 'vibration',
                                                'skin': _0x67b651('0x666'),
                                                'height': 0x51
                                            },
                                            'compId': 0x9
                                        }, {
                                            'type': _0x67b651('0x55c'),
                                            'props': {
                                                'y': 0xfe,
                                                'x': 13.5,
                                                'width': 0x4f,
                                                'var': 'sound',
                                                'skin': _0x67b651('0x2d9'),
                                                'height': 0x51
                                            },
                                            'compId': 0xb
                                        }]
                                    }, {
                                        'type': _0x67b651('0x55c'),
                                        'props': {
                                            'y': 0x1c,
                                            'x': 0x15,
                                            'width': 0x6a,
                                            'visible': ![],
                                            'var': 'setIcon',
                                            'skin': _0x67b651('0x1f5'),
                                            'height': 0x6c
                                        },
                                        'compId': 0x5
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x3c,
                                            'x': 0x113,
                                            'width': 0xe7,
                                            'skin': _0x67b651('0xde'),
                                            'sizeGrid': _0x67b651('0x582'),
                                            'height': 0x2c
                                        },
                                        'compId': 0x7,
                                        'child': [{
                                            'type': 'Image',
                                            'props': {
                                                'y': -0x5,
                                                'x': -0x18,
                                                'width': 0x3a,
                                                'skin': _0x67b651('0x20d'),
                                                'name': _0x67b651('0x605'),
                                                'height': 0x3b
                                            },
                                            'compId': 0xd
                                        }, {
                                            'type': _0x67b651('0x141'),
                                            'props': {
                                                'y': 0x0,
                                                'x': 0x2c,
                                                'width': 0xae,
                                                'var': 'coinCount',
                                                'valign': _0x67b651('0x10d'),
                                                'text': _0x67b651('0x362'),
                                                'height': 0x1d,
                                                'fontSize': 0x28,
                                                'font': _0x67b651('0xa3'),
                                                'color': _0x67b651('0x36f'),
                                                'bold': !![],
                                                'align': _0x67b651('0x59f'),
                                                'runtime': _0x67b651('0x63f')
                                            },
                                            'compId': 0xe
                                        }]
                                    }]
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'x': 0x0,
                                        'width': 0x2ee,
                                        'top': 0x202,
                                        'skin': _0x67b651('0x25a'),
                                        'sizeGrid': '35,23,17,18',
                                        'name': 'typeBg',
                                        'bottom': 0x0
                                    },
                                    'compId': 0x10,
                                    'child': [{
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x1,
                                            'x': 0x7e,
                                            'var': _0x67b651('0x3db'),
                                            'skin': 'skin/skin_Tap_Select.png',
                                            'anchorY': 0x1,
                                            'anchorX': 0.5
                                        },
                                        'compId': 0x12,
                                        'child': [{
                                            'type': _0x67b651('0x141'),
                                            'props': {
                                                'y': 0x17,
                                                'x': 0x2,
                                                'width': 0xcb,
                                                'var': _0x67b651('0x52a'),
                                                'valign': _0x67b651('0x46b'),
                                                'text': '领取',
                                                'height': 0x28,
                                                'fontSize': 0x21,
                                                'font': _0x67b651('0xa3'),
                                                'color': '#031871',
                                                'bold': !![],
                                                'align': 'center',
                                                'runtime': _0x67b651('0x63f')
                                            },
                                            'compId': 0x4d
                                        }]
                                    }, {
                                        'type': 'Image',
                                        'props': {
                                            'y': 0x1,
                                            'x': 0x165,
                                            'var': _0x67b651('0x6a5'),
                                            'skin': _0x67b651('0x176'),
                                            'anchorY': 0x1,
                                            'anchorX': 0.5
                                        },
                                        'compId': 0x1f,
                                        'child': [{
                                            'type': 'Text',
                                            'props': {
                                                'y': 0x17,
                                                'x': 0x5,
                                                'width': 0xcb,
                                                'var': _0x67b651('0x9a'),
                                                'valign': _0x67b651('0x46b'),
                                                'text': '领取',
                                                'height': 0x28,
                                                'fontSize': 0x21,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x67b651('0x5e6'),
                                                'bold': !![],
                                                'align': 'center',
                                                'runtime': _0x67b651('0x63f')
                                            },
                                            'compId': 0x4e
                                        }]
                                    }, {
                                        'type': _0x67b651('0x6ae'),
                                        'props': {
                                            'y': 0x2d,
                                            'x': 0x4b,
                                            'var': _0x67b651('0x330')
                                        },
                                        'compId': 0x3b
                                    }, {
                                        'type': _0x67b651('0x6ae'),
                                        'props': {
                                            'y': 0x2b,
                                            'x': 0x4b,
                                            'var': 'ballObj'
                                        },
                                        'compId': 0x3c
                                    }, {
                                        'type': _0x67b651('0x63d'),
                                        'props': {
                                            'y': 429.5,
                                            'x': 0x181,
                                            'var': 'pageObj',
                                            'space': 0x14,
                                            'anchorY': 0.5,
                                            'anchorX': 0.5,
                                            'align': 'middle'
                                        },
                                        'compId': 0x41
                                    }, {
                                        'type': _0x67b651('0x55c'),
                                        'props': {
                                            'y': -0x44,
                                            'x': 0x27a,
                                            'width': 0x60,
                                            'var': _0x67b651('0x500'),
                                            'skin': _0x67b651('0x37b'),
                                            'height': 0x45
                                        },
                                        'compId': 0x2a
                                    }, {
                                        'type': _0x67b651('0x4a0'),
                                        'props': {
                                            'y': 0xfe,
                                            'x': 0x1ef,
                                            'visible': ![],
                                            'var': _0x67b651('0x2a1'),
                                            'texture': _0x67b651('0x2ef')
                                        },
                                        'compId': 0x46
                                    }, {
                                        'type': _0x67b651('0x55c'),
                                        'props': {
                                            'y': 446.5,
                                            'x': 0x40,
                                            'width': 0x125,
                                            'var': _0x67b651('0x267'),
                                            'skin': _0x67b651('0x2c'),
                                            'height': 0x70
                                        },
                                        'compId': 0x37,
                                        'child': [{
                                            'type': _0x67b651('0x55c'),
                                            'props': {
                                                'y': 28.5,
                                                'x': 0x30,
                                                'width': 0x34,
                                                'skin': _0x67b651('0x56'),
                                                'height': 0x37
                                            },
                                            'compId': 0x38
                                        }, {
                                            'type': _0x67b651('0x55c'),
                                            'props': {
                                                'y': 37.5,
                                                'x': 0x73,
                                                'width': 0x8f,
                                                'skin': _0x67b651('0x50e'),
                                                'name': _0x67b651('0x338'),
                                                'height': 0x25
                                            },
                                            'compId': 0x4a
                                        }]
                                    }, {
                                        'type': _0x67b651('0x55c'),
                                        'props': {
                                            'y': 446.5,
                                            'x': 56.5,
                                            'width': 0x134,
                                            'var': _0x67b651('0x388'),
                                            'skin': _0x67b651('0x2c'),
                                            'height': 0x70
                                        },
                                        'compId': 0x20,
                                        'child': [{
                                            'type': 'Image',
                                            'props': {
                                                'y': 0x1f,
                                                'x': 0x20,
                                                'width': 0x3b,
                                                'visible': !![],
                                                'skin': _0x67b651('0x3b4'),
                                                'height': 0x32
                                            },
                                            'compId': 0x21
                                        }, {
                                            'type': _0x67b651('0x141'),
                                            'props': {
                                                'y': 0x19,
                                                'x': 0x5d,
                                                'wordWrap': !![],
                                                'width': 0xcb,
                                                'var': _0x67b651('0x5ed'),
                                                'valign': _0x67b651('0x46b'),
                                                'text': _0x67b651('0x4c0'),
                                                'height': 0x3a,
                                                'fontSize': 0x21,
                                                'font': _0x67b651('0xa3'),
                                                'color': '#ffffff',
                                                'bold': !![],
                                                'align': _0x67b651('0x59f'),
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x4f
                                        }]
                                    }, {
                                        'type': _0x67b651('0x55c'),
                                        'props': {
                                            'y': 446.5,
                                            'x': 0x193,
                                            'width': 0x125,
                                            'var': 'unlockbtn',
                                            'skin': _0x67b651('0x6b7'),
                                            'height': 0x70
                                        },
                                        'compId': 0x26,
                                        'child': [{
                                            'type': _0x67b651('0x141'),
                                            'props': {
                                                'y': 0x31,
                                                'x': 0xab,
                                                'width': 0x9c,
                                                'var': _0x67b651('0x375'),
                                                'valign': _0x67b651('0x10d'),
                                                'text': _0x67b651('0x4f7'),
                                                'pivotY': 0x20,
                                                'pivotX': 0x9c,
                                                'height': 0x1d,
                                                'fontSize': 0x23,
                                                'font': 'Microsoft\x20YaHei',
                                                'color': _0x67b651('0x3e0'),
                                                'bold': !![],
                                                'align': _0x67b651('0x4d4'),
                                                'runtime': 'laya.display.Text'
                                            },
                                            'compId': 0x27
                                        }, {
                                            'type': _0x67b651('0x55c'),
                                            'props': {
                                                'y': 0xe,
                                                'x': 0xab,
                                                'width': 0x23,
                                                'skin': _0x67b651('0x20d'),
                                                'height': 0x20
                                            },
                                            'compId': 0x28
                                        }, {
                                            'type': 'Text',
                                            'props': {
                                                'y': 0x2e,
                                                'x': 0xa,
                                                'wordWrap': !![],
                                                'width': 0x110,
                                                'var': 'randomUnlockTxt',
                                                'valign': _0x67b651('0x46b'),
                                                'text': _0x67b651('0x28a'),
                                                'leading': -0x4,
                                                'height': 0x38,
                                                'fontSize': 0x16,
                                                'font': _0x67b651('0xa3'),
                                                'color': _0x67b651('0x554'),
                                                'bold': !![],
                                                'align': _0x67b651('0x59f'),
                                                'runtime': _0x67b651('0x63f')
                                            },
                                            'compId': 0x50
                                        }]
                                    }]
                                }, {
                                    'type': 'Image',
                                    'props': {
                                        'y': 0x43e,
                                        'x': 0x109,
                                        'width': 0xf0,
                                        'visible': !![],
                                        'var': 'usebtn',
                                        'skin': _0x67b651('0x261'),
                                        'sizeGrid': _0x67b651('0x5d2'),
                                        'name': 'useSkin',
                                        'label': _0x67b651('0x55b'),
                                        'height': 0x47
                                    },
                                    'compId': 0x47,
                                    'child': [{
                                        'type': _0x67b651('0x141'),
                                        'props': {
                                            'y': 0x10,
                                            'x': 0xd,
                                            'width': 0xd6,
                                            'var': _0x67b651('0x460'),
                                            'valign': _0x67b651('0x46b'),
                                            'text': '领取',
                                            'height': 0x28,
                                            'fontSize': 0x21,
                                            'font': _0x67b651('0xa3'),
                                            'color': _0x67b651('0x554'),
                                            'bold': !![],
                                            'align': _0x67b651('0x59f'),
                                            'runtime': 'laya.display.Text'
                                        },
                                        'compId': 0x51
                                    }]
                                }, {
                                    'type': _0x67b651('0x6ae'),
                                    'props': {
                                        'y': 0x21a,
                                        'x': 0x0,
                                        'width': 0x2ee,
                                        'visible': ![],
                                        'var': _0x67b651('0x70'),
                                        'height': 0x1a3
                                    },
                                    'compId': 0x52
                                }]
                            }],
                            'loadList': [_0x67b651('0x1c9'), _0x67b651('0x666'), _0x67b651('0x2d9'), _0x67b651('0x1f5'), _0x67b651('0xde'), 'game/icon_diamond.png', 'skin/SkinBG.jpg', 'skin/skin_Tap_Select.png', _0x67b651('0x176'), _0x67b651('0x37b'), _0x67b651('0x2ef'), _0x67b651('0x2c'), _0x67b651('0x56'), _0x67b651('0x50e'), _0x67b651('0x3b4'), _0x67b651('0x6b7'), 'skin/btn_green.png'],
                            'loadList3D': []
                        },
                        _0x1b7fa6;
                }(Laya['BaseView']);
                _0x27a9bf[_0xc67ffd('0x501')] = _0x535aed,
                    _0x43b9b1('ui.view.SkinUIUI', _0x535aed);
                var _0x3d30c1 = function (_0x2d8e8c) {
                    var _0x448209 = _0xc67ffd;
                    __extends(_0x1778b5, _0x2d8e8c);
                    function _0x1778b5() {
                        var _0x348fd9 = _0x5985;
                        return _0x2d8e8c[_0x348fd9('0x324')](this) || this;
                    }
                    return _0x1778b5[_0x448209('0x64a')][_0x448209('0x292')] = function () {
                        var _0x4b7603 = _0x448209;
                        _0x2d8e8c[_0x4b7603('0x64a')][_0x4b7603('0x292')][_0x4b7603('0x324')](this),
                            this[_0x4b7603('0x39e')](_0x1778b5[_0x4b7603('0x31e')]);
                    }
                        ,
                        _0x1778b5['uiView'] = {
                            'type': _0x448209('0x646'),
                            'props': {
                                'width': 0x2ee,
                                'top': 0x0,
                                'runtime': _0x448209('0x527'),
                                'right': 0x0,
                                'left': 0x0,
                                'height': 0x536,
                                'bottom': 0x0
                            },
                            'compId': 0x2,
                            'child': [{
                                'type': _0x448209('0x55c'),
                                'props': {
                                    'top': 0x0,
                                    'skin': 'game/topUI.png',
                                    'sizeGrid': _0x448209('0x28'),
                                    'right': 0x0,
                                    'left': 0x0,
                                    'bottom': 0x0
                                },
                                'compId': 0x3,
                                'child': [{
                                    'type': _0x448209('0x4a0'),
                                    'props': {
                                        'y': 0x104,
                                        'x': 0xac,
                                        'var': _0x448209('0x500'),
                                        'texture': _0x448209('0x4e3')
                                    },
                                    'compId': 0x4
                                }]
                            }],
                            'loadList': [_0x448209('0x1db'), 'game/top_close.png'],
                            'loadList3D': []
                        },
                        _0x1778b5;
                }(Laya[_0xc67ffd('0x646')]);
                _0x27a9bf[_0xc67ffd('0x1e1')] = _0x3d30c1,
                    _0x43b9b1(_0xc67ffd('0x66b'), _0x3d30c1);
            }(_0x129804 = _0x57008c['view'] || (_0x57008c['view'] = {})));
        }(_0x9224eb = _0x128d2b['ui'] || (_0x128d2b['ui'] = {})));
    }
        , {}],
    0x37: [function (_0x47e69a, _0x5140cc, _0x407e90) {
        var _0x18a373 = _0x4b7fcf;
        'use strict';
        Object[_0x18a373('0x351')](_0x407e90, _0x18a373('0xb8'), {
            'value': !![]
        });
        var _0x336893 = _0x47e69a('../XGame')
            , _0x2e3fb1 = _0x47e69a(_0x18a373('0x1b'))
            , _0xb6d990 = _0x47e69a(_0x18a373('0x2ce'))
            , _0xd70392 = function () {
                var _0x4e178e = _0x18a373;
                function _0xae0b84() { }
                return _0xae0b84['isVector3'] = function (_0x426720) {
                    var _0x3eecf9 = _0x5985;
                    return _0x426720[_0x3eecf9('0x3b')] == 'laya.d3.math.Vector3';
                }
                    ,
                    _0xae0b84[_0x4e178e('0x16b')] = function (_0x4bc631) {
                        var _0x4e3fa0 = _0x4e178e;
                        return _0x4bc631[_0x4e3fa0('0x3b')] == 'laya.d3.math.Vector2';
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x159')] = function (_0x2f204e) {
                        var _0x48f190 = _0x4e178e;
                        return _0x2f204e[_0x48f190('0x3b')] == _0x48f190('0xc8');
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x655')] = function (_0x5cb375, _0x52d95d, _0x1ce4f1) {
                        if (_0x5cb375 > _0x1ce4f1)
                            return _0x1ce4f1;
                        if (_0x5cb375 < _0x52d95d)
                            return _0x52d95d;
                        return _0x5cb375;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x676')] = function (_0x5c2799) {
                        if (_0x5c2799 < 0x0)
                            return 0x0;
                        if (_0x5c2799 > 0x1)
                            return 0x1;
                        return _0x5c2799;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x163')] = function (_0x19c39d, _0x5e6820) {
                        var _0x29e437 = _0x4e178e;
                        return Math['acos'](this[_0x29e437('0x655')](this['Dot'](this[_0x29e437('0x2fc')](_0x19c39d), this['Normalized'](_0x5e6820)), -0x1, 0x1)) * 57.29578;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x23')] = function (_0x38dd46, _0x5003c5) {
                        var _0x4715c5 = _0x4e178e
                            , _0x5db47d = _0x38dd46['x'] - _0x5003c5['x']
                            , _0x1e169f = _0x38dd46['y'] - _0x5003c5['y']
                            , _0x514b42 = 0x0;
                        return this[_0x4715c5('0x464')](_0x38dd46) && (_0x514b42 = _0x38dd46['z'] - _0x5003c5['z']),
                            Math['sqrt'](Math['abs'](_0x5db47d + _0x1e169f + _0x514b42));
                    }
                    ,
                    _0xae0b84['Add'] = function (_0x19e6ad, _0x4692b7) {
                        var _0x265a0c = _0x4e178e;
                        if (this[_0x265a0c('0x464')](_0x19e6ad))
                            return new Laya[(_0x265a0c('0x592'))](_0x19e6ad['x'] + _0x4692b7['x'], _0x19e6ad['y'] + _0x4692b7['y'], _0x19e6ad['z'] + _0x4692b7['z']);
                        if (this[_0x265a0c('0x16b')](_0x19e6ad))
                            return new Laya[(_0x265a0c('0x50b'))](_0x19e6ad['x'] + _0x4692b7['x'], _0x19e6ad['y'] + _0x4692b7['y']);
                        return null;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x5e3')] = function (_0x2e4f09, _0x412ab8) {
                        var _0x30f94f = _0x4e178e;
                        if (this[_0x30f94f('0x464')](_0x2e4f09))
                            return new Laya['Vector3'](_0x2e4f09['x'] - _0x412ab8['x'], _0x2e4f09['y'] - _0x412ab8['y'], _0x2e4f09['z'] - _0x412ab8['z']);
                        if (this['isVector2'](_0x2e4f09))
                            return new Laya[(_0x30f94f('0x50b'))](_0x2e4f09['x'] - _0x412ab8['x'], _0x2e4f09['y'] - _0x412ab8['y']);
                        return null;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x699')] = function (_0x3dd9b1, _0x50e62c) {
                        var _0x44ce95 = _0x4e178e;
                        if (this[_0x44ce95('0x464')](_0x3dd9b1))
                            return new Laya[(_0x44ce95('0x592'))](_0x3dd9b1['x'] * _0x50e62c, _0x3dd9b1['y'] * _0x50e62c, _0x3dd9b1['z'] * _0x50e62c);
                        if (this[_0x44ce95('0x16b')](_0x3dd9b1))
                            return new Laya[(_0x44ce95('0x50b'))](_0x3dd9b1['x'] * _0x50e62c, _0x3dd9b1['y'] * _0x50e62c);
                        return null;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x390')] = function (_0x1100c4, _0x37f6a4, _0x373c37) {
                        var _0x3bedc3 = _0x4e178e;
                        _0x373c37 = this['Clamp01'](_0x373c37);
                        if (this[_0x3bedc3('0x464')](_0x1100c4))
                            return new Laya[(_0x3bedc3('0x592'))](_0x1100c4['x'] + (_0x37f6a4['x'] - _0x1100c4['x']) * _0x373c37, _0x1100c4['y'] + (_0x37f6a4['y'] - _0x1100c4['y']) * _0x373c37, _0x1100c4['z'] + (_0x37f6a4['z'] - _0x1100c4['z']) * _0x373c37);
                        if (this[_0x3bedc3('0x16b')](_0x1100c4))
                            return new Laya[(_0x3bedc3('0x50b'))](_0x1100c4['x'] + (_0x37f6a4['x'] - _0x1100c4['x']) * _0x373c37, _0x1100c4['y'] + (_0x37f6a4['y'] - _0x1100c4['y']) * _0x373c37);
                        return null;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x496')] = function (_0x3dfd81, _0x1488fc) {
                        var _0x54013a = _0x4e178e;
                        if (this[_0x54013a('0x464')](_0x3dfd81))
                            return new Laya[(_0x54013a('0x592'))](_0x3dfd81['x'] / _0x1488fc, _0x3dfd81['y'] / _0x1488fc, _0x3dfd81['z'] / _0x1488fc);
                        if (this['isVector2'](_0x3dfd81))
                            return new Laya[(_0x54013a('0x50b'))](_0x3dfd81['x'] / _0x1488fc, _0x3dfd81['y'] / _0x1488fc);
                    }
                    ,
                    _0xae0b84['Normalized'] = function (_0x1ff733) {
                        var _0x49a45a = _0x4e178e
                            , _0x1f92b5 = this[_0x49a45a('0xbb')](_0x1ff733);
                        return _0x1f92b5 > 0.00001 ? _0x1ff733 = this[_0x49a45a('0x496')](_0x1ff733, _0x1f92b5) : (this[_0x49a45a('0x464')](_0x1ff733) && (_0x1ff733 = new Laya['Vector3'](0x0, 0x0, 0x0)),
                            this[_0x49a45a('0x16b')](_0x1ff733) && (_0x1ff733 = new Laya[(_0x49a45a('0x50b'))](0x0, 0x0))),
                            _0x1ff733;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0xbb')] = function (_0x87691d) {
                        var _0xb88f33 = _0x4e178e;
                        return Math[_0xb88f33('0x425')](this[_0xb88f33('0x16')](_0x87691d));
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x16')] = function (_0x2290af) {
                        var _0x36e4d9 = _0x4e178e
                            , _0xc9e5 = _0x2290af['x'] * _0x2290af['x'] + _0x2290af['y'] * _0x2290af['y'];
                        return this[_0x36e4d9('0x464')](_0x2290af) && (_0xc9e5 += _0x2290af['z'] * _0x2290af['z']),
                            _0xc9e5;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x61')] = function (_0x4ec104, _0x79d187) {
                        var _0x566f26 = _0x4e178e;
                        if (this[_0x566f26('0x16')](_0x4ec104) > _0x79d187 * _0x79d187)
                            return _0x4ec104 = this[_0x566f26('0x2fc')](_0x4ec104),
                                this[_0x566f26('0x699')](_0x4ec104, _0x79d187);
                        return _0x4ec104;
                    }
                    ,
                    _0xae0b84['random'] = function (_0x1d00d5, _0x108597) {
                        var _0x498fcb = _0x4e178e
                            , _0x579bd5 = Math['random']();
                        return Math[_0x498fcb('0x80')](_0x1d00d5 + Math[_0x498fcb('0x139')]() * (_0x108597 - _0x1d00d5));
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x69b')] = function (_0x51189b, _0x4e7e51) {
                        var _0xdaa815 = _0x4e178e
                            , _0xbd4280 = Math[_0xdaa815('0x139')]();
                        return _0x51189b + Math['random']() * (_0x4e7e51 - _0x51189b);
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x148')] = function (_0x5ac0b3, _0x3335e9) {
                        return _0x5ac0b3 > _0x3335e9 ? 0x1 : -0x1;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x4d2')] = function (_0x1f46a8) {
                        var _0x51ed4e = _0x4e178e;
                        return typeof _0x1f46a8 == _0x51ed4e('0x51b') || _0x1f46a8 == null || _0x1f46a8 == '' ? !![] : ![];
                    }
                    ,
                    _0xae0b84['Dot'] = function (_0x4f21f2, _0xe2b294) {
                        return _0x4f21f2['x'] * _0xe2b294['x'] + _0x4f21f2['y'] * _0xe2b294['y'] + _0x4f21f2['z'] * _0xe2b294['z'];
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x37f')] = function (_0x383792) {
                        var _0x3995b7 = _0x4e178e
                            , _0x4caa25 = []
                            , _0x312a2e = _0x383792[_0x3995b7('0xcc')]()[_0x3995b7('0x1f8')](',');
                        for (var _0x4368ad = 0x0; _0x4368ad < _0x312a2e[_0x3995b7('0x4cc')]; _0x4368ad++) {
                            _0x4caa25[_0x3995b7('0xff')](parseFloat(_0x312a2e[_0x4368ad]));
                        }
                        return _0x4caa25;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x4c9')] = function (_0x24842e, _0x1cebac) {
                        var _0xf4a37c = _0x4e178e
                            , _0x3cb210 = []
                            , _0x5cf022 = _0x24842e[_0xf4a37c('0xcc')]()[_0xf4a37c('0x1f8')](_0x1cebac);
                        for (var _0x29f2e6 = 0x0; _0x29f2e6 < _0x5cf022[_0xf4a37c('0x4cc')]; _0x29f2e6++) {
                            _0x3cb210[_0xf4a37c('0xff')](_0x5cf022[_0x29f2e6]);
                        }
                        return _0x3cb210;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x456')] = function (_0x377419) {
                        var _0x2bc37c = _0x4e178e
                            , _0x279bb8 = Math['ceil'](_0x377419)[_0x2bc37c('0xcc')]();
                        if (_0x279bb8[_0x2bc37c('0x4cc')] == 0x4)
                            _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x3),
                                _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x1) + '.' + _0x279bb8['substring'](0x1, 0x3) + 'k';
                        else {
                            if (_0x279bb8[_0x2bc37c('0x4cc')] == 0x5)
                                _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x3),
                                    _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x2) + '.' + _0x279bb8['substring'](0x2, 0x3) + 'k';
                            else {
                                if (_0x279bb8[_0x2bc37c('0x4cc')] == 0x6)
                                    _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x4),
                                        _0x279bb8 = _0x279bb8['substring'](0x0, 0x3) + '.' + _0x279bb8[_0x2bc37c('0x154')](0x3, 0x4) + 'k';
                                else {
                                    if (_0x279bb8[_0x2bc37c('0x4cc')] == 0x7)
                                        _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x4),
                                            _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x1) + '.' + _0x279bb8[_0x2bc37c('0x154')](0x1, 0x4) + 'M';
                                    else
                                        _0x279bb8[_0x2bc37c('0x4cc')] == 0x8 && (_0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x5),
                                            _0x279bb8 = _0x279bb8[_0x2bc37c('0x154')](0x0, 0x2) + '.' + _0x279bb8[_0x2bc37c('0x154')](0x2, 0x5) + 'M');
                                }
                            }
                        }
                        return _0x279bb8;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x72')] = function (_0x422de0, _0x288a0f, _0x2eb8a2, _0x4fdea9) {
                        var _0x5101ae = _0x4e178e;
                        if (_0xb6d990[_0x5101ae('0x1d1')][_0x5101ae('0x400')] == _0xb6d990[_0x5101ae('0x52b')]['Game4399'] || _0xb6d990[_0x5101ae('0x1d1')][_0x5101ae('0x400')] == _0xb6d990[_0x5101ae('0x52b')][_0x5101ae('0x32b')] || _0xb6d990['GameConst']['Platform'] == _0xb6d990['PlatformType'][_0x5101ae('0x1e0')])
                            return;
                        if (_0xb6d990[_0x5101ae('0x1d1')]['Platform'] == _0xb6d990['PlatformType']['TouTAd'] || _0xb6d990['GameConst'][_0x5101ae('0x400')] == _0xb6d990[_0x5101ae('0x52b')][_0x5101ae('0x5a2')] || _0xb6d990['GameConst'][_0x5101ae('0x400')] == _0xb6d990[_0x5101ae('0x52b')][_0x5101ae('0x691')] || _0xb6d990[_0x5101ae('0x1d1')]['Platform'] == _0xb6d990[_0x5101ae('0x52b')]['BaiduAd'] || _0xb6d990['GameConst']['Platform'] == _0xb6d990[_0x5101ae('0x52b')][_0x5101ae('0x576')]) {
                            if (_0x288a0f[_0x5101ae('0x8c')] != _0x5101ae('0x514')) {
                                if (_0x288a0f[_0x5101ae('0x8c')] == 'useSkin')
                                    return;
                                _0x288a0f[_0x5101ae('0x5bf')] = ![];
                                var _0x5039ef = _0x336893[_0x5101ae('0x3b6')][_0x5101ae('0x4ce')][_0x5101ae('0xeb')](_0x5101ae('0x53e'));
                                Laya[_0x5101ae('0x5ac')][_0x5101ae('0x1e6')](_0x5039ef, _0x422de0, function () {
                                    var _0x5bedf9 = _0x5101ae;
                                    _0x288a0f[_0x5bedf9('0x5bf')] = !![];
                                });
                            }
                            return;
                        }
                        ; _0x288a0f[_0x5101ae('0x5bf')] = ![],
                            _0x2e3fb1['default'][_0x5101ae('0x574')](![]),
                            Laya['timer'][_0x5101ae('0x1e6')](0x1f4, _0x422de0, function () {
                                var _0x39fda4 = _0x5101ae;
                                _0x288a0f[_0x39fda4('0x5bf')] = !![],
                                    _0x288a0f[_0x39fda4('0x1bf')](_0x288a0f['x'], _0x2eb8a2, !![]),
                                    Laya['timer'][_0x39fda4('0x1e6')](_0x336893[_0x39fda4('0x3b6')]['CfgMgr']['getGlobalCfg'](_0x39fda4('0x1bc')), _0x422de0, function () {
                                        var _0x330e95 = _0x39fda4;
                                        console[_0x330e95('0x5df')](_0x330e95('0x5d4')),
                                            _0x2e3fb1[_0x330e95('0x3b6')][_0x330e95('0x574')](!![]),
                                            Laya[_0x330e95('0x5ac')][_0x330e95('0x1e6')](_0x336893['default']['CfgMgr'][_0x330e95('0xeb')](_0x330e95('0x408')), _0x422de0, function () {
                                                var _0x12b3b2 = _0x330e95;
                                                _0x288a0f[_0x12b3b2('0x1bf')](_0x288a0f['x'], _0x4fdea9, !![]);
                                            });
                                    });
                            });
                    }
                    ,
                    _0xae0b84['doSmall'] = function (_0x2b8522, _0x418c0e, _0x1b90f4, _0x2e61ea) {
                        var _0x147261 = _0x4e178e;
                        Laya[_0x147261('0x34d')]['to'](_0x418c0e, {
                            'scaleX': 0x1,
                            'scaleY': 0x1
                        }, _0x1b90f4, null, Laya[_0x147261('0x49f')][_0x147261('0x5fb')](this, this['doLager'], [_0x2b8522, _0x418c0e, _0x1b90f4, _0x2e61ea], !![]));
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x438')] = function (_0x5f51b9, _0x357c5c, _0x32d5f3, _0x47076c) {
                        var _0x4a5d9a = _0x4e178e;
                        Laya['Tween']['to'](_0x357c5c, {
                            'scaleX': _0x47076c,
                            'scaleY': _0x47076c
                        }, _0x32d5f3, null, Laya[_0x4a5d9a('0x49f')][_0x4a5d9a('0x5fb')](this, this[_0x4a5d9a('0xb')], [_0x5f51b9, _0x357c5c, _0x32d5f3, _0x47076c], !![]));
                    }
                    ,
                    _0xae0b84['guideLeftHandleSmall'] = function (_0x102def) {
                        var _0x230ded = _0x4e178e;
                        Laya['Tween']['to'](_0x102def, {
                            'scaleX': 0.9,
                            'scaleY': 0.9
                        }, 0x64, null, Laya['Handler'][_0x230ded('0x5fb')](this, this[_0x230ded('0x1d4')], [_0x102def]));
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x1d4')] = function (_0x4a08c3) {
                        var _0x25b0df = _0x4e178e;
                        Laya[_0x25b0df('0x34d')]['to'](_0x4a08c3, {
                            'scaleX': 0x1,
                            'scaleY': 0x1
                        }, 0x64, null, null);
                    }
                    ,
                    _0xae0b84[_0x4e178e('0xb4')] = function (_0x2a268f, _0x2c874f) {
                        var _0x575a73 = _0x4e178e
                            , _0x3d2219 = _0x2a268f[_0x575a73('0x3f7')]('|1|', _0x2c874f);
                        return _0x3d2219;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x1e5')] = function (_0x15ef93, _0x4adc33, _0x998c00) {
                        var _0x1c15c8 = _0x4e178e;
                        _0xb6d990[_0x1c15c8('0x1d1')]['Platform'] != _0xb6d990[_0x1c15c8('0x52b')]['Game4399'] ? _0x2e3fb1[_0x1c15c8('0x3b6')][_0x1c15c8('0xc3')](_0x15ef93, _0x998c00[_0x1c15c8('0x484')](_0x4adc33), ![]) : _0x998c00(!![]);
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x56b')] = function (_0x1748b3) {
                        var _0x2248b4 = _0x4e178e;
                        _0x2e3fb1[_0x2248b4('0x3b6')][_0x2248b4('0x16c')](_0x1748b3);
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x2ee')] = function () {
                        var _0x5c52b7 = _0x4e178e;
                        return Date['parse'](new Date()[_0x5c52b7('0xcc')]());
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x368')] = function (_0x38279c) {
                        var _0x18c6eb = _0x4e178e
                            , _0x1c0aa6 = new Date(_0x38279c);
                        return _0x1c0aa6[_0x18c6eb('0x57f')]() + ':' + _0x1c0aa6['getMinutes']() + ':' + _0x1c0aa6[_0x18c6eb('0x20b')]();
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x366')] = function () {
                        var _0x3a9b2d = _0x4e178e
                            , _0x379f81 = new Date();
                        return _0x379f81[_0x3a9b2d('0x294')]() + '年' + (_0x379f81[_0x3a9b2d('0xd')]() + 0x1) + '月' + _0x379f81['getDate']() + '日';
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x561')] = function (_0x5760f8) {
                        var _0xa1047b = _0x4e178e
                            , _0x5b787d = Math[_0xa1047b('0x80')](_0x5760f8 / 0x3c)
                            , _0x5760f8 = _0x5760f8 - _0x5b787d * 0x3c;
                        return (_0x5b787d < 0xa ? '0' + _0x5b787d : _0x5b787d) + ':' + (_0x5760f8 < 0xa ? '0' + _0x5760f8 : _0x5760f8);
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x5e1')] = function (_0x28fa55, _0x25f1e8, _0x3e49dc) {
                        var _0x7d9d2c = _0x4e178e
                            , _0x30fd69 = []
                            , _0xb40957 = Math[_0x7d9d2c('0x2fb')](_0x25f1e8, 0x2) - 0x4 * _0x28fa55 * _0x3e49dc;
                        if (_0xb40957 > 0x0)
                            _0x30fd69['push']((-_0x25f1e8 + Math[_0x7d9d2c('0x425')](_0xb40957)) / (0x2 * _0x28fa55)),
                                _0x30fd69[_0x7d9d2c('0xff')]((-_0x25f1e8 - Math[_0x7d9d2c('0x425')](_0xb40957)) / (0x2 * _0x28fa55));
                        else
                            _0xb40957 == 0x0 && _0x30fd69['push'](-_0x25f1e8 / (0x2 * _0x28fa55));
                        return _0x30fd69;
                    }
                    ,
                    _0xae0b84[_0x4e178e('0x5f9')] = function (_0x2ef320, _0x1b7f8f, _0x3c096e, _0x4a25e9) {
                        var _0x14af6e = (_0x1b7f8f - _0x4a25e9) / (_0x2ef320 - _0x3c096e)
                            , _0x4642e1 = (_0x2ef320 * _0x4a25e9 - _0x3c096e * _0x1b7f8f) / (_0x2ef320 - _0x3c096e);
                        return [_0x14af6e, _0x4642e1];
                    }
                    ,
                    _0xae0b84[_0x4e178e('0xe7')] = function (_0x445787, _0x327e7f, _0x2b4180, _0x393453, _0xc3034e, _0x54f91d, _0x5b95b6) {
                        var _0x4fa602 = _0x4e178e
                            , _0x3f9b2f = _0xae0b84[_0x4fa602('0x5f9')](_0x445787, _0x327e7f, _0x2b4180, _0x393453)
                            , _0x356c28 = _0x3f9b2f[0x0]
                            , _0x18ad0d = _0x3f9b2f[0x1]
                            , _0x570802 = 0x1 + _0x356c28 * _0x356c28
                            , _0x33dbee = 0x2 * _0x356c28 * (_0x18ad0d - _0x54f91d) - 0x2 * _0xc3034e
                            , _0x5d6471 = _0xc3034e * _0xc3034e + (_0x18ad0d - _0x54f91d) * (_0x18ad0d - _0x54f91d) - _0x5b95b6 * _0x5b95b6
                            , _0x486ed1 = []
                            , _0x54e221 = _0xae0b84[_0x4fa602('0x5e1')](_0x570802, _0x33dbee, _0x5d6471);
                        return _0x54e221[_0x4fa602('0x596')](function (_0x3514cb) {
                            var _0x3ae73c = _0x4fa602
                                , _0x23065a = _0x356c28 * _0x3514cb + _0x18ad0d;
                            _0x486ed1[_0x3ae73c('0xff')]({
                                'x': _0x3514cb,
                                'y': _0x23065a
                            });
                        }),
                            _0x486ed1;
                    }
                    ,
                    _0xae0b84;
            }();
        _0x407e90[_0x18a373('0x3b6')] = _0xd70392;
    }
        , {
        '../Platform': 0x3,
        '../XGame': 0x4,
        '../enum/GameConst': 0xf
    }],
    0x38: [function (_0x1e22e4, _0x56579e, _0x4b1d81) {
        var _0x263cce = _0x4b7fcf;
        'use strict';
        Object[_0x263cce('0x351')](_0x4b1d81, _0x263cce('0xb8'), {
            'value': !![]
        });
        var _0xfbc149 = _0x1e22e4('../Platform')
            , _0x5e3290 = function () {
                var _0x2dfc07 = _0x263cce;
                function _0x5882fb() { }
                ; return _0x5882fb[_0x2dfc07('0x48f')] = function (_0x4deb6c, _0xf9487, _0x2ee89d, _0x1bd1ea) {
                    var _0x164862 = _0x4deb6c - _0x2ee89d
                        , _0x2a837a = _0xf9487 - _0x1bd1ea;
                    return _0x164862 * _0x164862 + _0x2a837a * _0x2a837a;
                }
                    ,
                    _0x5882fb[_0x2dfc07('0x4ee')] = function (_0x402bbe, _0x18cddf) {
                        var _0x2dd4f2 = _0x402bbe['x'] - _0x18cddf['x']
                            , _0x36a77e = _0x402bbe['z'] - _0x18cddf['z']
                            , _0x22560f = _0x2dd4f2 * _0x2dd4f2 + _0x36a77e * _0x36a77e;
                        return _0x22560f;
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x390')] = function (_0x5912ba, _0x54ba1b, _0x35a17c) {
                        var _0x58403c = _0x2dfc07
                            , _0x5b59ab = _0x5912ba + (_0x54ba1b - _0x5912ba) * _0x35a17c;
                        return _0x5912ba < _0x54ba1b ? _0x5b59ab = _0x5882fb[_0x58403c('0x655')](_0x5b59ab, _0x5912ba, _0x54ba1b) : _0x5b59ab = _0x5882fb['Clamp'](_0x5b59ab, _0x54ba1b, _0x5912ba),
                            _0x5b59ab;
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x655')] = function (_0x531918, _0x21c8f3, _0x5e6eba) {
                        if (_0x531918 < _0x21c8f3)
                            return _0x21c8f3;
                        if (_0x531918 > _0x5e6eba)
                            return _0x5e6eba;
                        return _0x531918;
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x21e')] = function (_0x316a9c) {
                        var _0x3998e7 = _0x2dfc07;
                        if (_0x316a9c == null || _0x316a9c == _0x3998e7('0x51b'))
                            return 0x0;
                        var _0x415a3a = parseFloat(_0x316a9c);
                        if (_0x415a3a)
                            return Math[_0x3998e7('0x80')](_0x415a3a);
                        return 0x0;
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x4d2')] = function (_0x1b710e) {
                        return typeof _0x1b710e == 'undefined' || _0x1b710e == null || _0x1b710e == '' ? !![] : ![];
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x4c7')] = function (_0x2838ce, _0x3ace0e, _0x420196, _0x33ae9a, _0xbc3b2, _0x1cda1c) {
                        var _0x4a9b3a = _0x2dfc07;
                        _0x420196 === void 0x0 && (_0x420196 = 0x0),
                            _0x33ae9a === void 0x0 && (_0x33ae9a = 0x0),
                            _0xbc3b2 === void 0x0 && (_0xbc3b2 = 0xa),
                            _0x1cda1c === void 0x0 && (_0x1cda1c = 0xa),
                            _0x2838ce[_0x4a9b3a('0x596')](function (_0x2b5a56, _0x39b8f5) {
                                var _0x4070c3 = _0x4a9b3a;
                                _0x2b5a56['x'] = _0x420196 + (_0x2b5a56[_0x4070c3('0x1d2')] + _0xbc3b2) * (_0x39b8f5 % _0x3ace0e | 0x0),
                                    _0x2b5a56['y'] = _0x33ae9a + (_0x2b5a56[_0x4070c3('0x33c')] + _0x1cda1c) * (_0x39b8f5 / _0x3ace0e | 0x0);
                            });
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x536')] = function (_0x54a2d4, _0x2fd7d9) {
                        var _0x3c60cb = _0x2dfc07;
                        return Math[_0x3c60cb('0x80')](_0x54a2d4 + Math['random']() * (_0x2fd7d9 - _0x54a2d4));
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x487')] = function (_0xa87249, _0x40fc6b) {
                        var _0x169458 = _0x2dfc07;
                        return Math[_0x169458('0x43e')](_0x5882fb[_0x169458('0x536')](_0xa87249, _0x40fc6b));
                    }
                    ,
                    _0x5882fb['DegToRad'] = function (_0xe2e252) {
                        return _0xe2e252 * Math['PI'] / 0xb4;
                    }
                    ,
                    _0x5882fb['getGravity'] = function (_0x262a0b, _0xc77a04) {
                        var _0x504021 = 0x2 * _0x262a0b / (_0xc77a04 * _0xc77a04);
                        return _0x504021;
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x3d5')] = function (_0x5cc392, _0xc9c9e7, _0xbfda8f, _0x3d3451) {
                        var _0x3f7f53 = _0x2dfc07
                            , _0x290d49 = _0x5882fb['DegToRad'](_0xbfda8f - 0xb4)
                            , _0x5a51d8 = Math[_0x3f7f53('0x6af')](_0x290d49)
                            , _0x4a5b40 = Math[_0x3f7f53('0x4f0')](_0x290d49)
                            , _0x2e2f6d = (_0x5cc392['x'] - _0xc9c9e7['x']) * _0x5a51d8 + (_0x5cc392['z'] - _0xc9c9e7['z']) * _0x4a5b40 + _0xc9c9e7['x']
                            , _0x3b9516 = -(_0x5cc392['x'] - _0xc9c9e7['x']) * _0x4a5b40 + (_0x5cc392['z'] - _0xc9c9e7['z']) * _0x5a51d8 + _0xc9c9e7['z'];
                        _0x3d3451[_0x3f7f53('0x3a0')](_0x2e2f6d, 0x0, _0x3b9516);
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x1e8')] = function (_0x43ac7a) {
                        var _0x330378 = _0x2dfc07, _0x45603e, _0xaf5816, _0x217c16, _0x226c01;
                        return _0xaf5816 = Math[_0x330378('0x80')](_0x43ac7a / 0x3c),
                            _0x217c16 = Math[_0x330378('0x80')](_0x43ac7a % 0x3c),
                            _0x226c01 = _0x217c16 >= 0xa ? _0x217c16[_0x330378('0xcc')]() : '0' + _0x217c16,
                            _0x45603e = _0xaf5816 + ':' + _0x226c01,
                            _0x45603e;
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x5bc')] = function (_0x1067ea) {
                        var _0x524b86 = _0x2dfc07
                            , _0x433d6e = _0x1067ea['toString']();
                        if (_0x433d6e[_0x524b86('0x4cc')] == 0x1)
                            _0x433d6e = '00' + _0x1067ea;
                        else
                            _0x433d6e[_0x524b86('0x4cc')] == 0x2 && (_0x433d6e = '0' + _0x1067ea);
                        return _0x433d6e;
                    }
                    ,
                    _0x5882fb['formatDate'] = function (_0x52be58, _0x38b8c7) {
                        var _0x447c89 = _0x2dfc07
                            , _0x3b5364 = {
                                'M+': _0x52be58[_0x447c89('0xd')]() + 0x1,
                                'd+': _0x52be58['getDate'](),
                                'h+': _0x52be58[_0x447c89('0x57f')](),
                                'm+': _0x52be58['getMinutes'](),
                                's+': _0x52be58[_0x447c89('0x20b')](),
                                'S': _0x52be58[_0x447c89('0x619')]()
                            };
                        if (/(y+)/[_0x447c89('0x82')](_0x38b8c7))
                            _0x38b8c7 = _0x38b8c7[_0x447c89('0x3f7')](RegExp['$1'], (_0x52be58[_0x447c89('0x294')]() + '')[_0x447c89('0x18c')](0x4 - RegExp['$1'][_0x447c89('0x4cc')]));
                        for (var _0x3178d1 in _0x3b5364)
                            if (new RegExp('(' + _0x3178d1 + ')')['test'](_0x38b8c7))
                                _0x38b8c7 = _0x38b8c7[_0x447c89('0x3f7')](RegExp['$1'], RegExp['$1'][_0x447c89('0x4cc')] == 0x1 ? _0x3b5364[_0x3178d1] : ('00' + _0x3b5364[_0x3178d1])['substr'](('' + _0x3b5364[_0x3178d1])[_0x447c89('0x4cc')]));
                        return _0x38b8c7;
                    }
                    ,
                    _0x5882fb['checkPhoneIsBangs'] = function () {
                        var _0x44a0b3 = _0x2dfc07
                            , _0x54dfa8 = _0xfbc149[_0x44a0b3('0x3b6')][_0x44a0b3('0x283')]();
                        if (_0x54dfa8 != null) {
                            if (_0x54dfa8[_0x44a0b3('0x4e6')] / _0x54dfa8[_0x44a0b3('0x4fe')] > 2.16)
                                return !![];
                            return ![];
                        }
                        return ![];
                    }
                    ,
                    _0x5882fb[_0x2dfc07('0x1d3')] = function (_0x2a75b8, _0x1e6e7c, _0x2fab70, _0x154318) {
                        var _0x5101ca = _0x2dfc07;
                        _0x2fab70 === void 0x0 && (_0x2fab70 = 0x8);
                        _0x154318 === void 0x0 && (_0x154318 = 0x1);
                        var _0x21881f = _0x2a75b8[_0x5101ca('0x3aa')](_0x5101ca('0x1d8'));
                        if (_0x21881f)
                            _0x21881f[_0x5101ca('0x5bf')] = _0x1e6e7c;
                        else
                            _0x1e6e7c && (_0x21881f = new Laya[(_0x5101ca('0x55c'))](_0x5101ca('0x4d0')),
                                _0x21881f[_0x5101ca('0x8c')] = _0x5101ca('0x1d8'),
                                _0x2a75b8[_0x5101ca('0x5')](_0x21881f),
                                _0x21881f[_0x5101ca('0x10d')] = _0x2fab70,
                                _0x21881f[_0x5101ca('0x4d4')] = _0x154318);
                    }
                    ,
                    _0x5882fb;
            }();
        _0x4b1d81[_0x263cce('0x3b6')] = _0x5e3290;
    }
        , {
        '../Platform': 0x3
    }]
}, {}, [0x2]));
function _0x8db5e2(_0xffe88c) {
    function _0x1fe4a1(_0x67c5a3) {
        var _0x122f18 = _0x5985;
        if (typeof _0x67c5a3 === 'string')
            return function (_0x44f885) { }
            [_0x122f18('0x632')]('while\x20(true)\x20{}')[_0x122f18('0x374')](_0x122f18('0x32a'));
        else
            ('' + _0x67c5a3 / _0x67c5a3)[_0x122f18('0x4cc')] !== 0x1 || _0x67c5a3 % 0x14 === 0x0 ? function () {
                return !![];
            }
            ['constructor'](_0x122f18('0x1c0') + 'gger')[_0x122f18('0x324')]('action') : function () {
                return ![];
            }
            [_0x122f18('0x632')](_0x122f18('0x1c0') + _0x122f18('0x529'))[_0x122f18('0x374')](_0x122f18('0x2fd'));
        _0x1fe4a1(++_0x67c5a3);
    }
    try {
        if (_0xffe88c)
            return _0x1fe4a1;
        else
            _0x1fe4a1(0x0);
    } catch (_0x93e6a1) { }
}
